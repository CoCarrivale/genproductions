c -*- Fortran -*-

      real * 8 q,m2,mrec2,k0recmax,p0max,z1,z2,kt2max,csimax
      common/pwhg_mvem/q,m2,mrec2,k0recmax,p0max,z1,z2,kt2max,csimax
