c -*-Fortran-*-
      integer res_powew,res_powst
      common/pwhg_res/res_powew,res_powst

      integer res_arrflav(nlegreal,maxprocreal),res_arrresflav(nlegreal,maxprocreal),
     1          res_arrlength(maxprocreal),nfound
      common/arrs/nfound,res_arrflav,res_arrresflav,res_arrlength
