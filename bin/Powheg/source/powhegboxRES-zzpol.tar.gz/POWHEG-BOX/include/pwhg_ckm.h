c -*- Fortran -*-
      logical ckm_diag,ckm_cabibbo
      common/pwhg_ckm/ckm_diag,ckm_cabibbo
