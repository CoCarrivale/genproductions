c -*- Fortran -*-
      real * 8 em_alpha,em_muren2
      common/pwhg_em/em_alpha,em_muren2
      save /pwhg_em/


c     when generating photon radiation, it is set to true.
      logical em_rad_on
      common /cem_rad_on/em_rad_on
      save /cem_rad_on/
