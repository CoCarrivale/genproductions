void calculate_ME2_VJ_QCD(      observable_set & oset);
void calculate_ME2check_VJ_QCD( observable_set & oset);
void calculate_ME2_VJ2_QCD(     observable_set & oset, call_generic & generic);
void calculate_ME2check_VJ2_QCD(observable_set & oset, call_generic & generic);
