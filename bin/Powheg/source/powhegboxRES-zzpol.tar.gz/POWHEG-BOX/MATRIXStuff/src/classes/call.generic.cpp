#include "header.hpp"
////////////////////
//  constructors  //
////////////////////
call_generic::call_generic(){}
