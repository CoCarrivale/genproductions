#include <classes.cxx>
/*
#include <iostream>

#include "header/coefficientfunctions.h"

using namespace std;
*/
// 2-loop helicity amplitude coefficients for qq_bar -> Wgam/Zgam,
// see T. Gehrmann, L. Tancredi, 1112.1531

void alpha_2_1(double u, double v, int n_f, double *GHPLs1, double *GHPLs2, double *GHPLs3, double *GHPLs4, double *HPLs1, double *HPLs2, double *HPLs3, double *HPLs4, double_complex &alpha) {
  //  const double zeta2 = M_PI*M_PI/6;
  //  const double zeta3 = 1.20205690315959429;
  //  const double zeta4 = pow(M_PI,4)/90;
  //  const double N=3;
  //  const double CF=(N*N-1)/(2*N);
  double NF=(double)n_f;

  alpha =
          (dN_c*dN_c-1)*pow(u,-2) * (
          - 1.0/4*GHPLs3[3*4*4+2*4+2]*HPLs1[0]
          + 1.0/4*GHPLs4[0*4*4*4+3*4*4+2*4+2]
          + 1.0/4*GHPLs2[2*4+2]*zeta2
          - 1.0/4*GHPLs2[2*4+2]*HPLs2[0*2+0]
          + 1.0/4*GHPLs2[2*4+2]*HPLs2[0*2+1]
          + 1.0/4*GHPLs3[0*4*4+2*4+2]*HPLs1[0]
          + 1.0/4*GHPLs1[2]*zeta3
          + 1.0/4*GHPLs1[2]*HPLs1[0]*zeta2
          - 1.0/4*GHPLs1[2]*HPLs3[0*2*2+0*2+0]
          + 1.0/4*GHPLs1[2]*HPLs3[0*2*2+1*2+0]
          + 1.0/4*GHPLs1[2]*HPLs3[0*2*2+0*2+1]
          + 1.0/4*GHPLs3[3*4*4+0*4+2]*HPLs1[0]
          - 1.0/4*GHPLs4[0*4*4*4+3*4*4+0*4+2]
          + 1.0/4*GHPLs2[0*4+2]*HPLs2[0*2+0]
          - 1.0/4*GHPLs3[3*4*4+2*4+1]*HPLs1[0]
          + 1.0/4*GHPLs4[0*4*4*4+3*4*4+2*4+1]
          + 1.0/4*GHPLs2[2*4+1]*zeta2
          - 1.0/4*GHPLs2[2*4+1]*HPLs2[0*2+0]
          + 1.0/4*GHPLs2[2*4+1]*HPLs2[0*2+1]
          + 1.0/4*GHPLs3[0*4*4+2*4+1]*HPLs1[0]
          + 1.0/4*GHPLs1[1]*zeta3
          - 1.0/4*GHPLs1[1]*HPLs1[0]*zeta2
          + 1.0/4*GHPLs1[1]*HPLs3[0*2*2+0*2+0]
          - 1.0/4*GHPLs1[1]*HPLs3[0*2*2+1*2+0]
          - 1.0/4*GHPLs1[1]*HPLs1[1]*zeta2
          + 1.0/4*GHPLs1[1]*HPLs3[0*2*2+0*2+1]
          - 1.0/4*GHPLs1[1]*HPLs3[0*2*2+1*2+1]
          - 1.0/4*GHPLs3[3*4*4+0*4+1]*HPLs1[0]
          + 1.0/4*GHPLs4[0*4*4*4+3*4*4+0*4+1]
          - 1.0/2*GHPLs2[0*4+1]*zeta2
          - 1.0/4*GHPLs2[0*4+1]*HPLs2[0*2+0]
          - 1.0/4*GHPLs2[0*4+1]*HPLs2[0*2+1]
          )

       + (dN_c*dN_c-1)*pow(u,-2)*v * (
          + 1.0/2*GHPLs3[3*4*4+2*4+2]*HPLs1[0]
          - 1.0/2*GHPLs4[0*4*4*4+3*4*4+2*4+2]
          - 1.0/2*GHPLs2[2*4+2]*zeta2
          + 1.0/2*GHPLs2[2*4+2]*HPLs2[0*2+0]
          - 1.0/2*GHPLs2[2*4+2]*HPLs2[0*2+1]
          - 1.0/2*GHPLs3[0*4*4+2*4+2]*HPLs1[0]
          - 1.0/2*GHPLs1[2]*zeta3
          - 1.0/2*GHPLs1[2]*HPLs1[0]*zeta2
          + 1.0/2*GHPLs1[2]*HPLs3[0*2*2+0*2+0]
          - 1.0/2*GHPLs1[2]*HPLs3[0*2*2+1*2+0]
          - 1.0/2*GHPLs1[2]*HPLs3[0*2*2+0*2+1]
          - 1.0/2*GHPLs3[3*4*4+0*4+2]*HPLs1[0]
          + 1.0/2*GHPLs4[0*4*4*4+3*4*4+0*4+2]
          - 1.0/2*GHPLs2[0*4+2]*HPLs2[0*2+0]
          + 1.0/2*GHPLs3[3*4*4+2*4+1]*HPLs1[0]
          - 1.0/2*GHPLs4[0*4*4*4+3*4*4+2*4+1]
          - 1.0/2*GHPLs2[2*4+1]*zeta2
          + 1.0/2*GHPLs2[2*4+1]*HPLs2[0*2+0]
          - 1.0/2*GHPLs2[2*4+1]*HPLs2[0*2+1]
          - 1.0/2*GHPLs3[0*4*4+2*4+1]*HPLs1[0]
          - 1.0/2*GHPLs1[1]*zeta3
          + 1.0/2*GHPLs1[1]*HPLs1[0]*zeta2
          - 1.0/2*GHPLs1[1]*HPLs3[0*2*2+0*2+0]
          + 1.0/2*GHPLs1[1]*HPLs3[0*2*2+1*2+0]
          + 1.0/2*GHPLs1[1]*HPLs1[1]*zeta2
          - 1.0/2*GHPLs1[1]*HPLs3[0*2*2+0*2+1]
          + 1.0/2*GHPLs1[1]*HPLs3[0*2*2+1*2+1]
          + 1.0/2*GHPLs3[3*4*4+0*4+1]*HPLs1[0]
          - 1.0/2*GHPLs4[0*4*4*4+3*4*4+0*4+1]
          + GHPLs2[0*4+1]*zeta2
          + 1.0/2*GHPLs2[0*4+1]*HPLs2[0*2+0]
          + 1.0/2*GHPLs2[0*4+1]*HPLs2[0*2+1]
          )

       + (dN_c*dN_c-1)*pow(u,-2)*pow(v,2) * (
          - 1.0/4*GHPLs3[3*4*4+2*4+2]*HPLs1[0]
          + 1.0/4*GHPLs4[0*4*4*4+3*4*4+2*4+2]
          + 1.0/4*GHPLs2[2*4+2]*zeta2
          - 1.0/4*GHPLs2[2*4+2]*HPLs2[0*2+0]
          + 1.0/4*GHPLs2[2*4+2]*HPLs2[0*2+1]
          + 1.0/4*GHPLs3[0*4*4+2*4+2]*HPLs1[0]
          + 1.0/4*GHPLs1[2]*zeta3
          + 1.0/4*GHPLs1[2]*HPLs1[0]*zeta2
          - 1.0/4*GHPLs1[2]*HPLs3[0*2*2+0*2+0]
          + 1.0/4*GHPLs1[2]*HPLs3[0*2*2+1*2+0]
          + 1.0/4*GHPLs1[2]*HPLs3[0*2*2+0*2+1]
          + 1.0/4*GHPLs3[3*4*4+0*4+2]*HPLs1[0]
          - 1.0/4*GHPLs4[0*4*4*4+3*4*4+0*4+2]
          + 1.0/4*GHPLs2[0*4+2]*HPLs2[0*2+0]
          - 1.0/4*GHPLs3[3*4*4+2*4+1]*HPLs1[0]
          + 1.0/4*GHPLs4[0*4*4*4+3*4*4+2*4+1]
          + 1.0/4*GHPLs2[2*4+1]*zeta2
          - 1.0/4*GHPLs2[2*4+1]*HPLs2[0*2+0]
          + 1.0/4*GHPLs2[2*4+1]*HPLs2[0*2+1]
          + 1.0/4*GHPLs3[0*4*4+2*4+1]*HPLs1[0]
          + 1.0/4*GHPLs1[1]*zeta3
          - 1.0/4*GHPLs1[1]*HPLs1[0]*zeta2
          + 1.0/4*GHPLs1[1]*HPLs3[0*2*2+0*2+0]
          - 1.0/4*GHPLs1[1]*HPLs3[0*2*2+1*2+0]
          - 1.0/4*GHPLs1[1]*HPLs1[1]*zeta2
          + 1.0/4*GHPLs1[1]*HPLs3[0*2*2+0*2+1]
          - 1.0/4*GHPLs1[1]*HPLs3[0*2*2+1*2+1]
          - 1.0/4*GHPLs3[3*4*4+0*4+1]*HPLs1[0]
          + 1.0/4*GHPLs4[0*4*4*4+3*4*4+0*4+1]
          - 1.0/2*GHPLs2[0*4+1]*zeta2
          - 1.0/4*GHPLs2[0*4+1]*HPLs2[0*2+0]
          - 1.0/4*GHPLs2[0*4+1]*HPLs2[0*2+1]
          )

       + (dN_c*dN_c-1)*pow(u,-1) * (
          - 1.0/2
          + 1.0/2*zeta2
          + 1.0/2*zeta3
          - 1.0/2*GHPLs2[3*4+2]*HPLs1[0]
          + 1.0/2*GHPLs3[0*4*4+3*4+2]
          + 1.0/2*GHPLs1[2]*zeta2
          - 1.0/2*GHPLs1[2]*HPLs2[0*2+0]
          + 1.0/2*GHPLs1[2]*HPLs2[0*2+1]
          + 1.0/2*GHPLs2[0*4+2]*HPLs1[0]
          - 1.0/2*GHPLs1[0]*zeta2
          - 1.0/4*GHPLs1[0]*HPLs2[0*2+1]
          - 1.0/4*HPLs1[1]*zeta2
          + 1.0/4*HPLs2[0*2+1]
          + 1.0/2*HPLs3[0*2*2+0*2+1]
          - 1.0/4*HPLs3[0*2*2+1*2+1]
          )

       + (dN_c*dN_c-1)*pow(u,-1)*v * (
          + 1.0/2
          - zeta2
          - 3.0/4*zeta3
          + 3.0/4*GHPLs2[3*4+2]*HPLs1[0]
          - 3.0/4*GHPLs3[0*4*4+3*4+2]
          - 3.0/4*GHPLs1[2]*zeta2
          + 3.0/4*GHPLs1[2]*HPLs2[0*2+0]
          - 3.0/4*GHPLs1[2]*HPLs2[0*2+1]
          - 3.0/4*GHPLs2[0*4+2]*HPLs1[0]
          - 1.0/4*GHPLs1[3]*HPLs1[0]
          + 1.0/4*GHPLs2[0*4+3]
          + 1.0/4*GHPLs2[3*4+0]*HPLs1[0]
          - 1.0/4*GHPLs3[0*4*4+3*4+0]
          + GHPLs1[0]*zeta2
          + 1.0/4*GHPLs1[0]*HPLs2[0*2+0]
          + 1.0/2*GHPLs1[0]*HPLs2[0*2+1]
          + 1.0/4*HPLs1[0]*zeta2
          - 1.0/4*HPLs2[0*2+0]
          - 1.0/4*HPLs3[0*2*2+0*2+0]
          + 1.0/4*HPLs3[0*2*2+1*2+0]
          + 1.0/2*HPLs1[1]*zeta2
          - 1.0/2*HPLs2[0*2+1]
          - 3.0/4*HPLs3[0*2*2+0*2+1]
          + 1.0/2*HPLs3[0*2*2+1*2+1]
          )

       + (dN_c*dN_c-1)*pow(u,-1)*pow(v,2) * (
          + 1.0/2*zeta2
          + 1.0/4*zeta3
          - 1.0/4*GHPLs2[3*4+2]*HPLs1[0]
          + 1.0/4*GHPLs3[0*4*4+3*4+2]
          + 1.0/4*GHPLs1[2]*zeta2
          - 1.0/4*GHPLs1[2]*HPLs2[0*2+0]
          + 1.0/4*GHPLs1[2]*HPLs2[0*2+1]
          + 1.0/4*GHPLs2[0*4+2]*HPLs1[0]
          + 1.0/4*GHPLs1[3]*HPLs1[0]
          - 1.0/4*GHPLs2[0*4+3]
          - 1.0/4*GHPLs2[3*4+0]*HPLs1[0]
          + 1.0/4*GHPLs3[0*4*4+3*4+0]
          - 1.0/2*GHPLs1[0]*zeta2
          - 1.0/4*GHPLs1[0]*HPLs2[0*2+0]
          - 1.0/4*GHPLs1[0]*HPLs2[0*2+1]
          - 1.0/4*HPLs1[0]*zeta2
          + 1.0/4*HPLs2[0*2+0]
          + 1.0/4*HPLs3[0*2*2+0*2+0]
          - 1.0/4*HPLs3[0*2*2+1*2+0]
          - 1.0/4*HPLs1[1]*zeta2
          + 1.0/4*HPLs2[0*2+1]
          + 1.0/4*HPLs3[0*2*2+0*2+1]
          - 1.0/4*HPLs3[0*2*2+1*2+1]
          )

       + (dN_c*dN_c-1)*pow(1-u,-1) * (
          - 1.0/8*zeta2
          + 1.0/8*GHPLs1[3]*HPLs1[0]
          - 1.0/8*GHPLs2[0*4+3]
          - 1.0/8*GHPLs1[0]*HPLs1[0]
          + 1.0/8*HPLs2[0*2+0]
          - 1.0/8*HPLs2[0*2+1]
          )

       + (dN_c*dN_c-1)*pow(u+v,-1) * (
          - 1.0/16
          - 1.0/16*GHPLs1[0]
          + 1.0/16*HPLs1[0]
          )

       + (dN_c*dN_c-1) * (
          + 17.0/16
          - 5.0/16*zeta4
          + 259.0/144*zeta2
          + 7.0/6*zeta3
          + 1.0/4*GHPLs3[3*4*4+2*4+2]*HPLs1[0]
          - 1.0/4*GHPLs4[0*4*4*4+3*4*4+2*4+2]
          - 1.0/4*GHPLs2[2*4+2]*zeta2
          + 1.0/4*GHPLs2[2*4+2]*HPLs2[0*2+0]
          - 1.0/4*GHPLs2[2*4+2]*HPLs2[0*2+1]
          - 1.0/4*GHPLs3[0*4*4+2*4+2]*HPLs1[0]
          - 1.0/4*GHPLs2[3*4+2]*HPLs1[0]
          + 1.0/4*GHPLs3[0*4*4+3*4+2]
          + 1.0/4*GHPLs1[2]*zeta2
          - 1.0/4*GHPLs1[2]*zeta3
          - 1.0/4*GHPLs1[2]*HPLs1[0]*zeta2
          - 1.0/4*GHPLs1[2]*HPLs2[0*2+0]
          + 1.0/4*GHPLs1[2]*HPLs3[0*2*2+0*2+0]
          - 1.0/4*GHPLs1[2]*HPLs3[0*2*2+1*2+0]
          + 1.0/4*GHPLs1[2]*HPLs2[0*2+1]
          - 1.0/4*GHPLs1[2]*HPLs3[0*2*2+0*2+1]
          - 1.0/4*GHPLs3[3*4*4+0*4+2]*HPLs1[0]
          + 1.0/4*GHPLs4[0*4*4*4+3*4*4+0*4+2]
          + 1.0/4*GHPLs2[0*4+2]*HPLs1[0]
          - 1.0/4*GHPLs2[0*4+2]*HPLs2[0*2+0]
          + 1.0/4*GHPLs3[3*4*4+2*4+3]*HPLs1[0]
          - 1.0/4*GHPLs4[0*4*4*4+3*4*4+2*4+3]
          - 1.0/4*GHPLs2[2*4+3]*zeta2
          + 1.0/4*GHPLs2[2*4+3]*HPLs2[0*2+0]
          - 1.0/4*GHPLs2[2*4+3]*HPLs2[0*2+1]
          - 1.0/4*GHPLs3[0*4*4+2*4+3]*HPLs1[0]
          + 1.0/2*GHPLs3[3*4*4+3*4+3]*HPLs1[0]
          - 1.0/2*GHPLs4[0*4*4*4+3*4*4+3*4+3]
          - GHPLs2[3*4+3]*zeta2
          + 11.0/12*GHPLs2[3*4+3]*HPLs1[0]
          + 1.0/2*GHPLs2[3*4+3]*HPLs2[0*2+0]
          - 11.0/12*GHPLs3[0*4*4+3*4+3]
          - 1.0/2*GHPLs3[0*4*4+3*4+3]*HPLs1[0]
          + 1.0/2*GHPLs4[0*4*4*4+0*4*4+3*4+3]
          - 11.0/6*GHPLs1[3]*zeta2
          - 1.0/2*GHPLs1[3]*zeta3
          - 331.0/144*GHPLs1[3]*HPLs1[0]
          - 5.0/4*GHPLs1[3]*HPLs1[0]*zeta2
          - 11.0/12*GHPLs1[3]*HPLs2[0*2+0]
          + 3.0/4*GHPLs1[3]*HPLs3[0*2*2+0*2+0]
          - 1.0/4*GHPLs1[3]*HPLs3[0*2*2+1*2+0]
          + 1.0/4*GHPLs1[3]*HPLs1[1]*zeta2
          - 1.0/4*GHPLs1[3]*HPLs3[0*2*2+0*2+1]
          + 1.0/4*GHPLs1[3]*HPLs3[0*2*2+1*2+1]
          - 3.0/4*GHPLs3[3*4*4+0*4+3]*HPLs1[0]
          + 3.0/4*GHPLs4[0*4*4*4+3*4*4+0*4+3]
          + 331.0/144*GHPLs2[0*4+3]
          - 1.0/4*GHPLs2[0*4+3]*zeta2
          + 11.0/12*GHPLs2[0*4+3]*HPLs1[0]
          - 3.0/4*GHPLs2[0*4+3]*HPLs2[0*2+0]
          + 1.0/4*GHPLs2[0*4+3]*HPLs2[0*2+1]
          - 11.0/12*GHPLs3[0*4*4+0*4+3]
          + 1.0/2*GHPLs3[0*4*4+0*4+3]*HPLs1[0]
          - 1.0/2*GHPLs3[3*4*4+2*4+0]*HPLs1[0]
          + 1.0/2*GHPLs4[0*4*4*4+3*4*4+2*4+0]
          + 1.0/2*GHPLs2[2*4+0]*zeta2
          - 1.0/2*GHPLs2[2*4+0]*HPLs2[0*2+0]
          + 1.0/2*GHPLs2[2*4+0]*HPLs2[0*2+1]
          + 1.0/2*GHPLs3[0*4*4+2*4+0]*HPLs1[0]
          - 1.0/2*GHPLs3[3*4*4+3*4+0]*HPLs1[0]
          + 1.0/2*GHPLs4[0*4*4*4+3*4*4+3*4+0]
          - 1.0/2*GHPLs2[3*4+0]*zeta2
          - 1.0/2*GHPLs2[3*4+0]*HPLs2[0*2+0]
          + 1.0/4*GHPLs3[0*4*4+3*4+0]*HPLs1[0]
          - 1.0/16*GHPLs1[0]
          - 7.0/6*GHPLs1[0]*zeta2
          + 331.0/144*GHPLs1[0]*HPLs1[0]
          - 1.0/4*GHPLs1[0]*HPLs1[0]*zeta2
          + 11.0/6*GHPLs1[0]*HPLs2[0*2+0]
          - 3.0/4*GHPLs1[0]*HPLs3[0*2*2+0*2+0]
          + 1.0/4*GHPLs1[0]*HPLs3[0*2*2+1*2+0]
          - 25.0/24*GHPLs1[0]*HPLs2[0*2+1]
          + 1.0/2*GHPLs1[0]*HPLs3[0*2*2+0*2+1]
          + 1.0/2*GHPLs3[3*4*4+0*4+0]*HPLs1[0]
          - 1.0/2*GHPLs4[0*4*4*4+3*4*4+0*4+0]
          - 11.0/12*GHPLs2[0*4+0]*HPLs1[0]
          + 1.0/2*GHPLs2[0*4+0]*HPLs2[0*2+0]
          + 1.0/4*GHPLs3[3*4*4+2*4+1]*HPLs1[0]
          - 1.0/4*GHPLs4[0*4*4*4+3*4*4+2*4+1]
          - 1.0/4*GHPLs2[2*4+1]*zeta2
          + 1.0/4*GHPLs2[2*4+1]*HPLs2[0*2+0]
          - 1.0/4*GHPLs2[2*4+1]*HPLs2[0*2+1]
          - 1.0/4*GHPLs3[0*4*4+2*4+1]*HPLs1[0]
          - 1.0/4*GHPLs1[1]*zeta3
          + 1.0/4*GHPLs1[1]*HPLs1[0]*zeta2
          - 1.0/4*GHPLs1[1]*HPLs3[0*2*2+0*2+0]
          + 1.0/4*GHPLs1[1]*HPLs3[0*2*2+1*2+0]
          + 1.0/4*GHPLs1[1]*HPLs1[1]*zeta2
          - 1.0/4*GHPLs1[1]*HPLs3[0*2*2+0*2+1]
          + 1.0/4*GHPLs1[1]*HPLs3[0*2*2+1*2+1]
          + 1.0/4*GHPLs3[3*4*4+0*4+1]*HPLs1[0]
          - 1.0/4*GHPLs4[0*4*4*4+3*4*4+0*4+1]
          + 1.0/2*GHPLs2[0*4+1]*zeta2
          + 1.0/4*GHPLs2[0*4+1]*HPLs2[0*2+0]
          + 1.0/4*GHPLs2[0*4+1]*HPLs2[0*2+1]
          - 3.0/16*HPLs1[0]
          - 11.0/12*HPLs1[0]*zeta2
          - 1.0/2*HPLs1[0]*zeta3
          - 331.0/144*HPLs2[0*2+0]
          - 5.0/4*HPLs2[0*2+0]*zeta2
          - 11.0/6*HPLs3[0*2*2+0*2+0]
          + 3.0/4*HPLs4[0*2*2*2+0*2*2+0*2+0]
          - 1.0/4*HPLs4[0*2*2*2+1*2*2+0*2+0]
          + 1.0/4*HPLs2[1*2+0]*zeta2
          + 11.0/12*HPLs3[0*2*2+1*2+0]
          - 1.0/4*HPLs4[0*2*2*2+0*2*2+1*2+0]
          + 1.0/4*HPLs4[0*2*2*2+1*2*2+1*2+0]
          - 25.0/24*HPLs1[1]*zeta2
          + 1.0/2*HPLs1[1]*zeta3
          + 295.0/144*HPLs2[0*2+1]
          + 1.0/2*HPLs2[0*2+1]*zeta2
          + 25.0/12*HPLs3[0*2*2+0*2+1]
          - 1.0/2*HPLs4[0*2*2*2+0*2*2+0*2+1]
          + 1.0/2*HPLs4[0*2*2*2+1*2*2+0*2+1]
          - 25.0/24*HPLs3[0*2*2+1*2+1]
          + 1.0/2*HPLs4[0*2*2*2+0*2*2+1*2+1]
          )

       + (dN_c*dN_c-1)*v*pow(1-u,-2) * (
          + 1.0/4*zeta2
          - 1.0/4*zeta3
          + 1.0/4*GHPLs2[3*4+2]*HPLs1[0]
          - 1.0/4*GHPLs3[0*4*4+3*4+2]
          - 1.0/4*GHPLs1[2]*zeta2
          + 1.0/4*GHPLs1[2]*HPLs2[0*2+0]
          - 1.0/4*GHPLs1[2]*HPLs2[0*2+1]
          - 1.0/4*GHPLs2[0*4+2]*HPLs1[0]
          - 1.0/4*GHPLs1[3]*HPLs1[0]
          + 1.0/4*GHPLs2[0*4+3]
          + 1.0/4*GHPLs2[3*4+0]*HPLs1[0]
          - 1.0/4*GHPLs3[0*4*4+3*4+0]
          + 1.0/2*GHPLs1[0]*zeta2
          + 1.0/4*GHPLs1[0]*HPLs1[0]
          + 1.0/4*GHPLs1[0]*HPLs2[0*2+0]
          + 1.0/4*GHPLs1[0]*HPLs2[0*2+1]
          + 1.0/4*HPLs1[0]*zeta2
          - 1.0/4*HPLs2[0*2+0]
          - 1.0/4*HPLs3[0*2*2+0*2+0]
          + 1.0/4*HPLs3[0*2*2+1*2+0]
          + 1.0/4*HPLs1[1]*zeta2
          + 1.0/4*HPLs2[0*2+1]
          - 1.0/4*HPLs3[0*2*2+0*2+1]
          + 1.0/4*HPLs3[0*2*2+1*2+1]
          )

       + (dN_c*dN_c-1)*v*pow(1-u,-1) * (
          + 1.0/8*zeta2
          + 5.0/8*GHPLs1[3]*HPLs1[0]
          - 5.0/8*GHPLs2[0*4+3]
          + 1.0/8*GHPLs1[0]
          - 3.0/8*GHPLs1[0]*HPLs1[0]
          + 5.0/8*HPLs2[0*2+0]
          - 1.0/8*HPLs2[0*2+1]
          )

       + (dN_c*dN_c-1)*pow(v,2)*pow(1-u,-3) * (
          + 1.0/4*zeta3
          - 1.0/4*GHPLs2[3*4+2]*HPLs1[0]
          + 1.0/4*GHPLs3[0*4*4+3*4+2]
          + 1.0/4*GHPLs1[2]*zeta2
          - 1.0/4*GHPLs1[2]*HPLs2[0*2+0]
          + 1.0/4*GHPLs1[2]*HPLs2[0*2+1]
          + 1.0/4*GHPLs2[0*4+2]*HPLs1[0]
          - 1.0/4*GHPLs2[3*4+0]*HPLs1[0]
          + 1.0/4*GHPLs3[0*4*4+3*4+0]
          - 1.0/2*GHPLs1[0]*zeta2
          - 1.0/4*GHPLs1[0]*HPLs2[0*2+0]
          - 1.0/4*GHPLs1[0]*HPLs2[0*2+1]
          - 1.0/4*HPLs1[0]*zeta2
          + 1.0/4*HPLs3[0*2*2+0*2+0]
          - 1.0/4*HPLs3[0*2*2+1*2+0]
          - 1.0/4*HPLs1[1]*zeta2
          + 1.0/4*HPLs3[0*2*2+0*2+1]
          - 1.0/4*HPLs3[0*2*2+1*2+1]
          )

       + (dN_c*dN_c-1)*pow(v,2)*pow(1-u,-2) * (
          - 1.0/2*zeta2
          - 3.0/8*zeta3
          + 3.0/8*GHPLs2[3*4+2]*HPLs1[0]
          - 3.0/8*GHPLs3[0*4*4+3*4+2]
          - 3.0/8*GHPLs1[2]*zeta2
          + 3.0/8*GHPLs1[2]*HPLs2[0*2+0]
          - 3.0/8*GHPLs1[2]*HPLs2[0*2+1]
          - 3.0/8*GHPLs2[0*4+2]*HPLs1[0]
          - 1.0/4*GHPLs1[3]*HPLs1[0]
          + 1.0/4*GHPLs2[0*4+3]
          + 3.0/8*GHPLs2[3*4+0]*HPLs1[0]
          - 3.0/8*GHPLs3[0*4*4+3*4+0]
          + 3.0/4*GHPLs1[0]*zeta2
          + 3.0/8*GHPLs1[0]*HPLs2[0*2+0]
          + 3.0/8*GHPLs1[0]*HPLs2[0*2+1]
          + 3.0/8*HPLs1[0]*zeta2
          - 1.0/4*HPLs2[0*2+0]
          - 3.0/8*HPLs3[0*2*2+0*2+0]
          + 3.0/8*HPLs3[0*2*2+1*2+0]
          + 3.0/8*HPLs1[1]*zeta2
          - 1.0/4*HPLs2[0*2+1]
          - 3.0/8*HPLs3[0*2*2+0*2+1]
          + 3.0/8*HPLs3[0*2*2+1*2+1]
          )

       + (dN_c*dN_c-1)*pow(v,2)*pow(1-u,-1) * (
          + 1.0/2*zeta2
          + 1.0/4*zeta3
          - 1.0/4*GHPLs2[3*4+2]*HPLs1[0]
          + 1.0/4*GHPLs3[0*4*4+3*4+2]
          + 1.0/4*GHPLs1[2]*zeta2
          - 1.0/4*GHPLs1[2]*HPLs2[0*2+0]
          + 1.0/4*GHPLs1[2]*HPLs2[0*2+1]
          + 1.0/4*GHPLs2[0*4+2]*HPLs1[0]
          + 1.0/4*GHPLs1[3]*HPLs1[0]
          - 1.0/4*GHPLs2[0*4+3]
          - 1.0/4*GHPLs2[3*4+0]*HPLs1[0]
          + 1.0/4*GHPLs3[0*4*4+3*4+0]
          - 1.0/2*GHPLs1[0]*zeta2
          - 1.0/4*GHPLs1[0]*HPLs2[0*2+0]
          - 1.0/4*GHPLs1[0]*HPLs2[0*2+1]
          - 1.0/4*HPLs1[0]*zeta2
          + 1.0/4*HPLs2[0*2+0]
          + 1.0/4*HPLs3[0*2*2+0*2+0]
          - 1.0/4*HPLs3[0*2*2+1*2+0]
          - 1.0/4*HPLs1[1]*zeta2
          + 1.0/4*HPLs2[0*2+1]
          + 1.0/4*HPLs3[0*2*2+0*2+1]
          - 1.0/4*HPLs3[0*2*2+1*2+1]
          )

       + (dN_c*dN_c-1)*u*pow(u+v,-2) * (
          + 1.0/16*GHPLs1[0]
          - 1.0/16*HPLs1[0]
          )

       + (dN_c*dN_c-1)*u*pow(u+v,-1) * (
          - 3.0/16*GHPLs1[0]
          + 3.0/16*HPLs1[0]
          )

       + (dN_c*dN_c-1)*u*pow(1-u-v,-1) * (
          - 1.0/8*zeta2
          + 1.0/8*GHPLs1[3]*HPLs1[0]
          - 1.0/8*GHPLs2[0*4+3]
          - 1.0/8*GHPLs1[0]*HPLs1[0]
          + 1.0/8*HPLs2[0*2+0]
          - 1.0/8*HPLs2[0*2+1]
          )

       + (dN_c*dN_c-1)*double_complex(0,1)*M_PI*pow(u,-2) * (
          + 1.0/4*GHPLs3[3*4*4+2*4+2]
          + 1.0/4*GHPLs2[2*4+2]*HPLs1[0]
          + 1.0/4*GHPLs1[2]*HPLs2[0*2+0]
          - 1.0/4*GHPLs3[3*4*4+0*4+2]
          + 1.0/4*GHPLs3[3*4*4+2*4+1]
          + 1.0/4*GHPLs2[2*4+1]*HPLs1[0]
          - 1.0/2*GHPLs1[1]*zeta2
          - 1.0/4*GHPLs1[1]*HPLs2[0*2+0]
          - 1.0/4*GHPLs1[1]*HPLs2[0*2+1]
          + 1.0/4*GHPLs3[3*4*4+0*4+1]
          )

       + (dN_c*dN_c-1)*double_complex(0,1)*M_PI*pow(u,-2)*v * (
          - 1.0/2*GHPLs3[3*4*4+2*4+2]
          - 1.0/2*GHPLs2[2*4+2]*HPLs1[0]
          - 1.0/2*GHPLs1[2]*HPLs2[0*2+0]
          + 1.0/2*GHPLs3[3*4*4+0*4+2]
          - 1.0/2*GHPLs3[3*4*4+2*4+1]
          - 1.0/2*GHPLs2[2*4+1]*HPLs1[0]
          + GHPLs1[1]*zeta2
          + 1.0/2*GHPLs1[1]*HPLs2[0*2+0]
          + 1.0/2*GHPLs1[1]*HPLs2[0*2+1]
          - 1.0/2*GHPLs3[3*4*4+0*4+1]
          )

       + (dN_c*dN_c-1)*double_complex(0,1)*M_PI*pow(u,-2)*pow(v,2) * (
          + 1.0/4*GHPLs3[3*4*4+2*4+2]
          + 1.0/4*GHPLs2[2*4+2]*HPLs1[0]
          + 1.0/4*GHPLs1[2]*HPLs2[0*2+0]
          - 1.0/4*GHPLs3[3*4*4+0*4+2]
          + 1.0/4*GHPLs3[3*4*4+2*4+1]
          + 1.0/4*GHPLs2[2*4+1]*HPLs1[0]
          - 1.0/2*GHPLs1[1]*zeta2
          - 1.0/4*GHPLs1[1]*HPLs2[0*2+0]
          - 1.0/4*GHPLs1[1]*HPLs2[0*2+1]
          + 1.0/4*GHPLs3[3*4*4+0*4+1]
          )

       + (dN_c*dN_c-1)*double_complex(0,1)*M_PI*pow(u,-1) * (
          - 1.0/2*zeta2
          + 1.0/2*GHPLs2[3*4+2]
          + 1.0/2*GHPLs1[2]*HPLs1[0]
          - 1.0/4*HPLs2[0*2+1]
          )

       + (dN_c*dN_c-1)*double_complex(0,1)*M_PI*pow(u,-1)*v * (
          + zeta2
          - 3.0/4*GHPLs2[3*4+2]
          - 3.0/4*GHPLs1[2]*HPLs1[0]
          + 1.0/4*GHPLs1[3]
          - 1.0/4*GHPLs2[3*4+0]
          + 1.0/4*HPLs2[0*2+0]
          + 1.0/2*HPLs2[0*2+1]
          )

       + (dN_c*dN_c-1)*double_complex(0,1)*M_PI*pow(u,-1)*pow(v,2) * (
          - 1.0/2*zeta2
          + 1.0/4*GHPLs2[3*4+2]
          + 1.0/4*GHPLs1[2]*HPLs1[0]
          - 1.0/4*GHPLs1[3]
          + 1.0/4*GHPLs2[3*4+0]
          - 1.0/4*HPLs2[0*2+0]
          - 1.0/4*HPLs2[0*2+1]
          )

       + (dN_c*dN_c-1)*double_complex(0,1)*M_PI*pow(1-u,-1) * (
          - 1.0/8*GHPLs1[3]
          - 1.0/8*HPLs1[0]
          )

       + (dN_c*dN_c-1)*double_complex(0,1)*M_PI*pow(u+v,-1) * (
          - 1.0/16
          )

       + (dN_c*dN_c-1)*double_complex(0,1)*M_PI * (
          - 1.0/16
          - 1.0/4*zeta2
          - 1.0/4*GHPLs3[3*4*4+2*4+2]
          - 1.0/4*GHPLs2[2*4+2]*HPLs1[0]
          + 1.0/4*GHPLs2[3*4+2]
          + 1.0/4*GHPLs1[2]*HPLs1[0]
          - 1.0/4*GHPLs1[2]*HPLs2[0*2+0]
          + 1.0/4*GHPLs3[3*4*4+0*4+2]
          - 1.0/4*GHPLs3[3*4*4+2*4+3]
          - 1.0/4*GHPLs2[2*4+3]*HPLs1[0]
          - 1.0/2*GHPLs3[3*4*4+3*4+3]
          - 11.0/12*GHPLs2[3*4+3]
          - 1.0/2*GHPLs2[3*4+3]*HPLs1[0]
          + 1.0/2*GHPLs3[0*4*4+3*4+3]
          + 331.0/144*GHPLs1[3]
          - 1.0/4*GHPLs1[3]*zeta2
          - 3.0/4*GHPLs1[3]*HPLs2[0*2+0]
          + 1.0/4*GHPLs1[3]*HPLs2[0*2+1]
          + 3.0/4*GHPLs3[3*4*4+0*4+3]
          + 1.0/2*GHPLs2[0*4+3]*HPLs1[0]
          + 1.0/2*GHPLs3[3*4*4+2*4+0]
          + 1.0/2*GHPLs2[2*4+0]*HPLs1[0]
          + 1.0/2*GHPLs3[3*4*4+3*4+0]
          + 1.0/4*GHPLs2[3*4+0]*HPLs1[0]
          + 1.0/2*GHPLs1[0]*HPLs2[0*2+0]
          - 1.0/2*GHPLs3[3*4*4+0*4+0]
          - 1.0/4*GHPLs3[3*4*4+2*4+1]
          - 1.0/4*GHPLs2[2*4+1]*HPLs1[0]
          + 1.0/2*GHPLs1[1]*zeta2
          + 1.0/4*GHPLs1[1]*HPLs2[0*2+0]
          + 1.0/4*GHPLs1[1]*HPLs2[0*2+1]
          - 1.0/4*GHPLs3[3*4*4+0*4+1]
          + 331.0/144*HPLs1[0]
          - 1.0/4*HPLs1[0]*zeta2
          + 11.0/12*HPLs2[0*2+0]
          - 3.0/4*HPLs3[0*2*2+0*2+0]
          + 1.0/4*HPLs3[0*2*2+1*2+0]
          - 1.0/8*HPLs2[0*2+1]
          + 1.0/2*HPLs3[0*2*2+0*2+1]
          )

       + (dN_c*dN_c-1)*double_complex(0,1)*M_PI*v*pow(1-u,-2) * (
          + 1.0/2*zeta2
          - 1.0/4*GHPLs2[3*4+2]
          - 1.0/4*GHPLs1[2]*HPLs1[0]
          + 1.0/4*GHPLs1[3]
          - 1.0/4*GHPLs2[3*4+0]
          + 1.0/4*HPLs1[0]
          + 1.0/4*HPLs2[0*2+0]
          + 1.0/4*HPLs2[0*2+1]
          )

       + (dN_c*dN_c-1)*double_complex(0,1)*M_PI*v*pow(1-u,-1) * (
          + 1.0/8
          - 5.0/8*GHPLs1[3]
          - 3.0/8*HPLs1[0]
          )

       + (dN_c*dN_c-1)*double_complex(0,1)*M_PI*pow(v,2)*pow(1-u,-3) * (
          - 1.0/2*zeta2
          + 1.0/4*GHPLs2[3*4+2]
          + 1.0/4*GHPLs1[2]*HPLs1[0]
          + 1.0/4*GHPLs2[3*4+0]
          - 1.0/4*HPLs2[0*2+0]
          - 1.0/4*HPLs2[0*2+1]
          )

       + (dN_c*dN_c-1)*double_complex(0,1)*M_PI*pow(v,2)*pow(1-u,-2) * (
          + 3.0/4*zeta2
          - 3.0/8*GHPLs2[3*4+2]
          - 3.0/8*GHPLs1[2]*HPLs1[0]
          + 1.0/4*GHPLs1[3]
          - 3.0/8*GHPLs2[3*4+0]
          + 3.0/8*HPLs2[0*2+0]
          + 3.0/8*HPLs2[0*2+1]
          )

       + (dN_c*dN_c-1)*double_complex(0,1)*M_PI*pow(v,2)*pow(1-u,-1) * (
          - 1.0/2*zeta2
          + 1.0/4*GHPLs2[3*4+2]
          + 1.0/4*GHPLs1[2]*HPLs1[0]
          - 1.0/4*GHPLs1[3]
          + 1.0/4*GHPLs2[3*4+0]
          - 1.0/4*HPLs2[0*2+0]
          - 1.0/4*HPLs2[0*2+1]
          )

       + (dN_c*dN_c-1)*double_complex(0,1)*M_PI*u*pow(u+v,-2) * (
          + 1.0/16
          )

       + (dN_c*dN_c-1)*double_complex(0,1)*M_PI*u*pow(u+v,-1) * (
          - 3.0/16
          )

       + (dN_c*dN_c-1)*double_complex(0,1)*M_PI*u*pow(1-u-v,-1) * (
          - 1.0/8*GHPLs1[3]
          - 1.0/8*HPLs1[0]
          )

       + (dN_c*dN_c-1)/(dN_c*dN_c)*pow(u,-2) * (
          + 1.0/4*GHPLs3[3*4*4+2*4+2]*HPLs1[0]
          - 1.0/4*GHPLs4[0*4*4*4+3*4*4+2*4+2]
          - 1.0/4*GHPLs2[2*4+2]*zeta2
          + 1.0/4*GHPLs2[2*4+2]*HPLs2[0*2+0]
          - 1.0/4*GHPLs2[2*4+2]*HPLs2[0*2+1]
          - 1.0/4*GHPLs3[0*4*4+2*4+2]*HPLs1[0]
          + 3.0/8*GHPLs1[2]*zeta2
          - 1.0/4*GHPLs1[2]*zeta3
          + 1.0/4*GHPLs1[2]*HPLs1[0]
          - 1.0/4*GHPLs1[2]*HPLs1[0]*zeta2
          - 1.0/8*GHPLs1[2]*HPLs2[0*2+0]
          + 1.0/4*GHPLs1[2]*HPLs3[0*2*2+0*2+0]
          - 1.0/4*GHPLs1[2]*HPLs2[1*2+0]
          - 1.0/4*GHPLs1[2]*HPLs3[0*2*2+1*2+0]
          + 1.0/8*GHPLs1[2]*HPLs2[0*2+1]
          - 1.0/4*GHPLs1[2]*HPLs3[0*2*2+0*2+1]
          - 1.0/4*GHPLs3[3*4*4+0*4+2]*HPLs1[0]
          + 1.0/4*GHPLs4[0*4*4*4+3*4*4+0*4+2]
          - 1.0/4*GHPLs2[0*4+2]*HPLs2[0*2+0]
          - 1.0/4*GHPLs3[2*4*4+1*4+2]
          + 1.0/4*GHPLs2[1*4+2]*HPLs1[0]
          + 1.0/4*GHPLs2[1*4+2]*HPLs1[1]
          + 1.0/8*GHPLs2[2*4+0]*HPLs1[0]
          + 1.0/8*GHPLs3[2*4*4+1*4+0]
          - 1.0/8*GHPLs2[1*4+0]*HPLs1[0]
          - 1.0/8*GHPLs2[1*4+0]*HPLs1[1]
          + 1.0/4*GHPLs3[3*4*4+2*4+1]*HPLs1[0]
          - 1.0/4*GHPLs4[0*4*4*4+3*4*4+2*4+1]
          + 1.0/4*GHPLs2[2*4+1]
          - 1.0/4*GHPLs2[2*4+1]*zeta2
          + 1.0/4*GHPLs2[2*4+1]*HPLs2[0*2+0]
          - 1.0/4*GHPLs2[2*4+1]*HPLs2[0*2+1]
          - 1.0/4*GHPLs3[0*4*4+2*4+1]*HPLs1[0]
          - 1.0/4*GHPLs1[1]*zeta2
          - 1.0/4*GHPLs1[1]*zeta3
          - 1.0/4*GHPLs1[1]*HPLs1[0]
          + 1.0/4*GHPLs1[1]*HPLs1[0]*zeta2
          + 1.0/8*GHPLs1[1]*HPLs2[0*2+0]
          - 1.0/4*GHPLs1[1]*HPLs3[0*2*2+0*2+0]
          + 1.0/8*GHPLs1[1]*HPLs2[1*2+0]
          + 1.0/4*GHPLs1[1]*HPLs3[0*2*2+1*2+0]
          - 1.0/4*GHPLs1[1]*HPLs1[1]
          + 1.0/4*GHPLs1[1]*HPLs1[1]*zeta2
          - 1.0/4*GHPLs1[1]*HPLs3[0*2*2+0*2+1]
          + 1.0/4*GHPLs1[1]*HPLs3[0*2*2+1*2+1]
          + 1.0/4*GHPLs3[3*4*4+0*4+1]*HPLs1[0]
          - 1.0/4*GHPLs4[0*4*4*4+3*4*4+0*4+1]
          + 1.0/2*GHPLs2[0*4+1]*zeta2
          + 1.0/4*GHPLs2[0*4+1]*HPLs2[0*2+0]
          + 1.0/4*GHPLs2[0*4+1]*HPLs2[0*2+1]
          + 1.0/8*GHPLs3[2*4*4+1*4+1]
          - 1.0/8*GHPLs2[1*4+1]*HPLs1[0]
          - 1.0/8*GHPLs2[1*4+1]*HPLs1[1]
          )

       + (dN_c*dN_c-1)/(dN_c*dN_c)*pow(u,-2)*v * (
          - 1.0/2*GHPLs3[3*4*4+2*4+2]*HPLs1[0]
          + 1.0/2*GHPLs4[0*4*4*4+3*4*4+2*4+2]
          + 1.0/2*GHPLs2[2*4+2]*zeta2
          - 1.0/2*GHPLs2[2*4+2]*HPLs2[0*2+0]
          + 1.0/2*GHPLs2[2*4+2]*HPLs2[0*2+1]
          + 1.0/2*GHPLs3[0*4*4+2*4+2]*HPLs1[0]
          - 3.0/4*GHPLs1[2]*zeta2
          + 1.0/2*GHPLs1[2]*zeta3
          - 3.0/8*GHPLs1[2]*HPLs1[0]
          + 1.0/2*GHPLs1[2]*HPLs1[0]*zeta2
          + 1.0/4*GHPLs1[2]*HPLs2[0*2+0]
          - 1.0/2*GHPLs1[2]*HPLs3[0*2*2+0*2+0]
          + 1.0/2*GHPLs1[2]*HPLs2[1*2+0]
          + 1.0/2*GHPLs1[2]*HPLs3[0*2*2+1*2+0]
          - 1.0/4*GHPLs1[2]*HPLs2[0*2+1]
          + 1.0/2*GHPLs1[2]*HPLs3[0*2*2+0*2+1]
          + 1.0/2*GHPLs3[3*4*4+0*4+2]*HPLs1[0]
          - 1.0/2*GHPLs4[0*4*4*4+3*4*4+0*4+2]
          + 1.0/2*GHPLs2[0*4+2]*HPLs2[0*2+0]
          + 1.0/2*GHPLs3[2*4*4+1*4+2]
          - 1.0/2*GHPLs2[1*4+2]*HPLs1[0]
          - 1.0/2*GHPLs2[1*4+2]*HPLs1[1]
          - 1.0/4*GHPLs2[2*4+0]*HPLs1[0]
          - 1.0/4*GHPLs3[2*4*4+1*4+0]
          + 1.0/4*GHPLs2[1*4+0]*HPLs1[0]
          + 1.0/4*GHPLs2[1*4+0]*HPLs1[1]
          - 1.0/2*GHPLs3[3*4*4+2*4+1]*HPLs1[0]
          + 1.0/2*GHPLs4[0*4*4*4+3*4*4+2*4+1]
          - 3.0/8*GHPLs2[2*4+1]
          + 1.0/2*GHPLs2[2*4+1]*zeta2
          - 1.0/2*GHPLs2[2*4+1]*HPLs2[0*2+0]
          + 1.0/2*GHPLs2[2*4+1]*HPLs2[0*2+1]
          + 1.0/2*GHPLs3[0*4*4+2*4+1]*HPLs1[0]
          + 1.0/2*GHPLs1[1]*zeta2
          + 1.0/2*GHPLs1[1]*zeta3
          + 3.0/8*GHPLs1[1]*HPLs1[0]
          - 1.0/2*GHPLs1[1]*HPLs1[0]*zeta2
          - 1.0/4*GHPLs1[1]*HPLs2[0*2+0]
          + 1.0/2*GHPLs1[1]*HPLs3[0*2*2+0*2+0]
          - 1.0/4*GHPLs1[1]*HPLs2[1*2+0]
          - 1.0/2*GHPLs1[1]*HPLs3[0*2*2+1*2+0]
          + 3.0/8*GHPLs1[1]*HPLs1[1]
          - 1.0/2*GHPLs1[1]*HPLs1[1]*zeta2
          + 1.0/2*GHPLs1[1]*HPLs3[0*2*2+0*2+1]
          - 1.0/2*GHPLs1[1]*HPLs3[0*2*2+1*2+1]
          - 1.0/2*GHPLs3[3*4*4+0*4+1]*HPLs1[0]
          + 1.0/2*GHPLs4[0*4*4*4+3*4*4+0*4+1]
          - GHPLs2[0*4+1]*zeta2
          - 1.0/2*GHPLs2[0*4+1]*HPLs2[0*2+0]
          - 1.0/2*GHPLs2[0*4+1]*HPLs2[0*2+1]
          - 1.0/4*GHPLs3[2*4*4+1*4+1]
          + 1.0/4*GHPLs2[1*4+1]*HPLs1[0]
          + 1.0/4*GHPLs2[1*4+1]*HPLs1[1]
          )

       + (dN_c*dN_c-1)/(dN_c*dN_c)*pow(u,-2)*pow(v,2) * (
          + 1.0/4*GHPLs3[3*4*4+2*4+2]*HPLs1[0]
          - 1.0/4*GHPLs4[0*4*4*4+3*4*4+2*4+2]
          - 1.0/4*GHPLs2[2*4+2]*zeta2
          + 1.0/4*GHPLs2[2*4+2]*HPLs2[0*2+0]
          - 1.0/4*GHPLs2[2*4+2]*HPLs2[0*2+1]
          - 1.0/4*GHPLs3[0*4*4+2*4+2]*HPLs1[0]
          + 1.0/4*GHPLs1[2]*zeta2
          - 1.0/4*GHPLs1[2]*zeta3
          - 1.0/4*GHPLs1[2]*HPLs1[0]*zeta2
          - 1.0/4*GHPLs1[2]*HPLs2[0*2+0]
          + 1.0/4*GHPLs1[2]*HPLs3[0*2*2+0*2+0]
          - 1.0/8*GHPLs1[2]*HPLs2[1*2+0]
          - 1.0/4*GHPLs1[2]*HPLs3[0*2*2+1*2+0]
          + 1.0/8*GHPLs1[2]*HPLs2[0*2+1]
          - 1.0/4*GHPLs1[2]*HPLs3[0*2*2+0*2+1]
          - 1.0/4*GHPLs3[3*4*4+0*4+2]*HPLs1[0]
          + 1.0/4*GHPLs4[0*4*4*4+3*4*4+0*4+2]
          + 1.0/8*GHPLs2[0*4+2]*HPLs1[0]
          - 1.0/4*GHPLs2[0*4+2]*HPLs2[0*2+0]
          - 1.0/8*GHPLs3[2*4*4+1*4+2]
          + 1.0/8*GHPLs2[1*4+2]*HPLs1[0]
          + 1.0/8*GHPLs2[1*4+2]*HPLs1[1]
          + 1.0/8*GHPLs2[2*4+3]*HPLs1[0]
          - 1.0/8*GHPLs3[0*4*4+2*4+3]
          - 1.0/8*GHPLs2[3*4+3]*HPLs1[0]
          + 1.0/8*GHPLs3[0*4*4+3*4+3]
          + 5.0/8*GHPLs1[3]*zeta2
          - 1.0/8*GHPLs1[3]*HPLs2[1*2+0]
          - 1.0/8*GHPLs1[3]*HPLs2[0*2+1]
          - 1.0/8*GHPLs3[2*4*4+0*4+3]
          + 1.0/8*GHPLs2[0*4+3]*HPLs1[1]
          + 1.0/8*GHPLs2[2*4+0]*HPLs1[0]
          + 1.0/8*GHPLs3[2*4*4+1*4+0]
          - 1.0/8*GHPLs2[1*4+0]*HPLs1[0]
          - 1.0/8*GHPLs2[1*4+0]*HPLs1[1]
          + 1.0/4*GHPLs3[3*4*4+2*4+1]*HPLs1[0]
          - 1.0/4*GHPLs4[0*4*4*4+3*4*4+2*4+1]
          - 1.0/4*GHPLs2[2*4+1]*zeta2
          + 1.0/4*GHPLs2[2*4+1]*HPLs2[0*2+0]
          - 1.0/4*GHPLs2[2*4+1]*HPLs2[0*2+1]
          - 1.0/4*GHPLs3[0*4*4+2*4+1]*HPLs1[0]
          - 1.0/4*GHPLs1[1]*zeta2
          - 1.0/4*GHPLs1[1]*zeta3
          + 1.0/4*GHPLs1[1]*HPLs1[0]*zeta2
          + 1.0/8*GHPLs1[1]*HPLs2[0*2+0]
          - 1.0/4*GHPLs1[1]*HPLs3[0*2*2+0*2+0]
          + 1.0/8*GHPLs1[1]*HPLs2[1*2+0]
          + 1.0/4*GHPLs1[1]*HPLs3[0*2*2+1*2+0]
          + 1.0/4*GHPLs1[1]*HPLs1[1]*zeta2
          - 1.0/4*GHPLs1[1]*HPLs3[0*2*2+0*2+1]
          + 1.0/4*GHPLs1[1]*HPLs3[0*2*2+1*2+1]
          + 1.0/4*GHPLs3[3*4*4+0*4+1]*HPLs1[0]
          - 1.0/4*GHPLs4[0*4*4*4+3*4*4+0*4+1]
          + 1.0/2*GHPLs2[0*4+1]*zeta2
          + 1.0/4*GHPLs2[0*4+1]*HPLs2[0*2+0]
          + 1.0/4*GHPLs2[0*4+1]*HPLs2[0*2+1]
          + 1.0/8*GHPLs3[2*4*4+1*4+1]
          - 1.0/8*GHPLs2[1*4+1]*HPLs1[0]
          - 1.0/8*GHPLs2[1*4+1]*HPLs1[1]
          )

       + (dN_c*dN_c-1)/(dN_c*dN_c)*pow(u,-2)*pow(v,3) * (
          + 1.0/4*GHPLs1[2]*zeta2
          + 1.0/8*GHPLs1[2]*HPLs1[0]
          + 1.0/4*GHPLs1[2]*HPLs2[0*2+0]
          - 1.0/4*GHPLs1[2]*HPLs2[1*2+0]
          - 1.0/4*GHPLs2[0*4+2]*HPLs1[0]
          - 1.0/4*GHPLs3[2*4*4+1*4+2]
          + 1.0/4*GHPLs2[1*4+2]*HPLs1[0]
          + 1.0/4*GHPLs2[1*4+2]*HPLs1[1]
          - 1.0/4*GHPLs2[2*4+3]*HPLs1[0]
          + 1.0/4*GHPLs3[0*4*4+2*4+3]
          + 1.0/4*GHPLs2[3*4+3]*HPLs1[0]
          - 1.0/4*GHPLs3[0*4*4+3*4+3]
          - 5.0/4*GHPLs1[3]*zeta2
          + 1.0/4*GHPLs1[3]*HPLs2[1*2+0]
          + 1.0/4*GHPLs1[3]*HPLs2[0*2+1]
          + 1.0/4*GHPLs3[2*4*4+0*4+3]
          - 1.0/4*GHPLs2[0*4+3]*HPLs1[1]
          + 1.0/8*GHPLs2[2*4+1]
          - 1.0/8*GHPLs1[1]*HPLs1[0]
          - 1.0/8*GHPLs1[1]*HPLs1[1]
          )

       + (dN_c*dN_c-1)/(dN_c*dN_c)*pow(u,-2)*pow(v,4) * (
          - 1.0/8*GHPLs1[2]*zeta2
          - 1.0/8*GHPLs1[2]*HPLs2[0*2+0]
          + 1.0/8*GHPLs1[2]*HPLs2[1*2+0]
          + 1.0/8*GHPLs2[0*4+2]*HPLs1[0]
          + 1.0/8*GHPLs3[2*4*4+1*4+2]
          - 1.0/8*GHPLs2[1*4+2]*HPLs1[0]
          - 1.0/8*GHPLs2[1*4+2]*HPLs1[1]
          + 1.0/8*GHPLs2[2*4+3]*HPLs1[0]
          - 1.0/8*GHPLs3[0*4*4+2*4+3]
          - 1.0/8*GHPLs2[3*4+3]*HPLs1[0]
          + 1.0/8*GHPLs3[0*4*4+3*4+3]
          + 5.0/8*GHPLs1[3]*zeta2
          - 1.0/8*GHPLs1[3]*HPLs2[1*2+0]
          - 1.0/8*GHPLs1[3]*HPLs2[0*2+1]
          - 1.0/8*GHPLs3[2*4*4+0*4+3]
          + 1.0/8*GHPLs2[0*4+3]*HPLs1[1]
          )

       + (dN_c*dN_c-1)/(dN_c*dN_c)*pow(u,-1)*pow(u+v,-1) * (
          - 1.0/8*GHPLs1[2]*HPLs1[0]
          - 1.0/8*GHPLs2[2*4+1]
          + 1.0/8*GHPLs1[1]*HPLs1[0]
          + 1.0/8*GHPLs1[1]*HPLs1[1]
          )

       + (dN_c*dN_c-1)/(dN_c*dN_c)*pow(u,-1) * (
          + 1.0/2
          - 3.0/8*zeta2
          - 1.0/2*zeta3
          + 1.0/2*GHPLs2[3*4+2]*HPLs1[0]
          - 1.0/2*GHPLs3[0*4*4+3*4+2]
          + 3.0/8*GHPLs1[2]
          - 2*GHPLs1[2]*zeta2
          - 1.0/2*GHPLs1[2]*HPLs1[0]
          + GHPLs1[2]*HPLs2[0*2+0]
          + GHPLs1[2]*HPLs2[1*2+0]
          - GHPLs1[2]*HPLs2[0*2+1]
          - 1.0/2*GHPLs2[0*4+2]*HPLs1[0]
          + GHPLs3[2*4*4+1*4+2]
          - GHPLs2[1*4+2]*HPLs1[0]
          - GHPLs2[1*4+2]*HPLs1[1]
          - 1.0/2*GHPLs2[2*4+0]*HPLs1[0]
          + 1.0/2*GHPLs1[0]*zeta2
          + 1.0/4*GHPLs1[0]*HPLs2[0*2+1]
          - 1.0/2*GHPLs3[2*4*4+1*4+0]
          + 1.0/2*GHPLs2[1*4+0]*HPLs1[0]
          + 1.0/2*GHPLs2[1*4+0]*HPLs1[1]
          - 5.0/8*GHPLs2[2*4+1]
          + GHPLs1[1]*zeta2
          + 5.0/8*GHPLs1[1]*HPLs1[0]
          - 1.0/2*GHPLs1[1]*HPLs2[0*2+0]
          - 1.0/2*GHPLs1[1]*HPLs2[1*2+0]
          + 5.0/8*GHPLs1[1]*HPLs1[1]
          - 1.0/2*GHPLs3[2*4*4+1*4+1]
          + 1.0/2*GHPLs2[1*4+1]*HPLs1[0]
          + 1.0/2*GHPLs2[1*4+1]*HPLs1[1]
          - 1.0/8*HPLs2[1*2+0]
          - 3.0/8*HPLs1[1]
          + 1.0/4*HPLs1[1]*zeta2
          - 1.0/8*HPLs2[0*2+1]
          - 1.0/2*HPLs3[0*2*2+0*2+1]
          + 1.0/4*HPLs3[0*2*2+1*2+1]
          )

       + (dN_c*dN_c-1)/(dN_c*dN_c)*pow(u,-1)*v * (
          - 1.0/2
          + 1.0/2*zeta2
          + 3.0/4*zeta3
          - 3.0/4*GHPLs2[3*4+2]*HPLs1[0]
          + 3.0/4*GHPLs3[0*4*4+3*4+2]
          - 3.0/4*GHPLs1[2]
          + 5.0/2*GHPLs1[2]*zeta2
          - GHPLs1[2]*HPLs2[0*2+0]
          - 5.0/4*GHPLs1[2]*HPLs2[1*2+0]
          + 5.0/4*GHPLs1[2]*HPLs2[0*2+1]
          + 1.0/8*GHPLs2[0*4+2]
          + 1.0/2*GHPLs2[0*4+2]*HPLs1[0]
          - 5.0/4*GHPLs3[2*4*4+1*4+2]
          + 5.0/4*GHPLs2[1*4+2]*HPLs1[0]
          + 5.0/4*GHPLs2[1*4+2]*HPLs1[1]
          - 1.0/4*GHPLs2[2*4+3]*HPLs1[0]
          + 1.0/4*GHPLs3[0*4*4+2*4+3]
          + 1.0/4*GHPLs2[3*4+3]*HPLs1[0]
          - 1.0/4*GHPLs3[0*4*4+3*4+3]
          - 5.0/4*GHPLs1[3]*zeta2
          + 3.0/8*GHPLs1[3]*HPLs1[0]
          + 1.0/4*GHPLs1[3]*HPLs2[1*2+0]
          + 1.0/4*GHPLs1[3]*HPLs2[0*2+1]
          + 1.0/4*GHPLs3[2*4*4+0*4+3]
          - 3.0/8*GHPLs2[0*4+3]
          - 1.0/4*GHPLs2[0*4+3]*HPLs1[1]
          + 1.0/8*GHPLs2[2*4+0]
          + 1.0/2*GHPLs2[2*4+0]*HPLs1[0]
          - 1.0/4*GHPLs2[3*4+0]*HPLs1[0]
          + 1.0/4*GHPLs3[0*4*4+3*4+0]
          - GHPLs1[0]*zeta2
          - 1.0/4*GHPLs1[0]*HPLs2[0*2+0]
          - 1.0/8*GHPLs1[0]*HPLs1[1]
          - 1.0/2*GHPLs1[0]*HPLs2[0*2+1]
          + 1.0/2*GHPLs3[2*4*4+1*4+0]
          - 1.0/2*GHPLs2[1*4+0]*HPLs1[0]
          - 1.0/2*GHPLs2[1*4+0]*HPLs1[1]
          + 1.0/8*GHPLs2[2*4+1]
          - GHPLs1[1]*zeta2
          - 1.0/8*GHPLs1[1]*HPLs1[0]
          + 1.0/2*GHPLs1[1]*HPLs2[0*2+0]
          + 1.0/2*GHPLs1[1]*HPLs2[1*2+0]
          - 1.0/8*GHPLs1[1]*HPLs1[1]
          + 1.0/2*GHPLs3[2*4*4+1*4+1]
          - 1.0/2*GHPLs2[1*4+1]*HPLs1[0]
          - 1.0/2*GHPLs2[1*4+1]*HPLs1[1]
          + 3.0/8*HPLs1[0]
          - 1.0/4*HPLs1[0]*zeta2
          + 1.0/8*HPLs2[0*2+0]
          + 1.0/4*HPLs3[0*2*2+0*2+0]
          + 1.0/8*HPLs2[1*2+0]
          - 1.0/4*HPLs3[0*2*2+1*2+0]
          + 3.0/4*HPLs1[1]
          - 1.0/2*HPLs1[1]*zeta2
          + 1.0/2*HPLs2[0*2+1]
          + 3.0/4*HPLs3[0*2*2+0*2+1]
          - 1.0/2*HPLs3[0*2*2+1*2+1]
          )

       + (dN_c*dN_c-1)/(dN_c*dN_c)*pow(u,-1)*pow(v,2) * (
          + 3.0/8*zeta2
          - 1.0/4*zeta3
          + 1.0/4*GHPLs2[3*4+2]*HPLs1[0]
          - 1.0/4*GHPLs3[0*4*4+3*4+2]
          + 3.0/8*GHPLs1[2]
          - 1.0/4*GHPLs1[2]*zeta2
          + 3.0/4*GHPLs1[2]*HPLs1[0]
          + 1.0/4*GHPLs1[2]*HPLs2[0*2+0]
          - 1.0/4*GHPLs1[2]*HPLs2[0*2+1]
          - 1.0/4*GHPLs2[0*4+2]
          - 1.0/4*GHPLs2[0*4+2]*HPLs1[0]
          - 1.0/2*GHPLs1[3]*HPLs1[0]
          + 1.0/2*GHPLs2[0*4+3]
          - 1.0/4*GHPLs2[2*4+0]
          + 1.0/4*GHPLs2[3*4+0]*HPLs1[0]
          - 1.0/4*GHPLs3[0*4*4+3*4+0]
          + 1.0/2*GHPLs1[0]*zeta2
          + 1.0/8*GHPLs1[0]*HPLs1[0]
          + 1.0/4*GHPLs1[0]*HPLs2[0*2+0]
          + 1.0/4*GHPLs1[0]*HPLs1[1]
          + 1.0/4*GHPLs1[0]*HPLs2[0*2+1]
          + 3.0/4*GHPLs2[2*4+1]
          - 3.0/4*GHPLs1[1]*HPLs1[0]
          - 3.0/4*GHPLs1[1]*HPLs1[1]
          - 3.0/8*HPLs1[0]
          + 1.0/4*HPLs1[0]*zeta2
          - 1.0/4*HPLs2[0*2+0]
          - 1.0/4*HPLs3[0*2*2+0*2+0]
          + 1.0/4*HPLs3[0*2*2+1*2+0]
          - 3.0/8*HPLs1[1]
          + 1.0/4*HPLs1[1]*zeta2
          - 1.0/2*HPLs2[0*2+1]
          - 1.0/4*HPLs3[0*2*2+0*2+1]
          + 1.0/4*HPLs3[0*2*2+1*2+1]
          )

       + (dN_c*dN_c-1)/(dN_c*dN_c)*pow(u,-1)*pow(v,3) * (
          - 1.0/2*zeta2
          - 1.0/4*GHPLs1[2]*zeta2
          - 1.0/8*GHPLs1[2]*HPLs1[0]
          - 1.0/4*GHPLs1[2]*HPLs2[0*2+0]
          + 1.0/4*GHPLs1[2]*HPLs2[1*2+0]
          + 1.0/8*GHPLs2[0*4+2]
          + 1.0/4*GHPLs2[0*4+2]*HPLs1[0]
          + 1.0/4*GHPLs3[2*4*4+1*4+2]
          - 1.0/4*GHPLs2[1*4+2]*HPLs1[0]
          - 1.0/4*GHPLs2[1*4+2]*HPLs1[1]
          + 1.0/4*GHPLs2[2*4+3]*HPLs1[0]
          - 1.0/4*GHPLs3[0*4*4+2*4+3]
          - 1.0/4*GHPLs2[3*4+3]*HPLs1[0]
          + 1.0/4*GHPLs3[0*4*4+3*4+3]
          + 5.0/4*GHPLs1[3]*zeta2
          + 1.0/8*GHPLs1[3]*HPLs1[0]
          - 1.0/4*GHPLs1[3]*HPLs2[1*2+0]
          - 1.0/4*GHPLs1[3]*HPLs2[0*2+1]
          - 1.0/4*GHPLs3[2*4*4+0*4+3]
          - 1.0/8*GHPLs2[0*4+3]
          + 1.0/4*GHPLs2[0*4+3]*HPLs1[1]
          + 1.0/8*GHPLs2[2*4+0]
          - 1.0/8*GHPLs1[0]*HPLs1[0]
          - 1.0/8*GHPLs1[0]*HPLs1[1]
          - 1.0/8*GHPLs2[2*4+1]
          + 1.0/8*GHPLs1[1]*HPLs1[0]
          + 1.0/8*GHPLs1[1]*HPLs1[1]
          + 1.0/8*HPLs2[0*2+0]
          + 1.0/8*HPLs2[0*2+1]
          )

       + (dN_c*dN_c-1)/(dN_c*dN_c)*pow(1-u,-1) * (
          - 1.0/4*zeta2
          + 1.0/4*GHPLs1[3]*HPLs1[0]
          - 1.0/4*GHPLs2[0*4+3]
          - 1.0/4*GHPLs1[0]*HPLs1[0]
          + 1.0/4*HPLs2[0*2+0]
          - 1.0/4*HPLs2[0*2+1]
          )

       + (dN_c*dN_c-1)/(dN_c*dN_c)*pow(u+v,-2) * (
          - 3.0/8*GHPLs1[2]*zeta2
          + 1.0/8*GHPLs1[2]*HPLs2[1*2+0]
          - 1.0/8*GHPLs1[2]*HPLs2[0*2+1]
          + 1.0/8*GHPLs3[2*4*4+1*4+2]
          - 1.0/8*GHPLs2[1*4+2]*HPLs1[0]
          - 1.0/8*GHPLs2[1*4+2]*HPLs1[1]
          + 1.0/8*GHPLs2[2*4+0]*HPLs1[0]
          + 1.0/8*GHPLs3[2*4*4+1*4+0]
          - 1.0/8*GHPLs2[1*4+0]*HPLs1[0]
          - 1.0/8*GHPLs2[1*4+0]*HPLs1[1]
          + 3.0/8*HPLs1[1]*zeta2
          - 1.0/8*HPLs3[1*2*2+0*2+1]
          + 1.0/8*HPLs3[0*2*2+1*2+1]
          )

       + (dN_c*dN_c-1)/(dN_c*dN_c)*pow(u+v,-1) * (
          + 1.0/16
          - 3.0/8*zeta2
          + 3.0/2*GHPLs1[2]*zeta2
          - 1.0/2*GHPLs1[2]*HPLs2[1*2+0]
          + 1.0/2*GHPLs1[2]*HPLs2[0*2+1]
          - 1.0/2*GHPLs3[2*4*4+1*4+2]
          + 1.0/2*GHPLs2[1*4+2]*HPLs1[0]
          + 1.0/2*GHPLs2[1*4+2]*HPLs1[1]
          - 1.0/2*GHPLs2[2*4+0]*HPLs1[0]
          + 1.0/16*GHPLs1[0]
          - 1.0/2*GHPLs3[2*4*4+1*4+0]
          + 1.0/2*GHPLs2[1*4+0]*HPLs1[0]
          + 1.0/2*GHPLs2[1*4+0]*HPLs1[1]
          + 1.0/8*GHPLs2[2*4+1]
          - 1.0/8*GHPLs1[1]*HPLs1[0]
          - 1.0/8*GHPLs1[1]*HPLs1[1]
          - 1.0/16*HPLs1[0]
          + 1.0/8*HPLs2[1*2+0]
          - 3.0/2*HPLs1[1]*zeta2
          - 1.0/8*HPLs2[0*2+1]
          + 1.0/2*HPLs3[1*2*2+0*2+1]
          - 1.0/2*HPLs3[0*2*2+1*2+1]
          )

       + (dN_c*dN_c-1)/(dN_c*dN_c) * (
          - 17.0/16
          + 7.0/16*zeta4
          + 47.0/16*zeta2
          - 5.0/8*zeta3
          - 1.0/4*GHPLs3[3*4*4+2*4+2]*HPLs1[0]
          + 1.0/4*GHPLs4[0*4*4*4+3*4*4+2*4+2]
          + 1.0/4*GHPLs2[2*4+2]*zeta2
          - 1.0/4*GHPLs2[2*4+2]*HPLs2[0*2+0]
          + 1.0/4*GHPLs2[2*4+2]*HPLs2[0*2+1]
          + 1.0/4*GHPLs3[0*4*4+2*4+2]*HPLs1[0]
          + GHPLs2[3*4+2]*HPLs1[0]
          - GHPLs3[0*4*4+3*4+2]
          - GHPLs1[2]*zeta2
          + 1.0/4*GHPLs1[2]*zeta3
          + 3.0/4*GHPLs1[2]*HPLs1[0]
          + 1.0/4*GHPLs1[2]*HPLs1[0]*zeta2
          + 5.0/8*GHPLs1[2]*HPLs2[0*2+0]
          - 1.0/4*GHPLs1[2]*HPLs3[0*2*2+0*2+0]
          - 3.0/8*GHPLs1[2]*HPLs2[1*2+0]
          + 1.0/4*GHPLs1[2]*HPLs3[0*2*2+1*2+0]
          - GHPLs1[2]*HPLs2[0*2+1]
          + 1.0/4*GHPLs1[2]*HPLs3[0*2*2+0*2+1]
          + 1.0/4*GHPLs3[3*4*4+0*4+2]*HPLs1[0]
          - 1.0/4*GHPLs4[0*4*4*4+3*4*4+0*4+2]
          - 3.0/8*GHPLs2[0*4+2]
          - GHPLs2[0*4+2]*HPLs1[0]
          + 1.0/4*GHPLs2[0*4+2]*HPLs2[0*2+0]
          - 3.0/8*GHPLs3[2*4*4+1*4+2]
          + 3.0/8*GHPLs2[1*4+2]*HPLs1[0]
          + 3.0/8*GHPLs2[1*4+2]*HPLs1[1]
          - 1.0/4*GHPLs3[3*4*4+2*4+3]*HPLs1[0]
          + 1.0/4*GHPLs4[0*4*4*4+3*4*4+2*4+3]
          + 1.0/4*GHPLs2[2*4+3]*zeta2
          - 1.0/4*GHPLs2[2*4+3]*HPLs2[0*2+0]
          + 1.0/4*GHPLs2[2*4+3]*HPLs2[0*2+1]
          + 1.0/4*GHPLs3[0*4*4+2*4+3]*HPLs1[0]
          - 1.0/2*GHPLs3[3*4*4+3*4+3]*HPLs1[0]
          + 1.0/2*GHPLs4[0*4*4*4+3*4*4+3*4+3]
          + GHPLs2[3*4+3]*zeta2
          + 3.0/8*GHPLs2[3*4+3]*HPLs1[0]
          - 1.0/2*GHPLs2[3*4+3]*HPLs2[0*2+0]
          - 3.0/8*GHPLs3[0*4*4+3*4+3]
          + 1.0/2*GHPLs3[0*4*4+3*4+3]*HPLs1[0]
          - 1.0/2*GHPLs4[0*4*4*4+0*4*4+3*4+3]
          + 3.0/8*GHPLs1[3]*zeta2
          - 1.0/2*GHPLs1[3]*zeta3
          - 17.0/16*GHPLs1[3]*HPLs1[0]
          + 7.0/4*GHPLs1[3]*HPLs1[0]*zeta2
          - 3.0/4*GHPLs1[3]*HPLs3[0*2*2+0*2+0]
          + 1.0/4*GHPLs1[3]*HPLs3[0*2*2+1*2+0]
          - 1.0/4*GHPLs1[3]*HPLs1[1]*zeta2
          + 1.0/4*GHPLs1[3]*HPLs3[0*2*2+0*2+1]
          - 1.0/4*GHPLs1[3]*HPLs3[0*2*2+1*2+1]
          + 1.0/4*GHPLs3[3*4*4+0*4+3]*HPLs1[0]
          - 1.0/4*GHPLs4[0*4*4*4+3*4*4+0*4+3]
          + 17.0/16*GHPLs2[0*4+3]
          - 1.0/4*GHPLs2[0*4+3]*zeta2
          + 3.0/4*GHPLs2[0*4+3]*HPLs2[0*2+0]
          - 1.0/4*GHPLs2[0*4+3]*HPLs2[0*2+1]
          - 1.0/2*GHPLs3[0*4*4+0*4+3]*HPLs1[0]
          - 3.0/8*GHPLs2[2*4+0]
          - 1.0/2*GHPLs2[2*4+0]*zeta2
          + 3.0/4*GHPLs2[2*4+0]*HPLs1[0]
          + 1.0/2*GHPLs2[2*4+0]*HPLs2[0*2+0]
          + 1.0/2*GHPLs2[2*4+0]*HPLs2[1*2+0]
          + 1.0/2*GHPLs4[2*4*4*4+1*4*4+2*4+0]
          - 1.0/2*GHPLs3[1*4*4+2*4+0]*HPLs1[0]
          - 1.0/2*GHPLs3[1*4*4+2*4+0]*HPLs1[1]
          + 1.0/2*GHPLs3[3*4*4+3*4+0]*HPLs1[0]
          - 1.0/2*GHPLs4[0*4*4*4+3*4*4+3*4+0]
          + 1.0/2*GHPLs2[3*4+0]*zeta2
          - 3.0/8*GHPLs2[3*4+0]*HPLs1[0]
          + 1.0/2*GHPLs2[3*4+0]*HPLs2[0*2+0]
          + 3.0/8*GHPLs3[0*4*4+3*4+0]
          - 1.0/4*GHPLs3[0*4*4+3*4+0]*HPLs1[0]
          - 5.0/16*GHPLs1[0]
          + 5.0/8*GHPLs1[0]*zeta2
          + 17.0/16*GHPLs1[0]*HPLs1[0]
          - 1.0/4*GHPLs1[0]*HPLs1[0]*zeta2
          + 3.0/4*GHPLs1[0]*HPLs3[0*2*2+0*2+0]
          - 1.0/4*GHPLs1[0]*HPLs3[0*2*2+1*2+0]
          + 3.0/8*GHPLs1[0]*HPLs1[1]
          + 1.0/8*GHPLs1[0]*HPLs2[0*2+1]
          - 1.0/2*GHPLs1[0]*HPLs3[0*2*2+0*2+1]
          - 1.0/2*GHPLs3[2*4*4+0*4+0]*HPLs1[0]
          - 1.0/2*GHPLs2[0*4+0]*HPLs2[0*2+0]
          - 1.0/2*GHPLs4[2*4*4*4+1*4*4+0*4+0]
          + 1.0/2*GHPLs3[1*4*4+0*4+0]*HPLs1[0]
          + 1.0/2*GHPLs3[1*4*4+0*4+0]*HPLs1[1]
          + 3.0/4*GHPLs3[2*4*4+1*4+0]
          + GHPLs2[1*4+0]*zeta2
          - 3.0/4*GHPLs2[1*4+0]*HPLs1[0]
          - 1.0/2*GHPLs2[1*4+0]*HPLs2[0*2+0]
          - 1.0/2*GHPLs2[1*4+0]*HPLs2[1*2+0]
          - 3.0/4*GHPLs2[1*4+0]*HPLs1[1]
          - 1.0/2*GHPLs4[2*4*4*4+1*4*4+1*4+0]
          + 1.0/2*GHPLs3[1*4*4+1*4+0]*HPLs1[0]
          + 1.0/2*GHPLs3[1*4*4+1*4+0]*HPLs1[1]
          - 1.0/4*GHPLs3[3*4*4+2*4+1]*HPLs1[0]
          + 1.0/4*GHPLs4[0*4*4*4+3*4*4+2*4+1]
          + 3.0/4*GHPLs2[2*4+1]
          + 1.0/4*GHPLs2[2*4+1]*zeta2
          - 1.0/4*GHPLs2[2*4+1]*HPLs2[0*2+0]
          + 1.0/4*GHPLs2[2*4+1]*HPLs2[0*2+1]
          + 1.0/4*GHPLs3[0*4*4+2*4+1]*HPLs1[0]
          - 3.0/4*GHPLs1[1]*zeta2
          + 1.0/4*GHPLs1[1]*zeta3
          - 3.0/4*GHPLs1[1]*HPLs1[0]
          - 1.0/4*GHPLs1[1]*HPLs1[0]*zeta2
          + 3.0/8*GHPLs1[1]*HPLs2[0*2+0]
          + 1.0/4*GHPLs1[1]*HPLs3[0*2*2+0*2+0]
          + 3.0/8*GHPLs1[1]*HPLs2[1*2+0]
          - 1.0/4*GHPLs1[1]*HPLs3[0*2*2+1*2+0]
          - 3.0/4*GHPLs1[1]*HPLs1[1]
          - 1.0/4*GHPLs1[1]*HPLs1[1]*zeta2
          + 1.0/4*GHPLs1[1]*HPLs3[0*2*2+0*2+1]
          - 1.0/4*GHPLs1[1]*HPLs3[0*2*2+1*2+1]
          - 1.0/4*GHPLs3[3*4*4+0*4+1]*HPLs1[0]
          + 1.0/4*GHPLs4[0*4*4*4+3*4*4+0*4+1]
          - 1.0/2*GHPLs2[0*4+1]*zeta2
          - 1.0/4*GHPLs2[0*4+1]*HPLs2[0*2+0]
          - 1.0/4*GHPLs2[0*4+1]*HPLs2[0*2+1]
          + 3.0/8*GHPLs3[2*4*4+1*4+1]
          - 3.0/8*GHPLs2[1*4+1]*HPLs1[0]
          - 3.0/8*GHPLs2[1*4+1]*HPLs1[1]
          - 9.0/16*HPLs1[0]
          + 3.0/8*HPLs1[0]*zeta2
          - 1.0/2*HPLs1[0]*zeta3
          - 17.0/16*HPLs2[0*2+0]
          + 7.0/4*HPLs2[0*2+0]*zeta2
          - 3.0/4*HPLs4[0*2*2*2+0*2*2+0*2+0]
          + 1.0/4*HPLs4[0*2*2*2+1*2*2+0*2+0]
          - 1.0/4*HPLs2[1*2+0]*zeta2
          + 1.0/4*HPLs4[0*2*2*2+0*2*2+1*2+0]
          - 1.0/4*HPLs4[0*2*2*2+1*2*2+1*2+0]
          + 7.0/8*HPLs1[1]*zeta2
          + 9.0/16*HPLs2[0*2+1]
          - 5.0/8*HPLs3[0*2*2+0*2+1]
          - 1.0/2*HPLs4[1*2*2*2+0*2*2+0*2+1]
          - 3.0/8*HPLs3[1*2*2+0*2+1]
          - 1.0/2*HPLs4[0*2*2*2+1*2*2+0*2+1]
          + 1.0/8*HPLs3[0*2*2+1*2+1]
          - 1.0/2*HPLs4[0*2*2*2+0*2*2+1*2+1]
          )

       + (dN_c*dN_c-1)/(dN_c*dN_c)*v*pow(1-u,-2) * (
          + 1.0/2*zeta2
          - 1.0/2*zeta3
          + 1.0/2*GHPLs2[3*4+2]*HPLs1[0]
          - 1.0/2*GHPLs3[0*4*4+3*4+2]
          - 1.0/2*GHPLs1[2]*zeta2
          + 1.0/2*GHPLs1[2]*HPLs2[0*2+0]
          - 1.0/2*GHPLs1[2]*HPLs2[0*2+1]
          - 1.0/2*GHPLs2[0*4+2]*HPLs1[0]
          - 1.0/2*GHPLs1[3]*HPLs1[0]
          + 1.0/2*GHPLs2[0*4+3]
          + 1.0/2*GHPLs2[3*4+0]*HPLs1[0]
          - 1.0/2*GHPLs3[0*4*4+3*4+0]
          + GHPLs1[0]*zeta2
          + 1.0/2*GHPLs1[0]*HPLs1[0]
          + 1.0/2*GHPLs1[0]*HPLs2[0*2+0]
          + 1.0/2*GHPLs1[0]*HPLs2[0*2+1]
          + 1.0/2*HPLs1[0]*zeta2
          - 1.0/2*HPLs2[0*2+0]
          - 1.0/2*HPLs3[0*2*2+0*2+0]
          + 1.0/2*HPLs3[0*2*2+1*2+0]
          + 1.0/2*HPLs1[1]*zeta2
          + 1.0/2*HPLs2[0*2+1]
          - 1.0/2*HPLs3[0*2*2+0*2+1]
          + 1.0/2*HPLs3[0*2*2+1*2+1]
          )

       + (dN_c*dN_c-1)/(dN_c*dN_c)*v*pow(1-u,-1) * (
          + 3.0/4*zeta2
          + zeta3
          - GHPLs2[3*4+2]*HPLs1[0]
          + GHPLs3[0*4*4+3*4+2]
          + GHPLs1[2]*zeta2
          - GHPLs1[2]*HPLs2[0*2+0]
          + GHPLs1[2]*HPLs2[0*2+1]
          + GHPLs2[0*4+2]*HPLs1[0]
          + 3.0/4*GHPLs1[3]*HPLs1[0]
          - 3.0/4*GHPLs2[0*4+3]
          - GHPLs2[3*4+0]*HPLs1[0]
          + GHPLs3[0*4*4+3*4+0]
          + 1.0/4*GHPLs1[0]
          - 2*GHPLs1[0]*zeta2
          - 1.0/4*GHPLs1[0]*HPLs1[0]
          - GHPLs1[0]*HPLs2[0*2+0]
          - GHPLs1[0]*HPLs2[0*2+1]
          - HPLs1[0]*zeta2
          + 3.0/4*HPLs2[0*2+0]
          + HPLs3[0*2*2+0*2+0]
          - HPLs3[0*2*2+1*2+0]
          - HPLs1[1]*zeta2
          + 1.0/4*HPLs2[0*2+1]
          + HPLs3[0*2*2+0*2+1]
          - HPLs3[0*2*2+1*2+1]
          )

       + (dN_c*dN_c-1)/(dN_c*dN_c)*v * (
          + 1.0/2*zeta2
          - 3.0/8*GHPLs1[2]
          - 1.0/4*GHPLs1[2]*zeta2
          + 3.0/8*GHPLs1[2]*HPLs1[0]
          - 1.0/4*GHPLs1[2]*HPLs2[0*2+0]
          + 1.0/4*GHPLs1[2]*HPLs2[1*2+0]
          - 1.0/8*GHPLs2[0*4+2]
          + 1.0/4*GHPLs2[0*4+2]*HPLs1[0]
          + 1.0/4*GHPLs3[2*4*4+1*4+2]
          - 1.0/4*GHPLs2[1*4+2]*HPLs1[0]
          - 1.0/4*GHPLs2[1*4+2]*HPLs1[1]
          + 1.0/4*GHPLs2[2*4+3]*HPLs1[0]
          - 1.0/4*GHPLs3[0*4*4+2*4+3]
          - 1.0/4*GHPLs2[3*4+3]*HPLs1[0]
          + 1.0/4*GHPLs3[0*4*4+3*4+3]
          + 5.0/4*GHPLs1[3]*zeta2
          - 1.0/8*GHPLs1[3]*HPLs1[0]
          - 1.0/4*GHPLs1[3]*HPLs2[1*2+0]
          - 1.0/4*GHPLs1[3]*HPLs2[0*2+1]
          - 1.0/4*GHPLs3[2*4*4+0*4+3]
          + 1.0/8*GHPLs2[0*4+3]
          + 1.0/4*GHPLs2[0*4+3]*HPLs1[1]
          - 1.0/8*GHPLs2[2*4+0]
          - 1.0/4*GHPLs2[2*4+0]*HPLs1[0]
          + 1.0/4*GHPLs2[3*4+0]*HPLs1[0]
          - 1.0/4*GHPLs3[0*4*4+3*4+0]
          - 1.0/8*GHPLs1[0]*HPLs1[0]
          + 1.0/2*GHPLs1[0]*HPLs2[0*2+0]
          + 1.0/4*GHPLs1[0]*HPLs2[1*2+0]
          + 1.0/8*GHPLs1[0]*HPLs1[1]
          + 1.0/4*GHPLs1[0]*HPLs2[0*2+1]
          + 1.0/8*GHPLs2[2*4+1]
          + 1.0/4*GHPLs3[0*4*4+2*4+1]
          - GHPLs1[1]*zeta2
          - 1.0/8*GHPLs1[1]*HPLs1[0]
          - 1.0/4*GHPLs1[1]*HPLs2[0*2+0]
          - 1.0/4*GHPLs1[1]*HPLs2[1*2+0]
          - 1.0/8*GHPLs1[1]*HPLs1[1]
          + 1.0/4*GHPLs3[2*4*4+0*4+1]
          - 1.0/4*GHPLs2[0*4+1]*HPLs1[0]
          - 1.0/4*GHPLs2[0*4+1]*HPLs1[1]
          - 1.0/4*GHPLs3[2*4*4+1*4+1]
          + 1.0/4*GHPLs2[1*4+1]*HPLs1[0]
          + 1.0/4*GHPLs2[1*4+1]*HPLs1[1]
          + 3.0/8*HPLs1[0]
          + 5.0/4*HPLs1[0]*zeta2
          - 1.0/8*HPLs2[0*2+0]
          + 1.0/4*HPLs3[1*2*2+0*2+0]
          - 1.0/4*HPLs2[1*2+0]
          + 1.0/4*HPLs3[0*2*2+1*2+0]
          + 3.0/8*HPLs1[1]
          + 1.0/4*HPLs1[1]*zeta2
          - 3.0/8*HPLs2[0*2+1]
          + 1.0/4*HPLs3[0*2*2+0*2+1]
          + 1.0/4*HPLs3[1*2*2+0*2+1]
          + 1.0/2*HPLs3[0*2*2+1*2+1]
          )

       + (dN_c*dN_c-1)/(dN_c*dN_c)*pow(v,2)*pow(1-u,-3) * (
          + 1.0/2*zeta3
          - 1.0/2*GHPLs2[3*4+2]*HPLs1[0]
          + 1.0/2*GHPLs3[0*4*4+3*4+2]
          + 1.0/2*GHPLs1[2]*zeta2
          - 1.0/2*GHPLs1[2]*HPLs2[0*2+0]
          + 1.0/2*GHPLs1[2]*HPLs2[0*2+1]
          + 1.0/2*GHPLs2[0*4+2]*HPLs1[0]
          - 1.0/2*GHPLs2[3*4+0]*HPLs1[0]
          + 1.0/2*GHPLs3[0*4*4+3*4+0]
          - GHPLs1[0]*zeta2
          - 1.0/2*GHPLs1[0]*HPLs2[0*2+0]
          - 1.0/2*GHPLs1[0]*HPLs2[0*2+1]
          - 1.0/2*HPLs1[0]*zeta2
          + 1.0/2*HPLs3[0*2*2+0*2+0]
          - 1.0/2*HPLs3[0*2*2+1*2+0]
          - 1.0/2*HPLs1[1]*zeta2
          + 1.0/2*HPLs3[0*2*2+0*2+1]
          - 1.0/2*HPLs3[0*2*2+1*2+1]
          )

       + (dN_c*dN_c-1)/(dN_c*dN_c)*pow(v,2)*pow(1-u,-2) * (
          - zeta2
          - 1.0/4*zeta3
          + 1.0/4*GHPLs2[3*4+2]*HPLs1[0]
          - 1.0/4*GHPLs3[0*4*4+3*4+2]
          - 1.0/4*GHPLs1[2]*zeta2
          + 1.0/4*GHPLs1[2]*HPLs2[0*2+0]
          - 1.0/4*GHPLs1[2]*HPLs2[0*2+1]
          - 1.0/4*GHPLs2[0*4+2]*HPLs1[0]
          - 1.0/2*GHPLs1[3]*HPLs1[0]
          + 1.0/2*GHPLs2[0*4+3]
          + 1.0/4*GHPLs2[3*4+0]*HPLs1[0]
          - 1.0/4*GHPLs3[0*4*4+3*4+0]
          + 1.0/2*GHPLs1[0]*zeta2
          + 1.0/4*GHPLs1[0]*HPLs2[0*2+0]
          + 1.0/4*GHPLs1[0]*HPLs2[0*2+1]
          + 1.0/4*HPLs1[0]*zeta2
          - 1.0/2*HPLs2[0*2+0]
          - 1.0/4*HPLs3[0*2*2+0*2+0]
          + 1.0/4*HPLs3[0*2*2+1*2+0]
          + 1.0/4*HPLs1[1]*zeta2
          - 1.0/2*HPLs2[0*2+1]
          - 1.0/4*HPLs3[0*2*2+0*2+1]
          + 1.0/4*HPLs3[0*2*2+1*2+1]
          )

       + (dN_c*dN_c-1)/(dN_c*dN_c)*pow(v,2)*pow(1-u,-1) * (
          - 5.0/4*zeta2
          - 1.0/4*zeta3
          + 1.0/4*GHPLs2[3*4+2]*HPLs1[0]
          - 1.0/4*GHPLs3[0*4*4+3*4+2]
          + 3.0/8*GHPLs1[2]
          - 1.0/4*GHPLs1[2]*zeta2
          + 1.0/4*GHPLs1[2]*HPLs2[0*2+0]
          - 1.0/4*GHPLs1[2]*HPLs2[0*2+1]
          + 1.0/8*GHPLs2[0*4+2]
          - 1.0/4*GHPLs2[0*4+2]*HPLs1[0]
          + 1.0/8*GHPLs2[2*4+0]
          + 1.0/4*GHPLs2[3*4+0]*HPLs1[0]
          - 1.0/4*GHPLs3[0*4*4+3*4+0]
          + 1.0/2*GHPLs1[0]*zeta2
          - 1.0/8*GHPLs1[0]*HPLs1[0]
          + 1.0/4*GHPLs1[0]*HPLs2[0*2+0]
          - 1.0/8*GHPLs1[0]*HPLs1[1]
          + 1.0/4*GHPLs1[0]*HPLs2[0*2+1]
          + 1.0/4*GHPLs2[2*4+1]
          - 1.0/4*GHPLs1[1]*HPLs1[0]
          - 1.0/4*GHPLs1[1]*HPLs1[1]
          - 3.0/8*HPLs1[0]
          + 1.0/4*HPLs1[0]*zeta2
          + 1.0/4*HPLs2[0*2+0]
          - 1.0/4*HPLs3[0*2*2+0*2+0]
          + 1.0/4*HPLs2[1*2+0]
          + 1.0/4*HPLs3[0*2*2+1*2+0]
          - 3.0/8*HPLs1[1]
          + 1.0/4*HPLs1[1]*zeta2
          - 1.0/4*HPLs3[0*2*2+0*2+1]
          + 1.0/4*HPLs3[0*2*2+1*2+1]
          )

       + (dN_c*dN_c-1)/(dN_c*dN_c)*pow(v,2) * (
          - 3.0/2*zeta2
          - 1.0/8*GHPLs1[2]*zeta2
          - 3.0/8*GHPLs1[2]*HPLs1[0]
          - 1.0/8*GHPLs1[2]*HPLs2[0*2+0]
          + 1.0/8*GHPLs1[2]*HPLs2[1*2+0]
          + 3.0/8*GHPLs2[0*4+2]
          + 1.0/8*GHPLs2[0*4+2]*HPLs1[0]
          + 1.0/8*GHPLs3[2*4*4+1*4+2]
          - 1.0/8*GHPLs2[1*4+2]*HPLs1[0]
          - 1.0/8*GHPLs2[1*4+2]*HPLs1[1]
          + 1.0/8*GHPLs2[2*4+3]*HPLs1[0]
          - 1.0/8*GHPLs3[0*4*4+2*4+3]
          - 1.0/8*GHPLs2[3*4+3]*HPLs1[0]
          + 1.0/8*GHPLs3[0*4*4+3*4+3]
          + 5.0/8*GHPLs1[3]*zeta2
          + 3.0/8*GHPLs1[3]*HPLs1[0]
          - 1.0/8*GHPLs1[3]*HPLs2[1*2+0]
          - 1.0/8*GHPLs1[3]*HPLs2[0*2+1]
          - 1.0/8*GHPLs3[2*4*4+0*4+3]
          - 3.0/8*GHPLs2[0*4+3]
          + 1.0/8*GHPLs2[0*4+3]*HPLs1[1]
          + 3.0/8*GHPLs2[2*4+0]
          - 1.0/8*GHPLs2[2*4+0]*HPLs1[0]
          + 1.0/8*GHPLs2[3*4+0]*HPLs1[0]
          - 1.0/8*GHPLs3[0*4*4+3*4+0]
          - 3.0/8*GHPLs1[0]*HPLs1[0]
          + 1.0/4*GHPLs1[0]*HPLs2[0*2+0]
          + 1.0/8*GHPLs1[0]*HPLs2[1*2+0]
          - 3.0/8*GHPLs1[0]*HPLs1[1]
          + 1.0/8*GHPLs1[0]*HPLs2[0*2+1]
          - 3.0/8*GHPLs2[2*4+1]
          + 1.0/8*GHPLs3[0*4*4+2*4+1]
          - 1.0/2*GHPLs1[1]*zeta2
          + 3.0/8*GHPLs1[1]*HPLs1[0]
          - 1.0/8*GHPLs1[1]*HPLs2[0*2+0]
          - 1.0/8*GHPLs1[1]*HPLs2[1*2+0]
          + 3.0/8*GHPLs1[1]*HPLs1[1]
          + 1.0/8*GHPLs3[2*4*4+0*4+1]
          - 1.0/8*GHPLs2[0*4+1]*HPLs1[0]
          - 1.0/8*GHPLs2[0*4+1]*HPLs1[1]
          - 1.0/8*GHPLs3[2*4*4+1*4+1]
          + 1.0/8*GHPLs2[1*4+1]*HPLs1[0]
          + 1.0/8*GHPLs2[1*4+1]*HPLs1[1]
          + 5.0/8*HPLs1[0]*zeta2
          + 3.0/8*HPLs2[0*2+0]
          + 1.0/8*HPLs3[1*2*2+0*2+0]
          + 1.0/8*HPLs3[0*2*2+1*2+0]
          + 1.0/8*HPLs1[1]*zeta2
          + 3.0/8*HPLs2[0*2+1]
          + 1.0/8*HPLs3[0*2*2+0*2+1]
          + 1.0/8*HPLs3[1*2*2+0*2+1]
          + 1.0/4*HPLs3[0*2*2+1*2+1]
          )

       + (dN_c*dN_c-1)/(dN_c*dN_c)*u*pow(u+v,-2) * (
          - 1.0/16*GHPLs1[0]
          + 1.0/16*HPLs1[0]
          )

       + (dN_c*dN_c-1)/(dN_c*dN_c)*u*pow(u+v,-1) * (
          - 9.0/16*GHPLs1[0]
          + 9.0/16*HPLs1[0]
          )

       + (dN_c*dN_c-1)/(dN_c*dN_c)*u*pow(1-u-v,-1) * (
          - 1.0/4*zeta2
          + 1.0/4*GHPLs1[3]*HPLs1[0]
          - 1.0/4*GHPLs2[0*4+3]
          - 1.0/4*GHPLs1[0]*HPLs1[0]
          + 1.0/4*HPLs2[0*2+0]
          - 1.0/4*HPLs2[0*2+1]
          )

       + (dN_c*dN_c-1)/(dN_c*dN_c)*u * (
          - 3.0/8*GHPLs1[2]
          + 3.0/8*GHPLs1[0]
          + 3.0/8*HPLs1[1]
          )

       + (dN_c*dN_c-1)/(dN_c*dN_c)*u*v * (
          - 5.0/2*zeta2
          - 5.0/8*GHPLs1[2]*HPLs1[0]
          + 5.0/8*GHPLs2[0*4+2]
          + 5.0/8*GHPLs1[3]*HPLs1[0]
          - 5.0/8*GHPLs2[0*4+3]
          + 5.0/8*GHPLs2[2*4+0]
          - 5.0/8*GHPLs1[0]*HPLs1[0]
          - 5.0/8*GHPLs1[0]*HPLs1[1]
          - 5.0/8*GHPLs2[2*4+1]
          + 5.0/8*GHPLs1[1]*HPLs1[0]
          + 5.0/8*GHPLs1[1]*HPLs1[1]
          + 5.0/8*HPLs2[0*2+0]
          + 5.0/8*HPLs2[0*2+1]
          )

       + (dN_c*dN_c-1)/(dN_c*dN_c)*pow(u,2) * (
          - 3.0/2*zeta2
          - 3.0/8*GHPLs1[2]*HPLs1[0]
          + 3.0/8*GHPLs2[0*4+2]
          + 3.0/8*GHPLs1[3]*HPLs1[0]
          - 3.0/8*GHPLs2[0*4+3]
          + 3.0/8*GHPLs2[2*4+0]
          - 3.0/8*GHPLs1[0]*HPLs1[0]
          - 3.0/8*GHPLs1[0]*HPLs1[1]
          - 3.0/8*GHPLs2[2*4+1]
          + 3.0/8*GHPLs1[1]*HPLs1[0]
          + 3.0/8*GHPLs1[1]*HPLs1[1]
          + 3.0/8*HPLs2[0*2+0]
          + 3.0/8*HPLs2[0*2+1]
          )

       + (dN_c*dN_c-1)/(dN_c*dN_c)*double_complex(0,1)*M_PI*pow(u,-2) * (
          - 1.0/4*GHPLs3[3*4*4+2*4+2]
          - 1.0/4*GHPLs2[2*4+2]*HPLs1[0]
          + 1.0/4*GHPLs1[2]*HPLs1[0]
          - 1.0/4*GHPLs1[2]*HPLs2[0*2+0]
          + 1.0/4*GHPLs3[3*4*4+0*4+2]
          - 1.0/4*GHPLs2[1*4+2]
          + 1.0/8*GHPLs2[1*4+0]
          - 1.0/4*GHPLs3[3*4*4+2*4+1]
          - 1.0/4*GHPLs2[2*4+1]*HPLs1[0]
          + 1.0/4*GHPLs1[1]
          + 1.0/2*GHPLs1[1]*zeta2
          - 1.0/8*GHPLs1[1]*HPLs1[0]
          + 1.0/4*GHPLs1[1]*HPLs2[0*2+0]
          + 1.0/4*GHPLs1[1]*HPLs2[0*2+1]
          - 1.0/4*GHPLs3[3*4*4+0*4+1]
          + 1.0/8*GHPLs2[1*4+1]
          )

       + (dN_c*dN_c-1)/(dN_c*dN_c)*double_complex(0,1)*M_PI*pow(u,-2)*v * (
          + 1.0/2*GHPLs3[3*4*4+2*4+2]
          + 1.0/2*GHPLs2[2*4+2]*HPLs1[0]
          - 1.0/2*GHPLs1[2]*HPLs1[0]
          + 1.0/2*GHPLs1[2]*HPLs2[0*2+0]
          - 1.0/2*GHPLs3[3*4*4+0*4+2]
          + 1.0/2*GHPLs2[1*4+2]
          - 1.0/4*GHPLs2[1*4+0]
          + 1.0/2*GHPLs3[3*4*4+2*4+1]
          + 1.0/2*GHPLs2[2*4+1]*HPLs1[0]
          - 3.0/8*GHPLs1[1]
          - GHPLs1[1]*zeta2
          + 1.0/4*GHPLs1[1]*HPLs1[0]
          - 1.0/2*GHPLs1[1]*HPLs2[0*2+0]
          - 1.0/2*GHPLs1[1]*HPLs2[0*2+1]
          + 1.0/2*GHPLs3[3*4*4+0*4+1]
          - 1.0/4*GHPLs2[1*4+1]
          )

       + (dN_c*dN_c-1)/(dN_c*dN_c)*double_complex(0,1)*M_PI*pow(u,-2)*pow(v,2) * (
          - 1.0/4*GHPLs3[3*4*4+2*4+2]
          - 1.0/4*GHPLs2[2*4+2]*HPLs1[0]
          + 1.0/4*GHPLs1[2]*HPLs1[0]
          - 1.0/4*GHPLs1[2]*HPLs2[0*2+0]
          + 1.0/4*GHPLs3[3*4*4+0*4+2]
          - 1.0/8*GHPLs2[1*4+2]
          - 1.0/8*GHPLs2[2*4+3]
          + 1.0/8*GHPLs2[3*4+3]
          + 1.0/8*GHPLs1[3]*HPLs1[0]
          + 1.0/8*GHPLs1[3]*HPLs1[1]
          - 1.0/8*GHPLs2[0*4+3]
          + 1.0/8*GHPLs2[1*4+0]
          - 1.0/4*GHPLs3[3*4*4+2*4+1]
          - 1.0/4*GHPLs2[2*4+1]*HPLs1[0]
          + 1.0/2*GHPLs1[1]*zeta2
          - 1.0/8*GHPLs1[1]*HPLs1[0]
          + 1.0/4*GHPLs1[1]*HPLs2[0*2+0]
          + 1.0/4*GHPLs1[1]*HPLs2[0*2+1]
          - 1.0/4*GHPLs3[3*4*4+0*4+1]
          + 1.0/8*GHPLs2[1*4+1]
          )

       + (dN_c*dN_c-1)/(dN_c*dN_c)*double_complex(0,1)*M_PI*pow(u,-2)*pow(v,3) * (
          - 1.0/4*GHPLs2[1*4+2]
          + 1.0/4*GHPLs2[2*4+3]
          - 1.0/4*GHPLs2[3*4+3]
          - 1.0/4*GHPLs1[3]*HPLs1[0]
          - 1.0/4*GHPLs1[3]*HPLs1[1]
          + 1.0/4*GHPLs2[0*4+3]
          + 1.0/8*GHPLs1[1]
          )

       + (dN_c*dN_c-1)/(dN_c*dN_c)*double_complex(0,1)*M_PI*pow(u,-2)*pow(v,4) * (
          + 1.0/8*GHPLs2[1*4+2]
          - 1.0/8*GHPLs2[2*4+3]
          + 1.0/8*GHPLs2[3*4+3]
          + 1.0/8*GHPLs1[3]*HPLs1[0]
          + 1.0/8*GHPLs1[3]*HPLs1[1]
          - 1.0/8*GHPLs2[0*4+3]
          )

       + (dN_c*dN_c-1)/(dN_c*dN_c)*double_complex(0,1)*M_PI*pow(u,-1)*pow(u+v,-1) * (
          - 1.0/8*GHPLs1[1]
          )

       + (dN_c*dN_c-1)/(dN_c*dN_c)*double_complex(0,1)*M_PI*pow(u,-1) * (
          + 3.0/8
          + 1.0/2*zeta2
          - 1.0/2*GHPLs2[3*4+2]
          - 3.0/2*GHPLs1[2]*HPLs1[0]
          + GHPLs2[1*4+2]
          - 1.0/2*GHPLs2[1*4+0]
          - 5.0/8*GHPLs1[1]
          + 1.0/2*GHPLs1[1]*HPLs1[0]
          - 1.0/2*GHPLs2[1*4+1]
          + 1.0/8*HPLs1[0]
          + 1.0/4*HPLs2[0*2+1]
          )

       + (dN_c*dN_c-1)/(dN_c*dN_c)*double_complex(0,1)*M_PI*pow(u,-1)*v * (
          - 3.0/4
          - zeta2
          + 3.0/4*GHPLs2[3*4+2]
          + 1.0/8*GHPLs1[2]
          + 7.0/4*GHPLs1[2]*HPLs1[0]
          - 5.0/4*GHPLs2[1*4+2]
          + 1.0/4*GHPLs2[2*4+3]
          - 1.0/4*GHPLs2[3*4+3]
          - 3.0/8*GHPLs1[3]
          - 1.0/4*GHPLs1[3]*HPLs1[0]
          - 1.0/4*GHPLs1[3]*HPLs1[1]
          + 1.0/4*GHPLs2[0*4+3]
          + 1.0/4*GHPLs2[3*4+0]
          + 1.0/8*GHPLs1[0]
          + 1.0/2*GHPLs2[1*4+0]
          + 1.0/8*GHPLs1[1]
          - 1.0/2*GHPLs1[1]*HPLs1[0]
          + 1.0/2*GHPLs2[1*4+1]
          - 1.0/8*HPLs1[0]
          - 1.0/4*HPLs2[0*2+0]
          - 1.0/8*HPLs1[1]
          - 1.0/2*HPLs2[0*2+1]
          )

       + (dN_c*dN_c-1)/(dN_c*dN_c)*double_complex(0,1)*M_PI*pow(u,-1)*pow(v,2) * (
          + 3.0/8
          + 1.0/2*zeta2
          - 1.0/4*GHPLs2[3*4+2]
          - 1.0/4*GHPLs1[2]
          - 1.0/4*GHPLs1[2]*HPLs1[0]
          + 1.0/2*GHPLs1[3]
          - 1.0/4*GHPLs2[3*4+0]
          - 1.0/4*GHPLs1[0]
          + 3.0/4*GHPLs1[1]
          + 1.0/8*HPLs1[0]
          + 1.0/4*HPLs2[0*2+0]
          + 1.0/4*HPLs1[1]
          + 1.0/4*HPLs2[0*2+1]
          )

       + (dN_c*dN_c-1)/(dN_c*dN_c)*double_complex(0,1)*M_PI*pow(u,-1)*pow(v,3) * (
          + 1.0/8*GHPLs1[2]
          + 1.0/4*GHPLs2[1*4+2]
          - 1.0/4*GHPLs2[2*4+3]
          + 1.0/4*GHPLs2[3*4+3]
          - 1.0/8*GHPLs1[3]
          + 1.0/4*GHPLs1[3]*HPLs1[0]
          + 1.0/4*GHPLs1[3]*HPLs1[1]
          - 1.0/4*GHPLs2[0*4+3]
          + 1.0/8*GHPLs1[0]
          - 1.0/8*GHPLs1[1]
          - 1.0/8*HPLs1[0]
          - 1.0/8*HPLs1[1]
          )

       + (dN_c*dN_c-1)/(dN_c*dN_c)*double_complex(0,1)*M_PI*pow(1-u,-1) * (
          - 1.0/4*GHPLs1[3]
          - 1.0/4*HPLs1[0]
          )

       + (dN_c*dN_c-1)/(dN_c*dN_c)*double_complex(0,1)*M_PI*pow(u+v,-2) * (
          - 1.0/8*GHPLs1[2]*HPLs1[0]
          + 1.0/8*GHPLs2[1*4+2]
          + 1.0/8*GHPLs2[1*4+0]
          + 1.0/8*HPLs2[0*2+1]
          )

       + (dN_c*dN_c-1)/(dN_c*dN_c)*double_complex(0,1)*M_PI*pow(u+v,-1) * (
          + 1.0/16
          + 1.0/2*GHPLs1[2]*HPLs1[0]
          - 1.0/2*GHPLs2[1*4+2]
          - 1.0/2*GHPLs2[1*4+0]
          + 1.0/8*GHPLs1[1]
          - 1.0/8*HPLs1[0]
          - 1.0/2*HPLs2[0*2+1]
          )

       + (dN_c*dN_c-1)/(dN_c*dN_c)*double_complex(0,1)*M_PI * (
          - 5.0/16
          + 5.0/8*zeta2
          - 1.0/2*zeta3
          + 1.0/4*GHPLs3[3*4*4+2*4+2]
          + 1.0/4*GHPLs2[2*4+2]*HPLs1[0]
          - GHPLs2[3*4+2]
          - 3.0/8*GHPLs1[2]
          - 5.0/8*GHPLs1[2]*HPLs1[0]
          + 1.0/4*GHPLs1[2]*HPLs2[0*2+0]
          - 1.0/4*GHPLs3[3*4*4+0*4+2]
          - 3.0/8*GHPLs2[1*4+2]
          + 1.0/4*GHPLs3[3*4*4+2*4+3]
          + 1.0/4*GHPLs2[2*4+3]*HPLs1[0]
          + 1.0/2*GHPLs3[3*4*4+3*4+3]
          - 3.0/8*GHPLs2[3*4+3]
          + 1.0/2*GHPLs2[3*4+3]*HPLs1[0]
          - 1.0/2*GHPLs3[0*4*4+3*4+3]
          + 17.0/16*GHPLs1[3]
          - 1.0/4*GHPLs1[3]*zeta2
          + 3.0/4*GHPLs1[3]*HPLs2[0*2+0]
          - 1.0/4*GHPLs1[3]*HPLs2[0*2+1]
          - 1.0/4*GHPLs3[3*4*4+0*4+3]
          - 1.0/2*GHPLs2[0*4+3]*HPLs1[0]
          - 1.0/2*GHPLs2[2*4+0]*HPLs1[0]
          + 1.0/2*GHPLs3[1*4*4+2*4+0]
          - 1.0/2*GHPLs3[3*4*4+3*4+0]
          + 3.0/8*GHPLs2[3*4+0]
          - 1.0/4*GHPLs2[3*4+0]*HPLs1[0]
          - 3.0/8*GHPLs1[0]
          - 1.0/2*GHPLs1[0]*HPLs2[0*2+0]
          - 1.0/2*GHPLs3[1*4*4+0*4+0]
          + 3.0/4*GHPLs2[1*4+0]
          + 1.0/2*GHPLs2[1*4+0]*HPLs1[0]
          - 1.0/2*GHPLs3[1*4*4+1*4+0]
          + 1.0/4*GHPLs3[3*4*4+2*4+1]
          + 1.0/4*GHPLs2[2*4+1]*HPLs1[0]
          + 3.0/4*GHPLs1[1]
          - 1.0/2*GHPLs1[1]*zeta2
          - 3.0/8*GHPLs1[1]*HPLs1[0]
          - 1.0/4*GHPLs1[1]*HPLs2[0*2+0]
          - 1.0/4*GHPLs1[1]*HPLs2[0*2+1]
          + 1.0/4*GHPLs3[3*4*4+0*4+1]
          + 3.0/8*GHPLs2[1*4+1]
          + 17.0/16*HPLs1[0]
          - 1.0/4*HPLs1[0]*zeta2
          + 3.0/4*HPLs3[0*2*2+0*2+0]
          - 1.0/4*HPLs3[0*2*2+1*2+0]
          + 3.0/8*HPLs1[1]
          + 1.0/2*HPLs2[0*2+1]
          )

       + (dN_c*dN_c-1)/(dN_c*dN_c)*double_complex(0,1)*M_PI*v*pow(1-u,-2) * (
          + zeta2
          - 1.0/2*GHPLs2[3*4+2]
          - 1.0/2*GHPLs1[2]*HPLs1[0]
          + 1.0/2*GHPLs1[3]
          - 1.0/2*GHPLs2[3*4+0]
          + 1.0/2*HPLs1[0]
          + 1.0/2*HPLs2[0*2+0]
          + 1.0/2*HPLs2[0*2+1]
          )

       + (dN_c*dN_c-1)/(dN_c*dN_c)*double_complex(0,1)*M_PI*v*pow(1-u,-1) * (
          + 1.0/4
          - 2*zeta2
          + GHPLs2[3*4+2]
          + GHPLs1[2]*HPLs1[0]
          - 3.0/4*GHPLs1[3]
          + GHPLs2[3*4+0]
          - 1.0/4*HPLs1[0]
          - HPLs2[0*2+0]
          - HPLs2[0*2+1]
          )

       + (dN_c*dN_c-1)/(dN_c*dN_c)*double_complex(0,1)*M_PI*v * (
          - 3.0/8
          - 1.0/4*zeta2
          - 1.0/8*GHPLs1[2]
          + 1.0/4*GHPLs2[1*4+2]
          - 1.0/4*GHPLs2[2*4+3]
          + 1.0/4*GHPLs2[3*4+3]
          + 1.0/8*GHPLs1[3]
          + 1.0/4*GHPLs1[3]*HPLs1[0]
          + 1.0/4*GHPLs1[3]*HPLs1[1]
          - 1.0/4*GHPLs2[0*4+3]
          - 1.0/4*GHPLs2[3*4+0]
          - 1.0/8*GHPLs1[0]
          - 1.0/4*GHPLs1[0]*HPLs1[0]
          + 1.0/4*GHPLs2[2*4+1]
          + 1.0/8*GHPLs1[1]
          - 1.0/4*GHPLs1[1]*HPLs1[1]
          + 1.0/4*GHPLs2[0*4+1]
          - 1.0/4*GHPLs2[1*4+1]
          + 1.0/8*HPLs1[0]
          + 1.0/4*HPLs2[0*2+0]
          + 1.0/4*HPLs2[1*2+0]
          + 1.0/8*HPLs1[1]
          )

       + (dN_c*dN_c-1)/(dN_c*dN_c)*double_complex(0,1)*M_PI*pow(v,2)*pow(1-u,-3) * (
          - zeta2
          + 1.0/2*GHPLs2[3*4+2]
          + 1.0/2*GHPLs1[2]*HPLs1[0]
          + 1.0/2*GHPLs2[3*4+0]
          - 1.0/2*HPLs2[0*2+0]
          - 1.0/2*HPLs2[0*2+1]
          )

       + (dN_c*dN_c-1)/(dN_c*dN_c)*double_complex(0,1)*M_PI*pow(v,2)*pow(1-u,-2) * (
          + 1.0/2*zeta2
          - 1.0/4*GHPLs2[3*4+2]
          - 1.0/4*GHPLs1[2]*HPLs1[0]
          + 1.0/2*GHPLs1[3]
          - 1.0/4*GHPLs2[3*4+0]
          + 1.0/4*HPLs2[0*2+0]
          + 1.0/4*HPLs2[0*2+1]
          )

       + (dN_c*dN_c-1)/(dN_c*dN_c)*double_complex(0,1)*M_PI*pow(v,2)*pow(1-u,-1) * (
          + 3.0/8
          + 1.0/2*zeta2
          - 1.0/4*GHPLs2[3*4+2]
          + 1.0/8*GHPLs1[2]
          - 1.0/4*GHPLs1[2]*HPLs1[0]
          - 1.0/4*GHPLs2[3*4+0]
          + 1.0/8*GHPLs1[0]
          + 1.0/4*GHPLs1[1]
          - 3.0/8*HPLs1[0]
          + 1.0/4*HPLs2[0*2+0]
          - 1.0/8*HPLs1[1]
          + 1.0/4*HPLs2[0*2+1]
          )

       + (dN_c*dN_c-1)/(dN_c*dN_c)*double_complex(0,1)*M_PI*pow(v,2) * (
          - 1.0/8*zeta2
          + 3.0/8*GHPLs1[2]
          + 1.0/8*GHPLs2[1*4+2]
          - 1.0/8*GHPLs2[2*4+3]
          + 1.0/8*GHPLs2[3*4+3]
          - 3.0/8*GHPLs1[3]
          + 1.0/8*GHPLs1[3]*HPLs1[0]
          + 1.0/8*GHPLs1[3]*HPLs1[1]
          - 1.0/8*GHPLs2[0*4+3]
          - 1.0/8*GHPLs2[3*4+0]
          + 3.0/8*GHPLs1[0]
          - 1.0/8*GHPLs1[0]*HPLs1[0]
          + 1.0/8*GHPLs2[2*4+1]
          - 3.0/8*GHPLs1[1]
          - 1.0/8*GHPLs1[1]*HPLs1[1]
          + 1.0/8*GHPLs2[0*4+1]
          - 1.0/8*GHPLs2[1*4+1]
          - 3.0/8*HPLs1[0]
          + 1.0/8*HPLs2[0*2+0]
          + 1.0/8*HPLs2[1*2+0]
          - 3.0/8*HPLs1[1]
          )

       + (dN_c*dN_c-1)/(dN_c*dN_c)*double_complex(0,1)*M_PI*u*pow(u+v,-2) * (
          - 1.0/16
          )

       + (dN_c*dN_c-1)/(dN_c*dN_c)*double_complex(0,1)*M_PI*u*pow(u+v,-1) * (
          - 9.0/16
          )

       + (dN_c*dN_c-1)/(dN_c*dN_c)*double_complex(0,1)*M_PI*u*pow(1-u-v,-1) * (
          - 1.0/4*GHPLs1[3]
          - 1.0/4*HPLs1[0]
          )

       + (dN_c*dN_c-1)/(dN_c*dN_c)*double_complex(0,1)*M_PI*u*v * (
          + 5.0/8*GHPLs1[2]
          - 5.0/8*GHPLs1[3]
          + 5.0/8*GHPLs1[0]
          - 5.0/8*GHPLs1[1]
          - 5.0/8*HPLs1[0]
          - 5.0/8*HPLs1[1]
          )

       + (dN_c*dN_c-1)/(dN_c*dN_c)*double_complex(0,1)*M_PI*pow(u,2) * (
          + 3.0/8*GHPLs1[2]
          - 3.0/8*GHPLs1[3]
          + 3.0/8*GHPLs1[0]
          - 3.0/8*GHPLs1[1]
          - 3.0/8*HPLs1[0]
          - 3.0/8*HPLs1[1]
          )

       + C_F*NF * (
          - 19.0/18*zeta2
          - 1.0/3*zeta3
          - 1.0/3*GHPLs2[3*4+3]*HPLs1[0]
          + 1.0/3*GHPLs3[0*4*4+3*4+3]
          + 2.0/3*GHPLs1[3]*zeta2
          + 19.0/18*GHPLs1[3]*HPLs1[0]
          + 1.0/3*GHPLs1[3]*HPLs2[0*2+0]
          - 19.0/18*GHPLs2[0*4+3]
          - 1.0/3*GHPLs2[0*4+3]*HPLs1[0]
          + 1.0/3*GHPLs3[0*4*4+0*4+3]
          + 1.0/3*GHPLs1[0]*zeta2
          - 19.0/18*GHPLs1[0]*HPLs1[0]
          - 2.0/3*GHPLs1[0]*HPLs2[0*2+0]
          + 1.0/3*GHPLs1[0]*HPLs2[0*2+1]
          + 1.0/3*GHPLs2[0*4+0]*HPLs1[0]
          + 1.0/3*HPLs1[0]*zeta2
          + 19.0/18*HPLs2[0*2+0]
          + 2.0/3*HPLs3[0*2*2+0*2+0]
          - 1.0/3*HPLs3[0*2*2+1*2+0]
          + 1.0/3*HPLs1[1]*zeta2
          - 19.0/18*HPLs2[0*2+1]
          - 2.0/3*HPLs3[0*2*2+0*2+1]
          + 1.0/3*HPLs3[0*2*2+1*2+1]
          )

       + C_F*NF*double_complex(0,1)*M_PI * (
          + 1.0/3*GHPLs2[3*4+3]
          - 19.0/18*GHPLs1[3]
          - 19.0/18*HPLs1[0]
          - 1.0/3*HPLs2[0*2+0]
          );

}

void alpha_2_2(double u, double v, int n_f, double *GHPLs1, double *GHPLs2, double *GHPLs3, double *GHPLs4, double *HPLs1, double *HPLs2, double *HPLs3, double *HPLs4, double_complex &alpha) {
  //  const double zeta2 = M_PI*M_PI/6;
  //  const double zeta3 = 1.20205690315959429;
  //  const double zeta4 = pow(M_PI,4)/90;
  //  const double N=3;
  //  const double CF=(N*N-1)/(2*N);
  double NF=(double)n_f;

  alpha =
    (dN_c*dN_c-1)*pow(u,-2) * (
          + 1.0/2*GHPLs2[2*4+2]*zeta2
          - 13.0/24*GHPLs2[2*4+2]*HPLs1[0]
          - 1.0/2*GHPLs2[2*4+2]*HPLs2[1*2+0]
          - 1.0/2*GHPLs4[2*4*4*4+1*4*4+2*4+2]
          + 1.0/2*GHPLs3[1*4*4+2*4+2]*HPLs1[0]
          + 1.0/2*GHPLs3[1*4*4+2*4+2]*HPLs1[1]
          - 13.0/24*GHPLs1[2]*zeta2
          + 277.0/144*GHPLs1[2]*HPLs1[0]
          + 11.0/6*GHPLs1[2]*HPLs2[0*2+0]
          + 13.0/24*GHPLs1[2]*HPLs2[1*2+0]
          + 1.0/2*GHPLs3[2*4*4+0*4+2]*HPLs1[0]
          + 1.0/2*GHPLs4[2*4*4*4+1*4*4+0*4+2]
          - 1.0/2*GHPLs3[1*4*4+0*4+2]*HPLs1[0]
          - 1.0/2*GHPLs3[1*4*4+0*4+2]*HPLs1[1]
          + 1.0/4*GHPLs3[2*4*4+1*4+2]*HPLs1[0]
          - GHPLs2[1*4+2]*zeta2
          + 1.0/4*GHPLs2[1*4+2]*HPLs2[1*2+0]
          - 1.0/4*GHPLs2[1*4+2]*HPLs2[0*2+1]
          + 1.0/2*GHPLs4[2*4*4*4+1*4*4+1*4+2]
          - 1.0/2*GHPLs3[1*4*4+1*4+2]*HPLs1[0]
          - 1.0/2*GHPLs3[1*4*4+1*4+2]*HPLs1[1]
          - 13.0/24*GHPLs3[2*4*4+2*4+1]
          + 1.0/2*GHPLs3[2*4*4+2*4+1]*HPLs1[0]
          + 277.0/144*GHPLs2[2*4+1]
          - GHPLs2[2*4+1]*zeta2
          + 11.0/12*GHPLs2[2*4+1]*HPLs1[0]
          + 1.0/4*GHPLs2[2*4+1]*HPLs2[1*2+0]
          + 13.0/24*GHPLs2[2*4+1]*HPLs1[1]
          - 1.0/4*GHPLs2[2*4+1]*HPLs2[0*2+1]
          + 3.0/4*GHPLs4[2*4*4*4+1*4*4+2*4+1]
          - 3.0/4*GHPLs3[1*4*4+2*4+1]*HPLs1[0]
          - 3.0/4*GHPLs3[1*4*4+2*4+1]*HPLs1[1]
          - 67.0/24*GHPLs1[1]*zeta2
          - 3.0/4*GHPLs1[1]*zeta3
          - 277.0/144*GHPLs1[1]*HPLs1[0]
          - 11.0/6*GHPLs1[1]*HPLs2[0*2+0]
          - 35.0/24*GHPLs1[1]*HPLs2[1*2+0]
          - 277.0/144*GHPLs1[1]*HPLs1[1]
          + GHPLs1[1]*HPLs1[1]*zeta2
          - 11.0/12*GHPLs1[1]*HPLs2[0*2+1]
          - 1.0/4*GHPLs1[1]*HPLs3[1*2*2+0*2+1]
          - 13.0/24*GHPLs1[1]*HPLs2[1*2+1]
          + 1.0/4*GHPLs1[1]*HPLs3[0*2*2+1*2+1]
          - 1.0/4*GHPLs3[2*4*4+0*4+1]*HPLs1[0]
          - 1.0/4*GHPLs4[2*4*4*4+1*4*4+0*4+1]
          + 1.0/4*GHPLs3[1*4*4+0*4+1]*HPLs1[0]
          + 1.0/4*GHPLs3[1*4*4+0*4+1]*HPLs1[1]
          + 1.0/2*GHPLs4[2*4*4*4+2*4*4+1*4+1]
          - 13.0/24*GHPLs3[2*4*4+1*4+1]
          - 1.0/2*GHPLs3[2*4*4+1*4+1]*HPLs1[0]
          - 1.0/2*GHPLs3[2*4*4+1*4+1]*HPLs1[1]
          - 1.0/2*GHPLs2[1*4+1]*zeta2
          + 13.0/24*GHPLs2[1*4+1]*HPLs1[0]
          + 13.0/24*GHPLs2[1*4+1]*HPLs1[1]
          + 1.0/2*GHPLs2[1*4+1]*HPLs2[0*2+1]
          + 1.0/2*GHPLs2[1*4+1]*HPLs2[1*2+1]
          - 1.0/2*GHPLs4[2*4*4*4+1*4*4+1*4+1]
          + 1.0/2*GHPLs3[1*4*4+1*4+1]*HPLs1[0]
          + 1.0/2*GHPLs3[1*4*4+1*4+1]*HPLs1[1]
          )

       + (dN_c*dN_c-1)*pow(u,-2)*v * (
          - GHPLs2[2*4+2]*zeta2
          + 13.0/12*GHPLs2[2*4+2]*HPLs1[0]
          + GHPLs2[2*4+2]*HPLs2[1*2+0]
          + GHPLs4[2*4*4*4+1*4*4+2*4+2]
          - GHPLs3[1*4*4+2*4+2]*HPLs1[0]
          - GHPLs3[1*4*4+2*4+2]*HPLs1[1]
          + 13.0/12*GHPLs1[2]*zeta2
          - 277.0/72*GHPLs1[2]*HPLs1[0]
          - 11.0/3*GHPLs1[2]*HPLs2[0*2+0]
          - 13.0/12*GHPLs1[2]*HPLs2[1*2+0]
          - GHPLs3[2*4*4+0*4+2]*HPLs1[0]
          - GHPLs4[2*4*4*4+1*4*4+0*4+2]
          + GHPLs3[1*4*4+0*4+2]*HPLs1[0]
          + GHPLs3[1*4*4+0*4+2]*HPLs1[1]
          - 1.0/2*GHPLs3[2*4*4+1*4+2]*HPLs1[0]
          + 2*GHPLs2[1*4+2]*zeta2
          - 1.0/2*GHPLs2[1*4+2]*HPLs2[1*2+0]
          + 1.0/2*GHPLs2[1*4+2]*HPLs2[0*2+1]
          - GHPLs4[2*4*4*4+1*4*4+1*4+2]
          + GHPLs3[1*4*4+1*4+2]*HPLs1[0]
          + GHPLs3[1*4*4+1*4+2]*HPLs1[1]
          + 13.0/12*GHPLs3[2*4*4+2*4+1]
          - GHPLs3[2*4*4+2*4+1]*HPLs1[0]
          - 277.0/72*GHPLs2[2*4+1]
          + 2*GHPLs2[2*4+1]*zeta2
          - 11.0/6*GHPLs2[2*4+1]*HPLs1[0]
          - 1.0/2*GHPLs2[2*4+1]*HPLs2[1*2+0]
          - 13.0/12*GHPLs2[2*4+1]*HPLs1[1]
          + 1.0/2*GHPLs2[2*4+1]*HPLs2[0*2+1]
          - 3.0/2*GHPLs4[2*4*4*4+1*4*4+2*4+1]
          + 3.0/2*GHPLs3[1*4*4+2*4+1]*HPLs1[0]
          + 3.0/2*GHPLs3[1*4*4+2*4+1]*HPLs1[1]
          + 67.0/12*GHPLs1[1]*zeta2
          + 3.0/2*GHPLs1[1]*zeta3
          + 277.0/72*GHPLs1[1]*HPLs1[0]
          + 11.0/3*GHPLs1[1]*HPLs2[0*2+0]
          + 35.0/12*GHPLs1[1]*HPLs2[1*2+0]
          + 277.0/72*GHPLs1[1]*HPLs1[1]
          - 2*GHPLs1[1]*HPLs1[1]*zeta2
          + 11.0/6*GHPLs1[1]*HPLs2[0*2+1]
          + 1.0/2*GHPLs1[1]*HPLs3[1*2*2+0*2+1]
          + 13.0/12*GHPLs1[1]*HPLs2[1*2+1]
          - 1.0/2*GHPLs1[1]*HPLs3[0*2*2+1*2+1]
          + 1.0/2*GHPLs3[2*4*4+0*4+1]*HPLs1[0]
          + 1.0/2*GHPLs4[2*4*4*4+1*4*4+0*4+1]
          - 1.0/2*GHPLs3[1*4*4+0*4+1]*HPLs1[0]
          - 1.0/2*GHPLs3[1*4*4+0*4+1]*HPLs1[1]
          - GHPLs4[2*4*4*4+2*4*4+1*4+1]
          + 13.0/12*GHPLs3[2*4*4+1*4+1]
          + GHPLs3[2*4*4+1*4+1]*HPLs1[0]
          + GHPLs3[2*4*4+1*4+1]*HPLs1[1]
          + GHPLs2[1*4+1]*zeta2
          - 13.0/12*GHPLs2[1*4+1]*HPLs1[0]
          - 13.0/12*GHPLs2[1*4+1]*HPLs1[1]
          - GHPLs2[1*4+1]*HPLs2[0*2+1]
          - GHPLs2[1*4+1]*HPLs2[1*2+1]
          + GHPLs4[2*4*4*4+1*4*4+1*4+1]
          - GHPLs3[1*4*4+1*4+1]*HPLs1[0]
          - GHPLs3[1*4*4+1*4+1]*HPLs1[1]
          )

       + (dN_c*dN_c-1)*pow(u,-2)*pow(v,2) * (
          + 1.0/2*GHPLs2[2*4+2]*zeta2
          - 13.0/24*GHPLs2[2*4+2]*HPLs1[0]
          - 1.0/2*GHPLs2[2*4+2]*HPLs2[1*2+0]
          - 1.0/2*GHPLs4[2*4*4*4+1*4*4+2*4+2]
          + 1.0/2*GHPLs3[1*4*4+2*4+2]*HPLs1[0]
          + 1.0/2*GHPLs3[1*4*4+2*4+2]*HPLs1[1]
          - 13.0/24*GHPLs1[2]*zeta2
          + 277.0/144*GHPLs1[2]*HPLs1[0]
          + 11.0/6*GHPLs1[2]*HPLs2[0*2+0]
          + 13.0/24*GHPLs1[2]*HPLs2[1*2+0]
          + 1.0/2*GHPLs3[2*4*4+0*4+2]*HPLs1[0]
          + 1.0/2*GHPLs4[2*4*4*4+1*4*4+0*4+2]
          - 1.0/2*GHPLs3[1*4*4+0*4+2]*HPLs1[0]
          - 1.0/2*GHPLs3[1*4*4+0*4+2]*HPLs1[1]
          + 1.0/4*GHPLs3[2*4*4+1*4+2]*HPLs1[0]
          - GHPLs2[1*4+2]*zeta2
          + 1.0/4*GHPLs2[1*4+2]*HPLs2[1*2+0]
          - 1.0/4*GHPLs2[1*4+2]*HPLs2[0*2+1]
          + 1.0/2*GHPLs4[2*4*4*4+1*4*4+1*4+2]
          - 1.0/2*GHPLs3[1*4*4+1*4+2]*HPLs1[0]
          - 1.0/2*GHPLs3[1*4*4+1*4+2]*HPLs1[1]
          - 13.0/24*GHPLs3[2*4*4+2*4+1]
          + 1.0/2*GHPLs3[2*4*4+2*4+1]*HPLs1[0]
          + 277.0/144*GHPLs2[2*4+1]
          - GHPLs2[2*4+1]*zeta2
          + 11.0/12*GHPLs2[2*4+1]*HPLs1[0]
          + 1.0/4*GHPLs2[2*4+1]*HPLs2[1*2+0]
          + 13.0/24*GHPLs2[2*4+1]*HPLs1[1]
          - 1.0/4*GHPLs2[2*4+1]*HPLs2[0*2+1]
          + 3.0/4*GHPLs4[2*4*4*4+1*4*4+2*4+1]
          - 3.0/4*GHPLs3[1*4*4+2*4+1]*HPLs1[0]
          - 3.0/4*GHPLs3[1*4*4+2*4+1]*HPLs1[1]
          - 67.0/24*GHPLs1[1]*zeta2
          - 3.0/4*GHPLs1[1]*zeta3
          - 277.0/144*GHPLs1[1]*HPLs1[0]
          - 11.0/6*GHPLs1[1]*HPLs2[0*2+0]
          - 35.0/24*GHPLs1[1]*HPLs2[1*2+0]
          - 277.0/144*GHPLs1[1]*HPLs1[1]
          + GHPLs1[1]*HPLs1[1]*zeta2
          - 11.0/12*GHPLs1[1]*HPLs2[0*2+1]
          - 1.0/4*GHPLs1[1]*HPLs3[1*2*2+0*2+1]
          - 13.0/24*GHPLs1[1]*HPLs2[1*2+1]
          + 1.0/4*GHPLs1[1]*HPLs3[0*2*2+1*2+1]
          - 1.0/4*GHPLs3[2*4*4+0*4+1]*HPLs1[0]
          - 1.0/4*GHPLs4[2*4*4*4+1*4*4+0*4+1]
          + 1.0/4*GHPLs3[1*4*4+0*4+1]*HPLs1[0]
          + 1.0/4*GHPLs3[1*4*4+0*4+1]*HPLs1[1]
          + 1.0/2*GHPLs4[2*4*4*4+2*4*4+1*4+1]
          - 13.0/24*GHPLs3[2*4*4+1*4+1]
          - 1.0/2*GHPLs3[2*4*4+1*4+1]*HPLs1[0]
          - 1.0/2*GHPLs3[2*4*4+1*4+1]*HPLs1[1]
          - 1.0/2*GHPLs2[1*4+1]*zeta2
          + 13.0/24*GHPLs2[1*4+1]*HPLs1[0]
          + 13.0/24*GHPLs2[1*4+1]*HPLs1[1]
          + 1.0/2*GHPLs2[1*4+1]*HPLs2[0*2+1]
          + 1.0/2*GHPLs2[1*4+1]*HPLs2[1*2+1]
          - 1.0/2*GHPLs4[2*4*4*4+1*4*4+1*4+1]
          + 1.0/2*GHPLs3[1*4*4+1*4+1]*HPLs1[0]
          + 1.0/2*GHPLs3[1*4*4+1*4+1]*HPLs1[1]
          )

       + (dN_c*dN_c-1)*pow(u,-1) * (
          + 1.0/2
          - 10.0/3*zeta2
          - 3.0/4*zeta3
          - 13.0/24*GHPLs2[2*4+2]
          + 1.0/4*GHPLs2[2*4+2]*HPLs1[0]
          + 277.0/144*GHPLs1[2]
          - 3.0/4*GHPLs1[2]*zeta2
          + 1.0/4*GHPLs1[2]*HPLs1[0]
          + 13.0/24*GHPLs1[2]*HPLs1[1]
          - 1.0/4*GHPLs1[2]*HPLs2[0*2+1]
          + 1.0/4*GHPLs3[2*4*4+1*4+2]
          - 1.0/4*GHPLs2[1*4+2]*HPLs1[0]
          - 1.0/4*GHPLs2[1*4+2]*HPLs1[1]
          + 1.0/4*GHPLs2[2*4+0]*HPLs1[0]
          + 1.0/4*GHPLs3[2*4*4+1*4+0]
          - 1.0/4*GHPLs2[1*4+0]*HPLs1[0]
          - 1.0/4*GHPLs2[1*4+0]*HPLs1[1]
          + 1.0/4*GHPLs3[2*4*4+2*4+1]
          - 2.0/3*GHPLs2[2*4+1]
          - 1.0/4*GHPLs2[2*4+1]*HPLs1[0]
          - 1.0/4*GHPLs2[2*4+1]*HPLs1[1]
          - 1.0/4*GHPLs1[1]*zeta2
          + 2.0/3*GHPLs1[1]*HPLs1[0]
          + 2.0/3*GHPLs1[1]*HPLs1[1]
          + 1.0/4*GHPLs1[1]*HPLs2[0*2+1]
          + 1.0/4*GHPLs1[1]*HPLs2[1*2+1]
          - 1.0/4*GHPLs3[2*4*4+1*4+1]
          + 1.0/4*GHPLs2[1*4+1]*HPLs1[0]
          + 1.0/4*GHPLs2[1*4+1]*HPLs1[1]
          - 11.0/12*HPLs2[1*2+0]
          - 277.0/144*HPLs1[1]
          + HPLs1[1]*zeta2
          - 11.0/12*HPLs2[0*2+1]
          - 1.0/4*HPLs3[1*2*2+0*2+1]
          - 13.0/24*HPLs2[1*2+1]
          + 1.0/4*HPLs3[0*2*2+1*2+1]
          )

       + (dN_c*dN_c-1)*pow(u,-1)*v * (
          - 1.0/2
          + 49.0/8*zeta2
          + 3.0/2*zeta3
          + 13.0/12*GHPLs2[2*4+2]
          - 3.0/4*GHPLs2[2*4+2]*HPLs1[0]
          - 277.0/72*GHPLs1[2]
          + 7.0/4*GHPLs1[2]*zeta2
          - 31.0/24*GHPLs1[2]*HPLs1[0]
          - 1.0/4*GHPLs1[2]*HPLs2[1*2+0]
          - 13.0/12*GHPLs1[2]*HPLs1[1]
          + 1.0/2*GHPLs1[2]*HPLs2[0*2+1]
          - GHPLs3[2*4*4+1*4+2]
          + GHPLs2[1*4+2]*HPLs1[0]
          + GHPLs2[1*4+2]*HPLs1[1]
          - 3.0/4*GHPLs3[2*4*4+2*4+1]
          + 13.0/12*GHPLs2[2*4+1]
          + 3.0/4*GHPLs2[2*4+1]*HPLs1[0]
          + 3.0/4*GHPLs2[2*4+1]*HPLs1[1]
          + 3.0/4*GHPLs1[1]*zeta2
          - 13.0/12*GHPLs1[1]*HPLs1[0]
          - 13.0/12*GHPLs1[1]*HPLs1[1]
          - 3.0/4*GHPLs1[1]*HPLs2[0*2+1]
          - 3.0/4*GHPLs1[1]*HPLs2[1*2+1]
          + 3.0/4*GHPLs3[2*4*4+1*4+1]
          - 3.0/4*GHPLs2[1*4+1]*HPLs1[0]
          - 3.0/4*GHPLs2[1*4+1]*HPLs1[1]
          + 277.0/144*HPLs1[0]
          + 11.0/6*HPLs2[0*2+0]
          + 19.0/8*HPLs2[1*2+0]
          + 277.0/72*HPLs1[1]
          - 2*HPLs1[1]*zeta2
          + 11.0/6*HPLs2[0*2+1]
          + 1.0/2*HPLs3[1*2*2+0*2+1]
          + 13.0/12*HPLs2[1*2+1]
          - 1.0/2*HPLs3[0*2*2+1*2+1]
          )

       + (dN_c*dN_c-1)*pow(u,-1)*pow(v,2) * (
          - 67.0/24*zeta2
          - 3.0/4*zeta3
          - 13.0/24*GHPLs2[2*4+2]
          + 1.0/2*GHPLs2[2*4+2]*HPLs1[0]
          + 277.0/144*GHPLs1[2]
          - GHPLs1[2]*zeta2
          + 25.0/24*GHPLs1[2]*HPLs1[0]
          + 1.0/4*GHPLs1[2]*HPLs2[1*2+0]
          + 13.0/24*GHPLs1[2]*HPLs1[1]
          - 1.0/4*GHPLs1[2]*HPLs2[0*2+1]
          + 3.0/4*GHPLs3[2*4*4+1*4+2]
          - 3.0/4*GHPLs2[1*4+2]*HPLs1[0]
          - 3.0/4*GHPLs2[1*4+2]*HPLs1[1]
          - 1.0/4*GHPLs2[2*4+0]*HPLs1[0]
          - 1.0/4*GHPLs3[2*4*4+1*4+0]
          + 1.0/4*GHPLs2[1*4+0]*HPLs1[0]
          + 1.0/4*GHPLs2[1*4+0]*HPLs1[1]
          + 1.0/2*GHPLs3[2*4*4+2*4+1]
          - 5.0/12*GHPLs2[2*4+1]
          - 1.0/2*GHPLs2[2*4+1]*HPLs1[0]
          - 1.0/2*GHPLs2[2*4+1]*HPLs1[1]
          - 1.0/2*GHPLs1[1]*zeta2
          + 5.0/12*GHPLs1[1]*HPLs1[0]
          + 5.0/12*GHPLs1[1]*HPLs1[1]
          + 1.0/2*GHPLs1[1]*HPLs2[0*2+1]
          + 1.0/2*GHPLs1[1]*HPLs2[1*2+1]
          - 1.0/2*GHPLs3[2*4*4+1*4+1]
          + 1.0/2*GHPLs2[1*4+1]*HPLs1[0]
          + 1.0/2*GHPLs2[1*4+1]*HPLs1[1]
          - 277.0/144*HPLs1[0]
          - 11.0/6*HPLs2[0*2+0]
          - 35.0/24*HPLs2[1*2+0]
          - 277.0/144*HPLs1[1]
          + HPLs1[1]*zeta2
          - 11.0/12*HPLs2[0*2+1]
          - 1.0/4*HPLs3[1*2*2+0*2+1]
          - 13.0/24*HPLs2[1*2+1]
          + 1.0/4*HPLs3[0*2*2+1*2+1]
          )

       + (dN_c*dN_c-1) * (
          - 82055.0/10368
          + 49.0/32*zeta4
          - 25.0/12*zeta2
          + 335.0/144*zeta3
          - 13.0/48*GHPLs2[2*4+2]
          + 1.0/8*GHPLs2[2*4+2]*HPLs1[0]
          + 121.0/288*GHPLs1[2]
          - 3.0/8*GHPLs1[2]*zeta2
          + 3.0/16*GHPLs1[2]*HPLs1[0]
          + 13.0/48*GHPLs1[2]*HPLs1[1]
          - 1.0/8*GHPLs1[2]*HPLs2[0*2+1]
          + 1.0/8*GHPLs3[2*4*4+1*4+2]
          - 1.0/8*GHPLs2[1*4+2]*HPLs1[0]
          - 1.0/8*GHPLs2[1*4+2]*HPLs1[1]
          + 1.0/8*GHPLs2[2*4+0]*HPLs1[0]
          + 1.0/8*GHPLs3[2*4*4+1*4+0]
          - 1.0/8*GHPLs2[1*4+0]*HPLs1[0]
          - 1.0/8*GHPLs2[1*4+0]*HPLs1[1]
          + 1.0/8*GHPLs3[2*4*4+2*4+1]
          - 13.0/48*GHPLs2[2*4+1]
          - 1.0/8*GHPLs2[2*4+1]*HPLs1[0]
          - 1.0/8*GHPLs2[2*4+1]*HPLs1[1]
          - 1.0/8*GHPLs1[1]*zeta2
          + 13.0/48*GHPLs1[1]*HPLs1[0]
          + 13.0/48*GHPLs1[1]*HPLs1[1]
          + 1.0/8*GHPLs1[1]*HPLs2[0*2+1]
          + 1.0/8*GHPLs1[1]*HPLs2[1*2+1]
          - 1.0/8*GHPLs3[2*4*4+1*4+1]
          + 1.0/8*GHPLs2[1*4+1]*HPLs1[0]
          + 1.0/8*GHPLs2[1*4+1]*HPLs1[1]
          - 2363.0/864*HPLs1[0]
          - 11.0/16*HPLs1[0]*zeta2
          + 7.0/4*HPLs1[0]*zeta3
          - 11.0/24*HPLs2[1*2+0]
          - 121.0/288*HPLs1[1]
          + 1.0/2*HPLs1[1]*zeta2
          - 11.0/24*HPLs2[0*2+1]
          - 1.0/8*HPLs3[1*2*2+0*2+1]
          - 13.0/48*HPLs2[1*2+1]
          + 1.0/8*HPLs3[0*2*2+1*2+1]
          )

       + (dN_c*dN_c-1)*v*pow(1-u,-1) * (
          - 277.0/288
          + 73.0/24*zeta2
          + 3.0/4*zeta3
          + 7.0/24*GHPLs2[2*4+2]
          - 1.0/2*GHPLs2[2*4+2]*HPLs1[0]
          - 10.0/9*GHPLs1[2]
          + GHPLs1[2]*zeta2
          - 19.0/24*GHPLs1[2]*HPLs1[0]
          - 1.0/4*GHPLs1[2]*HPLs2[1*2+0]
          - 7.0/24*GHPLs1[2]*HPLs1[1]
          + 1.0/4*GHPLs1[2]*HPLs2[0*2+1]
          - 3.0/4*GHPLs3[2*4*4+1*4+2]
          + 3.0/4*GHPLs2[1*4+2]*HPLs1[0]
          + 3.0/4*GHPLs2[1*4+2]*HPLs1[1]
          + 1.0/4*GHPLs2[2*4+0]*HPLs1[0]
          + 1.0/4*GHPLs3[2*4*4+1*4+0]
          - 1.0/4*GHPLs2[1*4+0]*HPLs1[0]
          - 1.0/4*GHPLs2[1*4+0]*HPLs1[1]
          - 1.0/2*GHPLs3[2*4*4+2*4+1]
          + 2.0/3*GHPLs2[2*4+1]
          + 1.0/2*GHPLs2[2*4+1]*HPLs1[0]
          + 1.0/2*GHPLs2[2*4+1]*HPLs1[1]
          + 1.0/2*GHPLs1[1]*zeta2
          - 2.0/3*GHPLs1[1]*HPLs1[0]
          - 2.0/3*GHPLs1[1]*HPLs1[1]
          - 1.0/2*GHPLs1[1]*HPLs2[0*2+1]
          - 1.0/2*GHPLs1[1]*HPLs2[1*2+1]
          + 1.0/2*GHPLs3[2*4*4+1*4+1]
          - 1.0/2*GHPLs2[1*4+1]*HPLs1[0]
          - 1.0/2*GHPLs2[1*4+1]*HPLs1[1]
          + 133.0/144*HPLs1[0]
          + 11.0/6*HPLs2[0*2+0]
          + 35.0/24*HPLs2[1*2+0]
          + 10.0/9*HPLs1[1]
          - HPLs1[1]*zeta2
          + 2.0/3*HPLs2[0*2+1]
          + 1.0/4*HPLs3[1*2*2+0*2+1]
          + 7.0/24*HPLs2[1*2+1]
          - 1.0/4*HPLs3[0*2*2+1*2+1]
          )

       + (dN_c*dN_c-1)*pow(v,2)*pow(1-u,-2) * (
          + 55.0/48*zeta2
          + 3.0/8*zeta3
          + 25.0/48*GHPLs2[2*4+2]
          - 1.0/4*GHPLs2[2*4+2]*HPLs1[0]
          - 355.0/288*GHPLs1[2]
          + 1.0/2*GHPLs1[2]*zeta2
          - 17.0/24*GHPLs1[2]*HPLs1[0]
          - 1.0/8*GHPLs1[2]*HPLs2[1*2+0]
          - 25.0/48*GHPLs1[2]*HPLs1[1]
          + 1.0/8*GHPLs1[2]*HPLs2[0*2+1]
          - 3.0/8*GHPLs3[2*4*4+1*4+2]
          + 3.0/8*GHPLs2[1*4+2]*HPLs1[0]
          + 3.0/8*GHPLs2[1*4+2]*HPLs1[1]
          + 1.0/8*GHPLs2[2*4+0]*HPLs1[0]
          + 1.0/8*GHPLs3[2*4*4+1*4+0]
          - 1.0/8*GHPLs2[1*4+0]*HPLs1[0]
          - 1.0/8*GHPLs2[1*4+0]*HPLs1[1]
          - 1.0/4*GHPLs3[2*4*4+2*4+1]
          + 1.0/48*GHPLs2[2*4+1]
          + 1.0/4*GHPLs2[2*4+1]*HPLs1[0]
          + 1.0/4*GHPLs2[2*4+1]*HPLs1[1]
          + 1.0/4*GHPLs1[1]*zeta2
          - 1.0/48*GHPLs1[1]*HPLs1[0]
          - 1.0/48*GHPLs1[1]*HPLs1[1]
          - 1.0/4*GHPLs1[1]*HPLs2[0*2+1]
          - 1.0/4*GHPLs1[1]*HPLs2[1*2+1]
          + 1.0/4*GHPLs3[2*4*4+1*4+1]
          - 1.0/4*GHPLs2[1*4+1]*HPLs1[0]
          - 1.0/4*GHPLs2[1*4+1]*HPLs1[1]
          + 355.0/288*HPLs1[0]
          + 11.0/12*HPLs2[0*2+0]
          + 35.0/48*HPLs2[1*2+0]
          + 355.0/288*HPLs1[1]
          - 1.0/2*HPLs1[1]*zeta2
          + 17.0/24*HPLs2[0*2+1]
          + 1.0/8*HPLs3[1*2*2+0*2+1]
          + 25.0/48*HPLs2[1*2+1]
          - 1.0/8*HPLs3[0*2*2+1*2+1]
          )

       + (dN_c*dN_c-1)*pow(v,2)*pow(1-u,-1) * (
          - 67.0/24*zeta2
          - 3.0/4*zeta3
          - 13.0/24*GHPLs2[2*4+2]
          + 1.0/2*GHPLs2[2*4+2]*HPLs1[0]
          + 277.0/144*GHPLs1[2]
          - GHPLs1[2]*zeta2
          + 25.0/24*GHPLs1[2]*HPLs1[0]
          + 1.0/4*GHPLs1[2]*HPLs2[1*2+0]
          + 13.0/24*GHPLs1[2]*HPLs1[1]
          - 1.0/4*GHPLs1[2]*HPLs2[0*2+1]
          + 3.0/4*GHPLs3[2*4*4+1*4+2]
          - 3.0/4*GHPLs2[1*4+2]*HPLs1[0]
          - 3.0/4*GHPLs2[1*4+2]*HPLs1[1]
          - 1.0/4*GHPLs2[2*4+0]*HPLs1[0]
          - 1.0/4*GHPLs3[2*4*4+1*4+0]
          + 1.0/4*GHPLs2[1*4+0]*HPLs1[0]
          + 1.0/4*GHPLs2[1*4+0]*HPLs1[1]
          + 1.0/2*GHPLs3[2*4*4+2*4+1]
          - 5.0/12*GHPLs2[2*4+1]
          - 1.0/2*GHPLs2[2*4+1]*HPLs1[0]
          - 1.0/2*GHPLs2[2*4+1]*HPLs1[1]
          - 1.0/2*GHPLs1[1]*zeta2
          + 5.0/12*GHPLs1[1]*HPLs1[0]
          + 5.0/12*GHPLs1[1]*HPLs1[1]
          + 1.0/2*GHPLs1[1]*HPLs2[0*2+1]
          + 1.0/2*GHPLs1[1]*HPLs2[1*2+1]
          - 1.0/2*GHPLs3[2*4*4+1*4+1]
          + 1.0/2*GHPLs2[1*4+1]*HPLs1[0]
          + 1.0/2*GHPLs2[1*4+1]*HPLs1[1]
          - 277.0/144*HPLs1[0]
          - 11.0/6*HPLs2[0*2+0]
          - 35.0/24*HPLs2[1*2+0]
          - 277.0/144*HPLs1[1]
          + HPLs1[1]*zeta2
          - 11.0/12*HPLs2[0*2+1]
          - 1.0/4*HPLs3[1*2*2+0*2+1]
          - 13.0/24*HPLs2[1*2+1]
          + 1.0/4*HPLs3[0*2*2+1*2+1]
          )

       + (dN_c*dN_c-1)*double_complex(0,1)*M_PI*pow(u,-2) * (
          + 1.0/2*GHPLs2[2*4+2]*HPLs1[0]
          - 1.0/2*GHPLs3[1*4*4+2*4+2]
          + 3.0/8*GHPLs1[2]*HPLs1[0]
          + 1.0/2*GHPLs3[1*4*4+0*4+2]
          - 1.0/4*GHPLs2[1*4+2]*HPLs1[0]
          + 1.0/2*GHPLs3[1*4*4+1*4+2]
          + 3.0/8*GHPLs2[2*4+1]
          - 1.0/4*GHPLs2[2*4+1]*HPLs1[0]
          + 3.0/4*GHPLs3[1*4*4+2*4+1]
          + 277.0/144*GHPLs1[1]
          - 1.0/4*GHPLs1[1]*zeta2
          + 13.0/24*GHPLs1[1]*HPLs1[0]
          - 3.0/8*GHPLs1[1]*HPLs1[1]
          + 1.0/4*GHPLs1[1]*HPLs2[0*2+1]
          - 1.0/4*GHPLs3[1*4*4+0*4+1]
          + 1.0/2*GHPLs3[2*4*4+1*4+1]
          - 13.0/24*GHPLs2[1*4+1]
          - 1.0/2*GHPLs2[1*4+1]*HPLs1[1]
          - 1.0/2*GHPLs3[1*4*4+1*4+1]
          )

       + (dN_c*dN_c-1)*double_complex(0,1)*M_PI*pow(u,-2)*v * (
          - GHPLs2[2*4+2]*HPLs1[0]
          + GHPLs3[1*4*4+2*4+2]
          - 3.0/4*GHPLs1[2]*HPLs1[0]
          - GHPLs3[1*4*4+0*4+2]
          + 1.0/2*GHPLs2[1*4+2]*HPLs1[0]
          - GHPLs3[1*4*4+1*4+2]
          - 3.0/4*GHPLs2[2*4+1]
          + 1.0/2*GHPLs2[2*4+1]*HPLs1[0]
          - 3.0/2*GHPLs3[1*4*4+2*4+1]
          - 277.0/72*GHPLs1[1]
          + 1.0/2*GHPLs1[1]*zeta2
          - 13.0/12*GHPLs1[1]*HPLs1[0]
          + 3.0/4*GHPLs1[1]*HPLs1[1]
          - 1.0/2*GHPLs1[1]*HPLs2[0*2+1]
          + 1.0/2*GHPLs3[1*4*4+0*4+1]
          - GHPLs3[2*4*4+1*4+1]
          + 13.0/12*GHPLs2[1*4+1]
          + GHPLs2[1*4+1]*HPLs1[1]
          + GHPLs3[1*4*4+1*4+1]
          )

       + (dN_c*dN_c-1)*double_complex(0,1)*M_PI*pow(u,-2)*pow(v,2) * (
          + 1.0/2*GHPLs2[2*4+2]*HPLs1[0]
          - 1.0/2*GHPLs3[1*4*4+2*4+2]
          + 3.0/8*GHPLs1[2]*HPLs1[0]
          + 1.0/2*GHPLs3[1*4*4+0*4+2]
          - 1.0/4*GHPLs2[1*4+2]*HPLs1[0]
          + 1.0/2*GHPLs3[1*4*4+1*4+2]
          + 3.0/8*GHPLs2[2*4+1]
          - 1.0/4*GHPLs2[2*4+1]*HPLs1[0]
          + 3.0/4*GHPLs3[1*4*4+2*4+1]
          + 277.0/144*GHPLs1[1]
          - 1.0/4*GHPLs1[1]*zeta2
          + 13.0/24*GHPLs1[1]*HPLs1[0]
          - 3.0/8*GHPLs1[1]*HPLs1[1]
          + 1.0/4*GHPLs1[1]*HPLs2[0*2+1]
          - 1.0/4*GHPLs3[1*4*4+0*4+1]
          + 1.0/2*GHPLs3[2*4*4+1*4+1]
          - 13.0/24*GHPLs2[1*4+1]
          - 1.0/2*GHPLs2[1*4+1]*HPLs1[1]
          - 1.0/2*GHPLs3[1*4*4+1*4+1]
          )

       + (dN_c*dN_c-1)*double_complex(0,1)*M_PI*pow(u,-1) * (
          + 277.0/144
          - 1.0/4*zeta2
          + 3.0/8*GHPLs1[2]
          + 1.0/4*GHPLs2[1*4+2]
          + 1.0/4*GHPLs2[1*4+0]
          + 1.0/4*GHPLs2[2*4+1]
          - 2.0/3*GHPLs1[1]
          - 1.0/4*GHPLs1[1]*HPLs1[1]
          - 1.0/4*GHPLs2[1*4+1]
          + 11.0/12*HPLs1[0]
          - 3.0/8*HPLs1[1]
          + 1.0/4*HPLs2[0*2+1]
          )

       + (dN_c*dN_c-1)*double_complex(0,1)*M_PI*pow(u,-1)*v * (
          - 277.0/72
          + 1.0/2*zeta2
          - 3.0/4*GHPLs1[2]
          + 1.0/4*GHPLs1[2]*HPLs1[0]
          - GHPLs2[1*4+2]
          - 3.0/4*GHPLs2[2*4+1]
          + 13.0/12*GHPLs1[1]
          + 3.0/4*GHPLs1[1]*HPLs1[1]
          + 3.0/4*GHPLs2[1*4+1]
          - 35.0/24*HPLs1[0]
          + 3.0/4*HPLs1[1]
          - 1.0/2*HPLs2[0*2+1]
          )

       + (dN_c*dN_c-1)*double_complex(0,1)*M_PI*pow(u,-1)*pow(v,2) * (
          + 277.0/144
          - 1.0/4*zeta2
          + 3.0/8*GHPLs1[2]
          - 1.0/4*GHPLs1[2]*HPLs1[0]
          + 3.0/4*GHPLs2[1*4+2]
          - 1.0/4*GHPLs2[1*4+0]
          + 1.0/2*GHPLs2[2*4+1]
          - 5.0/12*GHPLs1[1]
          - 1.0/2*GHPLs1[1]*HPLs1[1]
          - 1.0/2*GHPLs2[1*4+1]
          + 13.0/24*HPLs1[0]
          - 3.0/8*HPLs1[1]
          + 1.0/4*HPLs2[0*2+1]
          )

       + (dN_c*dN_c-1)*double_complex(0,1)*M_PI * (
          - 125.0/54
          - 13.0/16*zeta2
          + 7.0/4*zeta3
          + 3.0/16*GHPLs1[2]
          + 1.0/8*GHPLs2[1*4+2]
          + 1.0/8*GHPLs2[1*4+0]
          + 1.0/8*GHPLs2[2*4+1]
          - 13.0/48*GHPLs1[1]
          - 1.0/8*GHPLs1[1]*HPLs1[1]
          - 1.0/8*GHPLs2[1*4+1]
          + 11.0/24*HPLs1[0]
          - 3.0/16*HPLs1[1]
          + 1.0/8*HPLs2[0*2+1]
          )

       + (dN_c*dN_c-1)*double_complex(0,1)*M_PI*v*pow(1-u,-1) * (
          - 113.0/72
          + 1.0/4*zeta2
          - 5.0/8*GHPLs1[2]
          + 1.0/4*GHPLs1[2]*HPLs1[0]
          - 3.0/4*GHPLs2[1*4+2]
          + 1.0/4*GHPLs2[1*4+0]
          - 1.0/2*GHPLs2[2*4+1]
          + 2.0/3*GHPLs1[1]
          + 1.0/2*GHPLs1[1]*HPLs1[1]
          + 1.0/2*GHPLs2[1*4+1]
          - 13.0/24*HPLs1[0]
          + 5.0/8*HPLs1[1]
          - 1.0/4*HPLs2[0*2+1]
          )

       + (dN_c*dN_c-1)*double_complex(0,1)*M_PI*pow(v,2)*pow(1-u,-2) * (
          - 355.0/288
          + 1.0/8*zeta2
          + 1.0/16*GHPLs1[2]
          + 1.0/8*GHPLs1[2]*HPLs1[0]
          - 3.0/8*GHPLs2[1*4+2]
          + 1.0/8*GHPLs2[1*4+0]
          - 1.0/4*GHPLs2[2*4+1]
          + 1.0/48*GHPLs1[1]
          + 1.0/4*GHPLs1[1]*HPLs1[1]
          + 1.0/4*GHPLs2[1*4+1]
          - 13.0/48*HPLs1[0]
          - 1.0/16*HPLs1[1]
          - 1.0/8*HPLs2[0*2+1]
          )

       + (dN_c*dN_c-1)*double_complex(0,1)*M_PI*pow(v,2)*pow(1-u,-1) * (
          + 277.0/144
          - 1.0/4*zeta2
          + 3.0/8*GHPLs1[2]
          - 1.0/4*GHPLs1[2]*HPLs1[0]
          + 3.0/4*GHPLs2[1*4+2]
          - 1.0/4*GHPLs2[1*4+0]
          + 1.0/2*GHPLs2[2*4+1]
          - 5.0/12*GHPLs1[1]
          - 1.0/2*GHPLs1[1]*HPLs1[1]
          - 1.0/2*GHPLs2[1*4+1]
          + 13.0/24*HPLs1[0]
          - 3.0/8*HPLs1[1]
          + 1.0/4*HPLs2[0*2+1]
          )

       + (dN_c*dN_c-1)/(dN_c*dN_c)*pow(u,-2) * (
          + 7.0/4*GHPLs3[3*4*4+2*4+2]*HPLs1[0]
          - 7.0/4*GHPLs4[0*4*4*4+3*4*4+2*4+2]
          - 7.0/4*GHPLs2[2*4+2]*zeta2
          + 5.0/4*GHPLs2[2*4+2]*HPLs2[0*2+0]
          + 5.0/4*GHPLs2[2*4+2]*HPLs2[1*2+0]
          - 1.0/2*GHPLs2[2*4+2]*HPLs2[0*2+1]
          - 1.0/2*GHPLs3[0*4*4+2*4+2]*HPLs1[0]
          + 5.0/4*GHPLs4[2*4*4*4+1*4*4+2*4+2]
          - 5.0/4*GHPLs3[1*4*4+2*4+2]*HPLs1[0]
          - 5.0/4*GHPLs3[1*4*4+2*4+2]*HPLs1[1]
          + 1.0/2*GHPLs3[3*4*4+3*4+2]*HPLs1[0]
          - 1.0/2*GHPLs4[0*4*4*4+3*4*4+3*4+2]
          + 1.0/2*GHPLs2[3*4+2]*zeta2
          - 3.0/2*GHPLs1[2]*zeta2
          + 3.0/4*GHPLs1[2]*zeta3
          + 11.0/16*GHPLs1[2]*HPLs1[0]
          - 11.0/2*GHPLs1[2]*HPLs1[0]*zeta2
          + 3.0/8*GHPLs1[2]*HPLs2[0*2+0]
          + 7.0/4*GHPLs1[2]*HPLs3[0*2*2+0*2+0]
          + 1.0/2*GHPLs1[2]*HPLs3[1*2*2+0*2+0]
          + 3.0/8*GHPLs1[2]*HPLs2[1*2+0]
          + 5.0/4*GHPLs1[2]*HPLs3[0*2*2+1*2+0]
          + 5.0/4*GHPLs1[2]*HPLs1[1]*zeta2
          - 9.0/8*GHPLs1[2]*HPLs2[0*2+1]
          - 5.0/4*GHPLs1[2]*HPLs3[0*2*2+0*2+1]
          - 5.0/4*GHPLs1[2]*HPLs3[1*2*2+0*2+1]
          - 7.0/4*GHPLs3[3*4*4+0*4+2]*HPLs1[0]
          + 7.0/4*GHPLs4[0*4*4*4+3*4*4+0*4+2]
          + 5.0/4*GHPLs2[0*4+2]*zeta2
          - 3.0/4*GHPLs2[0*4+2]*HPLs1[0]
          - 5.0/4*GHPLs2[0*4+2]*HPLs2[0*2+0]
          - 5.0/4*GHPLs2[0*4+2]*HPLs2[1*2+0]
          - 5.0/4*GHPLs4[2*4*4*4+1*4*4+0*4+2]
          + 5.0/4*GHPLs3[1*4*4+0*4+2]*HPLs1[0]
          + 5.0/4*GHPLs3[1*4*4+0*4+2]*HPLs1[1]
          + 3.0/8*GHPLs3[2*4*4+1*4+2]
          - 1.0/4*GHPLs3[2*4*4+1*4+2]*HPLs1[0]
          + GHPLs2[1*4+2]*zeta2
          - 3.0/8*GHPLs2[1*4+2]*HPLs1[0]
          - 1.0/4*GHPLs2[1*4+2]*HPLs2[1*2+0]
          - 3.0/8*GHPLs2[1*4+2]*HPLs1[1]
          + 1.0/4*GHPLs2[1*4+2]*HPLs2[0*2+1]
          - 1.0/2*GHPLs4[2*4*4*4+1*4*4+1*4+2]
          + 1.0/2*GHPLs3[1*4*4+1*4+2]*HPLs1[0]
          + 1.0/2*GHPLs3[1*4*4+1*4+2]*HPLs1[1]
          - 7.0/4*GHPLs3[2*4*4+2*4+1]*HPLs1[0]
          + 5.0/4*GHPLs4[0*4*4*4+2*4*4+2*4+1]
          + 5.0/4*GHPLs3[3*4*4+2*4+1]*HPLs1[0]
          - 5.0/4*GHPLs4[0*4*4*4+3*4*4+2*4+1]
          + 11.0/16*GHPLs2[2*4+1]
          - 5*GHPLs2[2*4+1]*zeta2
          + 7.0/4*GHPLs2[2*4+1]*HPLs2[0*2+0]
          + 1.0/4*GHPLs2[2*4+1]*HPLs2[1*2+0]
          + 3.0/2*GHPLs2[2*4+1]*HPLs2[0*2+1]
          + 5.0/4*GHPLs4[2*4*4*4+0*4*4+2*4+1]
          - 3.0/4*GHPLs3[0*4*4+2*4+1]
          - 5.0/4*GHPLs3[0*4*4+2*4+1]*HPLs1[0]
          - 5.0/4*GHPLs3[0*4*4+2*4+1]*HPLs1[1]
          - 3.0/2*GHPLs4[2*4*4*4+1*4*4+2*4+1]
          + 3.0/2*GHPLs3[1*4*4+2*4+1]*HPLs1[0]
          + 3.0/2*GHPLs3[1*4*4+2*4+1]*HPLs1[1]
          + 21.0/4*GHPLs1[1]*zeta2
          + GHPLs1[1]*zeta3
          - 11.0/16*GHPLs1[1]*HPLs1[0]
          + 6*GHPLs1[1]*HPLs1[0]*zeta2
          - 3.0/8*GHPLs1[1]*HPLs2[0*2+0]
          - 7.0/4*GHPLs1[1]*HPLs3[0*2*2+0*2+0]
          - 1.0/2*GHPLs1[1]*HPLs3[1*2*2+0*2+0]
          - 3.0/8*GHPLs1[1]*HPLs2[1*2+0]
          - 5.0/4*GHPLs1[1]*HPLs3[0*2*2+1*2+0]
          - 11.0/16*GHPLs1[1]*HPLs1[1]
          + 5*GHPLs1[1]*HPLs1[1]*zeta2
          - 7.0/4*GHPLs1[1]*HPLs3[0*2*2+0*2+1]
          - 1.0/4*GHPLs1[1]*HPLs3[1*2*2+0*2+1]
          - 3.0/2*GHPLs1[1]*HPLs3[0*2*2+1*2+1]
          + 5.0/4*GHPLs4[2*4*4*4+2*4*4+0*4+1]
          - 3.0/4*GHPLs3[2*4*4+0*4+1]
          - GHPLs3[2*4*4+0*4+1]*HPLs1[0]
          - 5.0/4*GHPLs3[2*4*4+0*4+1]*HPLs1[1]
          + 5.0/4*GHPLs3[3*4*4+0*4+1]*HPLs1[0]
          - 5.0/4*GHPLs4[0*4*4*4+3*4*4+0*4+1]
          - 15.0/4*GHPLs2[0*4+1]*zeta2
          + 3.0/4*GHPLs2[0*4+1]*HPLs1[0]
          + 5.0/4*GHPLs2[0*4+1]*HPLs2[0*2+0]
          + 5.0/4*GHPLs2[0*4+1]*HPLs2[1*2+0]
          + 3.0/4*GHPLs2[0*4+1]*HPLs1[1]
          + 5.0/4*GHPLs2[0*4+1]*HPLs2[0*2+1]
          + 5.0/4*GHPLs2[0*4+1]*HPLs2[1*2+1]
          + 1.0/4*GHPLs4[2*4*4*4+1*4*4+0*4+1]
          - 1.0/4*GHPLs3[1*4*4+0*4+1]*HPLs1[0]
          - 1.0/4*GHPLs3[1*4*4+0*4+1]*HPLs1[1]
          - 7.0/4*GHPLs4[2*4*4*4+2*4*4+1*4+1]
          - 3.0/8*GHPLs3[2*4*4+1*4+1]
          + 1.0/2*GHPLs3[2*4*4+1*4+1]*HPLs1[0]
          + 7.0/4*GHPLs3[2*4*4+1*4+1]*HPLs1[1]
          + 5.0/4*GHPLs4[0*4*4*4+2*4*4+1*4+1]
          - 3.0/4*GHPLs2[1*4+1]*zeta2
          + 3.0/8*GHPLs2[1*4+1]*HPLs1[0]
          - 5.0/4*GHPLs2[1*4+1]*HPLs2[1*2+0]
          + 3.0/8*GHPLs2[1*4+1]*HPLs1[1]
          - 1.0/2*GHPLs2[1*4+1]*HPLs2[0*2+1]
          - 7.0/4*GHPLs2[1*4+1]*HPLs2[1*2+1]
          + 5.0/4*GHPLs4[2*4*4*4+0*4*4+1*4+1]
          - 5.0/4*GHPLs3[0*4*4+1*4+1]*HPLs1[0]
          - 5.0/4*GHPLs3[0*4*4+1*4+1]*HPLs1[1]
          - 3.0/4*GHPLs4[2*4*4*4+1*4*4+1*4+1]
          + 3.0/4*GHPLs3[1*4*4+1*4+1]*HPLs1[0]
          + 3.0/4*GHPLs3[1*4*4+1*4+1]*HPLs1[1]
          )

       + (dN_c*dN_c-1)/(dN_c*dN_c)*pow(u,-2)*v * (
          - 7.0/2*GHPLs3[3*4*4+2*4+2]*HPLs1[0]
          + 7.0/2*GHPLs4[0*4*4*4+3*4*4+2*4+2]
          + 7.0/2*GHPLs2[2*4+2]*zeta2
          - 5.0/2*GHPLs2[2*4+2]*HPLs2[0*2+0]
          - 5.0/2*GHPLs2[2*4+2]*HPLs2[1*2+0]
          + GHPLs2[2*4+2]*HPLs2[0*2+1]
          + GHPLs3[0*4*4+2*4+2]*HPLs1[0]
          - 5.0/2*GHPLs4[2*4*4*4+1*4*4+2*4+2]
          + 5.0/2*GHPLs3[1*4*4+2*4+2]*HPLs1[0]
          + 5.0/2*GHPLs3[1*4*4+2*4+2]*HPLs1[1]
          - GHPLs3[3*4*4+3*4+2]*HPLs1[0]
          + GHPLs4[0*4*4*4+3*4*4+3*4+2]
          - GHPLs2[3*4+2]*zeta2
          + 13.0/4*GHPLs1[2]*zeta2
          - 3.0/2*GHPLs1[2]*zeta3
          - 13.0/8*GHPLs1[2]*HPLs1[0]
          + 11*GHPLs1[2]*HPLs1[0]*zeta2
          - 1.0/2*GHPLs1[2]*HPLs2[0*2+0]
          - 7.0/2*GHPLs1[2]*HPLs3[0*2*2+0*2+0]
          - GHPLs1[2]*HPLs3[1*2*2+0*2+0]
          - GHPLs1[2]*HPLs2[1*2+0]
          - 5.0/2*GHPLs1[2]*HPLs3[0*2*2+1*2+0]
          - 5.0/2*GHPLs1[2]*HPLs1[1]*zeta2
          + 9.0/4*GHPLs1[2]*HPLs2[0*2+1]
          + 5.0/2*GHPLs1[2]*HPLs3[0*2*2+0*2+1]
          + 5.0/2*GHPLs1[2]*HPLs3[1*2*2+0*2+1]
          + 7.0/2*GHPLs3[3*4*4+0*4+2]*HPLs1[0]
          - 7.0/2*GHPLs4[0*4*4*4+3*4*4+0*4+2]
          - 5.0/2*GHPLs2[0*4+2]*zeta2
          + 5.0/4*GHPLs2[0*4+2]*HPLs1[0]
          + 5.0/2*GHPLs2[0*4+2]*HPLs2[0*2+0]
          + 5.0/2*GHPLs2[0*4+2]*HPLs2[1*2+0]
          + 5.0/2*GHPLs4[2*4*4*4+1*4*4+0*4+2]
          - 5.0/2*GHPLs3[1*4*4+0*4+2]*HPLs1[0]
          - 5.0/2*GHPLs3[1*4*4+0*4+2]*HPLs1[1]
          - GHPLs3[2*4*4+1*4+2]
          + 1.0/2*GHPLs3[2*4*4+1*4+2]*HPLs1[0]
          - 2*GHPLs2[1*4+2]*zeta2
          + GHPLs2[1*4+2]*HPLs1[0]
          + 1.0/2*GHPLs2[1*4+2]*HPLs2[1*2+0]
          + GHPLs2[1*4+2]*HPLs1[1]
          - 1.0/2*GHPLs2[1*4+2]*HPLs2[0*2+1]
          + GHPLs4[2*4*4*4+1*4*4+1*4+2]
          - GHPLs3[1*4*4+1*4+2]*HPLs1[0]
          - GHPLs3[1*4*4+1*4+2]*HPLs1[1]
          + 1.0/2*GHPLs2[3*4+3]*HPLs1[0]
          - 1.0/2*GHPLs3[0*4*4+3*4+3]
          + 1.0/2*GHPLs1[3]*zeta2
          + 7.0/2*GHPLs3[2*4*4+2*4+1]*HPLs1[0]
          - 5.0/2*GHPLs4[0*4*4*4+2*4*4+2*4+1]
          - 5.0/2*GHPLs3[3*4*4+2*4+1]*HPLs1[0]
          + 5.0/2*GHPLs4[0*4*4*4+3*4*4+2*4+1]
          - 13.0/8*GHPLs2[2*4+1]
          + 10*GHPLs2[2*4+1]*zeta2
          - 7.0/2*GHPLs2[2*4+1]*HPLs2[0*2+0]
          - 1.0/2*GHPLs2[2*4+1]*HPLs2[1*2+0]
          - 3*GHPLs2[2*4+1]*HPLs2[0*2+1]
          - 5.0/2*GHPLs4[2*4*4*4+0*4*4+2*4+1]
          + 5.0/4*GHPLs3[0*4*4+2*4+1]
          + 5.0/2*GHPLs3[0*4*4+2*4+1]*HPLs1[0]
          + 5.0/2*GHPLs3[0*4*4+2*4+1]*HPLs1[1]
          + 3*GHPLs4[2*4*4*4+1*4*4+2*4+1]
          - 3*GHPLs3[1*4*4+2*4+1]*HPLs1[0]
          - 3*GHPLs3[1*4*4+2*4+1]*HPLs1[1]
          - 17.0/2*GHPLs1[1]*zeta2
          - 2*GHPLs1[1]*zeta3
          + 13.0/8*GHPLs1[1]*HPLs1[0]
          - 12*GHPLs1[1]*HPLs1[0]*zeta2
          + 1.0/2*GHPLs1[1]*HPLs2[0*2+0]
          + 7.0/2*GHPLs1[1]*HPLs3[0*2*2+0*2+0]
          + GHPLs1[1]*HPLs3[1*2*2+0*2+0]
          + 1.0/2*GHPLs1[1]*HPLs2[1*2+0]
          + 5.0/2*GHPLs1[1]*HPLs3[0*2*2+1*2+0]
          + 13.0/8*GHPLs1[1]*HPLs1[1]
          - 10*GHPLs1[1]*HPLs1[1]*zeta2
          + 7.0/2*GHPLs1[1]*HPLs3[0*2*2+0*2+1]
          + 1.0/2*GHPLs1[1]*HPLs3[1*2*2+0*2+1]
          + 3*GHPLs1[1]*HPLs3[0*2*2+1*2+1]
          - 5.0/2*GHPLs4[2*4*4*4+2*4*4+0*4+1]
          + 5.0/4*GHPLs3[2*4*4+0*4+1]
          + 2*GHPLs3[2*4*4+0*4+1]*HPLs1[0]
          + 5.0/2*GHPLs3[2*4*4+0*4+1]*HPLs1[1]
          - 5.0/2*GHPLs3[3*4*4+0*4+1]*HPLs1[0]
          + 5.0/2*GHPLs4[0*4*4*4+3*4*4+0*4+1]
          + 15.0/2*GHPLs2[0*4+1]*zeta2
          - 5.0/4*GHPLs2[0*4+1]*HPLs1[0]
          - 5.0/2*GHPLs2[0*4+1]*HPLs2[0*2+0]
          - 5.0/2*GHPLs2[0*4+1]*HPLs2[1*2+0]
          - 5.0/4*GHPLs2[0*4+1]*HPLs1[1]
          - 5.0/2*GHPLs2[0*4+1]*HPLs2[0*2+1]
          - 5.0/2*GHPLs2[0*4+1]*HPLs2[1*2+1]
          - 1.0/2*GHPLs4[2*4*4*4+1*4*4+0*4+1]
          + 1.0/2*GHPLs3[1*4*4+0*4+1]*HPLs1[0]
          + 1.0/2*GHPLs3[1*4*4+0*4+1]*HPLs1[1]
          + 7.0/2*GHPLs4[2*4*4*4+2*4*4+1*4+1]
          + 1.0/2*GHPLs3[2*4*4+1*4+1]
          - GHPLs3[2*4*4+1*4+1]*HPLs1[0]
          - 7.0/2*GHPLs3[2*4*4+1*4+1]*HPLs1[1]
          - 5.0/2*GHPLs4[0*4*4*4+2*4*4+1*4+1]
          + 3.0/2*GHPLs2[1*4+1]*zeta2
          - 1.0/2*GHPLs2[1*4+1]*HPLs1[0]
          + 5.0/2*GHPLs2[1*4+1]*HPLs2[1*2+0]
          - 1.0/2*GHPLs2[1*4+1]*HPLs1[1]
          + GHPLs2[1*4+1]*HPLs2[0*2+1]
          + 7.0/2*GHPLs2[1*4+1]*HPLs2[1*2+1]
          - 5.0/2*GHPLs4[2*4*4*4+0*4*4+1*4+1]
          + 5.0/2*GHPLs3[0*4*4+1*4+1]*HPLs1[0]
          + 5.0/2*GHPLs3[0*4*4+1*4+1]*HPLs1[1]
          + 3.0/2*GHPLs4[2*4*4*4+1*4*4+1*4+1]
          - 3.0/2*GHPLs3[1*4*4+1*4+1]*HPLs1[0]
          - 3.0/2*GHPLs3[1*4*4+1*4+1]*HPLs1[1]
          )

       + (dN_c*dN_c-1)/(dN_c*dN_c)*pow(u,-2)*pow(v,2) * (
          + 7.0/4*GHPLs3[3*4*4+2*4+2]*HPLs1[0]
          - 7.0/4*GHPLs4[0*4*4*4+3*4*4+2*4+2]
          - 7.0/4*GHPLs2[2*4+2]*zeta2
          + 5.0/4*GHPLs2[2*4+2]*HPLs2[0*2+0]
          + 5.0/4*GHPLs2[2*4+2]*HPLs2[1*2+0]
          - 1.0/2*GHPLs2[2*4+2]*HPLs2[0*2+1]
          - 1.0/2*GHPLs3[0*4*4+2*4+2]*HPLs1[0]
          + 5.0/4*GHPLs4[2*4*4*4+1*4*4+2*4+2]
          - 5.0/4*GHPLs3[1*4*4+2*4+2]*HPLs1[0]
          - 5.0/4*GHPLs3[1*4*4+2*4+2]*HPLs1[1]
          + 1.0/2*GHPLs3[3*4*4+3*4+2]*HPLs1[0]
          - 1.0/2*GHPLs4[0*4*4*4+3*4*4+3*4+2]
          + 1.0/2*GHPLs2[3*4+2]*zeta2
          - 15.0/8*GHPLs1[2]*zeta2
          + 3.0/4*GHPLs1[2]*zeta3
          + 17.0/16*GHPLs1[2]*HPLs1[0]
          - 11.0/2*GHPLs1[2]*HPLs1[0]*zeta2
          + 7.0/4*GHPLs1[2]*HPLs3[0*2*2+0*2+0]
          + 1.0/2*GHPLs1[2]*HPLs3[1*2*2+0*2+0]
          + 3.0/4*GHPLs1[2]*HPLs2[1*2+0]
          + 5.0/4*GHPLs1[2]*HPLs3[0*2*2+1*2+0]
          + 5.0/4*GHPLs1[2]*HPLs1[1]*zeta2
          - 9.0/8*GHPLs1[2]*HPLs2[0*2+1]
          - 5.0/4*GHPLs1[2]*HPLs3[0*2*2+0*2+1]
          - 5.0/4*GHPLs1[2]*HPLs3[1*2*2+0*2+1]
          - 7.0/4*GHPLs3[3*4*4+0*4+2]*HPLs1[0]
          + 7.0/4*GHPLs4[0*4*4*4+3*4*4+0*4+2]
          + 5.0/4*GHPLs2[0*4+2]*zeta2
          - 3.0/8*GHPLs2[0*4+2]*HPLs1[0]
          - 5.0/4*GHPLs2[0*4+2]*HPLs2[0*2+0]
          - 5.0/4*GHPLs2[0*4+2]*HPLs2[1*2+0]
          - 5.0/4*GHPLs4[2*4*4*4+1*4*4+0*4+2]
          + 5.0/4*GHPLs3[1*4*4+0*4+2]*HPLs1[0]
          + 5.0/4*GHPLs3[1*4*4+0*4+2]*HPLs1[1]
          + 3.0/4*GHPLs3[2*4*4+1*4+2]
          - 1.0/4*GHPLs3[2*4*4+1*4+2]*HPLs1[0]
          + GHPLs2[1*4+2]*zeta2
          - 3.0/4*GHPLs2[1*4+2]*HPLs1[0]
          - 1.0/4*GHPLs2[1*4+2]*HPLs2[1*2+0]
          - 3.0/4*GHPLs2[1*4+2]*HPLs1[1]
          + 1.0/4*GHPLs2[1*4+2]*HPLs2[0*2+1]
          - 1.0/2*GHPLs4[2*4*4*4+1*4*4+1*4+2]
          + 1.0/2*GHPLs3[1*4*4+1*4+2]*HPLs1[0]
          + 1.0/2*GHPLs3[1*4*4+1*4+2]*HPLs1[1]
          - 3.0/4*GHPLs2[3*4+3]*HPLs1[0]
          + 3.0/4*GHPLs3[0*4*4+3*4+3]
          - 3.0/4*GHPLs1[3]*zeta2
          - 7.0/4*GHPLs3[2*4*4+2*4+1]*HPLs1[0]
          + 5.0/4*GHPLs4[0*4*4*4+2*4*4+2*4+1]
          + 5.0/4*GHPLs3[3*4*4+2*4+1]*HPLs1[0]
          - 5.0/4*GHPLs4[0*4*4*4+3*4*4+2*4+1]
          + 17.0/16*GHPLs2[2*4+1]
          - 5*GHPLs2[2*4+1]*zeta2
          + 7.0/4*GHPLs2[2*4+1]*HPLs2[0*2+0]
          + 1.0/4*GHPLs2[2*4+1]*HPLs2[1*2+0]
          + 3.0/2*GHPLs2[2*4+1]*HPLs2[0*2+1]
          + 5.0/4*GHPLs4[2*4*4*4+0*4*4+2*4+1]
          - 3.0/8*GHPLs3[0*4*4+2*4+1]
          - 5.0/4*GHPLs3[0*4*4+2*4+1]*HPLs1[0]
          - 5.0/4*GHPLs3[0*4*4+2*4+1]*HPLs1[1]
          - 3.0/2*GHPLs4[2*4*4*4+1*4*4+2*4+1]
          + 3.0/2*GHPLs3[1*4*4+2*4+1]*HPLs1[0]
          + 3.0/2*GHPLs3[1*4*4+2*4+1]*HPLs1[1]
          + 9.0/4*GHPLs1[1]*zeta2
          + GHPLs1[1]*zeta3
          - 17.0/16*GHPLs1[1]*HPLs1[0]
          + 6*GHPLs1[1]*HPLs1[0]*zeta2
          - 7.0/4*GHPLs1[1]*HPLs3[0*2*2+0*2+0]
          - 1.0/2*GHPLs1[1]*HPLs3[1*2*2+0*2+0]
          - 5.0/4*GHPLs1[1]*HPLs3[0*2*2+1*2+0]
          - 17.0/16*GHPLs1[1]*HPLs1[1]
          + 5*GHPLs1[1]*HPLs1[1]*zeta2
          - 7.0/4*GHPLs1[1]*HPLs3[0*2*2+0*2+1]
          - 1.0/4*GHPLs1[1]*HPLs3[1*2*2+0*2+1]
          - 3.0/2*GHPLs1[1]*HPLs3[0*2*2+1*2+1]
          + 5.0/4*GHPLs4[2*4*4*4+2*4*4+0*4+1]
          - 3.0/8*GHPLs3[2*4*4+0*4+1]
          - GHPLs3[2*4*4+0*4+1]*HPLs1[0]
          - 5.0/4*GHPLs3[2*4*4+0*4+1]*HPLs1[1]
          + 5.0/4*GHPLs3[3*4*4+0*4+1]*HPLs1[0]
          - 5.0/4*GHPLs4[0*4*4*4+3*4*4+0*4+1]
          - 15.0/4*GHPLs2[0*4+1]*zeta2
          + 3.0/8*GHPLs2[0*4+1]*HPLs1[0]
          + 5.0/4*GHPLs2[0*4+1]*HPLs2[0*2+0]
          + 5.0/4*GHPLs2[0*4+1]*HPLs2[1*2+0]
          + 3.0/8*GHPLs2[0*4+1]*HPLs1[1]
          + 5.0/4*GHPLs2[0*4+1]*HPLs2[0*2+1]
          + 5.0/4*GHPLs2[0*4+1]*HPLs2[1*2+1]
          + 1.0/4*GHPLs4[2*4*4*4+1*4*4+0*4+1]
          - 1.0/4*GHPLs3[1*4*4+0*4+1]*HPLs1[0]
          - 1.0/4*GHPLs3[1*4*4+0*4+1]*HPLs1[1]
          - 7.0/4*GHPLs4[2*4*4*4+2*4*4+1*4+1]
          + 1.0/2*GHPLs3[2*4*4+1*4+1]*HPLs1[0]
          + 7.0/4*GHPLs3[2*4*4+1*4+1]*HPLs1[1]
          + 5.0/4*GHPLs4[0*4*4*4+2*4*4+1*4+1]
          - 3.0/4*GHPLs2[1*4+1]*zeta2
          - 5.0/4*GHPLs2[1*4+1]*HPLs2[1*2+0]
          - 1.0/2*GHPLs2[1*4+1]*HPLs2[0*2+1]
          - 7.0/4*GHPLs2[1*4+1]*HPLs2[1*2+1]
          + 5.0/4*GHPLs4[2*4*4*4+0*4*4+1*4+1]
          - 5.0/4*GHPLs3[0*4*4+1*4+1]*HPLs1[0]
          - 5.0/4*GHPLs3[0*4*4+1*4+1]*HPLs1[1]
          - 3.0/4*GHPLs4[2*4*4*4+1*4*4+1*4+1]
          + 3.0/4*GHPLs3[1*4*4+1*4+1]*HPLs1[0]
          + 3.0/4*GHPLs3[1*4*4+1*4+1]*HPLs1[1]
          )

       + (dN_c*dN_c-1)/(dN_c*dN_c)*pow(u,-2)*pow(v,3) * (
          - 1.0/8*GHPLs1[2]*HPLs1[0]
          - 1.0/8*GHPLs2[2*4+1]
          + 1.0/8*GHPLs1[1]*HPLs1[0]
          + 1.0/8*GHPLs1[1]*HPLs1[1]
          )

       + (dN_c*dN_c-1)/(dN_c*dN_c)*pow(u,-2)*pow(v,4) * (
          + 1.0/8*GHPLs1[2]*zeta2
          + 1.0/8*GHPLs1[2]*HPLs2[0*2+0]
          - 1.0/8*GHPLs1[2]*HPLs2[1*2+0]
          - 1.0/8*GHPLs2[0*4+2]*HPLs1[0]
          - 1.0/8*GHPLs3[2*4*4+1*4+2]
          + 1.0/8*GHPLs2[1*4+2]*HPLs1[0]
          + 1.0/8*GHPLs2[1*4+2]*HPLs1[1]
          - 1.0/8*GHPLs2[2*4+3]*HPLs1[0]
          + 1.0/8*GHPLs3[0*4*4+2*4+3]
          + 1.0/8*GHPLs2[3*4+3]*HPLs1[0]
          - 1.0/8*GHPLs3[0*4*4+3*4+3]
          - 5.0/8*GHPLs1[3]*zeta2
          + 1.0/8*GHPLs1[3]*HPLs2[1*2+0]
          + 1.0/8*GHPLs1[3]*HPLs2[0*2+1]
          + 1.0/8*GHPLs3[2*4*4+0*4+3]
          - 1.0/8*GHPLs2[0*4+3]*HPLs1[1]
          )

       + (dN_c*dN_c-1)/(dN_c*dN_c)*pow(u,-1) * (
          - 1.0/2
          + 23.0/4*zeta2
          + 7.0/4*zeta3
          - 3.0/2*GHPLs3[3*4*4+2*4+2]*HPLs1[0]
          + 3.0/2*GHPLs4[0*4*4*4+3*4*4+2*4+2]
          - 5.0/4*GHPLs2[2*4+2]
          + 3.0/2*GHPLs2[2*4+2]*zeta2
          - 3.0/2*GHPLs2[2*4+2]*HPLs1[0]
          - 3.0/2*GHPLs2[2*4+2]*HPLs2[0*2+0]
          - 3.0/2*GHPLs2[2*4+2]*HPLs2[1*2+0]
          + 5.0/4*GHPLs3[0*4*4+2*4+2]
          - 3.0/2*GHPLs4[2*4*4*4+1*4*4+2*4+2]
          + 3.0/2*GHPLs3[1*4*4+2*4+2]*HPLs1[0]
          + 3.0/2*GHPLs3[1*4*4+2*4+2]*HPLs1[1]
          + 3*GHPLs2[3*4+2]*HPLs1[0]
          - 3*GHPLs3[0*4*4+3*4+2]
          + 23.0/16*GHPLs1[2]
          - 13.0/2*GHPLs1[2]*zeta2
          - 3.0/2*GHPLs1[2]*zeta3
          + 11.0/8*GHPLs1[2]*HPLs1[0]
          + 6*GHPLs1[2]*HPLs1[0]*zeta2
          + 3*GHPLs1[2]*HPLs2[0*2+0]
          - 3.0/2*GHPLs1[2]*HPLs3[0*2*2+0*2+0]
          + 5.0/4*GHPLs1[2]*HPLs2[1*2+0]
          - 3.0/2*GHPLs1[2]*HPLs3[0*2*2+1*2+0]
          + 5.0/4*GHPLs1[2]*HPLs1[1]
          - 3.0/2*GHPLs1[2]*HPLs1[1]*zeta2
          + GHPLs1[2]*HPLs2[0*2+1]
          + 3.0/2*GHPLs1[2]*HPLs3[0*2*2+0*2+1]
          + 3.0/2*GHPLs1[2]*HPLs3[1*2*2+0*2+1]
          + 5.0/4*GHPLs3[2*4*4+0*4+2]
          + 3.0/2*GHPLs3[3*4*4+0*4+2]*HPLs1[0]
          - 3.0/2*GHPLs4[0*4*4*4+3*4*4+0*4+2]
          - 3.0/4*GHPLs2[0*4+2]
          - 3.0/2*GHPLs2[0*4+2]*zeta2
          - 7.0/4*GHPLs2[0*4+2]*HPLs1[0]
          + 3.0/2*GHPLs2[0*4+2]*HPLs2[0*2+0]
          + 3.0/2*GHPLs2[0*4+2]*HPLs2[1*2+0]
          - 5.0/4*GHPLs2[0*4+2]*HPLs1[1]
          + 3.0/2*GHPLs4[2*4*4*4+1*4*4+0*4+2]
          - 3.0/2*GHPLs3[1*4*4+0*4+2]*HPLs1[0]
          - 3.0/2*GHPLs3[1*4*4+0*4+2]*HPLs1[1]
          - 1.0/4*GHPLs3[2*4*4+1*4+2]
          + 1.0/4*GHPLs2[1*4+2]*HPLs1[0]
          + 1.0/4*GHPLs2[1*4+2]*HPLs1[1]
          + 1.0/2*GHPLs2[3*4+3]*HPLs1[0]
          - 1.0/2*GHPLs3[0*4*4+3*4+3]
          + 1.0/2*GHPLs1[3]*zeta2
          + 5.0/4*GHPLs3[2*4*4+2*4+0]
          - 3.0/4*GHPLs2[2*4+0]
          - GHPLs2[2*4+0]*HPLs1[0]
          - 5.0/4*GHPLs2[2*4+0]*HPLs1[1]
          - 1.0/2*GHPLs2[3*4+0]*HPLs1[0]
          + 1.0/2*GHPLs3[0*4*4+3*4+0]
          - 5.0/2*GHPLs1[0]*zeta2
          + 3.0/4*GHPLs1[0]*HPLs1[1]
          + 5.0/4*GHPLs1[0]*HPLs2[0*2+1]
          + 5.0/4*GHPLs1[0]*HPLs2[1*2+1]
          - GHPLs3[2*4*4+1*4+0]
          + GHPLs2[1*4+0]*HPLs1[0]
          + GHPLs2[1*4+0]*HPLs1[1]
          - 3.0/2*GHPLs3[2*4*4+2*4+1]
          + 3.0/2*GHPLs3[2*4*4+2*4+1]*HPLs1[0]
          - 3.0/2*GHPLs4[0*4*4*4+2*4*4+2*4+1]
          - 3.0/2*GHPLs3[3*4*4+2*4+1]*HPLs1[0]
          + 3.0/2*GHPLs4[0*4*4*4+3*4*4+2*4+1]
          + 11.0/8*GHPLs2[2*4+1]
          + 6*GHPLs2[2*4+1]*zeta2
          + 1.0/4*GHPLs2[2*4+1]*HPLs1[0]
          - 3.0/2*GHPLs2[2*4+1]*HPLs2[0*2+0]
          + 3.0/2*GHPLs2[2*4+1]*HPLs1[1]
          - 3.0/2*GHPLs2[2*4+1]*HPLs2[0*2+1]
          - 3.0/2*GHPLs4[2*4*4*4+0*4*4+2*4+1]
          + 5.0/4*GHPLs3[0*4*4+2*4+1]
          + 3.0/2*GHPLs3[0*4*4+2*4+1]*HPLs1[0]
          + 3.0/2*GHPLs3[0*4*4+2*4+1]*HPLs1[1]
          + 3.0/2*GHPLs4[2*4*4*4+1*4*4+2*4+1]
          - 3.0/2*GHPLs3[1*4*4+2*4+1]*HPLs1[0]
          - 3.0/2*GHPLs3[1*4*4+2*4+1]*HPLs1[1]
          - GHPLs1[1]*zeta2
          - 3.0/2*GHPLs1[1]*zeta3
          - 11.0/8*GHPLs1[1]*HPLs1[0]
          - 6*GHPLs1[1]*HPLs1[0]*zeta2
          + 3.0/2*GHPLs1[1]*HPLs3[0*2*2+0*2+0]
          - 5.0/4*GHPLs1[1]*HPLs2[1*2+0]
          + 3.0/2*GHPLs1[1]*HPLs3[0*2*2+1*2+0]
          - 11.0/8*GHPLs1[1]*HPLs1[1]
          - 6*GHPLs1[1]*HPLs1[1]*zeta2
          - 1.0/4*GHPLs1[1]*HPLs2[0*2+1]
          + 3.0/2*GHPLs1[1]*HPLs3[0*2*2+0*2+1]
          - 3.0/2*GHPLs1[1]*HPLs2[1*2+1]
          + 3.0/2*GHPLs1[1]*HPLs3[0*2*2+1*2+1]
          - 3.0/2*GHPLs4[2*4*4*4+2*4*4+0*4+1]
          + 5.0/4*GHPLs3[2*4*4+0*4+1]
          + 3.0/2*GHPLs3[2*4*4+0*4+1]*HPLs1[0]
          + 3.0/2*GHPLs3[2*4*4+0*4+1]*HPLs1[1]
          - 3.0/2*GHPLs3[3*4*4+0*4+1]*HPLs1[0]
          + 3.0/2*GHPLs4[0*4*4*4+3*4*4+0*4+1]
          + 9.0/2*GHPLs2[0*4+1]*zeta2
          - 5.0/4*GHPLs2[0*4+1]*HPLs1[0]
          - 3.0/2*GHPLs2[0*4+1]*HPLs2[0*2+0]
          - 3.0/2*GHPLs2[0*4+1]*HPLs2[1*2+0]
          - 5.0/4*GHPLs2[0*4+1]*HPLs1[1]
          - 3.0/2*GHPLs2[0*4+1]*HPLs2[0*2+1]
          - 3.0/2*GHPLs2[0*4+1]*HPLs2[1*2+1]
          + 3.0/2*GHPLs4[2*4*4*4+2*4*4+1*4+1]
          - GHPLs3[2*4*4+1*4+1]
          - 3.0/2*GHPLs3[2*4*4+1*4+1]*HPLs1[1]
          - 3.0/2*GHPLs4[0*4*4*4+2*4*4+1*4+1]
          + 3.0/2*GHPLs2[1*4+1]*zeta2
          + GHPLs2[1*4+1]*HPLs1[0]
          + 3.0/2*GHPLs2[1*4+1]*HPLs2[1*2+0]
          + GHPLs2[1*4+1]*HPLs1[1]
          + 3.0/2*GHPLs2[1*4+1]*HPLs2[1*2+1]
          - 3.0/2*GHPLs4[2*4*4*4+0*4*4+1*4+1]
          + 3.0/2*GHPLs3[0*4*4+1*4+1]*HPLs1[0]
          + 3.0/2*GHPLs3[0*4*4+1*4+1]*HPLs1[1]
          + 3.0/2*GHPLs4[2*4*4*4+1*4*4+1*4+1]
          - 3.0/2*GHPLs3[1*4*4+1*4+1]*HPLs1[0]
          - 3.0/2*GHPLs3[1*4*4+1*4+1]*HPLs1[1]
          + 1.0/2*HPLs1[0]*zeta2
          - 23.0/16*HPLs1[1]
          + 25.0/4*HPLs1[1]*zeta2
          - 19.0/8*HPLs2[0*2+1]
          - 3*HPLs3[0*2*2+0*2+1]
          - 3.0/2*HPLs3[1*2*2+0*2+1]
          - 5.0/4*HPLs2[1*2+1]
          - 3.0/2*HPLs3[0*2*2+1*2+1]
          )

       + (dN_c*dN_c-1)/(dN_c*dN_c)*pow(u,-1)*v * (
          + 1.0/2
          - 49.0/4*zeta2
          - 11.0/4*zeta3
          + 3.0/2*GHPLs3[3*4*4+2*4+2]*HPLs1[0]
          - 3.0/2*GHPLs4[0*4*4*4+3*4*4+2*4+2]
          + 5.0/2*GHPLs2[2*4+2]
          - 3.0/2*GHPLs2[2*4+2]*zeta2
          + 3*GHPLs2[2*4+2]*HPLs1[0]
          + 3.0/2*GHPLs2[2*4+2]*HPLs2[0*2+0]
          + 3.0/2*GHPLs2[2*4+2]*HPLs2[1*2+0]
          - 5.0/2*GHPLs3[0*4*4+2*4+2]
          + 3.0/2*GHPLs4[2*4*4*4+1*4*4+2*4+2]
          - 3.0/2*GHPLs3[1*4*4+2*4+2]*HPLs1[0]
          - 3.0/2*GHPLs3[1*4*4+2*4+2]*HPLs1[1]
          - 17.0/4*GHPLs2[3*4+2]*HPLs1[0]
          + 17.0/4*GHPLs3[0*4*4+3*4+2]
          - 23.0/8*GHPLs1[2]
          + 47.0/4*GHPLs1[2]*zeta2
          + 3.0/2*GHPLs1[2]*zeta3
          - 17.0/8*GHPLs1[2]*HPLs1[0]
          - 6*GHPLs1[2]*HPLs1[0]*zeta2
          - 9.0/2*GHPLs1[2]*HPLs2[0*2+0]
          + 3.0/2*GHPLs1[2]*HPLs3[0*2*2+0*2+0]
          - 5.0/4*GHPLs1[2]*HPLs2[1*2+0]
          + 3.0/2*GHPLs1[2]*HPLs3[0*2*2+1*2+0]
          - 5.0/2*GHPLs1[2]*HPLs1[1]
          + 3.0/2*GHPLs1[2]*HPLs1[1]*zeta2
          - 2*GHPLs1[2]*HPLs2[0*2+1]
          - 3.0/2*GHPLs1[2]*HPLs3[0*2*2+0*2+1]
          - 3.0/2*GHPLs1[2]*HPLs3[1*2*2+0*2+1]
          - 5.0/2*GHPLs3[2*4*4+0*4+2]
          - 3.0/2*GHPLs3[3*4*4+0*4+2]*HPLs1[0]
          + 3.0/2*GHPLs4[0*4*4*4+3*4*4+0*4+2]
          + 5.0/4*GHPLs2[0*4+2]
          + 3.0/2*GHPLs2[0*4+2]*zeta2
          + 13.0/4*GHPLs2[0*4+2]*HPLs1[0]
          - 3.0/2*GHPLs2[0*4+2]*HPLs2[0*2+0]
          - 3.0/2*GHPLs2[0*4+2]*HPLs2[1*2+0]
          + 5.0/2*GHPLs2[0*4+2]*HPLs1[1]
          - 3.0/2*GHPLs4[2*4*4*4+1*4*4+0*4+2]
          + 3.0/2*GHPLs3[1*4*4+0*4+2]*HPLs1[0]
          + 3.0/2*GHPLs3[1*4*4+0*4+2]*HPLs1[1]
          + 7.0/4*GHPLs3[2*4*4+1*4+2]
          - 7.0/4*GHPLs2[1*4+2]*HPLs1[0]
          - 7.0/4*GHPLs2[1*4+2]*HPLs1[1]
          - 1.0/2*GHPLs2[3*4+3]*HPLs1[0]
          + 1.0/2*GHPLs3[0*4*4+3*4+3]
          - 1.0/2*GHPLs1[3]*zeta2
          + 3.0/2*GHPLs1[3]*HPLs1[0]
          - 3.0/2*GHPLs2[0*4+3]
          - 5.0/2*GHPLs3[2*4*4+2*4+0]
          + 5.0/4*GHPLs2[2*4+0]
          + 7.0/4*GHPLs2[2*4+0]*HPLs1[0]
          + 5.0/2*GHPLs2[2*4+0]*HPLs1[1]
          - 3.0/4*GHPLs2[3*4+0]*HPLs1[0]
          + 3.0/4*GHPLs3[0*4*4+3*4+0]
          + 25.0/4*GHPLs1[0]*zeta2
          - 3.0/4*GHPLs1[0]*HPLs1[0]
          - 5.0/4*GHPLs1[0]*HPLs2[0*2+0]
          - 5.0/4*GHPLs1[0]*HPLs2[1*2+0]
          - 5.0/4*GHPLs1[0]*HPLs1[1]
          - 5.0/2*GHPLs1[0]*HPLs2[0*2+1]
          - 5.0/2*GHPLs1[0]*HPLs2[1*2+1]
          + 1.0/2*GHPLs3[2*4*4+1*4+0]
          - 1.0/2*GHPLs2[1*4+0]*HPLs1[0]
          - 1.0/2*GHPLs2[1*4+0]*HPLs1[1]
          + 3*GHPLs3[2*4*4+2*4+1]
          - 3.0/2*GHPLs3[2*4*4+2*4+1]*HPLs1[0]
          + 3.0/2*GHPLs4[0*4*4*4+2*4*4+2*4+1]
          + 3.0/2*GHPLs3[3*4*4+2*4+1]*HPLs1[0]
          - 3.0/2*GHPLs4[0*4*4*4+3*4*4+2*4+1]
          - GHPLs2[2*4+1]
          - 6*GHPLs2[2*4+1]*zeta2
          - 1.0/2*GHPLs2[2*4+1]*HPLs1[0]
          + 3.0/2*GHPLs2[2*4+1]*HPLs2[0*2+0]
          - 3*GHPLs2[2*4+1]*HPLs1[1]
          + 3.0/2*GHPLs2[2*4+1]*HPLs2[0*2+1]
          + 3.0/2*GHPLs4[2*4*4*4+0*4*4+2*4+1]
          - 9.0/4*GHPLs3[0*4*4+2*4+1]
          - 3.0/2*GHPLs3[0*4*4+2*4+1]*HPLs1[0]
          - 3.0/2*GHPLs3[0*4*4+2*4+1]*HPLs1[1]
          - 3.0/2*GHPLs4[2*4*4*4+1*4*4+2*4+1]
          + 3.0/2*GHPLs3[1*4*4+2*4+1]*HPLs1[0]
          + 3.0/2*GHPLs3[1*4*4+2*4+1]*HPLs1[1]
          + GHPLs1[1]*zeta2
          + 3.0/2*GHPLs1[1]*zeta3
          + GHPLs1[1]*HPLs1[0]
          + 6*GHPLs1[1]*HPLs1[0]*zeta2
          - 1.0/4*GHPLs1[1]*HPLs2[0*2+0]
          - 3.0/2*GHPLs1[1]*HPLs3[0*2*2+0*2+0]
          + 9.0/4*GHPLs1[1]*HPLs2[1*2+0]
          - 3.0/2*GHPLs1[1]*HPLs3[0*2*2+1*2+0]
          + GHPLs1[1]*HPLs1[1]
          + 6*GHPLs1[1]*HPLs1[1]*zeta2
          + 1.0/2*GHPLs1[1]*HPLs2[0*2+1]
          - 3.0/2*GHPLs1[1]*HPLs3[0*2*2+0*2+1]
          + 3*GHPLs1[1]*HPLs2[1*2+1]
          - 3.0/2*GHPLs1[1]*HPLs3[0*2*2+1*2+1]
          + 3.0/2*GHPLs4[2*4*4*4+2*4*4+0*4+1]
          - 9.0/4*GHPLs3[2*4*4+0*4+1]
          - 3.0/2*GHPLs3[2*4*4+0*4+1]*HPLs1[0]
          - 3.0/2*GHPLs3[2*4*4+0*4+1]*HPLs1[1]
          + 3.0/2*GHPLs3[3*4*4+0*4+1]*HPLs1[0]
          - 3.0/2*GHPLs4[0*4*4*4+3*4*4+0*4+1]
          - 9.0/2*GHPLs2[0*4+1]*zeta2
          + 9.0/4*GHPLs2[0*4+1]*HPLs1[0]
          + 3.0/2*GHPLs2[0*4+1]*HPLs2[0*2+0]
          + 3.0/2*GHPLs2[0*4+1]*HPLs2[1*2+0]
          + 9.0/4*GHPLs2[0*4+1]*HPLs1[1]
          + 3.0/2*GHPLs2[0*4+1]*HPLs2[0*2+1]
          + 3.0/2*GHPLs2[0*4+1]*HPLs2[1*2+1]
          - 3.0/2*GHPLs4[2*4*4*4+2*4*4+1*4+1]
          + 7.0/4*GHPLs3[2*4*4+1*4+1]
          + 3.0/2*GHPLs3[2*4*4+1*4+1]*HPLs1[1]
          + 3.0/2*GHPLs4[0*4*4*4+2*4*4+1*4+1]
          - 3.0/2*GHPLs2[1*4+1]*zeta2
          - 7.0/4*GHPLs2[1*4+1]*HPLs1[0]
          - 3.0/2*GHPLs2[1*4+1]*HPLs2[1*2+0]
          - 7.0/4*GHPLs2[1*4+1]*HPLs1[1]
          - 3.0/2*GHPLs2[1*4+1]*HPLs2[1*2+1]
          + 3.0/2*GHPLs4[2*4*4*4+0*4*4+1*4+1]
          - 3.0/2*GHPLs3[0*4*4+1*4+1]*HPLs1[0]
          - 3.0/2*GHPLs3[0*4*4+1*4+1]*HPLs1[1]
          - 3.0/2*GHPLs4[2*4*4*4+1*4*4+1*4+1]
          + 3.0/2*GHPLs3[1*4*4+1*4+1]*HPLs1[0]
          + 3.0/2*GHPLs3[1*4*4+1*4+1]*HPLs1[1]
          + 23.0/16*HPLs1[0]
          - 13.0/2*HPLs1[0]*zeta2
          + 13.0/8*HPLs2[0*2+0]
          + 7.0/4*HPLs3[0*2*2+0*2+0]
          + 1.0/2*HPLs3[1*2*2+0*2+0]
          + 9.0/8*HPLs2[1*2+0]
          + 5.0/4*HPLs3[0*2*2+1*2+0]
          + 23.0/8*HPLs1[1]
          - 45.0/4*HPLs1[1]*zeta2
          + 29.0/8*HPLs2[0*2+1]
          + 19.0/4*HPLs3[0*2*2+0*2+1]
          + 7.0/4*HPLs3[1*2*2+0*2+1]
          + 5.0/2*HPLs2[1*2+1]
          + 3*HPLs3[0*2*2+1*2+1]
          )

       + (dN_c*dN_c-1)/(dN_c*dN_c)*pow(u,-1)*pow(v,2) * (
          + 47.0/8*zeta2
          + zeta3
          - 5.0/4*GHPLs2[2*4+2]
          - 3.0/2*GHPLs2[2*4+2]*HPLs1[0]
          + 5.0/4*GHPLs3[0*4*4+2*4+2]
          + 5.0/4*GHPLs2[3*4+2]*HPLs1[0]
          - 5.0/4*GHPLs3[0*4*4+3*4+2]
          + 23.0/16*GHPLs1[2]
          - 11.0/2*GHPLs1[2]*zeta2
          + 3.0/4*GHPLs1[2]*HPLs1[0]
          + 5.0/4*GHPLs1[2]*HPLs2[0*2+0]
          + 1.0/4*GHPLs1[2]*HPLs2[1*2+0]
          + 5.0/4*GHPLs1[2]*HPLs1[1]
          + GHPLs1[2]*HPLs2[0*2+1]
          + 5.0/4*GHPLs3[2*4*4+0*4+2]
          - 3.0/8*GHPLs2[0*4+2]
          - 5.0/4*GHPLs2[0*4+2]*HPLs1[0]
          - 5.0/4*GHPLs2[0*4+2]*HPLs1[1]
          - 5.0/4*GHPLs3[2*4*4+1*4+2]
          + 5.0/4*GHPLs2[1*4+2]*HPLs1[0]
          + 5.0/4*GHPLs2[1*4+2]*HPLs1[1]
          + 1.0/4*GHPLs2[2*4+3]*HPLs1[0]
          - 1.0/4*GHPLs3[0*4*4+2*4+3]
          - 1.0/4*GHPLs2[3*4+3]*HPLs1[0]
          + 1.0/4*GHPLs3[0*4*4+3*4+3]
          + 5.0/4*GHPLs1[3]*zeta2
          - 5.0/4*GHPLs1[3]*HPLs1[0]
          - 1.0/4*GHPLs1[3]*HPLs2[1*2+0]
          - 1.0/4*GHPLs1[3]*HPLs2[0*2+1]
          - 1.0/4*GHPLs3[2*4*4+0*4+3]
          + 5.0/4*GHPLs2[0*4+3]
          + 1.0/4*GHPLs2[0*4+3]*HPLs1[1]
          + 5.0/4*GHPLs3[2*4*4+2*4+0]
          - 3.0/8*GHPLs2[2*4+0]
          - 3.0/4*GHPLs2[2*4+0]*HPLs1[0]
          - 5.0/4*GHPLs2[2*4+0]*HPLs1[1]
          + 5.0/4*GHPLs2[3*4+0]*HPLs1[0]
          - 5.0/4*GHPLs3[0*4*4+3*4+0]
          - 15.0/4*GHPLs1[0]*zeta2
          + 1.0/2*GHPLs1[0]*HPLs1[0]
          + 5.0/4*GHPLs1[0]*HPLs2[0*2+0]
          + 5.0/4*GHPLs1[0]*HPLs2[1*2+0]
          + 3.0/8*GHPLs1[0]*HPLs1[1]
          + 5.0/4*GHPLs1[0]*HPLs2[0*2+1]
          + 5.0/4*GHPLs1[0]*HPLs2[1*2+1]
          + 1.0/2*GHPLs3[2*4*4+1*4+0]
          - 1.0/2*GHPLs2[1*4+0]*HPLs1[0]
          - 1.0/2*GHPLs2[1*4+0]*HPLs1[1]
          - 3.0/2*GHPLs3[2*4*4+2*4+1]
          - 3.0/8*GHPLs2[2*4+1]
          + 1.0/4*GHPLs2[2*4+1]*HPLs1[0]
          + 3.0/2*GHPLs2[2*4+1]*HPLs1[1]
          + GHPLs3[0*4*4+2*4+1]
          + 3.0/8*GHPLs1[1]*HPLs1[0]
          + 1.0/4*GHPLs1[1]*HPLs2[0*2+0]
          - GHPLs1[1]*HPLs2[1*2+0]
          + 3.0/8*GHPLs1[1]*HPLs1[1]
          - 1.0/4*GHPLs1[1]*HPLs2[0*2+1]
          - 3.0/2*GHPLs1[1]*HPLs2[1*2+1]
          + GHPLs3[2*4*4+0*4+1]
          - GHPLs2[0*4+1]*HPLs1[0]
          - GHPLs2[0*4+1]*HPLs1[1]
          - 3.0/4*GHPLs3[2*4*4+1*4+1]
          + 3.0/4*GHPLs2[1*4+1]*HPLs1[0]
          + 3.0/4*GHPLs2[1*4+1]*HPLs1[1]
          - 23.0/16*HPLs1[0]
          + 6*HPLs1[0]*zeta2
          - 11.0/8*HPLs2[0*2+0]
          - 7.0/4*HPLs3[0*2*2+0*2+0]
          - 1.0/2*HPLs3[1*2*2+0*2+0]
          - 9.0/8*HPLs2[1*2+0]
          - 5.0/4*HPLs3[0*2*2+1*2+0]
          - 23.0/16*HPLs1[1]
          + 5*HPLs1[1]*zeta2
          - 5.0/4*HPLs2[0*2+1]
          - 7.0/4*HPLs3[0*2*2+0*2+1]
          - 1.0/4*HPLs3[1*2*2+0*2+1]
          - 5.0/4*HPLs2[1*2+1]
          - 3.0/2*HPLs3[0*2*2+1*2+1]
          )

       + (dN_c*dN_c-1)/(dN_c*dN_c)*pow(u,-1)*pow(v,3) * (
          + 1.0/2*zeta2
          + 1.0/4*GHPLs1[2]*zeta2
          + 1.0/8*GHPLs1[2]*HPLs1[0]
          + 1.0/4*GHPLs1[2]*HPLs2[0*2+0]
          - 1.0/4*GHPLs1[2]*HPLs2[1*2+0]
          - 1.0/8*GHPLs2[0*4+2]
          - 1.0/4*GHPLs2[0*4+2]*HPLs1[0]
          - 1.0/4*GHPLs3[2*4*4+1*4+2]
          + 1.0/4*GHPLs2[1*4+2]*HPLs1[0]
          + 1.0/4*GHPLs2[1*4+2]*HPLs1[1]
          - 1.0/4*GHPLs2[2*4+3]*HPLs1[0]
          + 1.0/4*GHPLs3[0*4*4+2*4+3]
          + 1.0/4*GHPLs2[3*4+3]*HPLs1[0]
          - 1.0/4*GHPLs3[0*4*4+3*4+3]
          - 5.0/4*GHPLs1[3]*zeta2
          - 1.0/8*GHPLs1[3]*HPLs1[0]
          + 1.0/4*GHPLs1[3]*HPLs2[1*2+0]
          + 1.0/4*GHPLs1[3]*HPLs2[0*2+1]
          + 1.0/4*GHPLs3[2*4*4+0*4+3]
          + 1.0/8*GHPLs2[0*4+3]
          - 1.0/4*GHPLs2[0*4+3]*HPLs1[1]
          - 1.0/8*GHPLs2[2*4+0]
          + 1.0/8*GHPLs1[0]*HPLs1[0]
          + 1.0/8*GHPLs1[0]*HPLs1[1]
          + 1.0/8*GHPLs2[2*4+1]
          - 1.0/8*GHPLs1[1]*HPLs1[0]
          - 1.0/8*GHPLs1[1]*HPLs1[1]
          - 1.0/8*HPLs2[0*2+0]
          - 1.0/8*HPLs2[0*2+1]
          )

       + (dN_c*dN_c-1)/(dN_c*dN_c) * (
          - 59.0/128
          + 11.0/8*zeta4
          - 107.0/16*zeta2
          - 1.0/4*zeta3
          + 1.0/4*GHPLs3[3*4*4+2*4+2]*HPLs1[0]
          - 1.0/4*GHPLs4[0*4*4*4+3*4*4+2*4+2]
          + 9.0/16*GHPLs2[2*4+2]
          - 1.0/4*GHPLs2[2*4+2]*zeta2
          + 3.0/4*GHPLs2[2*4+2]*HPLs1[0]
          + 1.0/4*GHPLs2[2*4+2]*HPLs2[0*2+0]
          + 1.0/4*GHPLs2[2*4+2]*HPLs2[1*2+0]
          - 7.0/8*GHPLs3[0*4*4+2*4+2]
          + 1.0/4*GHPLs4[2*4*4*4+1*4*4+2*4+2]
          - 1.0/4*GHPLs3[1*4*4+2*4+2]*HPLs1[0]
          - 1.0/4*GHPLs3[1*4*4+2*4+2]*HPLs1[1]
          - 3.0/2*GHPLs2[3*4+2]*HPLs1[0]
          + 3.0/2*GHPLs3[0*4*4+3*4+2]
          + 5.0/32*GHPLs1[2]
          + 17.0/4*GHPLs1[2]*zeta2
          + 1.0/4*GHPLs1[2]*zeta3
          - 19.0/16*GHPLs1[2]*HPLs1[0]
          - GHPLs1[2]*HPLs1[0]*zeta2
          - 3.0/2*GHPLs1[2]*HPLs2[0*2+0]
          + 1.0/4*GHPLs1[2]*HPLs3[0*2*2+0*2+0]
          - 7.0/8*GHPLs1[2]*HPLs2[1*2+0]
          + 1.0/4*GHPLs1[2]*HPLs3[0*2*2+1*2+0]
          - 9.0/16*GHPLs1[2]*HPLs1[1]
          + 1.0/4*GHPLs1[2]*HPLs1[1]*zeta2
          - GHPLs1[2]*HPLs2[0*2+1]
          - 1.0/4*GHPLs1[2]*HPLs3[0*2*2+0*2+1]
          - 1.0/4*GHPLs1[2]*HPLs3[1*2*2+0*2+1]
          - 7.0/8*GHPLs3[2*4*4+0*4+2]
          - 1.0/4*GHPLs3[3*4*4+0*4+2]*HPLs1[0]
          + 1.0/4*GHPLs4[0*4*4*4+3*4*4+0*4+2]
          + 7.0/8*GHPLs2[0*4+2]
          + 1.0/4*GHPLs2[0*4+2]*zeta2
          + 5.0/8*GHPLs2[0*4+2]*HPLs1[0]
          - 1.0/4*GHPLs2[0*4+2]*HPLs2[0*2+0]
          - 1.0/4*GHPLs2[0*4+2]*HPLs2[1*2+0]
          + 7.0/8*GHPLs2[0*4+2]*HPLs1[1]
          - 1.0/4*GHPLs4[2*4*4*4+1*4*4+0*4+2]
          + 1.0/4*GHPLs3[1*4*4+0*4+2]*HPLs1[0]
          + 1.0/4*GHPLs3[1*4*4+0*4+2]*HPLs1[1]
          - 1.0/8*GHPLs3[2*4*4+1*4+2]
          + 1.0/8*GHPLs2[1*4+2]*HPLs1[0]
          + 1.0/8*GHPLs2[1*4+2]*HPLs1[1]
          + 1.0/4*GHPLs2[3*4+3]*HPLs1[0]
          - 1.0/4*GHPLs3[0*4*4+3*4+3]
          + 1.0/4*GHPLs1[3]*zeta2
          + 3.0/2*GHPLs1[3]*HPLs1[0]
          - 3.0/2*GHPLs2[0*4+3]
          - 7.0/8*GHPLs3[2*4*4+2*4+0]
          + 7.0/8*GHPLs2[2*4+0]
          + GHPLs2[2*4+0]*HPLs1[0]
          + 7.0/8*GHPLs2[2*4+0]*HPLs1[1]
          - 1.0/4*GHPLs2[3*4+0]*HPLs1[0]
          + 1.0/4*GHPLs3[0*4*4+3*4+0]
          + 3.0/8*GHPLs1[0]
          + 7.0/4*GHPLs1[0]*zeta2
          - 3.0/2*GHPLs1[0]*HPLs1[0]
          - 7.0/8*GHPLs1[0]*HPLs1[1]
          - 7.0/8*GHPLs1[0]*HPLs2[0*2+1]
          - 7.0/8*GHPLs1[0]*HPLs2[1*2+1]
          + GHPLs3[2*4*4+1*4+0]
          - GHPLs2[1*4+0]*HPLs1[0]
          - GHPLs2[1*4+0]*HPLs1[1]
          + 3.0/4*GHPLs3[2*4*4+2*4+1]
          - 1.0/4*GHPLs3[2*4*4+2*4+1]*HPLs1[0]
          + 1.0/4*GHPLs4[0*4*4*4+2*4*4+2*4+1]
          + 1.0/4*GHPLs3[3*4*4+2*4+1]*HPLs1[0]
          - 1.0/4*GHPLs4[0*4*4*4+3*4*4+2*4+1]
          - 19.0/16*GHPLs2[2*4+1]
          - GHPLs2[2*4+1]*zeta2
          + 1.0/8*GHPLs2[2*4+1]*HPLs1[0]
          + 1.0/4*GHPLs2[2*4+1]*HPLs2[0*2+0]
          - 3.0/4*GHPLs2[2*4+1]*HPLs1[1]
          + 1.0/4*GHPLs2[2*4+1]*HPLs2[0*2+1]
          + 1.0/4*GHPLs4[2*4*4*4+0*4*4+2*4+1]
          - 7.0/8*GHPLs3[0*4*4+2*4+1]
          - 1.0/4*GHPLs3[0*4*4+2*4+1]*HPLs1[0]
          - 1.0/4*GHPLs3[0*4*4+2*4+1]*HPLs1[1]
          - 1.0/4*GHPLs4[2*4*4*4+1*4*4+2*4+1]
          + 1.0/4*GHPLs3[1*4*4+2*4+1]*HPLs1[0]
          + 1.0/4*GHPLs3[1*4*4+2*4+1]*HPLs1[1]
          + GHPLs1[1]*zeta2
          + 1.0/4*GHPLs1[1]*zeta3
          + 19.0/16*GHPLs1[1]*HPLs1[0]
          + GHPLs1[1]*HPLs1[0]*zeta2
          - 1.0/4*GHPLs1[1]*HPLs3[0*2*2+0*2+0]
          + 7.0/8*GHPLs1[1]*HPLs2[1*2+0]
          - 1.0/4*GHPLs1[1]*HPLs3[0*2*2+1*2+0]
          + 19.0/16*GHPLs1[1]*HPLs1[1]
          + GHPLs1[1]*HPLs1[1]*zeta2
          - 1.0/8*GHPLs1[1]*HPLs2[0*2+1]
          - 1.0/4*GHPLs1[1]*HPLs3[0*2*2+0*2+1]
          + 3.0/4*GHPLs1[1]*HPLs2[1*2+1]
          - 1.0/4*GHPLs1[1]*HPLs3[0*2*2+1*2+1]
          + 1.0/4*GHPLs4[2*4*4*4+2*4*4+0*4+1]
          - 7.0/8*GHPLs3[2*4*4+0*4+1]
          - 1.0/4*GHPLs3[2*4*4+0*4+1]*HPLs1[0]
          - 1.0/4*GHPLs3[2*4*4+0*4+1]*HPLs1[1]
          + 1.0/4*GHPLs3[3*4*4+0*4+1]*HPLs1[0]
          - 1.0/4*GHPLs4[0*4*4*4+3*4*4+0*4+1]
          - 3.0/4*GHPLs2[0*4+1]*zeta2
          + 7.0/8*GHPLs2[0*4+1]*HPLs1[0]
          + 1.0/4*GHPLs2[0*4+1]*HPLs2[0*2+0]
          + 1.0/4*GHPLs2[0*4+1]*HPLs2[1*2+0]
          + 7.0/8*GHPLs2[0*4+1]*HPLs1[1]
          + 1.0/4*GHPLs2[0*4+1]*HPLs2[0*2+1]
          + 1.0/4*GHPLs2[0*4+1]*HPLs2[1*2+1]
          - 1.0/4*GHPLs4[2*4*4*4+2*4*4+1*4+1]
          + GHPLs3[2*4*4+1*4+1]
          + 1.0/4*GHPLs3[2*4*4+1*4+1]*HPLs1[1]
          + 1.0/4*GHPLs4[0*4*4*4+2*4*4+1*4+1]
          - 1.0/4*GHPLs2[1*4+1]*zeta2
          - GHPLs2[1*4+1]*HPLs1[0]
          - 1.0/4*GHPLs2[1*4+1]*HPLs2[1*2+0]
          - GHPLs2[1*4+1]*HPLs1[1]
          - 1.0/4*GHPLs2[1*4+1]*HPLs2[1*2+1]
          + 1.0/4*GHPLs4[2*4*4*4+0*4*4+1*4+1]
          - 1.0/4*GHPLs3[0*4*4+1*4+1]*HPLs1[0]
          - 1.0/4*GHPLs3[0*4*4+1*4+1]*HPLs1[1]
          - 1.0/4*GHPLs4[2*4*4*4+1*4*4+1*4+1]
          + 1.0/4*GHPLs3[1*4*4+1*4+1]*HPLs1[0]
          + 1.0/4*GHPLs3[1*4*4+1*4+1]*HPLs1[1]
          + 3.0/32*HPLs1[0]
          - 1.0/2*HPLs1[0]*zeta2
          + 3.0/2*HPLs1[0]*zeta3
          + 3.0/2*HPLs2[0*2+0]
          - 5.0/32*HPLs1[1]
          - 35.0/8*HPLs1[1]*zeta2
          + HPLs2[0*2+1]
          + 3.0/2*HPLs3[0*2*2+0*2+1]
          + 3.0/4*HPLs3[1*2*2+0*2+1]
          + 9.0/16*HPLs2[1*2+1]
          + 3.0/4*HPLs3[0*2*2+1*2+1]
          )

       + (dN_c*dN_c-1)/(dN_c*dN_c)*v*pow(1-u,-1) * (
          - 17.0/32
          - 15.0/4*zeta2
          + 3.0/8*GHPLs2[2*4+2]
          + 1.0/2*GHPLs2[2*4+2]*HPLs1[0]
          - 1.0/4*GHPLs3[0*4*4+2*4+2]
          - 1.0/4*GHPLs2[3*4+2]*HPLs1[0]
          + 1.0/4*GHPLs3[0*4*4+3*4+2]
          - 1.0/2*GHPLs1[2]
          + 5.0/4*GHPLs1[2]*zeta2
          + 1.0/8*GHPLs1[2]*HPLs1[0]
          - 1.0/2*GHPLs1[2]*HPLs2[0*2+0]
          - 3.0/8*GHPLs1[2]*HPLs1[1]
          - 1.0/4*GHPLs3[2*4*4+0*4+2]
          + 3.0/8*GHPLs2[0*4+2]
          + 1.0/2*GHPLs2[0*4+2]*HPLs1[0]
          + 1.0/4*GHPLs2[0*4+2]*HPLs1[1]
          + 1.0/2*GHPLs3[2*4*4+1*4+2]
          - 1.0/2*GHPLs2[1*4+2]*HPLs1[0]
          - 1.0/2*GHPLs2[1*4+2]*HPLs1[1]
          - 1.0/8*GHPLs1[3]*HPLs1[0]
          + 1.0/8*GHPLs2[0*4+3]
          - 1.0/4*GHPLs3[2*4*4+2*4+0]
          + 3.0/8*GHPLs2[2*4+0]
          + 1.0/4*GHPLs2[2*4+0]*HPLs1[1]
          - 1.0/4*GHPLs2[3*4+0]*HPLs1[0]
          + 1.0/4*GHPLs3[0*4*4+3*4+0]
          - 3.0/8*GHPLs1[0]
          + 1.0/4*GHPLs1[0]*zeta2
          - 1.0/4*GHPLs1[0]*HPLs1[0]
          - 1.0/2*GHPLs1[0]*HPLs2[0*2+0]
          - 1.0/4*GHPLs1[0]*HPLs2[1*2+0]
          - 3.0/8*GHPLs1[0]*HPLs1[1]
          - 1.0/2*GHPLs1[0]*HPLs2[0*2+1]
          - 1.0/4*GHPLs1[0]*HPLs2[1*2+1]
          - 1.0/4*GHPLs3[2*4*4+1*4+0]
          + 1.0/4*GHPLs2[1*4+0]*HPLs1[0]
          + 1.0/4*GHPLs2[1*4+0]*HPLs1[1]
          + 1.0/2*GHPLs3[2*4*4+2*4+1]
          + 3.0/8*GHPLs2[2*4+1]
          - 1.0/2*GHPLs2[2*4+1]*HPLs1[0]
          - 1.0/2*GHPLs2[2*4+1]*HPLs1[1]
          - 1.0/2*GHPLs1[1]*zeta2
          - 3.0/8*GHPLs1[1]*HPLs1[0]
          - 3.0/8*GHPLs1[1]*HPLs1[1]
          + 1.0/2*GHPLs1[1]*HPLs2[0*2+1]
          + 1.0/2*GHPLs1[1]*HPLs2[1*2+1]
          - 1.0/2*GHPLs3[2*4*4+1*4+1]
          + 1.0/2*GHPLs2[1*4+1]*HPLs1[0]
          + 1.0/2*GHPLs2[1*4+1]*HPLs1[1]
          + 11.0/16*HPLs1[0]
          - 9.0/4*HPLs1[0]*zeta2
          - 1.0/4*HPLs2[0*2+0]
          + 1.0/2*HPLs3[0*2*2+0*2+0]
          + 1.0/4*HPLs3[1*2*2+0*2+0]
          + 1.0/4*HPLs2[1*2+0]
          - 1.0/4*HPLs3[0*2*2+1*2+0]
          + 1.0/2*HPLs1[1]
          - 5.0/4*HPLs1[1]*zeta2
          + 1.0/8*HPLs2[0*2+1]
          + 1.0/2*HPLs3[0*2*2+0*2+1]
          + 3.0/8*HPLs2[1*2+1]
          )

       + (dN_c*dN_c-1)/(dN_c*dN_c)*v * (
          + 9.0/2*zeta2
          + 1.0/2*zeta3
          - 1.0/2*GHPLs2[2*4+2]*HPLs1[0]
          + 1.0/2*GHPLs3[0*4*4+2*4+2]
          + 1.0/2*GHPLs2[3*4+2]*HPLs1[0]
          - 1.0/2*GHPLs3[0*4*4+3*4+2]
          - 3.0/8*GHPLs1[2]
          - 9.0/4*GHPLs1[2]*zeta2
          + 7.0/8*GHPLs1[2]*HPLs1[0]
          + 1.0/4*GHPLs1[2]*HPLs2[0*2+0]
          + 1.0/4*GHPLs1[2]*HPLs2[1*2+0]
          + 1.0/2*GHPLs1[2]*HPLs2[0*2+1]
          + 1.0/2*GHPLs3[2*4*4+0*4+2]
          - 9.0/8*GHPLs2[0*4+2]
          - 1.0/4*GHPLs2[0*4+2]*HPLs1[0]
          - 1.0/2*GHPLs2[0*4+2]*HPLs1[1]
          - 1.0/4*GHPLs3[2*4*4+1*4+2]
          + 1.0/4*GHPLs2[1*4+2]*HPLs1[0]
          + 1.0/4*GHPLs2[1*4+2]*HPLs1[1]
          + 1.0/4*GHPLs2[2*4+3]*HPLs1[0]
          - 1.0/4*GHPLs3[0*4*4+2*4+3]
          - 1.0/4*GHPLs2[3*4+3]*HPLs1[0]
          + 1.0/4*GHPLs3[0*4*4+3*4+3]
          + 5.0/4*GHPLs1[3]*zeta2
          - 9.0/8*GHPLs1[3]*HPLs1[0]
          - 1.0/4*GHPLs1[3]*HPLs2[1*2+0]
          - 1.0/4*GHPLs1[3]*HPLs2[0*2+1]
          - 1.0/4*GHPLs3[2*4*4+0*4+3]
          + 9.0/8*GHPLs2[0*4+3]
          + 1.0/4*GHPLs2[0*4+3]*HPLs1[1]
          + 1.0/2*GHPLs3[2*4*4+2*4+0]
          - 9.0/8*GHPLs2[2*4+0]
          - 3.0/4*GHPLs2[2*4+0]*HPLs1[0]
          - 1.0/2*GHPLs2[2*4+0]*HPLs1[1]
          + 1.0/2*GHPLs2[3*4+0]*HPLs1[0]
          - 1.0/2*GHPLs3[0*4*4+3*4+0]
          - GHPLs1[0]*zeta2
          + 11.0/8*GHPLs1[0]*HPLs1[0]
          + 3.0/4*GHPLs1[0]*HPLs2[0*2+0]
          + 1.0/2*GHPLs1[0]*HPLs2[1*2+0]
          + 9.0/8*GHPLs1[0]*HPLs1[1]
          + 3.0/4*GHPLs1[0]*HPLs2[0*2+1]
          + 1.0/2*GHPLs1[0]*HPLs2[1*2+1]
          - 1.0/4*GHPLs3[2*4*4+1*4+0]
          + 1.0/4*GHPLs2[1*4+0]*HPLs1[0]
          + 1.0/4*GHPLs2[1*4+0]*HPLs1[1]
          - 1.0/2*GHPLs3[2*4*4+2*4+1]
          + 9.0/8*GHPLs2[2*4+1]
          + 1.0/4*GHPLs2[2*4+1]*HPLs1[0]
          + 1.0/2*GHPLs2[2*4+1]*HPLs1[1]
          + 1.0/2*GHPLs3[0*4*4+2*4+1]
          - GHPLs1[1]*zeta2
          - 9.0/8*GHPLs1[1]*HPLs1[0]
          - 1.0/4*GHPLs1[1]*HPLs2[0*2+0]
          - 1.0/2*GHPLs1[1]*HPLs2[1*2+0]
          - 9.0/8*GHPLs1[1]*HPLs1[1]
          - 1.0/4*GHPLs1[1]*HPLs2[0*2+1]
          - 1.0/2*GHPLs1[1]*HPLs2[1*2+1]
          + 1.0/2*GHPLs3[2*4*4+0*4+1]
          - 1.0/2*GHPLs2[0*4+1]*HPLs1[0]
          - 1.0/2*GHPLs2[0*4+1]*HPLs1[1]
          - 1.0/4*GHPLs3[2*4*4+1*4+1]
          + 1.0/4*GHPLs2[1*4+1]*HPLs1[0]
          + 1.0/4*GHPLs2[1*4+1]*HPLs1[1]
          + 3.0/8*HPLs1[0]
          + 9.0/4*HPLs1[0]*zeta2
          - 9.0/8*HPLs2[0*2+0]
          - 1.0/4*HPLs3[0*2*2+0*2+0]
          + 1.0/4*HPLs3[1*2*2+0*2+0]
          + 1.0/4*HPLs2[1*2+0]
          + 3.0/8*HPLs1[1]
          + 9.0/4*HPLs1[1]*zeta2
          - 7.0/8*HPLs2[0*2+1]
          - 1.0/4*HPLs3[0*2*2+0*2+1]
          + 1.0/4*HPLs3[1*2*2+0*2+1]
          )

       + (dN_c*dN_c-1)/(dN_c*dN_c)*pow(v,2)*pow(1-u,-2) * (
          + 7.0/16*zeta2
          + 5.0/16*GHPLs2[2*4+2]
          + 1.0/4*GHPLs2[2*4+2]*HPLs1[0]
          - 1.0/8*GHPLs3[0*4*4+2*4+2]
          - 1.0/8*GHPLs2[3*4+2]*HPLs1[0]
          + 1.0/8*GHPLs3[0*4*4+3*4+2]
          - 23.0/32*GHPLs1[2]
          + 5.0/8*GHPLs1[2]*zeta2
          - 1.0/8*GHPLs1[2]*HPLs1[0]
          - 1.0/4*GHPLs1[2]*HPLs2[0*2+0]
          - 5.0/16*GHPLs1[2]*HPLs1[1]
          - 1.0/8*GHPLs3[2*4*4+0*4+2]
          - 3.0/8*GHPLs2[0*4+2]
          + 1.0/4*GHPLs2[0*4+2]*HPLs1[0]
          + 1.0/8*GHPLs2[0*4+2]*HPLs1[1]
          + 1.0/4*GHPLs3[2*4*4+1*4+2]
          - 1.0/4*GHPLs2[1*4+2]*HPLs1[0]
          - 1.0/4*GHPLs2[1*4+2]*HPLs1[1]
          - 1.0/8*GHPLs3[2*4*4+2*4+0]
          - 3.0/8*GHPLs2[2*4+0]
          + 1.0/8*GHPLs2[2*4+0]*HPLs1[1]
          - 1.0/8*GHPLs2[3*4+0]*HPLs1[0]
          + 1.0/8*GHPLs3[0*4*4+3*4+0]
          + 1.0/8*GHPLs1[0]*zeta2
          + 3.0/8*GHPLs1[0]*HPLs1[0]
          - 1.0/4*GHPLs1[0]*HPLs2[0*2+0]
          - 1.0/8*GHPLs1[0]*HPLs2[1*2+0]
          + 3.0/8*GHPLs1[0]*HPLs1[1]
          - 1.0/4*GHPLs1[0]*HPLs2[0*2+1]
          - 1.0/8*GHPLs1[0]*HPLs2[1*2+1]
          - 1.0/8*GHPLs3[2*4*4+1*4+0]
          + 1.0/8*GHPLs2[1*4+0]*HPLs1[0]
          + 1.0/8*GHPLs2[1*4+0]*HPLs1[1]
          + 1.0/4*GHPLs3[2*4*4+2*4+1]
          + 7.0/16*GHPLs2[2*4+1]
          - 1.0/4*GHPLs2[2*4+1]*HPLs1[0]
          - 1.0/4*GHPLs2[2*4+1]*HPLs1[1]
          - 1.0/4*GHPLs1[1]*zeta2
          - 7.0/16*GHPLs1[1]*HPLs1[0]
          - 7.0/16*GHPLs1[1]*HPLs1[1]
          + 1.0/4*GHPLs1[1]*HPLs2[0*2+1]
          + 1.0/4*GHPLs1[1]*HPLs2[1*2+1]
          - 1.0/4*GHPLs3[2*4*4+1*4+1]
          + 1.0/4*GHPLs2[1*4+1]*HPLs1[0]
          + 1.0/4*GHPLs2[1*4+1]*HPLs1[1]
          + 23.0/32*HPLs1[0]
          - 9.0/8*HPLs1[0]*zeta2
          + 3.0/8*HPLs2[0*2+0]
          + 1.0/4*HPLs3[0*2*2+0*2+0]
          + 1.0/8*HPLs3[1*2*2+0*2+0]
          + 9.0/16*HPLs2[1*2+0]
          - 1.0/8*HPLs3[0*2*2+1*2+0]
          + 23.0/32*HPLs1[1]
          - 5.0/8*HPLs1[1]*zeta2
          + 1.0/8*HPLs2[0*2+1]
          + 1.0/4*HPLs3[0*2*2+0*2+1]
          + 5.0/16*HPLs2[1*2+1]
          )

       + (dN_c*dN_c-1)/(dN_c*dN_c)*pow(v,2)*pow(1-u,-1) * (
          + 5.0/4*zeta2
          + 1.0/2*zeta3
          - 5.0/4*GHPLs2[2*4+2]
          - GHPLs2[2*4+2]*HPLs1[0]
          + 3.0/4*GHPLs3[0*4*4+2*4+2]
          + 3.0/4*GHPLs2[3*4+2]*HPLs1[0]
          - 3.0/4*GHPLs3[0*4*4+3*4+2]
          + 23.0/16*GHPLs1[2]
          - 13.0/4*GHPLs1[2]*zeta2
          + GHPLs1[2]*HPLs2[0*2+0]
          + 5.0/4*GHPLs1[2]*HPLs1[1]
          + 1.0/2*GHPLs1[2]*HPLs2[0*2+1]
          + 3.0/4*GHPLs3[2*4*4+0*4+2]
          + 3.0/4*GHPLs2[0*4+2]
          - GHPLs2[0*4+2]*HPLs1[0]
          - 3.0/4*GHPLs2[0*4+2]*HPLs1[1]
          - GHPLs3[2*4*4+1*4+2]
          + GHPLs2[1*4+2]*HPLs1[0]
          + GHPLs2[1*4+2]*HPLs1[1]
          - 1.0/8*GHPLs1[3]*HPLs1[0]
          + 1.0/8*GHPLs2[0*4+3]
          + 3.0/4*GHPLs3[2*4*4+2*4+0]
          + 3.0/4*GHPLs2[2*4+0]
          - 1.0/2*GHPLs2[2*4+0]*HPLs1[0]
          - 3.0/4*GHPLs2[2*4+0]*HPLs1[1]
          + 3.0/4*GHPLs2[3*4+0]*HPLs1[0]
          - 3.0/4*GHPLs3[0*4*4+3*4+0]
          - 7.0/4*GHPLs1[0]*zeta2
          - 3.0/4*GHPLs1[0]*HPLs1[0]
          + GHPLs1[0]*HPLs2[0*2+0]
          + 3.0/4*GHPLs1[0]*HPLs2[1*2+0]
          - 3.0/4*GHPLs1[0]*HPLs1[1]
          + GHPLs1[0]*HPLs2[0*2+1]
          + 3.0/4*GHPLs1[0]*HPLs2[1*2+1]
          + 1.0/4*GHPLs3[2*4*4+1*4+0]
          - 1.0/4*GHPLs2[1*4+0]*HPLs1[0]
          - 1.0/4*GHPLs2[1*4+0]*HPLs1[1]
          - GHPLs3[2*4*4+2*4+1]
          - 5.0/4*GHPLs2[2*4+1]
          + 1.0/2*GHPLs2[2*4+1]*HPLs1[0]
          + GHPLs2[2*4+1]*HPLs1[1]
          + 1.0/2*GHPLs3[0*4*4+2*4+1]
          + 5.0/4*GHPLs1[1]*HPLs1[0]
          - 1.0/2*GHPLs1[1]*HPLs2[1*2+0]
          + 5.0/4*GHPLs1[1]*HPLs1[1]
          - 1.0/2*GHPLs1[1]*HPLs2[0*2+1]
          - GHPLs1[1]*HPLs2[1*2+1]
          + 1.0/2*GHPLs3[2*4*4+0*4+1]
          - 1.0/2*GHPLs2[0*4+1]*HPLs1[0]
          - 1.0/2*GHPLs2[0*4+1]*HPLs1[1]
          - 23.0/16*HPLs1[0]
          + 17.0/4*HPLs1[0]*zeta2
          - 1.0/4*HPLs2[0*2+0]
          - HPLs3[0*2*2+0*2+0]
          - 1.0/4*HPLs3[1*2*2+0*2+0]
          - 5.0/4*HPLs2[1*2+0]
          - 1.0/4*HPLs3[0*2*2+1*2+0]
          - 23.0/16*HPLs1[1]
          + 13.0/4*HPLs1[1]*zeta2
          - 1.0/4*HPLs2[0*2+1]
          - HPLs3[0*2*2+0*2+1]
          - 5.0/4*HPLs2[1*2+1]
          - 1.0/2*HPLs3[0*2*2+1*2+1]
          )

       + (dN_c*dN_c-1)/(dN_c*dN_c)*pow(v,2) * (
          + 3.0/2*zeta2
          + 1.0/8*GHPLs1[2]*zeta2
          + 3.0/8*GHPLs1[2]*HPLs1[0]
          + 1.0/8*GHPLs1[2]*HPLs2[0*2+0]
          - 1.0/8*GHPLs1[2]*HPLs2[1*2+0]
          - 3.0/8*GHPLs2[0*4+2]
          - 1.0/8*GHPLs2[0*4+2]*HPLs1[0]
          - 1.0/8*GHPLs3[2*4*4+1*4+2]
          + 1.0/8*GHPLs2[1*4+2]*HPLs1[0]
          + 1.0/8*GHPLs2[1*4+2]*HPLs1[1]
          - 1.0/8*GHPLs2[2*4+3]*HPLs1[0]
          + 1.0/8*GHPLs3[0*4*4+2*4+3]
          + 1.0/8*GHPLs2[3*4+3]*HPLs1[0]
          - 1.0/8*GHPLs3[0*4*4+3*4+3]
          - 5.0/8*GHPLs1[3]*zeta2
          - 3.0/8*GHPLs1[3]*HPLs1[0]
          + 1.0/8*GHPLs1[3]*HPLs2[1*2+0]
          + 1.0/8*GHPLs1[3]*HPLs2[0*2+1]
          + 1.0/8*GHPLs3[2*4*4+0*4+3]
          + 3.0/8*GHPLs2[0*4+3]
          - 1.0/8*GHPLs2[0*4+3]*HPLs1[1]
          - 3.0/8*GHPLs2[2*4+0]
          + 1.0/8*GHPLs2[2*4+0]*HPLs1[0]
          - 1.0/4*GHPLs1[0]*zeta2
          + 3.0/8*GHPLs1[0]*HPLs1[0]
          - 1.0/8*GHPLs1[0]*HPLs2[0*2+0]
          + 3.0/8*GHPLs1[0]*HPLs1[1]
          - 1.0/8*GHPLs1[0]*HPLs2[0*2+1]
          + 1.0/8*GHPLs3[2*4*4+1*4+0]
          - 1.0/8*GHPLs2[1*4+0]*HPLs1[0]
          - 1.0/8*GHPLs2[1*4+0]*HPLs1[1]
          + 3.0/8*GHPLs2[2*4+1]
          - 1.0/8*GHPLs2[2*4+1]*HPLs1[0]
          + 1.0/4*GHPLs1[1]*zeta2
          - 3.0/8*GHPLs1[1]*HPLs1[0]
          + 1.0/8*GHPLs1[1]*HPLs2[0*2+0]
          - 3.0/8*GHPLs1[1]*HPLs1[1]
          + 1.0/8*GHPLs1[1]*HPLs2[0*2+1]
          - 1.0/8*GHPLs3[2*4*4+1*4+1]
          + 1.0/8*GHPLs2[1*4+1]*HPLs1[0]
          + 1.0/8*GHPLs2[1*4+1]*HPLs1[1]
          - 1.0/8*HPLs1[0]*zeta2
          - 3.0/8*HPLs2[0*2+0]
          - 1.0/8*HPLs3[0*2*2+0*2+0]
          - 1.0/8*HPLs3[1*2*2+0*2+0]
          - 1.0/4*HPLs3[0*2*2+1*2+0]
          - 1.0/8*HPLs1[1]*zeta2
          - 3.0/8*HPLs2[0*2+1]
          - 1.0/8*HPLs3[0*2*2+0*2+1]
          - 1.0/8*HPLs3[1*2*2+0*2+1]
          - 1.0/4*HPLs3[0*2*2+1*2+1]
          )

       + (dN_c*dN_c-1)/(dN_c*dN_c)*u * (
          + 2*zeta2
          - 3.0/8*GHPLs1[2]
          + 1.0/2*GHPLs1[2]*HPLs1[0]
          - 1.0/2*GHPLs2[0*4+2]
          - 1.0/2*GHPLs1[3]*HPLs1[0]
          + 1.0/2*GHPLs2[0*4+3]
          - 1.0/2*GHPLs2[2*4+0]
          + 3.0/8*GHPLs1[0]
          + 1.0/2*GHPLs1[0]*HPLs1[0]
          + 1.0/2*GHPLs1[0]*HPLs1[1]
          + 1.0/2*GHPLs2[2*4+1]
          - 1.0/2*GHPLs1[1]*HPLs1[0]
          - 1.0/2*GHPLs1[1]*HPLs1[1]
          - 1.0/2*HPLs2[0*2+0]
          + 3.0/8*HPLs1[1]
          - 1.0/2*HPLs2[0*2+1]
          )

       + (dN_c*dN_c-1)/(dN_c*dN_c)*u*v * (
          - 1.0/2*zeta2
          - 1.0/8*GHPLs1[2]*HPLs1[0]
          + 1.0/8*GHPLs2[0*4+2]
          + 1.0/8*GHPLs1[3]*HPLs1[0]
          - 1.0/8*GHPLs2[0*4+3]
          + 1.0/8*GHPLs2[2*4+0]
          - 1.0/8*GHPLs1[0]*HPLs1[0]
          - 1.0/8*GHPLs1[0]*HPLs1[1]
          - 1.0/8*GHPLs2[2*4+1]
          + 1.0/8*GHPLs1[1]*HPLs1[0]
          + 1.0/8*GHPLs1[1]*HPLs1[1]
          + 1.0/8*HPLs2[0*2+0]
          + 1.0/8*HPLs2[0*2+1]
          )

       + (dN_c*dN_c-1)/(dN_c*dN_c)*pow(u,2) * (
          - 3.0/2*zeta2
          - 3.0/8*GHPLs1[2]*HPLs1[0]
          + 3.0/8*GHPLs2[0*4+2]
          + 3.0/8*GHPLs1[3]*HPLs1[0]
          - 3.0/8*GHPLs2[0*4+3]
          + 3.0/8*GHPLs2[2*4+0]
          - 3.0/8*GHPLs1[0]*HPLs1[0]
          - 3.0/8*GHPLs1[0]*HPLs1[1]
          - 3.0/8*GHPLs2[2*4+1]
          + 3.0/8*GHPLs1[1]*HPLs1[0]
          + 3.0/8*GHPLs1[1]*HPLs1[1]
          + 3.0/8*HPLs2[0*2+0]
          + 3.0/8*HPLs2[0*2+1]
          )

       + (dN_c*dN_c-1)/(dN_c*dN_c)*double_complex(0,1)*M_PI*pow(u,-2) * (
          - 7.0/4*GHPLs3[3*4*4+2*4+2]
          - 7.0/4*GHPLs2[2*4+2]*HPLs1[0]
          + 5.0/4*GHPLs3[1*4*4+2*4+2]
          - 1.0/2*GHPLs3[3*4*4+3*4+2]
          + 5.0/2*GHPLs1[2]*zeta2
          - 9.0/8*GHPLs1[2]*HPLs1[0]
          - 7.0/4*GHPLs1[2]*HPLs2[0*2+0]
          - 5.0/4*GHPLs1[2]*HPLs2[1*2+0]
          + 5.0/4*GHPLs1[2]*HPLs2[0*2+1]
          + 7.0/4*GHPLs3[3*4*4+0*4+2]
          + 5.0/4*GHPLs2[0*4+2]*HPLs1[0]
          - 5.0/4*GHPLs3[1*4*4+0*4+2]
          + 3.0/8*GHPLs2[1*4+2]
          + 1.0/4*GHPLs2[1*4+2]*HPLs1[0]
          - 1.0/2*GHPLs3[1*4*4+1*4+2]
          + 5.0/4*GHPLs3[2*4*4+2*4+1]
          - 5.0/4*GHPLs3[3*4*4+2*4+1]
          - 3.0/4*GHPLs2[2*4+1]
          - 3.0/2*GHPLs2[2*4+1]*HPLs1[0]
          - 5.0/4*GHPLs2[2*4+1]*HPLs1[1]
          + 5.0/4*GHPLs3[0*4*4+2*4+1]
          - 3.0/2*GHPLs3[1*4*4+2*4+1]
          + 11.0/16*GHPLs1[1]
          - 9.0/4*GHPLs1[1]*zeta2
          + 9.0/8*GHPLs1[1]*HPLs1[0]
          + 7.0/4*GHPLs1[1]*HPLs2[0*2+0]
          + 5.0/4*GHPLs1[1]*HPLs2[1*2+0]
          + 3.0/4*GHPLs1[1]*HPLs1[1]
          + 3.0/2*GHPLs1[1]*HPLs2[0*2+1]
          + 5.0/4*GHPLs1[1]*HPLs2[1*2+1]
          + 5.0/4*GHPLs3[2*4*4+0*4+1]
          - 5.0/4*GHPLs3[3*4*4+0*4+1]
          - 3.0/4*GHPLs2[0*4+1]
          - 5.0/4*GHPLs2[0*4+1]*HPLs1[0]
          - 5.0/4*GHPLs2[0*4+1]*HPLs1[1]
          + 1.0/4*GHPLs3[1*4*4+0*4+1]
          - 1.0/2*GHPLs3[2*4*4+1*4+1]
          - 3.0/8*GHPLs2[1*4+1]
          + 1.0/2*GHPLs2[1*4+1]*HPLs1[1]
          + 5.0/4*GHPLs3[0*4*4+1*4+1]
          - 3.0/4*GHPLs3[1*4*4+1*4+1]
          )

       + (dN_c*dN_c-1)/(dN_c*dN_c)*double_complex(0,1)*M_PI*pow(u,-2)*v * (
          + 7.0/2*GHPLs3[3*4*4+2*4+2]
          + 7.0/2*GHPLs2[2*4+2]*HPLs1[0]
          - 5.0/2*GHPLs3[1*4*4+2*4+2]
          + GHPLs3[3*4*4+3*4+2]
          - 5*GHPLs1[2]*zeta2
          + 9.0/4*GHPLs1[2]*HPLs1[0]
          + 7.0/2*GHPLs1[2]*HPLs2[0*2+0]
          + 5.0/2*GHPLs1[2]*HPLs2[1*2+0]
          - 5.0/2*GHPLs1[2]*HPLs2[0*2+1]
          - 7.0/2*GHPLs3[3*4*4+0*4+2]
          - 5.0/2*GHPLs2[0*4+2]*HPLs1[0]
          + 5.0/2*GHPLs3[1*4*4+0*4+2]
          - GHPLs2[1*4+2]
          - 1.0/2*GHPLs2[1*4+2]*HPLs1[0]
          + GHPLs3[1*4*4+1*4+2]
          - 1.0/2*GHPLs2[3*4+3]
          - 5.0/2*GHPLs3[2*4*4+2*4+1]
          + 5.0/2*GHPLs3[3*4*4+2*4+1]
          + 5.0/4*GHPLs2[2*4+1]
          + 3*GHPLs2[2*4+1]*HPLs1[0]
          + 5.0/2*GHPLs2[2*4+1]*HPLs1[1]
          - 5.0/2*GHPLs3[0*4*4+2*4+1]
          + 3*GHPLs3[1*4*4+2*4+1]
          - 13.0/8*GHPLs1[1]
          + 9.0/2*GHPLs1[1]*zeta2
          - 7.0/4*GHPLs1[1]*HPLs1[0]
          - 7.0/2*GHPLs1[1]*HPLs2[0*2+0]
          - 5.0/2*GHPLs1[1]*HPLs2[1*2+0]
          - 5.0/4*GHPLs1[1]*HPLs1[1]
          - 3*GHPLs1[1]*HPLs2[0*2+1]
          - 5.0/2*GHPLs1[1]*HPLs2[1*2+1]
          - 5.0/2*GHPLs3[2*4*4+0*4+1]
          + 5.0/2*GHPLs3[3*4*4+0*4+1]
          + 5.0/4*GHPLs2[0*4+1]
          + 5.0/2*GHPLs2[0*4+1]*HPLs1[0]
          + 5.0/2*GHPLs2[0*4+1]*HPLs1[1]
          - 1.0/2*GHPLs3[1*4*4+0*4+1]
          + GHPLs3[2*4*4+1*4+1]
          + 1.0/2*GHPLs2[1*4+1]
          - GHPLs2[1*4+1]*HPLs1[1]
          - 5.0/2*GHPLs3[0*4*4+1*4+1]
          + 3.0/2*GHPLs3[1*4*4+1*4+1]
          )

       + (dN_c*dN_c-1)/(dN_c*dN_c)*double_complex(0,1)*M_PI*pow(u,-2)*pow(v,2) * (
          - 7.0/4*GHPLs3[3*4*4+2*4+2]
          - 7.0/4*GHPLs2[2*4+2]*HPLs1[0]
          + 5.0/4*GHPLs3[1*4*4+2*4+2]
          - 1.0/2*GHPLs3[3*4*4+3*4+2]
          + 5.0/2*GHPLs1[2]*zeta2
          - 9.0/8*GHPLs1[2]*HPLs1[0]
          - 7.0/4*GHPLs1[2]*HPLs2[0*2+0]
          - 5.0/4*GHPLs1[2]*HPLs2[1*2+0]
          + 5.0/4*GHPLs1[2]*HPLs2[0*2+1]
          + 7.0/4*GHPLs3[3*4*4+0*4+2]
          + 5.0/4*GHPLs2[0*4+2]*HPLs1[0]
          - 5.0/4*GHPLs3[1*4*4+0*4+2]
          + 3.0/4*GHPLs2[1*4+2]
          + 1.0/4*GHPLs2[1*4+2]*HPLs1[0]
          - 1.0/2*GHPLs3[1*4*4+1*4+2]
          + 3.0/4*GHPLs2[3*4+3]
          + 5.0/4*GHPLs3[2*4*4+2*4+1]
          - 5.0/4*GHPLs3[3*4*4+2*4+1]
          - 3.0/8*GHPLs2[2*4+1]
          - 3.0/2*GHPLs2[2*4+1]*HPLs1[0]
          - 5.0/4*GHPLs2[2*4+1]*HPLs1[1]
          + 5.0/4*GHPLs3[0*4*4+2*4+1]
          - 3.0/2*GHPLs3[1*4*4+2*4+1]
          + 17.0/16*GHPLs1[1]
          - 9.0/4*GHPLs1[1]*zeta2
          + 3.0/8*GHPLs1[1]*HPLs1[0]
          + 7.0/4*GHPLs1[1]*HPLs2[0*2+0]
          + 5.0/4*GHPLs1[1]*HPLs2[1*2+0]
          + 3.0/8*GHPLs1[1]*HPLs1[1]
          + 3.0/2*GHPLs1[1]*HPLs2[0*2+1]
          + 5.0/4*GHPLs1[1]*HPLs2[1*2+1]
          + 5.0/4*GHPLs3[2*4*4+0*4+1]
          - 5.0/4*GHPLs3[3*4*4+0*4+1]
          - 3.0/8*GHPLs2[0*4+1]
          - 5.0/4*GHPLs2[0*4+1]*HPLs1[0]
          - 5.0/4*GHPLs2[0*4+1]*HPLs1[1]
          + 1.0/4*GHPLs3[1*4*4+0*4+1]
          - 1.0/2*GHPLs3[2*4*4+1*4+1]
          + 1.0/2*GHPLs2[1*4+1]*HPLs1[1]
          + 5.0/4*GHPLs3[0*4*4+1*4+1]
          - 3.0/4*GHPLs3[1*4*4+1*4+1]
          )

       + (dN_c*dN_c-1)/(dN_c*dN_c)*double_complex(0,1)*M_PI*pow(u,-2)*pow(v,3) * (
          - 1.0/8*GHPLs1[1]
          )

       + (dN_c*dN_c-1)/(dN_c*dN_c)*double_complex(0,1)*M_PI*pow(u,-2)*pow(v,4) * (
          - 1.0/8*GHPLs2[1*4+2]
          + 1.0/8*GHPLs2[2*4+3]
          - 1.0/8*GHPLs2[3*4+3]
          - 1.0/8*GHPLs1[3]*HPLs1[0]
          - 1.0/8*GHPLs1[3]*HPLs1[1]
          + 1.0/8*GHPLs2[0*4+3]
          )

       + (dN_c*dN_c-1)/(dN_c*dN_c)*double_complex(0,1)*M_PI*pow(u,-1) * (
          + 23.0/16
          + 1.0/4*zeta2
          + 3.0/2*GHPLs3[3*4*4+2*4+2]
          + 5.0/4*GHPLs2[2*4+2]
          + 3.0/2*GHPLs2[2*4+2]*HPLs1[0]
          - 3.0/2*GHPLs3[1*4*4+2*4+2]
          - 3*GHPLs2[3*4+2]
          - 2*GHPLs1[2]
          - 3*GHPLs1[2]*zeta2
          - 3*GHPLs1[2]*HPLs1[0]
          + 3.0/2*GHPLs1[2]*HPLs2[0*2+0]
          + 3.0/2*GHPLs1[2]*HPLs2[1*2+0]
          - 5.0/4*GHPLs1[2]*HPLs1[1]
          - 3.0/2*GHPLs1[2]*HPLs2[0*2+1]
          - 3.0/2*GHPLs3[3*4*4+0*4+2]
          + 5.0/4*GHPLs2[0*4+2]
          - 3.0/2*GHPLs2[0*4+2]*HPLs1[0]
          + 3.0/2*GHPLs3[1*4*4+0*4+2]
          - 1.0/4*GHPLs2[1*4+2]
          - 1.0/2*GHPLs2[3*4+3]
          + 5.0/4*GHPLs2[2*4+0]
          + 1.0/2*GHPLs2[3*4+0]
          - 3.0/4*GHPLs1[0]
          - 5.0/4*GHPLs1[0]*HPLs1[1]
          - GHPLs2[1*4+0]
          - 3.0/2*GHPLs3[2*4*4+2*4+1]
          + 3.0/2*GHPLs3[3*4*4+2*4+1]
          - 1.0/4*GHPLs2[2*4+1]
          + 3.0/2*GHPLs2[2*4+1]*HPLs1[0]
          + 3.0/2*GHPLs2[2*4+1]*HPLs1[1]
          - 3.0/2*GHPLs3[0*4*4+2*4+1]
          + 3.0/2*GHPLs3[1*4*4+2*4+1]
          + 11.0/8*GHPLs1[1]
          + 3*GHPLs1[1]*zeta2
          - 3.0/2*GHPLs1[1]*HPLs2[0*2+0]
          - 3.0/2*GHPLs1[1]*HPLs2[1*2+0]
          + 1.0/4*GHPLs1[1]*HPLs1[1]
          - 3.0/2*GHPLs1[1]*HPLs2[0*2+1]
          - 3.0/2*GHPLs1[1]*HPLs2[1*2+1]
          - 3.0/2*GHPLs3[2*4*4+0*4+1]
          + 3.0/2*GHPLs3[3*4*4+0*4+1]
          + 5.0/4*GHPLs2[0*4+1]
          + 3.0/2*GHPLs2[0*4+1]*HPLs1[0]
          + 3.0/2*GHPLs2[0*4+1]*HPLs1[1]
          - GHPLs2[1*4+1]
          - 3.0/2*GHPLs3[0*4*4+1*4+1]
          + 3.0/2*GHPLs3[1*4*4+1*4+1]
          + 2*HPLs1[1]
          + 11.0/4*HPLs2[0*2+1]
          + 5.0/4*HPLs2[1*2+1]
          )

       + (dN_c*dN_c-1)/(dN_c*dN_c)*double_complex(0,1)*M_PI*pow(u,-1)*v * (
          - 23.0/8
          + 2*zeta2
          - 3.0/2*GHPLs3[3*4*4+2*4+2]
          - 5.0/2*GHPLs2[2*4+2]
          - 3.0/2*GHPLs2[2*4+2]*HPLs1[0]
          + 3.0/2*GHPLs3[1*4*4+2*4+2]
          + 17.0/4*GHPLs2[3*4+2]
          + 15.0/4*GHPLs1[2]
          + 3*GHPLs1[2]*zeta2
          + 9.0/2*GHPLs1[2]*HPLs1[0]
          - 3.0/2*GHPLs1[2]*HPLs2[0*2+0]
          - 3.0/2*GHPLs1[2]*HPLs2[1*2+0]
          + 5.0/2*GHPLs1[2]*HPLs1[1]
          + 3.0/2*GHPLs1[2]*HPLs2[0*2+1]
          + 3.0/2*GHPLs3[3*4*4+0*4+2]
          - 5.0/2*GHPLs2[0*4+2]
          + 3.0/2*GHPLs2[0*4+2]*HPLs1[0]
          - 3.0/2*GHPLs3[1*4*4+0*4+2]
          + 7.0/4*GHPLs2[1*4+2]
          + 1.0/2*GHPLs2[3*4+3]
          - 3.0/2*GHPLs1[3]
          - 5.0/2*GHPLs2[2*4+0]
          + 3.0/4*GHPLs2[3*4+0]
          + 5.0/4*GHPLs1[0]
          + 5.0/4*GHPLs1[0]*HPLs1[0]
          + 5.0/2*GHPLs1[0]*HPLs1[1]
          + 1.0/2*GHPLs2[1*4+0]
          + 3.0/2*GHPLs3[2*4*4+2*4+1]
          - 3.0/2*GHPLs3[3*4*4+2*4+1]
          + 3.0/4*GHPLs2[2*4+1]
          - 3.0/2*GHPLs2[2*4+1]*HPLs1[0]
          - 3.0/2*GHPLs2[2*4+1]*HPLs1[1]
          + 3.0/2*GHPLs3[0*4*4+2*4+1]
          - 3.0/2*GHPLs3[1*4*4+2*4+1]
          - GHPLs1[1]
          - 3*GHPLs1[1]*zeta2
          + 3.0/2*GHPLs1[1]*HPLs2[0*2+0]
          + 3.0/2*GHPLs1[1]*HPLs2[1*2+0]
          - 3.0/4*GHPLs1[1]*HPLs1[1]
          + 3.0/2*GHPLs1[1]*HPLs2[0*2+1]
          + 3.0/2*GHPLs1[1]*HPLs2[1*2+1]
          + 3.0/2*GHPLs3[2*4*4+0*4+1]
          - 3.0/2*GHPLs3[3*4*4+0*4+1]
          - 9.0/4*GHPLs2[0*4+1]
          - 3.0/2*GHPLs2[0*4+1]*HPLs1[0]
          - 3.0/2*GHPLs2[0*4+1]*HPLs1[1]
          + 7.0/4*GHPLs2[1*4+1]
          + 3.0/2*GHPLs3[0*4*4+1*4+1]
          - 3.0/2*GHPLs3[1*4*4+1*4+1]
          - 15.0/8*HPLs1[0]
          - 7.0/4*HPLs2[0*2+0]
          - 5.0/4*HPLs2[1*2+0]
          - 15.0/4*HPLs1[1]
          - 17.0/4*HPLs2[0*2+1]
          - 5.0/2*HPLs2[1*2+1]
          )

       + (dN_c*dN_c-1)/(dN_c*dN_c)*double_complex(0,1)*M_PI*pow(u,-1)*pow(v,2) * (
          + 23.0/16
          - 9.0/4*zeta2
          + 5.0/4*GHPLs2[2*4+2]
          - 5.0/4*GHPLs2[3*4+2]
          - 13.0/8*GHPLs1[2]
          - 3.0/2*GHPLs1[2]*HPLs1[0]
          - 5.0/4*GHPLs1[2]*HPLs1[1]
          + 5.0/4*GHPLs2[0*4+2]
          - 5.0/4*GHPLs2[1*4+2]
          - 1.0/4*GHPLs2[2*4+3]
          + 1.0/4*GHPLs2[3*4+3]
          + 5.0/4*GHPLs1[3]
          + 1.0/4*GHPLs1[3]*HPLs1[0]
          + 1.0/4*GHPLs1[3]*HPLs1[1]
          - 1.0/4*GHPLs2[0*4+3]
          + 5.0/4*GHPLs2[2*4+0]
          - 5.0/4*GHPLs2[3*4+0]
          - 3.0/8*GHPLs1[0]
          - 5.0/4*GHPLs1[0]*HPLs1[0]
          - 5.0/4*GHPLs1[0]*HPLs1[1]
          + 1.0/2*GHPLs2[1*4+0]
          - 1.0/2*GHPLs2[2*4+1]
          - 3.0/8*GHPLs1[1]
          + 1.0/2*GHPLs1[1]*HPLs1[1]
          + GHPLs2[0*4+1]
          - 3.0/4*GHPLs2[1*4+1]
          + 13.0/8*HPLs1[0]
          + 7.0/4*HPLs2[0*2+0]
          + 5.0/4*HPLs2[1*2+0]
          + 13.0/8*HPLs1[1]
          + 3.0/2*HPLs2[0*2+1]
          + 5.0/4*HPLs2[1*2+1]
          )

       + (dN_c*dN_c-1)/(dN_c*dN_c)*double_complex(0,1)*M_PI*pow(u,-1)*pow(v,3) * (
          - 1.0/8*GHPLs1[2]
          - 1.0/4*GHPLs2[1*4+2]
          + 1.0/4*GHPLs2[2*4+3]
          - 1.0/4*GHPLs2[3*4+3]
          + 1.0/8*GHPLs1[3]
          - 1.0/4*GHPLs1[3]*HPLs1[0]
          - 1.0/4*GHPLs1[3]*HPLs1[1]
          + 1.0/4*GHPLs2[0*4+3]
          - 1.0/8*GHPLs1[0]
          + 1.0/8*GHPLs1[1]
          + 1.0/8*HPLs1[0]
          + 1.0/8*HPLs1[1]
          )

       + (dN_c*dN_c-1)/(dN_c*dN_c)*double_complex(0,1)*M_PI * (
          + 5.0/8
          - 5.0/8*zeta2
          + 3.0/2*zeta3
          - 1.0/4*GHPLs3[3*4*4+2*4+2]
          - 7.0/8*GHPLs2[2*4+2]
          - 1.0/4*GHPLs2[2*4+2]*HPLs1[0]
          + 1.0/4*GHPLs3[1*4*4+2*4+2]
          + 3.0/2*GHPLs2[3*4+2]
          + 23.0/16*GHPLs1[2]
          + 1.0/2*GHPLs1[2]*zeta2
          + 3.0/2*GHPLs1[2]*HPLs1[0]
          - 1.0/4*GHPLs1[2]*HPLs2[0*2+0]
          - 1.0/4*GHPLs1[2]*HPLs2[1*2+0]
          + 7.0/8*GHPLs1[2]*HPLs1[1]
          + 1.0/4*GHPLs1[2]*HPLs2[0*2+1]
          + 1.0/4*GHPLs3[3*4*4+0*4+2]
          - 7.0/8*GHPLs2[0*4+2]
          + 1.0/4*GHPLs2[0*4+2]*HPLs1[0]
          - 1.0/4*GHPLs3[1*4*4+0*4+2]
          - 1.0/8*GHPLs2[1*4+2]
          - 1.0/4*GHPLs2[3*4+3]
          - 3.0/2*GHPLs1[3]
          - 7.0/8*GHPLs2[2*4+0]
          + 1.0/4*GHPLs2[3*4+0]
          + 7.0/8*GHPLs1[0]
          + 7.0/8*GHPLs1[0]*HPLs1[1]
          + GHPLs2[1*4+0]
          + 1.0/4*GHPLs3[2*4*4+2*4+1]
          - 1.0/4*GHPLs3[3*4*4+2*4+1]
          - 1.0/8*GHPLs2[2*4+1]
          - 1.0/4*GHPLs2[2*4+1]*HPLs1[0]
          - 1.0/4*GHPLs2[2*4+1]*HPLs1[1]
          + 1.0/4*GHPLs3[0*4*4+2*4+1]
          - 1.0/4*GHPLs3[1*4*4+2*4+1]
          - 19.0/16*GHPLs1[1]
          - 1.0/2*GHPLs1[1]*zeta2
          + 1.0/4*GHPLs1[1]*HPLs2[0*2+0]
          + 1.0/4*GHPLs1[1]*HPLs2[1*2+0]
          + 1.0/8*GHPLs1[1]*HPLs1[1]
          + 1.0/4*GHPLs1[1]*HPLs2[0*2+1]
          + 1.0/4*GHPLs1[1]*HPLs2[1*2+1]
          + 1.0/4*GHPLs3[2*4*4+0*4+1]
          - 1.0/4*GHPLs3[3*4*4+0*4+1]
          - 7.0/8*GHPLs2[0*4+1]
          - 1.0/4*GHPLs2[0*4+1]*HPLs1[0]
          - 1.0/4*GHPLs2[0*4+1]*HPLs1[1]
          + GHPLs2[1*4+1]
          + 1.0/4*GHPLs3[0*4*4+1*4+1]
          - 1.0/4*GHPLs3[1*4*4+1*4+1]
          - 3.0/2*HPLs1[0]
          - 23.0/16*HPLs1[1]
          - 13.0/8*HPLs2[0*2+1]
          - 7.0/8*HPLs2[1*2+1]
          )

       + (dN_c*dN_c-1)/(dN_c*dN_c)*double_complex(0,1)*M_PI*v*pow(1-u,-1) * (
          - 7.0/8
          - 1.0/4*GHPLs2[2*4+2]
          + 1.0/4*GHPLs2[3*4+2]
          + 3.0/4*GHPLs1[2]
          + 1.0/2*GHPLs1[2]*HPLs1[0]
          + 1.0/4*GHPLs1[2]*HPLs1[1]
          - 1.0/4*GHPLs2[0*4+2]
          + 1.0/2*GHPLs2[1*4+2]
          + 1.0/8*GHPLs1[3]
          - 1.0/4*GHPLs2[2*4+0]
          + 1.0/4*GHPLs2[3*4+0]
          + 3.0/8*GHPLs1[0]
          + 1.0/4*GHPLs1[0]*HPLs1[0]
          + 1.0/4*GHPLs1[0]*HPLs1[1]
          - 1.0/4*GHPLs2[1*4+0]
          + 1.0/2*GHPLs2[2*4+1]
          + 3.0/8*GHPLs1[1]
          - 1.0/2*GHPLs1[1]*HPLs1[1]
          - 1.0/2*GHPLs2[1*4+1]
          - 1.0/2*HPLs1[0]
          - 3.0/4*HPLs2[0*2+0]
          - 1.0/4*HPLs2[1*2+0]
          - 3.0/4*HPLs1[1]
          - 1.0/2*HPLs2[0*2+1]
          - 1.0/4*HPLs2[1*2+1]
          )

       + (dN_c*dN_c-1)/(dN_c*dN_c)*double_complex(0,1)*M_PI*v * (
          - 3.0/8
          - 3.0/4*zeta2
          + 1.0/2*GHPLs2[2*4+2]
          - 1.0/2*GHPLs2[3*4+2]
          - 9.0/8*GHPLs1[2]
          - 1.0/2*GHPLs1[2]*HPLs1[0]
          - 1.0/2*GHPLs1[2]*HPLs1[1]
          + 1.0/2*GHPLs2[0*4+2]
          - 1.0/4*GHPLs2[1*4+2]
          - 1.0/4*GHPLs2[2*4+3]
          + 1.0/4*GHPLs2[3*4+3]
          + 9.0/8*GHPLs1[3]
          + 1.0/4*GHPLs1[3]*HPLs1[0]
          + 1.0/4*GHPLs1[3]*HPLs1[1]
          - 1.0/4*GHPLs2[0*4+3]
          + 1.0/2*GHPLs2[2*4+0]
          - 1.0/2*GHPLs2[3*4+0]
          - 9.0/8*GHPLs1[0]
          - 1.0/2*GHPLs1[0]*HPLs1[0]
          - 1.0/2*GHPLs1[0]*HPLs1[1]
          - 1.0/4*GHPLs2[1*4+0]
          + 9.0/8*GHPLs1[1]
          + 1.0/2*GHPLs2[0*4+1]
          - 1.0/4*GHPLs2[1*4+1]
          + 9.0/8*HPLs1[0]
          + 1.0/2*HPLs2[0*2+0]
          + 1.0/2*HPLs2[1*2+0]
          + 9.0/8*HPLs1[1]
          + 1.0/2*HPLs2[0*2+1]
          + 1.0/2*HPLs2[1*2+1]
          )

       + (dN_c*dN_c-1)/(dN_c*dN_c)*double_complex(0,1)*M_PI*pow(v,2)*pow(1-u,-2) * (
          - 23.0/32
          - 1.0/8*GHPLs2[2*4+2]
          + 1.0/8*GHPLs2[3*4+2]
          - 1.0/16*GHPLs1[2]
          + 1.0/4*GHPLs1[2]*HPLs1[0]
          + 1.0/8*GHPLs1[2]*HPLs1[1]
          - 1.0/8*GHPLs2[0*4+2]
          + 1.0/4*GHPLs2[1*4+2]
          - 1.0/8*GHPLs2[2*4+0]
          + 1.0/8*GHPLs2[3*4+0]
          - 3.0/8*GHPLs1[0]
          + 1.0/8*GHPLs1[0]*HPLs1[0]
          + 1.0/8*GHPLs1[0]*HPLs1[1]
          - 1.0/8*GHPLs2[1*4+0]
          + 1.0/4*GHPLs2[2*4+1]
          + 7.0/16*GHPLs1[1]
          - 1.0/4*GHPLs1[1]*HPLs1[1]
          - 1.0/4*GHPLs2[1*4+1]
          - 3.0/16*HPLs1[0]
          - 3.0/8*HPLs2[0*2+0]
          - 1.0/8*HPLs2[1*2+0]
          + 1.0/16*HPLs1[1]
          - 1.0/4*HPLs2[0*2+1]
          - 1.0/8*HPLs2[1*2+1]
          )

       + (dN_c*dN_c-1)/(dN_c*dN_c)*double_complex(0,1)*M_PI*pow(v,2)*pow(1-u,-1) * (
          + 23.0/16
          - zeta2
          + 3.0/4*GHPLs2[2*4+2]
          - 3.0/4*GHPLs2[3*4+2]
          - 1.0/2*GHPLs1[2]
          - GHPLs1[2]*HPLs1[0]
          - 3.0/4*GHPLs1[2]*HPLs1[1]
          + 3.0/4*GHPLs2[0*4+2]
          - GHPLs2[1*4+2]
          + 1.0/8*GHPLs1[3]
          + 3.0/4*GHPLs2[2*4+0]
          - 3.0/4*GHPLs2[3*4+0]
          + 3.0/4*GHPLs1[0]
          - 3.0/4*GHPLs1[0]*HPLs1[0]
          - 3.0/4*GHPLs1[0]*HPLs1[1]
          + 1.0/4*GHPLs2[1*4+0]
          - 1.0/2*GHPLs2[2*4+1]
          - 5.0/4*GHPLs1[1]
          + 1.0/2*GHPLs1[1]*HPLs1[1]
          + 1.0/2*GHPLs2[0*4+1]
          + 1.0/2*HPLs1[0]
          + 5.0/4*HPLs2[0*2+0]
          + 3.0/4*HPLs2[1*2+0]
          + 1.0/2*HPLs1[1]
          + HPLs2[0*2+1]
          + 3.0/4*HPLs2[1*2+1]
          )

       + (dN_c*dN_c-1)/(dN_c*dN_c)*double_complex(0,1)*M_PI*pow(v,2) * (
          - 1.0/8*zeta2
          - 3.0/8*GHPLs1[2]
          - 1.0/8*GHPLs2[1*4+2]
          + 1.0/8*GHPLs2[2*4+3]
          - 1.0/8*GHPLs2[3*4+3]
          + 3.0/8*GHPLs1[3]
          - 1.0/8*GHPLs1[3]*HPLs1[0]
          - 1.0/8*GHPLs1[3]*HPLs1[1]
          + 1.0/8*GHPLs2[0*4+3]
          - 3.0/8*GHPLs1[0]
          + 1.0/8*GHPLs2[1*4+0]
          + 3.0/8*GHPLs1[1]
          - 1.0/8*GHPLs2[1*4+1]
          + 3.0/8*HPLs1[0]
          + 3.0/8*HPLs1[1]
          )

       + (dN_c*dN_c-1)/(dN_c*dN_c)*double_complex(0,1)*M_PI*u * (
          - 1.0/2*GHPLs1[2]
          + 1.0/2*GHPLs1[3]
          - 1.0/2*GHPLs1[0]
          + 1.0/2*GHPLs1[1]
          + 1.0/2*HPLs1[0]
          + 1.0/2*HPLs1[1]
          )

       + (dN_c*dN_c-1)/(dN_c*dN_c)*double_complex(0,1)*M_PI*u*v * (
          + 1.0/8*GHPLs1[2]
          - 1.0/8*GHPLs1[3]
          + 1.0/8*GHPLs1[0]
          - 1.0/8*GHPLs1[1]
          - 1.0/8*HPLs1[0]
          - 1.0/8*HPLs1[1]
          )

       + (dN_c*dN_c-1)/(dN_c*dN_c)*double_complex(0,1)*M_PI*pow(u,2) * (
          + 3.0/8*GHPLs1[2]
          - 3.0/8*GHPLs1[3]
          + 3.0/8*GHPLs1[0]
          - 3.0/8*GHPLs1[1]
          - 3.0/8*HPLs1[0]
          - 3.0/8*HPLs1[1]
          )

       + C_F*NF*pow(u,-2) * (
          + 1.0/3*GHPLs2[2*4+2]*HPLs1[0]
          + 1.0/3*GHPLs1[2]*zeta2
          - 19.0/18*GHPLs1[2]*HPLs1[0]
          - 2.0/3*GHPLs1[2]*HPLs2[0*2+0]
          - 1.0/3*GHPLs1[2]*HPLs2[1*2+0]
          + 1.0/3*GHPLs3[2*4*4+2*4+1]
          - 19.0/18*GHPLs2[2*4+1]
          - 1.0/3*GHPLs2[2*4+1]*HPLs1[0]
          - 1.0/3*GHPLs2[2*4+1]*HPLs1[1]
          + 1.0/3*GHPLs1[1]*zeta2
          + 19.0/18*GHPLs1[1]*HPLs1[0]
          + 2.0/3*GHPLs1[1]*HPLs2[0*2+0]
          + 2.0/3*GHPLs1[1]*HPLs2[1*2+0]
          + 19.0/18*GHPLs1[1]*HPLs1[1]
          + 1.0/3*GHPLs1[1]*HPLs2[0*2+1]
          + 1.0/3*GHPLs1[1]*HPLs2[1*2+1]
          + 1.0/3*GHPLs3[2*4*4+1*4+1]
          - 1.0/3*GHPLs2[1*4+1]*HPLs1[0]
          - 1.0/3*GHPLs2[1*4+1]*HPLs1[1]
          )

       + C_F*NF*pow(u,-2)*v * (
          - 2.0/3*GHPLs2[2*4+2]*HPLs1[0]
          - 2.0/3*GHPLs1[2]*zeta2
          + 19.0/9*GHPLs1[2]*HPLs1[0]
          + 4.0/3*GHPLs1[2]*HPLs2[0*2+0]
          + 2.0/3*GHPLs1[2]*HPLs2[1*2+0]
          - 2.0/3*GHPLs3[2*4*4+2*4+1]
          + 19.0/9*GHPLs2[2*4+1]
          + 2.0/3*GHPLs2[2*4+1]*HPLs1[0]
          + 2.0/3*GHPLs2[2*4+1]*HPLs1[1]
          - 2.0/3*GHPLs1[1]*zeta2
          - 19.0/9*GHPLs1[1]*HPLs1[0]
          - 4.0/3*GHPLs1[1]*HPLs2[0*2+0]
          - 4.0/3*GHPLs1[1]*HPLs2[1*2+0]
          - 19.0/9*GHPLs1[1]*HPLs1[1]
          - 2.0/3*GHPLs1[1]*HPLs2[0*2+1]
          - 2.0/3*GHPLs1[1]*HPLs2[1*2+1]
          - 2.0/3*GHPLs3[2*4*4+1*4+1]
          + 2.0/3*GHPLs2[1*4+1]*HPLs1[0]
          + 2.0/3*GHPLs2[1*4+1]*HPLs1[1]
          )

       + C_F*NF*pow(u,-2)*pow(v,2) * (
          + 1.0/3*GHPLs2[2*4+2]*HPLs1[0]
          + 1.0/3*GHPLs1[2]*zeta2
          - 19.0/18*GHPLs1[2]*HPLs1[0]
          - 2.0/3*GHPLs1[2]*HPLs2[0*2+0]
          - 1.0/3*GHPLs1[2]*HPLs2[1*2+0]
          + 1.0/3*GHPLs3[2*4*4+2*4+1]
          - 19.0/18*GHPLs2[2*4+1]
          - 1.0/3*GHPLs2[2*4+1]*HPLs1[0]
          - 1.0/3*GHPLs2[2*4+1]*HPLs1[1]
          + 1.0/3*GHPLs1[1]*zeta2
          + 19.0/18*GHPLs1[1]*HPLs1[0]
          + 2.0/3*GHPLs1[1]*HPLs2[0*2+0]
          + 2.0/3*GHPLs1[1]*HPLs2[1*2+0]
          + 19.0/18*GHPLs1[1]*HPLs1[1]
          + 1.0/3*GHPLs1[1]*HPLs2[0*2+1]
          + 1.0/3*GHPLs1[1]*HPLs2[1*2+1]
          + 1.0/3*GHPLs3[2*4*4+1*4+1]
          - 1.0/3*GHPLs2[1*4+1]*HPLs1[0]
          - 1.0/3*GHPLs2[1*4+1]*HPLs1[1]
          )

       + C_F*NF*pow(u,-1) * (
          + 2.0/3*zeta2
          + 1.0/3*GHPLs2[2*4+2]
          - 19.0/18*GHPLs1[2]
          - 1.0/3*GHPLs1[2]*HPLs1[1]
          + 1.0/3*GHPLs2[2*4+1]
          - 1.0/3*GHPLs1[1]*HPLs1[0]
          - 1.0/3*GHPLs1[1]*HPLs1[1]
          + 1.0/3*HPLs2[1*2+0]
          + 19.0/18*HPLs1[1]
          + 1.0/3*HPLs2[0*2+1]
          + 1.0/3*HPLs2[1*2+1]
          )

       + C_F*NF*pow(u,-1)*v * (
          - zeta2
          - 2.0/3*GHPLs2[2*4+2]
          + 19.0/9*GHPLs1[2]
          + 1.0/3*GHPLs1[2]*HPLs1[0]
          + 2.0/3*GHPLs1[2]*HPLs1[1]
          - 2.0/3*GHPLs2[2*4+1]
          + 2.0/3*GHPLs1[1]*HPLs1[0]
          + 2.0/3*GHPLs1[1]*HPLs1[1]
          - 19.0/18*HPLs1[0]
          - 2.0/3*HPLs2[0*2+0]
          - HPLs2[1*2+0]
          - 19.0/9*HPLs1[1]
          - 2.0/3*HPLs2[0*2+1]
          - 2.0/3*HPLs2[1*2+1]
          )

       + C_F*NF*pow(u,-1)*pow(v,2) * (
          + 1.0/3*zeta2
          + 1.0/3*GHPLs2[2*4+2]
          - 19.0/18*GHPLs1[2]
          - 1.0/3*GHPLs1[2]*HPLs1[0]
          - 1.0/3*GHPLs1[2]*HPLs1[1]
          + 1.0/3*GHPLs2[2*4+1]
          - 1.0/3*GHPLs1[1]*HPLs1[0]
          - 1.0/3*GHPLs1[1]*HPLs1[1]
          + 19.0/18*HPLs1[0]
          + 2.0/3*HPLs2[0*2+0]
          + 2.0/3*HPLs2[1*2+0]
          + 19.0/18*HPLs1[1]
          + 1.0/3*HPLs2[0*2+1]
          + 1.0/3*HPLs2[1*2+1]
          )

       + C_F*NF * (
          + 3401.0/1296
          + 11.0/12*zeta2
          - 1.0/36*zeta3
          + 1.0/6*GHPLs2[2*4+2]
          - 7.0/36*GHPLs1[2]
          - 1.0/6*GHPLs1[2]*HPLs1[1]
          + 1.0/6*GHPLs2[2*4+1]
          - 1.0/6*GHPLs1[1]*HPLs1[0]
          - 1.0/6*GHPLs1[1]*HPLs1[1]
          + 101.0/108*HPLs1[0]
          + 1.0/4*HPLs1[0]*zeta2
          + 1.0/6*HPLs2[1*2+0]
          + 7.0/36*HPLs1[1]
          + 1.0/6*HPLs2[0*2+1]
          + 1.0/6*HPLs2[1*2+1]
          )

       + C_F*NF*v*pow(1-u,-1) * (
          + 19.0/36
          - 1.0/3*zeta2
          - 1.0/3*GHPLs2[2*4+2]
          + 5.0/9*GHPLs1[2]
          + 1.0/3*GHPLs1[2]*HPLs1[0]
          + 1.0/3*GHPLs1[2]*HPLs1[1]
          - 1.0/3*GHPLs2[2*4+1]
          + 1.0/3*GHPLs1[1]*HPLs1[0]
          + 1.0/3*GHPLs1[1]*HPLs1[1]
          - 5.0/9*HPLs1[0]
          - 2.0/3*HPLs2[0*2+0]
          - 2.0/3*HPLs2[1*2+0]
          - 5.0/9*HPLs1[1]
          - 1.0/3*HPLs2[0*2+1]
          - 1.0/3*HPLs2[1*2+1]
          )

       + C_F*NF*pow(v,2)*pow(1-u,-2) * (
          - 1.0/6*zeta2
          - 1.0/6*GHPLs2[2*4+2]
          + 25.0/36*GHPLs1[2]
          + 1.0/6*GHPLs1[2]*HPLs1[0]
          + 1.0/6*GHPLs1[2]*HPLs1[1]
          - 1.0/6*GHPLs2[2*4+1]
          + 1.0/6*GHPLs1[1]*HPLs1[0]
          + 1.0/6*GHPLs1[1]*HPLs1[1]
          - 25.0/36*HPLs1[0]
          - 1.0/3*HPLs2[0*2+0]
          - 1.0/3*HPLs2[1*2+0]
          - 25.0/36*HPLs1[1]
          - 1.0/6*HPLs2[0*2+1]
          - 1.0/6*HPLs2[1*2+1]
          )

       + C_F*NF*pow(v,2)*pow(1-u,-1) * (
          + 1.0/3*zeta2
          + 1.0/3*GHPLs2[2*4+2]
          - 19.0/18*GHPLs1[2]
          - 1.0/3*GHPLs1[2]*HPLs1[0]
          - 1.0/3*GHPLs1[2]*HPLs1[1]
          + 1.0/3*GHPLs2[2*4+1]
          - 1.0/3*GHPLs1[1]*HPLs1[0]
          - 1.0/3*GHPLs1[1]*HPLs1[1]
          + 19.0/18*HPLs1[0]
          + 2.0/3*HPLs2[0*2+0]
          + 2.0/3*HPLs2[1*2+0]
          + 19.0/18*HPLs1[1]
          + 1.0/3*HPLs2[0*2+1]
          + 1.0/3*HPLs2[1*2+1]
          )

       + C_F*NF*double_complex(0,1)*M_PI*pow(u,-2) * (
          - 19.0/18*GHPLs1[1]
          - 1.0/3*GHPLs1[1]*HPLs1[0]
          + 1.0/3*GHPLs2[1*4+1]
          )

       + C_F*NF*double_complex(0,1)*M_PI*pow(u,-2)*v * (
          + 19.0/9*GHPLs1[1]
          + 2.0/3*GHPLs1[1]*HPLs1[0]
          - 2.0/3*GHPLs2[1*4+1]
          )

       + C_F*NF*double_complex(0,1)*M_PI*pow(u,-2)*pow(v,2) * (
          - 19.0/18*GHPLs1[1]
          - 1.0/3*GHPLs1[1]*HPLs1[0]
          + 1.0/3*GHPLs2[1*4+1]
          )

       + C_F*NF*double_complex(0,1)*M_PI*pow(u,-1) * (
          - 19.0/18
          + 1.0/3*GHPLs1[1]
          - 1.0/3*HPLs1[0]
          )

       + C_F*NF*double_complex(0,1)*M_PI*pow(u,-1)*v * (
          + 19.0/9
          - 2.0/3*GHPLs1[1]
          + 2.0/3*HPLs1[0]
          )

       + C_F*NF*double_complex(0,1)*M_PI*pow(u,-1)*pow(v,2) * (
          - 19.0/18
          + 1.0/3*GHPLs1[1]
          - 1.0/3*HPLs1[0]
          )

       + C_F*NF*double_complex(0,1)*M_PI * (
          + 20.0/27
          + 1.0/4*zeta2
          + 1.0/6*GHPLs1[1]
          - 1.0/6*HPLs1[0]
          )

       + C_F*NF*double_complex(0,1)*M_PI*v*pow(1-u,-1) * (
          + 13.0/18
          - 1.0/3*GHPLs1[1]
          + 1.0/3*HPLs1[0]
          )

       + C_F*NF*double_complex(0,1)*M_PI*pow(v,2)*pow(1-u,-2) * (
          + 25.0/36
          - 1.0/6*GHPLs1[1]
          + 1.0/6*HPLs1[0]
          )

       + C_F*NF*double_complex(0,1)*M_PI*pow(v,2)*pow(1-u,-1) * (
          - 19.0/18
          + 1.0/3*GHPLs1[1]
          - 1.0/3*HPLs1[0]
          );
}

void alpha_2_3(double u, double v, int n_f, double *GHPLs1, double *GHPLs2, double *GHPLs3, double *GHPLs4, double *HPLs1, double *HPLs2, double *HPLs3, double *HPLs4, double_complex &alpha) {
  //  const double zeta2 = M_PI*M_PI/6;
  //  const double zeta3 = 1.20205690315959429;
  //  const double zeta4 = pow(M_PI,4)/90;
  //  const double dN_c=3;
  //  const double CF=(dN_c*dN_c-1)/(2*dN_c);
  double NF=(double)n_f;

  alpha =
    (dN_c*dN_c-1) * (
          - 81659.0/10368
          + 49.0/32*zeta4
          - 5.0/12*zeta2
          + 389.0/144*zeta3
          - 2759.0/864*HPLs1[0]
          - 11.0/16*HPLs1[0]*zeta2
          + 7.0/4*HPLs1[0]*zeta3
          )

       + (dN_c*dN_c-1)*u*pow(1-v,-1) * (
          + 81659.0/10368
          - 49.0/32*zeta4
          + 5.0/12*zeta2
          - 389.0/144*zeta3
          + 2759.0/864*HPLs1[0]
          + 11.0/16*HPLs1[0]*zeta2
          - 7.0/4*HPLs1[0]*zeta3
          )

       + (dN_c*dN_c-1)*double_complex(0,1)*M_PI * (
          - 2759.0/864
          - 11.0/16*zeta2
          + 7.0/4*zeta3
          )

       + (dN_c*dN_c-1)*double_complex(0,1)*M_PI*u*pow(1-v,-1) * (
          + 2759.0/864
          + 11.0/16*zeta2
          - 7.0/4*zeta3
          )

       + (dN_c*dN_c-1)/(dN_c*dN_c) * (
          - 255.0/128
          + 11.0/8*zeta4
          - 29.0/16*zeta2
          + 15.0/8*zeta3
          + 3.0/32*HPLs1[0]
          - 3.0/4*HPLs1[0]*zeta2
          + 3.0/2*HPLs1[0]*zeta3
          )

       + (dN_c*dN_c-1)/(dN_c*dN_c)*u*pow(1-v,-1) * (
          + 255.0/128
          - 11.0/8*zeta4
          + 29.0/16*zeta2
          - 15.0/8*zeta3
          - 3.0/32*HPLs1[0]
          + 3.0/4*HPLs1[0]*zeta2
          - 3.0/2*HPLs1[0]*zeta3
          )

       + (dN_c*dN_c-1)/(dN_c*dN_c)*double_complex(0,1)*M_PI * (
          + 3.0/32
          - 3.0/4*zeta2
          + 3.0/2*zeta3
          )

       + (dN_c*dN_c-1)/(dN_c*dN_c)*double_complex(0,1)*M_PI*u*pow(1-v,-1) * (
          - 3.0/32
          + 3.0/4*zeta2
          - 3.0/2*zeta3
          )

       + C_F*NF * (
          + 4085.0/1296
          + 7.0/12*zeta2
          - 1.0/36*zeta3
          + 119.0/108*HPLs1[0]
          + 1.0/4*HPLs1[0]*zeta2
          )

       + C_F*NF*u*pow(1-v,-1) * (
          - 4085.0/1296
          - 7.0/12*zeta2
          + 1.0/36*zeta3
          - 119.0/108*HPLs1[0]
          - 1.0/4*HPLs1[0]*zeta2
          )

       + C_F*NF*double_complex(0,1)*M_PI * (
          + 119.0/108
          + 1.0/4*zeta2
          )

       + C_F*NF*double_complex(0,1)*M_PI*u*pow(1-v,-1) * (
          - 119.0/108
          - 1.0/4*zeta2
          );
}

void alpha_2_4(double u, double v, int n_f, double *GHPLs1, double *GHPLs2, double *GHPLs3, double *GHPLs4, double *HPLs1, double *HPLs2, double *HPLs3, double *HPLs4, double_complex &alpha) {
  //  const double zeta2 = M_PI*M_PI/6;
  //  const double zeta3 = 1.20205690315959429;
  //  const double zeta4 = pow(M_PI,4)/90;
  //  const double dN_c=3;
  //  const double CF=(dN_c*dN_c-1)/(2*dN_c);
  double NF=(double)n_f;

  alpha =
    C_F*pow(u,-2) * (
          + 4*GHPLs3[3*4*4+2*4+2]*HPLs1[0]
          - 4*GHPLs4[0*4*4*4+3*4*4+2*4+2]
          - 4*GHPLs2[2*4+2]*zeta2
          + 4*GHPLs2[2*4+2]*HPLs2[0*2+0]
          - 4*GHPLs2[2*4+2]*HPLs2[0*2+1]
          - 4*GHPLs3[0*4*4+2*4+2]*HPLs1[0]
          + 2.0/3*GHPLs1[2]*zeta2
          - 4*GHPLs1[2]*zeta3
          + GHPLs1[2]*HPLs1[0]
          - 4*GHPLs1[2]*HPLs1[0]*zeta2
          - 2.0/3*GHPLs1[2]*HPLs2[0*2+0]
          + 4*GHPLs1[2]*HPLs3[0*2*2+0*2+0]
          - 2.0/3*GHPLs1[2]*HPLs2[1*2+0]
          - 4*GHPLs1[2]*HPLs3[0*2*2+1*2+0]
          - 4*GHPLs1[2]*HPLs3[0*2*2+0*2+1]
          - 4*GHPLs3[3*4*4+0*4+2]*HPLs1[0]
          + 4*GHPLs4[0*4*4*4+3*4*4+0*4+2]
          - 2.0/3*GHPLs2[0*4+2]*HPLs1[0]
          - 4*GHPLs2[0*4+2]*HPLs2[0*2+0]
          - 2.0/3*GHPLs3[2*4*4+1*4+2]
          + 2.0/3*GHPLs2[1*4+2]*HPLs1[0]
          + 2.0/3*GHPLs2[1*4+2]*HPLs1[1]
          + 4*GHPLs3[3*4*4+2*4+1]*HPLs1[0]
          - 4*GHPLs4[0*4*4*4+3*4*4+2*4+1]
          + GHPLs2[2*4+1]
          - 4*GHPLs2[2*4+1]*zeta2
          + 4*GHPLs2[2*4+1]*HPLs2[0*2+0]
          - 4*GHPLs2[2*4+1]*HPLs2[0*2+1]
          - 2.0/3*GHPLs3[0*4*4+2*4+1]
          - 4*GHPLs3[0*4*4+2*4+1]*HPLs1[0]
          + 8.0/3*GHPLs1[1]*zeta2
          - 4*GHPLs1[1]*zeta3
          - GHPLs1[1]*HPLs1[0]
          + 4*GHPLs1[1]*HPLs1[0]*zeta2
          + 2.0/3*GHPLs1[1]*HPLs2[0*2+0]
          - 4*GHPLs1[1]*HPLs3[0*2*2+0*2+0]
          + 2.0/3*GHPLs1[1]*HPLs2[1*2+0]
          + 4*GHPLs1[1]*HPLs3[0*2*2+1*2+0]
          - GHPLs1[1]*HPLs1[1]
          + 4*GHPLs1[1]*HPLs1[1]*zeta2
          - 4*GHPLs1[1]*HPLs3[0*2*2+0*2+1]
          + 4*GHPLs1[1]*HPLs3[0*2*2+1*2+1]
          - 2.0/3*GHPLs3[2*4*4+0*4+1]
          + 4*GHPLs3[3*4*4+0*4+1]*HPLs1[0]
          - 4*GHPLs4[0*4*4*4+3*4*4+0*4+1]
          + 8*GHPLs2[0*4+1]*zeta2
          + 2.0/3*GHPLs2[0*4+1]*HPLs1[0]
          + 4*GHPLs2[0*4+1]*HPLs2[0*2+0]
          + 2.0/3*GHPLs2[0*4+1]*HPLs1[1]
          + 4*GHPLs2[0*4+1]*HPLs2[0*2+1]
          + 2.0/3*GHPLs3[2*4*4+1*4+1]
          - 2.0/3*GHPLs2[1*4+1]*HPLs1[0]
          - 2.0/3*GHPLs2[1*4+1]*HPLs1[1]
          )

       + C_F*pow(u,-2)*v * (
          - 8*GHPLs3[3*4*4+2*4+2]*HPLs1[0]
          + 8*GHPLs4[0*4*4*4+3*4*4+2*4+2]
          + 8*GHPLs2[2*4+2]*zeta2
          - 8*GHPLs2[2*4+2]*HPLs2[0*2+0]
          + 8*GHPLs2[2*4+2]*HPLs2[0*2+1]
          + 8*GHPLs3[0*4*4+2*4+2]*HPLs1[0]
          - 4.0/3*GHPLs1[2]*zeta2
          + 8*GHPLs1[2]*zeta3
          - 5.0/3*GHPLs1[2]*HPLs1[0]
          + 8*GHPLs1[2]*HPLs1[0]*zeta2
          + 4.0/3*GHPLs1[2]*HPLs2[0*2+0]
          - 8*GHPLs1[2]*HPLs3[0*2*2+0*2+0]
          + 4.0/3*GHPLs1[2]*HPLs2[1*2+0]
          + 8*GHPLs1[2]*HPLs3[0*2*2+1*2+0]
          + 8*GHPLs1[2]*HPLs3[0*2*2+0*2+1]
          + 8*GHPLs3[3*4*4+0*4+2]*HPLs1[0]
          - 8*GHPLs4[0*4*4*4+3*4*4+0*4+2]
          + 4.0/3*GHPLs2[0*4+2]*HPLs1[0]
          + 8*GHPLs2[0*4+2]*HPLs2[0*2+0]
          + 4.0/3*GHPLs3[2*4*4+1*4+2]
          - 4.0/3*GHPLs2[1*4+2]*HPLs1[0]
          - 4.0/3*GHPLs2[1*4+2]*HPLs1[1]
          - 8*GHPLs3[3*4*4+2*4+1]*HPLs1[0]
          + 8*GHPLs4[0*4*4*4+3*4*4+2*4+1]
          - 5.0/3*GHPLs2[2*4+1]
          + 8*GHPLs2[2*4+1]*zeta2
          - 8*GHPLs2[2*4+1]*HPLs2[0*2+0]
          + 8*GHPLs2[2*4+1]*HPLs2[0*2+1]
          + 4.0/3*GHPLs3[0*4*4+2*4+1]
          + 8*GHPLs3[0*4*4+2*4+1]*HPLs1[0]
          - 16.0/3*GHPLs1[1]*zeta2
          + 8*GHPLs1[1]*zeta3
          + 5.0/3*GHPLs1[1]*HPLs1[0]
          - 8*GHPLs1[1]*HPLs1[0]*zeta2
          - 4.0/3*GHPLs1[1]*HPLs2[0*2+0]
          + 8*GHPLs1[1]*HPLs3[0*2*2+0*2+0]
          - 4.0/3*GHPLs1[1]*HPLs2[1*2+0]
          - 8*GHPLs1[1]*HPLs3[0*2*2+1*2+0]
          + 5.0/3*GHPLs1[1]*HPLs1[1]
          - 8*GHPLs1[1]*HPLs1[1]*zeta2
          + 8*GHPLs1[1]*HPLs3[0*2*2+0*2+1]
          - 8*GHPLs1[1]*HPLs3[0*2*2+1*2+1]
          + 4.0/3*GHPLs3[2*4*4+0*4+1]
          - 8*GHPLs3[3*4*4+0*4+1]*HPLs1[0]
          + 8*GHPLs4[0*4*4*4+3*4*4+0*4+1]
          - 16*GHPLs2[0*4+1]*zeta2
          - 4.0/3*GHPLs2[0*4+1]*HPLs1[0]
          - 8*GHPLs2[0*4+1]*HPLs2[0*2+0]
          - 4.0/3*GHPLs2[0*4+1]*HPLs1[1]
          - 8*GHPLs2[0*4+1]*HPLs2[0*2+1]
          - 4.0/3*GHPLs3[2*4*4+1*4+1]
          + 4.0/3*GHPLs2[1*4+1]*HPLs1[0]
          + 4.0/3*GHPLs2[1*4+1]*HPLs1[1]
          )

       + C_F*pow(u,-2)*pow(v,2) * (
          + 4*GHPLs3[3*4*4+2*4+2]*HPLs1[0]
          - 4*GHPLs4[0*4*4*4+3*4*4+2*4+2]
          - 4*GHPLs2[2*4+2]*zeta2
          + 4*GHPLs2[2*4+2]*HPLs2[0*2+0]
          - 4*GHPLs2[2*4+2]*HPLs2[0*2+1]
          - 4*GHPLs3[0*4*4+2*4+2]*HPLs1[0]
          + 2.0/3*GHPLs1[2]*zeta2
          - 4*GHPLs1[2]*zeta3
          + GHPLs1[2]*HPLs1[0]
          - 4*GHPLs1[2]*HPLs1[0]*zeta2
          - 2.0/3*GHPLs1[2]*HPLs2[0*2+0]
          + 4*GHPLs1[2]*HPLs3[0*2*2+0*2+0]
          - 2.0/3*GHPLs1[2]*HPLs2[1*2+0]
          - 4*GHPLs1[2]*HPLs3[0*2*2+1*2+0]
          - 4*GHPLs1[2]*HPLs3[0*2*2+0*2+1]
          - 4*GHPLs3[3*4*4+0*4+2]*HPLs1[0]
          + 4*GHPLs4[0*4*4*4+3*4*4+0*4+2]
          - 2.0/3*GHPLs2[0*4+2]*HPLs1[0]
          - 4*GHPLs2[0*4+2]*HPLs2[0*2+0]
          - 2.0/3*GHPLs3[2*4*4+1*4+2]
          + 2.0/3*GHPLs2[1*4+2]*HPLs1[0]
          + 2.0/3*GHPLs2[1*4+2]*HPLs1[1]
          + 4*GHPLs3[3*4*4+2*4+1]*HPLs1[0]
          - 4*GHPLs4[0*4*4*4+3*4*4+2*4+1]
          + GHPLs2[2*4+1]
          - 4*GHPLs2[2*4+1]*zeta2
          + 4*GHPLs2[2*4+1]*HPLs2[0*2+0]
          - 4*GHPLs2[2*4+1]*HPLs2[0*2+1]
          - 2.0/3*GHPLs3[0*4*4+2*4+1]
          - 4*GHPLs3[0*4*4+2*4+1]*HPLs1[0]
          + 8.0/3*GHPLs1[1]*zeta2
          - 4*GHPLs1[1]*zeta3
          - GHPLs1[1]*HPLs1[0]
          + 4*GHPLs1[1]*HPLs1[0]*zeta2
          + 2.0/3*GHPLs1[1]*HPLs2[0*2+0]
          - 4*GHPLs1[1]*HPLs3[0*2*2+0*2+0]
          + 2.0/3*GHPLs1[1]*HPLs2[1*2+0]
          + 4*GHPLs1[1]*HPLs3[0*2*2+1*2+0]
          - GHPLs1[1]*HPLs1[1]
          + 4*GHPLs1[1]*HPLs1[1]*zeta2
          - 4*GHPLs1[1]*HPLs3[0*2*2+0*2+1]
          + 4*GHPLs1[1]*HPLs3[0*2*2+1*2+1]
          - 2.0/3*GHPLs3[2*4*4+0*4+1]
          + 4*GHPLs3[3*4*4+0*4+1]*HPLs1[0]
          - 4*GHPLs4[0*4*4*4+3*4*4+0*4+1]
          + 8*GHPLs2[0*4+1]*zeta2
          + 2.0/3*GHPLs2[0*4+1]*HPLs1[0]
          + 4*GHPLs2[0*4+1]*HPLs2[0*2+0]
          + 2.0/3*GHPLs2[0*4+1]*HPLs1[1]
          + 4*GHPLs2[0*4+1]*HPLs2[0*2+1]
          + 2.0/3*GHPLs3[2*4*4+1*4+1]
          - 2.0/3*GHPLs2[1*4+1]*HPLs1[0]
          - 2.0/3*GHPLs2[1*4+1]*HPLs1[1]
          )

       + C_F*pow(u,-2)*pow(v,3) * (
          - 2.0/3*GHPLs1[2]*zeta2
          - GHPLs1[2]*HPLs1[0]
          - 2.0/3*GHPLs1[2]*HPLs2[0*2+0]
          + 2.0/3*GHPLs1[2]*HPLs2[1*2+0]
          + 2.0/3*GHPLs2[0*4+2]*HPLs1[0]
          + 2.0/3*GHPLs3[2*4*4+1*4+2]
          - 2.0/3*GHPLs2[1*4+2]*HPLs1[0]
          - 2.0/3*GHPLs2[1*4+2]*HPLs1[1]
          + 2.0/3*GHPLs2[2*4+3]*HPLs1[0]
          - 2.0/3*GHPLs3[0*4*4+2*4+3]
          - 2.0/3*GHPLs2[3*4+3]*HPLs1[0]
          + 2.0/3*GHPLs3[0*4*4+3*4+3]
          + 10.0/3*GHPLs1[3]*zeta2
          - 2.0/3*GHPLs1[3]*HPLs2[1*2+0]
          - 2.0/3*GHPLs1[3]*HPLs2[0*2+1]
          - 2.0/3*GHPLs3[2*4*4+0*4+3]
          + 2.0/3*GHPLs2[0*4+3]*HPLs1[1]
          - GHPLs2[2*4+1]
          + GHPLs1[1]*HPLs1[0]
          + GHPLs1[1]*HPLs1[1]
          )

       + C_F*pow(u,-2)*pow(v,4) * (
          + 4.0/3*GHPLs1[2]*zeta2
          + 2.0/3*GHPLs1[2]*HPLs1[0]
          + 4.0/3*GHPLs1[2]*HPLs2[0*2+0]
          - 4.0/3*GHPLs1[2]*HPLs2[1*2+0]
          - 4.0/3*GHPLs2[0*4+2]*HPLs1[0]
          - 4.0/3*GHPLs3[2*4*4+1*4+2]
          + 4.0/3*GHPLs2[1*4+2]*HPLs1[0]
          + 4.0/3*GHPLs2[1*4+2]*HPLs1[1]
          - 4.0/3*GHPLs2[2*4+3]*HPLs1[0]
          + 4.0/3*GHPLs3[0*4*4+2*4+3]
          + 4.0/3*GHPLs2[3*4+3]*HPLs1[0]
          - 4.0/3*GHPLs3[0*4*4+3*4+3]
          - 20.0/3*GHPLs1[3]*zeta2
          + 4.0/3*GHPLs1[3]*HPLs2[1*2+0]
          + 4.0/3*GHPLs1[3]*HPLs2[0*2+1]
          + 4.0/3*GHPLs3[2*4*4+0*4+3]
          - 4.0/3*GHPLs2[0*4+3]*HPLs1[1]
          + 2.0/3*GHPLs2[2*4+1]
          - 2.0/3*GHPLs1[1]*HPLs1[0]
          - 2.0/3*GHPLs1[1]*HPLs1[1]
          )

       + C_F*pow(u,-2)*pow(v,5) * (
          - 2.0/3*GHPLs1[2]*zeta2
          - 2.0/3*GHPLs1[2]*HPLs2[0*2+0]
          + 2.0/3*GHPLs1[2]*HPLs2[1*2+0]
          + 2.0/3*GHPLs2[0*4+2]*HPLs1[0]
          + 2.0/3*GHPLs3[2*4*4+1*4+2]
          - 2.0/3*GHPLs2[1*4+2]*HPLs1[0]
          - 2.0/3*GHPLs2[1*4+2]*HPLs1[1]
          + 2.0/3*GHPLs2[2*4+3]*HPLs1[0]
          - 2.0/3*GHPLs3[0*4*4+2*4+3]
          - 2.0/3*GHPLs2[3*4+3]*HPLs1[0]
          + 2.0/3*GHPLs3[0*4*4+3*4+3]
          + 10.0/3*GHPLs1[3]*zeta2
          - 2.0/3*GHPLs1[3]*HPLs2[1*2+0]
          - 2.0/3*GHPLs1[3]*HPLs2[0*2+1]
          - 2.0/3*GHPLs3[2*4*4+0*4+3]
          + 2.0/3*GHPLs2[0*4+3]*HPLs1[1]
          )

       + C_F*pow(u,-1) * (
          - 14.0/3*zeta2
          - 8*zeta3
          - 6*GHPLs3[3*4*4+2*4+2]*HPLs1[0]
          + 6*GHPLs4[0*4*4*4+3*4*4+2*4+2]
          + 6*GHPLs2[2*4+2]*zeta2
          - 6*GHPLs2[2*4+2]*HPLs2[0*2+0]
          + 6*GHPLs2[2*4+2]*HPLs2[0*2+1]
          + 6*GHPLs3[0*4*4+2*4+2]*HPLs1[0]
          + 8*GHPLs2[3*4+2]*HPLs1[0]
          - 8*GHPLs3[0*4*4+3*4+2]
          + 5.0/3*GHPLs1[2]
          - 8*GHPLs1[2]*zeta2
          + 6*GHPLs1[2]*zeta3
          + GHPLs1[2]*HPLs1[0]
          + 6*GHPLs1[2]*HPLs1[0]*zeta2
          + 9*GHPLs1[2]*HPLs2[0*2+0]
          - 6*GHPLs1[2]*HPLs3[0*2*2+0*2+0]
          + GHPLs1[2]*HPLs2[1*2+0]
          + 6*GHPLs1[2]*HPLs3[0*2*2+1*2+0]
          - 7*GHPLs1[2]*HPLs2[0*2+1]
          + 6*GHPLs1[2]*HPLs3[0*2*2+0*2+1]
          + 6*GHPLs3[3*4*4+0*4+2]*HPLs1[0]
          - 6*GHPLs4[0*4*4*4+3*4*4+0*4+2]
          - 2.0/3*GHPLs2[0*4+2]
          - 6*GHPLs2[0*4+2]*HPLs1[0]
          + 6*GHPLs2[0*4+2]*HPLs2[0*2+0]
          + GHPLs3[2*4*4+1*4+2]
          - GHPLs2[1*4+2]*HPLs1[0]
          - GHPLs2[1*4+2]*HPLs1[1]
          - 2.0/3*GHPLs2[2*4+0]
          + 8*GHPLs1[0]*zeta2
          + 2.0/3*GHPLs1[0]*HPLs1[1]
          + 4*GHPLs1[0]*HPLs2[0*2+1]
          - 6*GHPLs3[3*4*4+2*4+1]*HPLs1[0]
          + 6*GHPLs4[0*4*4*4+3*4*4+2*4+1]
          + GHPLs2[2*4+1]
          + 6*GHPLs2[2*4+1]*zeta2
          - 6*GHPLs2[2*4+1]*HPLs2[0*2+0]
          + 6*GHPLs2[2*4+1]*HPLs2[0*2+1]
          + 2*GHPLs3[0*4*4+2*4+1]
          + 6*GHPLs3[0*4*4+2*4+1]*HPLs1[0]
          - 10*GHPLs1[1]*zeta2
          + 6*GHPLs1[1]*zeta3
          - GHPLs1[1]*HPLs1[0]
          - 6*GHPLs1[1]*HPLs1[0]*zeta2
          - GHPLs1[1]*HPLs2[0*2+0]
          + 6*GHPLs1[1]*HPLs3[0*2*2+0*2+0]
          - GHPLs1[1]*HPLs2[1*2+0]
          - 6*GHPLs1[1]*HPLs3[0*2*2+1*2+0]
          - GHPLs1[1]*HPLs1[1]
          - 6*GHPLs1[1]*HPLs1[1]*zeta2
          + 6*GHPLs1[1]*HPLs3[0*2*2+0*2+1]
          - 6*GHPLs1[1]*HPLs3[0*2*2+1*2+1]
          + 2*GHPLs3[2*4*4+0*4+1]
          - 6*GHPLs3[3*4*4+0*4+1]*HPLs1[0]
          + 6*GHPLs4[0*4*4*4+3*4*4+0*4+1]
          - 12*GHPLs2[0*4+1]*zeta2
          - 2*GHPLs2[0*4+1]*HPLs1[0]
          - 6*GHPLs2[0*4+1]*HPLs2[0*2+0]
          - 2*GHPLs2[0*4+1]*HPLs1[1]
          - 6*GHPLs2[0*4+1]*HPLs2[0*2+1]
          - GHPLs3[2*4*4+1*4+1]
          + GHPLs2[1*4+1]*HPLs1[0]
          + GHPLs2[1*4+1]*HPLs1[1]
          - 5.0/3*HPLs1[1]
          + 4*HPLs1[1]*zeta2
          - 4*HPLs2[0*2+1]
          - 8*HPLs3[0*2*2+0*2+1]
          + 4*HPLs3[0*2*2+1*2+1]
          )

       + C_F*pow(u,-1)*v * (
          + 10*zeta2
          + 12*zeta3
          + 6*GHPLs3[3*4*4+2*4+2]*HPLs1[0]
          - 6*GHPLs4[0*4*4*4+3*4*4+2*4+2]
          - 6*GHPLs2[2*4+2]*zeta2
          + 6*GHPLs2[2*4+2]*HPLs2[0*2+0]
          - 6*GHPLs2[2*4+2]*HPLs2[0*2+1]
          - 6*GHPLs3[0*4*4+2*4+2]*HPLs1[0]
          - 12*GHPLs2[3*4+2]*HPLs1[0]
          + 12*GHPLs3[0*4*4+3*4+2]
          - 3*GHPLs1[2]
          + 12*GHPLs1[2]*zeta2
          - 6*GHPLs1[2]*zeta3
          - 3.0/2*GHPLs1[2]*HPLs1[0]
          - 6*GHPLs1[2]*HPLs1[0]*zeta2
          - 13*GHPLs1[2]*HPLs2[0*2+0]
          + 6*GHPLs1[2]*HPLs3[0*2*2+0*2+0]
          - GHPLs1[2]*HPLs2[1*2+0]
          - 6*GHPLs1[2]*HPLs3[0*2*2+1*2+0]
          + 11*GHPLs1[2]*HPLs2[0*2+1]
          - 6*GHPLs1[2]*HPLs3[0*2*2+0*2+1]
          - 6*GHPLs3[3*4*4+0*4+2]*HPLs1[0]
          + 6*GHPLs4[0*4*4*4+3*4*4+0*4+2]
          + 4.0/3*GHPLs2[0*4+2]
          + 10*GHPLs2[0*4+2]*HPLs1[0]
          - 6*GHPLs2[0*4+2]*HPLs2[0*2+0]
          - GHPLs3[2*4*4+1*4+2]
          + GHPLs2[1*4+2]*HPLs1[0]
          + GHPLs2[1*4+2]*HPLs1[1]
          + 4*GHPLs1[3]*HPLs1[0]
          - 4*GHPLs2[0*4+3]
          + 4.0/3*GHPLs2[2*4+0]
          - 4*GHPLs2[3*4+0]*HPLs1[0]
          + 4*GHPLs3[0*4*4+3*4+0]
          - 16*GHPLs1[0]*zeta2
          - 2.0/3*GHPLs1[0]*HPLs1[0]
          - 4*GHPLs1[0]*HPLs2[0*2+0]
          - 4.0/3*GHPLs1[0]*HPLs1[1]
          - 8*GHPLs1[0]*HPLs2[0*2+1]
          + 6*GHPLs3[3*4*4+2*4+1]*HPLs1[0]
          - 6*GHPLs4[0*4*4*4+3*4*4+2*4+1]
          - 13.0/6*GHPLs2[2*4+1]
          - 6*GHPLs2[2*4+1]*zeta2
          + 6*GHPLs2[2*4+1]*HPLs2[0*2+0]
          - 6*GHPLs2[2*4+1]*HPLs2[0*2+1]
          - 2*GHPLs3[0*4*4+2*4+1]
          - 6*GHPLs3[0*4*4+2*4+1]*HPLs1[0]
          + 10*GHPLs1[1]*zeta2
          - 6*GHPLs1[1]*zeta3
          + 13.0/6*GHPLs1[1]*HPLs1[0]
          + 6*GHPLs1[1]*HPLs1[0]*zeta2
          + GHPLs1[1]*HPLs2[0*2+0]
          - 6*GHPLs1[1]*HPLs3[0*2*2+0*2+0]
          + GHPLs1[1]*HPLs2[1*2+0]
          + 6*GHPLs1[1]*HPLs3[0*2*2+1*2+0]
          + 13.0/6*GHPLs1[1]*HPLs1[1]
          + 6*GHPLs1[1]*HPLs1[1]*zeta2
          - 6*GHPLs1[1]*HPLs3[0*2*2+0*2+1]
          + 6*GHPLs1[1]*HPLs3[0*2*2+1*2+1]
          - 2*GHPLs3[2*4*4+0*4+1]
          + 6*GHPLs3[3*4*4+0*4+1]*HPLs1[0]
          - 6*GHPLs4[0*4*4*4+3*4*4+0*4+1]
          + 12*GHPLs2[0*4+1]*zeta2
          + 2*GHPLs2[0*4+1]*HPLs1[0]
          + 6*GHPLs2[0*4+1]*HPLs2[0*2+0]
          + 2*GHPLs2[0*4+1]*HPLs1[1]
          + 6*GHPLs2[0*4+1]*HPLs2[0*2+1]
          + GHPLs3[2*4*4+1*4+1]
          - GHPLs2[1*4+1]*HPLs1[0]
          - GHPLs2[1*4+1]*HPLs1[1]
          + 5.0/3*HPLs1[0]
          - 4*HPLs1[0]*zeta2
          + 10.0/3*HPLs2[0*2+0]
          + 4*HPLs3[0*2*2+0*2+0]
          - 2.0/3*HPLs2[1*2+0]
          - 4*HPLs3[0*2*2+1*2+0]
          + 3*HPLs1[1]
          - 8*HPLs1[1]*zeta2
          + 8*HPLs2[0*2+1]
          + 12*HPLs3[0*2*2+0*2+1]
          - 8*HPLs3[0*2*2+1*2+1]
          )

       + C_F*pow(u,-1)*pow(v,2) * (
          - 26.0/3*zeta2
          - 4*zeta3
          + 4*GHPLs2[3*4+2]*HPLs1[0]
          - 4*GHPLs3[0*4*4+3*4+2]
          + GHPLs1[2]
          - 5*GHPLs1[2]*zeta2
          - 13.0/6*GHPLs1[2]*HPLs1[0]
          + 3*GHPLs1[2]*HPLs2[0*2+0]
          + GHPLs1[2]*HPLs2[1*2+0]
          - 4*GHPLs1[2]*HPLs2[0*2+1]
          - 3*GHPLs2[0*4+2]*HPLs1[0]
          + GHPLs3[2*4*4+1*4+2]
          - GHPLs2[1*4+2]*HPLs1[0]
          - GHPLs2[1*4+2]*HPLs1[1]
          + GHPLs2[2*4+3]*HPLs1[0]
          - GHPLs3[0*4*4+2*4+3]
          - GHPLs2[3*4+3]*HPLs1[0]
          + GHPLs3[0*4*4+3*4+3]
          + 5*GHPLs1[3]*zeta2
          - 10.0/3*GHPLs1[3]*HPLs1[0]
          - GHPLs1[3]*HPLs2[1*2+0]
          - GHPLs1[3]*HPLs2[0*2+1]
          - GHPLs3[2*4*4+0*4+3]
          + 10.0/3*GHPLs2[0*4+3]
          + GHPLs2[0*4+3]*HPLs1[1]
          + 4*GHPLs2[3*4+0]*HPLs1[0]
          - 4*GHPLs3[0*4*4+3*4+0]
          + 8*GHPLs1[0]*zeta2
          + 2.0/3*GHPLs1[0]*HPLs1[0]
          + 4*GHPLs1[0]*HPLs2[0*2+0]
          + 4*GHPLs1[0]*HPLs2[0*2+1]
          - 5.0/6*GHPLs2[2*4+1]
          + 5.0/6*GHPLs1[1]*HPLs1[0]
          + 5.0/6*GHPLs1[1]*HPLs1[1]
          - 4.0/3*HPLs1[0]
          + 4*HPLs1[0]*zeta2
          - 10.0/3*HPLs2[0*2+0]
          - 4*HPLs3[0*2*2+0*2+0]
          + 4.0/3*HPLs2[1*2+0]
          + 4*HPLs3[0*2*2+1*2+0]
          - HPLs1[1]
          + 4*HPLs1[1]*zeta2
          - 10.0/3*HPLs2[0*2+1]
          - 4*HPLs3[0*2*2+0*2+1]
          + 4*HPLs3[0*2*2+1*2+1]
          )

       + C_F*pow(u,-1)*pow(v,3) * (
          + 6*zeta2
          + 1.0/3*GHPLs1[2]
          + 3*GHPLs1[2]*zeta2
          + 10.0/3*GHPLs1[2]*HPLs1[0]
          + 3*GHPLs1[2]*HPLs2[0*2+0]
          - 3*GHPLs1[2]*HPLs2[1*2+0]
          - 4.0/3*GHPLs2[0*4+2]
          - 3*GHPLs2[0*4+2]*HPLs1[0]
          - 3*GHPLs3[2*4*4+1*4+2]
          + 3*GHPLs2[1*4+2]*HPLs1[0]
          + 3*GHPLs2[1*4+2]*HPLs1[1]
          - 3*GHPLs2[2*4+3]*HPLs1[0]
          + 3*GHPLs3[0*4*4+2*4+3]
          + 3*GHPLs2[3*4+3]*HPLs1[0]
          - 3*GHPLs3[0*4*4+3*4+3]
          - 15*GHPLs1[3]*zeta2
          - 4.0/3*GHPLs1[3]*HPLs1[0]
          + 3*GHPLs1[3]*HPLs2[1*2+0]
          + 3*GHPLs1[3]*HPLs2[0*2+1]
          + 3*GHPLs3[2*4*4+0*4+3]
          + 4.0/3*GHPLs2[0*4+3]
          - 3*GHPLs2[0*4+3]*HPLs1[1]
          - 4.0/3*GHPLs2[2*4+0]
          + 2.0/3*GHPLs1[0]*HPLs1[0]
          + 4.0/3*GHPLs1[0]*HPLs1[1]
          + 8.0/3*GHPLs2[2*4+1]
          - 8.0/3*GHPLs1[1]*HPLs1[0]
          - 8.0/3*GHPLs1[1]*HPLs1[1]
          - 1.0/3*HPLs1[0]
          - 2.0/3*HPLs2[0*2+0]
          - 2.0/3*HPLs2[1*2+0]
          - 1.0/3*HPLs1[1]
          - 4.0/3*HPLs2[0*2+1]
          )

       + C_F*pow(u,-1)*pow(v,4) * (
          - 8.0/3*zeta2
          - 2*GHPLs1[2]*zeta2
          - 2.0/3*GHPLs1[2]*HPLs1[0]
          - 2*GHPLs1[2]*HPLs2[0*2+0]
          + 2*GHPLs1[2]*HPLs2[1*2+0]
          + 2.0/3*GHPLs2[0*4+2]
          + 2*GHPLs2[0*4+2]*HPLs1[0]
          + 2*GHPLs3[2*4*4+1*4+2]
          - 2*GHPLs2[1*4+2]*HPLs1[0]
          - 2*GHPLs2[1*4+2]*HPLs1[1]
          + 2*GHPLs2[2*4+3]*HPLs1[0]
          - 2*GHPLs3[0*4*4+2*4+3]
          - 2*GHPLs2[3*4+3]*HPLs1[0]
          + 2*GHPLs3[0*4*4+3*4+3]
          + 10*GHPLs1[3]*zeta2
          + 2.0/3*GHPLs1[3]*HPLs1[0]
          - 2*GHPLs1[3]*HPLs2[1*2+0]
          - 2*GHPLs1[3]*HPLs2[0*2+1]
          - 2*GHPLs3[2*4*4+0*4+3]
          - 2.0/3*GHPLs2[0*4+3]
          + 2*GHPLs2[0*4+3]*HPLs1[1]
          + 2.0/3*GHPLs2[2*4+0]
          - 2.0/3*GHPLs1[0]*HPLs1[0]
          - 2.0/3*GHPLs1[0]*HPLs1[1]
          - 2.0/3*GHPLs2[2*4+1]
          + 2.0/3*GHPLs1[1]*HPLs1[0]
          + 2.0/3*GHPLs1[1]*HPLs1[1]
          + 2.0/3*HPLs2[0*2+0]
          + 2.0/3*HPLs2[0*2+1]
          )

       + C_F*pow(1-u,-1) * (
          + 3.0/2*zeta2
          - 3.0/2*GHPLs1[3]*HPLs1[0]
          + 3.0/2*GHPLs2[0*4+3]
          + 3.0/2*GHPLs1[0]*HPLs1[0]
          - 3.0/2*HPLs2[0*2+0]
          + 3.0/2*HPLs2[0*2+1]
          )

       + C_F * (
          - 23.0/6*zeta2
          + 8*zeta3
          + 2*GHPLs3[3*4*4+2*4+2]*HPLs1[0]
          - 2*GHPLs4[0*4*4*4+3*4*4+2*4+2]
          - 2*GHPLs2[2*4+2]*zeta2
          + 2*GHPLs2[2*4+2]*HPLs2[0*2+0]
          - 2*GHPLs2[2*4+2]*HPLs2[0*2+1]
          - 2*GHPLs3[0*4*4+2*4+2]*HPLs1[0]
          - 8*GHPLs2[3*4+2]*HPLs1[0]
          + 8*GHPLs3[0*4*4+3*4+2]
          - 1.0/3*GHPLs1[2]
          + 8*GHPLs1[2]*zeta2
          - 2*GHPLs1[2]*zeta3
          - 3*GHPLs1[2]*HPLs1[0]
          - 2*GHPLs1[2]*HPLs1[0]*zeta2
          - 9*GHPLs1[2]*HPLs2[0*2+0]
          + 2*GHPLs1[2]*HPLs3[0*2*2+0*2+0]
          - GHPLs1[2]*HPLs2[1*2+0]
          - 2*GHPLs1[2]*HPLs3[0*2*2+1*2+0]
          + 7*GHPLs1[2]*HPLs2[0*2+1]
          - 2*GHPLs1[2]*HPLs3[0*2*2+0*2+1]
          - 2*GHPLs3[3*4*4+0*4+2]*HPLs1[0]
          + 2*GHPLs4[0*4*4*4+3*4*4+0*4+2]
          + 5.0/3*GHPLs2[0*4+2]
          + 6*GHPLs2[0*4+2]*HPLs1[0]
          - 2*GHPLs2[0*4+2]*HPLs2[0*2+0]
          - GHPLs3[2*4*4+1*4+2]
          + GHPLs2[1*4+2]*HPLs1[0]
          + GHPLs2[1*4+2]*HPLs1[1]
          + 11.0/2*GHPLs1[3]*HPLs1[0]
          - 11.0/2*GHPLs2[0*4+3]
          + 5.0/3*GHPLs2[2*4+0]
          + 5.0/3*GHPLs1[0]
          - 8*GHPLs1[0]*zeta2
          - 11.0/2*GHPLs1[0]*HPLs1[0]
          - 5.0/3*GHPLs1[0]*HPLs1[1]
          - 4*GHPLs1[0]*HPLs2[0*2+1]
          + 2*GHPLs3[3*4*4+2*4+1]*HPLs1[0]
          - 2*GHPLs4[0*4*4*4+3*4*4+2*4+1]
          - 3*GHPLs2[2*4+1]
          - 2*GHPLs2[2*4+1]*zeta2
          + 2*GHPLs2[2*4+1]*HPLs2[0*2+0]
          - 2*GHPLs2[2*4+1]*HPLs2[0*2+1]
          - 2*GHPLs3[0*4*4+2*4+1]
          - 2*GHPLs3[0*4*4+2*4+1]*HPLs1[0]
          + 10*GHPLs1[1]*zeta2
          - 2*GHPLs1[1]*zeta3
          + 3*GHPLs1[1]*HPLs1[0]
          + 2*GHPLs1[1]*HPLs1[0]*zeta2
          + GHPLs1[1]*HPLs2[0*2+0]
          - 2*GHPLs1[1]*HPLs3[0*2*2+0*2+0]
          + GHPLs1[1]*HPLs2[1*2+0]
          + 2*GHPLs1[1]*HPLs3[0*2*2+1*2+0]
          + 3*GHPLs1[1]*HPLs1[1]
          + 2*GHPLs1[1]*HPLs1[1]*zeta2
          - 2*GHPLs1[1]*HPLs3[0*2*2+0*2+1]
          + 2*GHPLs1[1]*HPLs3[0*2*2+1*2+1]
          - 2*GHPLs3[2*4*4+0*4+1]
          + 2*GHPLs3[3*4*4+0*4+1]*HPLs1[0]
          - 2*GHPLs4[0*4*4*4+3*4*4+0*4+1]
          + 4*GHPLs2[0*4+1]*zeta2
          + 2*GHPLs2[0*4+1]*HPLs1[0]
          + 2*GHPLs2[0*4+1]*HPLs2[0*2+0]
          + 2*GHPLs2[0*4+1]*HPLs1[1]
          + 2*GHPLs2[0*4+1]*HPLs2[0*2+1]
          + GHPLs3[2*4*4+1*4+1]
          - GHPLs2[1*4+1]*HPLs1[0]
          - GHPLs2[1*4+1]*HPLs1[1]
          + 11.0/2*HPLs2[0*2+0]
          + 1.0/3*HPLs1[1]
          - 4*HPLs1[1]*zeta2
          + 1.0/2*HPLs2[0*2+1]
          + 8*HPLs3[0*2*2+0*2+1]
          - 4*HPLs3[0*2*2+1*2+1]
          )

       + C_F*v*pow(1-u,-2) * (
          - 3*zeta2
          + 3*zeta3
          - 3*GHPLs2[3*4+2]*HPLs1[0]
          + 3*GHPLs3[0*4*4+3*4+2]
          + 3*GHPLs1[2]*zeta2
          - 3*GHPLs1[2]*HPLs2[0*2+0]
          + 3*GHPLs1[2]*HPLs2[0*2+1]
          + 3*GHPLs2[0*4+2]*HPLs1[0]
          + 3*GHPLs1[3]*HPLs1[0]
          - 3*GHPLs2[0*4+3]
          - 3*GHPLs2[3*4+0]*HPLs1[0]
          + 3*GHPLs3[0*4*4+3*4+0]
          - 6*GHPLs1[0]*zeta2
          - 3*GHPLs1[0]*HPLs1[0]
          - 3*GHPLs1[0]*HPLs2[0*2+0]
          - 3*GHPLs1[0]*HPLs2[0*2+1]
          - 3*HPLs1[0]*zeta2
          + 3*HPLs2[0*2+0]
          + 3*HPLs3[0*2*2+0*2+0]
          - 3*HPLs3[0*2*2+1*2+0]
          - 3*HPLs1[1]*zeta2
          - 3*HPLs2[0*2+1]
          + 3*HPLs3[0*2*2+0*2+1]
          - 3*HPLs3[0*2*2+1*2+1]
          )

       + C_F*v*pow(1-u,-1) * (
          - zeta2
          - 5*zeta3
          + 5*GHPLs2[3*4+2]*HPLs1[0]
          - 5*GHPLs3[0*4*4+3*4+2]
          - 5*GHPLs1[2]*zeta2
          + 5*GHPLs1[2]*HPLs2[0*2+0]
          - 5*GHPLs1[2]*HPLs2[0*2+1]
          - 5*GHPLs2[0*4+2]*HPLs1[0]
          - 8*GHPLs1[3]*HPLs1[0]
          + 8*GHPLs2[0*4+3]
          + 5*GHPLs2[3*4+0]*HPLs1[0]
          - 5*GHPLs3[0*4*4+3*4+0]
          - 3.0/2*GHPLs1[0]
          + 10*GHPLs1[0]*zeta2
          + 5*GHPLs1[0]*HPLs1[0]
          + 5*GHPLs1[0]*HPLs2[0*2+0]
          + 5*GHPLs1[0]*HPLs2[0*2+1]
          + 5*HPLs1[0]*zeta2
          - 8*HPLs2[0*2+0]
          - 5*HPLs3[0*2*2+0*2+0]
          + 5*HPLs3[0*2*2+1*2+0]
          + 5*HPLs1[1]*zeta2
          + 2*HPLs2[0*2+1]
          - 5*HPLs3[0*2*2+0*2+1]
          + 5*HPLs3[0*2*2+1*2+1]
          )

       + C_F*v * (
          + 2*zeta2
          - 11.0/6*GHPLs1[2]
          - GHPLs1[2]*zeta2
          - 2.0/3*GHPLs1[2]*HPLs1[0]
          - GHPLs1[2]*HPLs2[0*2+0]
          + GHPLs1[2]*HPLs2[1*2+0]
          - 2.0/3*GHPLs2[0*4+2]
          + GHPLs2[0*4+2]*HPLs1[0]
          + GHPLs3[2*4*4+1*4+2]
          - GHPLs2[1*4+2]*HPLs1[0]
          - GHPLs2[1*4+2]*HPLs1[1]
          + GHPLs2[2*4+3]*HPLs1[0]
          - GHPLs3[0*4*4+2*4+3]
          - GHPLs2[3*4+3]*HPLs1[0]
          + GHPLs3[0*4*4+3*4+3]
          + 5*GHPLs1[3]*zeta2
          - 1.0/3*GHPLs1[3]*HPLs1[0]
          - GHPLs1[3]*HPLs2[1*2+0]
          - GHPLs1[3]*HPLs2[0*2+1]
          - GHPLs3[2*4*4+0*4+3]
          + 1.0/3*GHPLs2[0*4+3]
          + GHPLs2[0*4+3]*HPLs1[1]
          - 2.0/3*GHPLs2[2*4+0]
          + 1.0/6*GHPLs1[0]
          + 4.0/3*GHPLs1[0]*HPLs1[0]
          + 2.0/3*GHPLs1[0]*HPLs1[1]
          + 1.0/3*GHPLs2[2*4+1]
          - 1.0/3*GHPLs1[1]*HPLs1[0]
          - 1.0/3*GHPLs1[1]*HPLs1[1]
          + 4.0/3*HPLs1[0]
          - 2.0/3*HPLs2[0*2+0]
          + HPLs2[1*2+0]
          + 11.0/6*HPLs1[1]
          - 1.0/3*HPLs2[0*2+1]
          )

       + C_F*pow(v,2)*pow(1-u,-3) * (
          - 3*zeta3
          + 3*GHPLs2[3*4+2]*HPLs1[0]
          - 3*GHPLs3[0*4*4+3*4+2]
          - 3*GHPLs1[2]*zeta2
          + 3*GHPLs1[2]*HPLs2[0*2+0]
          - 3*GHPLs1[2]*HPLs2[0*2+1]
          - 3*GHPLs2[0*4+2]*HPLs1[0]
          + 3*GHPLs2[3*4+0]*HPLs1[0]
          - 3*GHPLs3[0*4*4+3*4+0]
          + 6*GHPLs1[0]*zeta2
          + 3*GHPLs1[0]*HPLs2[0*2+0]
          + 3*GHPLs1[0]*HPLs2[0*2+1]
          + 3*HPLs1[0]*zeta2
          - 3*HPLs3[0*2*2+0*2+0]
          + 3*HPLs3[0*2*2+1*2+0]
          + 3*HPLs1[1]*zeta2
          - 3*HPLs3[0*2*2+0*2+1]
          + 3*HPLs3[0*2*2+1*2+1]
          )

       + C_F*pow(v,2)*pow(1-u,-2) * (
          + 6*zeta2
          + 5*zeta3
          - 5*GHPLs2[3*4+2]*HPLs1[0]
          + 5*GHPLs3[0*4*4+3*4+2]
          + 5*GHPLs1[2]*zeta2
          - 5*GHPLs1[2]*HPLs2[0*2+0]
          + 5*GHPLs1[2]*HPLs2[0*2+1]
          + 5*GHPLs2[0*4+2]*HPLs1[0]
          + 3*GHPLs1[3]*HPLs1[0]
          - 3*GHPLs2[0*4+3]
          - 5*GHPLs2[3*4+0]*HPLs1[0]
          + 5*GHPLs3[0*4*4+3*4+0]
          - 10*GHPLs1[0]*zeta2
          - 5*GHPLs1[0]*HPLs2[0*2+0]
          - 5*GHPLs1[0]*HPLs2[0*2+1]
          - 5*HPLs1[0]*zeta2
          + 3*HPLs2[0*2+0]
          + 5*HPLs3[0*2*2+0*2+0]
          - 5*HPLs3[0*2*2+1*2+0]
          - 5*HPLs1[1]*zeta2
          + 3*HPLs2[0*2+1]
          + 5*HPLs3[0*2*2+0*2+1]
          - 5*HPLs3[0*2*2+1*2+1]
          )

       + C_F*pow(v,2)*pow(1-u,-1) * (
          - 6*zeta2
          - 4*zeta3
          + 4*GHPLs2[3*4+2]*HPLs1[0]
          - 4*GHPLs3[0*4*4+3*4+2]
          + 3.0/2*GHPLs1[2]
          - 4*GHPLs1[2]*zeta2
          + 4*GHPLs1[2]*HPLs2[0*2+0]
          - 4*GHPLs1[2]*HPLs2[0*2+1]
          - 1.0/2*GHPLs2[0*4+2]
          - 4*GHPLs2[0*4+2]*HPLs1[0]
          - 7.0/2*GHPLs1[3]*HPLs1[0]
          + 7.0/2*GHPLs2[0*4+3]
          - 1.0/2*GHPLs2[2*4+0]
          + 4*GHPLs2[3*4+0]*HPLs1[0]
          - 4*GHPLs3[0*4*4+3*4+0]
          + 8*GHPLs1[0]*zeta2
          + 1.0/2*GHPLs1[0]*HPLs1[0]
          + 4*GHPLs1[0]*HPLs2[0*2+0]
          + 1.0/2*GHPLs1[0]*HPLs1[1]
          + 4*GHPLs1[0]*HPLs2[0*2+1]
          + GHPLs2[2*4+1]
          - GHPLs1[1]*HPLs1[0]
          - GHPLs1[1]*HPLs1[1]
          - 3.0/2*HPLs1[0]
          + 4*HPLs1[0]*zeta2
          - 5.0/2*HPLs2[0*2+0]
          - 4*HPLs3[0*2*2+0*2+0]
          + HPLs2[1*2+0]
          + 4*HPLs3[0*2*2+1*2+0]
          - 3.0/2*HPLs1[1]
          + 4*HPLs1[1]*zeta2
          - 7.0/2*HPLs2[0*2+1]
          - 4*HPLs3[0*2*2+0*2+1]
          + 4*HPLs3[0*2*2+1*2+1]
          )

       + C_F*pow(v,2) * (
          + 10*zeta2
          + 2.0/3*GHPLs1[2]
          + 2*GHPLs1[2]*zeta2
          + 29.0/6*GHPLs1[2]*HPLs1[0]
          + 2*GHPLs1[2]*HPLs2[0*2+0]
          - 2*GHPLs1[2]*HPLs2[1*2+0]
          - 13.0/6*GHPLs2[0*4+2]
          - 2*GHPLs2[0*4+2]*HPLs1[0]
          - 2*GHPLs3[2*4*4+1*4+2]
          + 2*GHPLs2[1*4+2]*HPLs1[0]
          + 2*GHPLs2[1*4+2]*HPLs1[1]
          - 2*GHPLs2[2*4+3]*HPLs1[0]
          + 2*GHPLs3[0*4*4+2*4+3]
          + 2*GHPLs2[3*4+3]*HPLs1[0]
          - 2*GHPLs3[0*4*4+3*4+3]
          - 10*GHPLs1[3]*zeta2
          - 17.0/6*GHPLs1[3]*HPLs1[0]
          + 2*GHPLs1[3]*HPLs2[1*2+0]
          + 2*GHPLs1[3]*HPLs2[0*2+1]
          + 2*GHPLs3[2*4*4+0*4+3]
          + 17.0/6*GHPLs2[0*4+3]
          - 2*GHPLs2[0*4+3]*HPLs1[1]
          - 13.0/6*GHPLs2[2*4+0]
          - 1.0/3*GHPLs1[0]
          + 5.0/6*GHPLs1[0]*HPLs1[0]
          + 13.0/6*GHPLs1[0]*HPLs1[1]
          + 17.0/6*GHPLs2[2*4+1]
          - 17.0/6*GHPLs1[1]*HPLs1[0]
          - 17.0/6*GHPLs1[1]*HPLs1[1]
          - 1.0/3*HPLs1[0]
          - 13.0/6*HPLs2[0*2+0]
          - 2*HPLs2[1*2+0]
          - 2.0/3*HPLs1[1]
          - 17.0/6*HPLs2[0*2+1]
          )

       + C_F*pow(v,3) * (
          - 20.0/3*zeta2
          - 2*GHPLs1[2]*zeta2
          - 5.0/3*GHPLs1[2]*HPLs1[0]
          - 2*GHPLs1[2]*HPLs2[0*2+0]
          + 2*GHPLs1[2]*HPLs2[1*2+0]
          + 5.0/3*GHPLs2[0*4+2]
          + 2*GHPLs2[0*4+2]*HPLs1[0]
          + 2*GHPLs3[2*4*4+1*4+2]
          - 2*GHPLs2[1*4+2]*HPLs1[0]
          - 2*GHPLs2[1*4+2]*HPLs1[1]
          + 2*GHPLs2[2*4+3]*HPLs1[0]
          - 2*GHPLs3[0*4*4+2*4+3]
          - 2*GHPLs2[3*4+3]*HPLs1[0]
          + 2*GHPLs3[0*4*4+3*4+3]
          + 10*GHPLs1[3]*zeta2
          + 5.0/3*GHPLs1[3]*HPLs1[0]
          - 2*GHPLs1[3]*HPLs2[1*2+0]
          - 2*GHPLs1[3]*HPLs2[0*2+1]
          - 2*GHPLs3[2*4*4+0*4+3]
          - 5.0/3*GHPLs2[0*4+3]
          + 2*GHPLs2[0*4+3]*HPLs1[1]
          + 5.0/3*GHPLs2[2*4+0]
          - 5.0/3*GHPLs1[0]*HPLs1[0]
          - 5.0/3*GHPLs1[0]*HPLs1[1]
          - 5.0/3*GHPLs2[2*4+1]
          + 5.0/3*GHPLs1[1]*HPLs1[0]
          + 5.0/3*GHPLs1[1]*HPLs1[1]
          + 5.0/3*HPLs2[0*2+0]
          + 5.0/3*HPLs2[0*2+1]
          )

       + C_F*u*pow(1-v,-1) * (
          + 4.0/3*GHPLs1[2]*HPLs2[0*2+0]
          - 4.0/3*GHPLs1[0]*HPLs2[0*2+0]
          - 4.0/3*HPLs3[1*2*2+0*2+0]
          - 4.0/3*HPLs3[0*2*2+1*2+0]
          - 4.0/3*HPLs3[0*2*2+0*2+1]
          )

       + C_F*u*pow(1-u-v,-1) * (
          + 3.0/2*zeta2
          - 3.0/2*GHPLs1[3]*HPLs1[0]
          + 3.0/2*GHPLs2[0*4+3]
          + 3.0/2*GHPLs1[0]*HPLs1[0]
          - 3.0/2*HPLs2[0*2+0]
          + 3.0/2*HPLs2[0*2+1]
          )

       + C_F*u * (
          + 4*zeta2
          - 4.0/3*GHPLs1[2]
          - 2.0/3*GHPLs1[2]*zeta2
          + GHPLs1[2]*HPLs1[0]
          - 2.0/3*GHPLs1[2]*HPLs2[0*2+0]
          + 2.0/3*GHPLs1[2]*HPLs2[1*2+0]
          - GHPLs2[0*4+2]
          + 2.0/3*GHPLs2[0*4+2]*HPLs1[0]
          + 2.0/3*GHPLs3[2*4*4+1*4+2]
          - 2.0/3*GHPLs2[1*4+2]*HPLs1[0]
          - 2.0/3*GHPLs2[1*4+2]*HPLs1[1]
          + 2.0/3*GHPLs2[2*4+3]*HPLs1[0]
          - 2.0/3*GHPLs3[0*4*4+2*4+3]
          - 2.0/3*GHPLs2[3*4+3]*HPLs1[0]
          + 2.0/3*GHPLs3[0*4*4+3*4+3]
          + 10.0/3*GHPLs1[3]*zeta2
          - GHPLs1[3]*HPLs1[0]
          - 2.0/3*GHPLs1[3]*HPLs2[1*2+0]
          - 2.0/3*GHPLs1[3]*HPLs2[0*2+1]
          - 2.0/3*GHPLs3[2*4*4+0*4+3]
          + GHPLs2[0*4+3]
          + 2.0/3*GHPLs2[0*4+3]*HPLs1[1]
          - GHPLs2[2*4+0]
          - 2.0/3*GHPLs2[2*4+0]*HPLs1[0]
          + 2.0/3*GHPLs2[3*4+0]*HPLs1[0]
          - 2.0/3*GHPLs3[0*4*4+3*4+0]
          + 4.0/3*GHPLs1[0]
          + GHPLs1[0]*HPLs1[0]
          + 4.0/3*GHPLs1[0]*HPLs2[0*2+0]
          + 2.0/3*GHPLs1[0]*HPLs2[1*2+0]
          + GHPLs1[0]*HPLs1[1]
          + 2.0/3*GHPLs1[0]*HPLs2[0*2+1]
          + GHPLs2[2*4+1]
          + 2.0/3*GHPLs3[0*4*4+2*4+1]
          - 8.0/3*GHPLs1[1]*zeta2
          - GHPLs1[1]*HPLs1[0]
          - 2.0/3*GHPLs1[1]*HPLs2[0*2+0]
          - 2.0/3*GHPLs1[1]*HPLs2[1*2+0]
          - GHPLs1[1]*HPLs1[1]
          + 2.0/3*GHPLs3[2*4*4+0*4+1]
          - 2.0/3*GHPLs2[0*4+1]*HPLs1[0]
          - 2.0/3*GHPLs2[0*4+1]*HPLs1[1]
          - 2.0/3*GHPLs3[2*4*4+1*4+1]
          + 2.0/3*GHPLs2[1*4+1]*HPLs1[0]
          + 2.0/3*GHPLs2[1*4+1]*HPLs1[1]
          + 10.0/3*HPLs1[0]*zeta2
          - HPLs2[0*2+0]
          + 2.0/3*HPLs3[1*2*2+0*2+0]
          + 2.0/3*HPLs3[0*2*2+1*2+0]
          + 4.0/3*HPLs1[1]
          + 2.0/3*HPLs1[1]*zeta2
          - HPLs2[0*2+1]
          + 2.0/3*HPLs3[0*2*2+0*2+1]
          + 2.0/3*HPLs3[1*2*2+0*2+1]
          + 4.0/3*HPLs3[0*2*2+1*2+1]
          )

       + C_F*u*v * (
          + 6*zeta2
          + 1.0/3*GHPLs1[2]
          + 1.0/3*GHPLs1[2]*zeta2
          + 17.0/6*GHPLs1[2]*HPLs1[0]
          + 1.0/3*GHPLs1[2]*HPLs2[0*2+0]
          - 1.0/3*GHPLs1[2]*HPLs2[1*2+0]
          - 3.0/2*GHPLs2[0*4+2]
          - 1.0/3*GHPLs2[0*4+2]*HPLs1[0]
          - 1.0/3*GHPLs3[2*4*4+1*4+2]
          + 1.0/3*GHPLs2[1*4+2]*HPLs1[0]
          + 1.0/3*GHPLs2[1*4+2]*HPLs1[1]
          - 1.0/3*GHPLs2[2*4+3]*HPLs1[0]
          + 1.0/3*GHPLs3[0*4*4+2*4+3]
          + 1.0/3*GHPLs2[3*4+3]*HPLs1[0]
          - 1.0/3*GHPLs3[0*4*4+3*4+3]
          - 5.0/3*GHPLs1[3]*zeta2
          - 3.0/2*GHPLs1[3]*HPLs1[0]
          + 1.0/3*GHPLs1[3]*HPLs2[1*2+0]
          + 1.0/3*GHPLs1[3]*HPLs2[0*2+1]
          + 1.0/3*GHPLs3[2*4*4+0*4+3]
          + 3.0/2*GHPLs2[0*4+3]
          - 1.0/3*GHPLs2[0*4+3]*HPLs1[1]
          - 3.0/2*GHPLs2[2*4+0]
          + 1.0/3*GHPLs2[2*4+0]*HPLs1[0]
          - 1.0/3*GHPLs2[3*4+0]*HPLs1[0]
          + 1.0/3*GHPLs3[0*4*4+3*4+0]
          - 1.0/3*GHPLs1[0]
          + 1.0/6*GHPLs1[0]*HPLs1[0]
          - 2.0/3*GHPLs1[0]*HPLs2[0*2+0]
          - 1.0/3*GHPLs1[0]*HPLs2[1*2+0]
          + 3.0/2*GHPLs1[0]*HPLs1[1]
          - 1.0/3*GHPLs1[0]*HPLs2[0*2+1]
          + 3.0/2*GHPLs2[2*4+1]
          - 1.0/3*GHPLs3[0*4*4+2*4+1]
          + 4.0/3*GHPLs1[1]*zeta2
          - 3.0/2*GHPLs1[1]*HPLs1[0]
          + 1.0/3*GHPLs1[1]*HPLs2[0*2+0]
          + 1.0/3*GHPLs1[1]*HPLs2[1*2+0]
          - 3.0/2*GHPLs1[1]*HPLs1[1]
          - 1.0/3*GHPLs3[2*4*4+0*4+1]
          + 1.0/3*GHPLs2[0*4+1]*HPLs1[0]
          + 1.0/3*GHPLs2[0*4+1]*HPLs1[1]
          + 1.0/3*GHPLs3[2*4*4+1*4+1]
          - 1.0/3*GHPLs2[1*4+1]*HPLs1[0]
          - 1.0/3*GHPLs2[1*4+1]*HPLs1[1]
          - 5.0/3*HPLs1[0]*zeta2
          - 3.0/2*HPLs2[0*2+0]
          - 1.0/3*HPLs3[1*2*2+0*2+0]
          - 4.0/3*HPLs2[1*2+0]
          - 1.0/3*HPLs3[0*2*2+1*2+0]
          - 1.0/3*HPLs1[1]
          - 1.0/3*HPLs1[1]*zeta2
          - 17.0/6*HPLs2[0*2+1]
          - 1.0/3*HPLs3[0*2*2+0*2+1]
          - 1.0/3*HPLs3[1*2*2+0*2+1]
          - 2.0/3*HPLs3[0*2*2+1*2+1]
          )

       + C_F*u*pow(v,2) * (
          - 8*zeta2
          - 2.0/3*GHPLs1[2]*zeta2
          - 2*GHPLs1[2]*HPLs1[0]
          - 2.0/3*GHPLs1[2]*HPLs2[0*2+0]
          + 2.0/3*GHPLs1[2]*HPLs2[1*2+0]
          + 2*GHPLs2[0*4+2]
          + 2.0/3*GHPLs2[0*4+2]*HPLs1[0]
          + 2.0/3*GHPLs3[2*4*4+1*4+2]
          - 2.0/3*GHPLs2[1*4+2]*HPLs1[0]
          - 2.0/3*GHPLs2[1*4+2]*HPLs1[1]
          + 2.0/3*GHPLs2[2*4+3]*HPLs1[0]
          - 2.0/3*GHPLs3[0*4*4+2*4+3]
          - 2.0/3*GHPLs2[3*4+3]*HPLs1[0]
          + 2.0/3*GHPLs3[0*4*4+3*4+3]
          + 10.0/3*GHPLs1[3]*zeta2
          + 2*GHPLs1[3]*HPLs1[0]
          - 2.0/3*GHPLs1[3]*HPLs2[1*2+0]
          - 2.0/3*GHPLs1[3]*HPLs2[0*2+1]
          - 2.0/3*GHPLs3[2*4*4+0*4+3]
          - 2*GHPLs2[0*4+3]
          + 2.0/3*GHPLs2[0*4+3]*HPLs1[1]
          + 2*GHPLs2[2*4+0]
          - 2.0/3*GHPLs2[2*4+0]*HPLs1[0]
          + 2.0/3*GHPLs2[3*4+0]*HPLs1[0]
          - 2.0/3*GHPLs3[0*4*4+3*4+0]
          - 2*GHPLs1[0]*HPLs1[0]
          + 4.0/3*GHPLs1[0]*HPLs2[0*2+0]
          + 2.0/3*GHPLs1[0]*HPLs2[1*2+0]
          - 2*GHPLs1[0]*HPLs1[1]
          + 2.0/3*GHPLs1[0]*HPLs2[0*2+1]
          - 2*GHPLs2[2*4+1]
          + 2.0/3*GHPLs3[0*4*4+2*4+1]
          - 8.0/3*GHPLs1[1]*zeta2
          + 2*GHPLs1[1]*HPLs1[0]
          - 2.0/3*GHPLs1[1]*HPLs2[0*2+0]
          - 2.0/3*GHPLs1[1]*HPLs2[1*2+0]
          + 2*GHPLs1[1]*HPLs1[1]
          + 2.0/3*GHPLs3[2*4*4+0*4+1]
          - 2.0/3*GHPLs2[0*4+1]*HPLs1[0]
          - 2.0/3*GHPLs2[0*4+1]*HPLs1[1]
          - 2.0/3*GHPLs3[2*4*4+1*4+1]
          + 2.0/3*GHPLs2[1*4+1]*HPLs1[0]
          + 2.0/3*GHPLs2[1*4+1]*HPLs1[1]
          + 10.0/3*HPLs1[0]*zeta2
          + 2*HPLs2[0*2+0]
          + 2.0/3*HPLs3[1*2*2+0*2+0]
          + 2.0/3*HPLs3[0*2*2+1*2+0]
          + 2.0/3*HPLs1[1]*zeta2
          + 2*HPLs2[0*2+1]
          + 2.0/3*HPLs3[0*2*2+0*2+1]
          + 2.0/3*HPLs3[1*2*2+0*2+1]
          + 4.0/3*HPLs3[0*2*2+1*2+1]
          )

       + C_F*pow(u,2)*v * (
          - 4*zeta2
          - GHPLs1[2]*HPLs1[0]
          + GHPLs2[0*4+2]
          + GHPLs1[3]*HPLs1[0]
          - GHPLs2[0*4+3]
          + GHPLs2[2*4+0]
          - GHPLs1[0]*HPLs1[0]
          - GHPLs1[0]*HPLs1[1]
          - GHPLs2[2*4+1]
          + GHPLs1[1]*HPLs1[0]
          + GHPLs1[1]*HPLs1[1]
          + HPLs2[0*2+0]
          + HPLs2[0*2+1]
          )

       + C_F*double_complex(0,1)*M_PI*pow(u,-2) * (
          - 4*GHPLs3[3*4*4+2*4+2]
          - 4*GHPLs2[2*4+2]*HPLs1[0]
          - 4*GHPLs1[2]*HPLs2[0*2+0]
          + 4*GHPLs3[3*4*4+0*4+2]
          - 2.0/3*GHPLs2[1*4+2]
          - 4*GHPLs3[3*4*4+2*4+1]
          - 2.0/3*GHPLs2[2*4+1]
          - 4*GHPLs2[2*4+1]*HPLs1[0]
          + GHPLs1[1]
          + 8*GHPLs1[1]*zeta2
          + 4*GHPLs1[1]*HPLs2[0*2+0]
          + 2.0/3*GHPLs1[1]*HPLs1[1]
          + 4*GHPLs1[1]*HPLs2[0*2+1]
          - 4*GHPLs3[3*4*4+0*4+1]
          - 2.0/3*GHPLs2[0*4+1]
          + 2.0/3*GHPLs2[1*4+1]
          )

       + C_F*double_complex(0,1)*M_PI*pow(u,-2)*v * (
          + 8*GHPLs3[3*4*4+2*4+2]
          + 8*GHPLs2[2*4+2]*HPLs1[0]
          + 8*GHPLs1[2]*HPLs2[0*2+0]
          - 8*GHPLs3[3*4*4+0*4+2]
          + 4.0/3*GHPLs2[1*4+2]
          + 8*GHPLs3[3*4*4+2*4+1]
          + 4.0/3*GHPLs2[2*4+1]
          + 8*GHPLs2[2*4+1]*HPLs1[0]
          - 5.0/3*GHPLs1[1]
          - 16*GHPLs1[1]*zeta2
          - 8*GHPLs1[1]*HPLs2[0*2+0]
          - 4.0/3*GHPLs1[1]*HPLs1[1]
          - 8*GHPLs1[1]*HPLs2[0*2+1]
          + 8*GHPLs3[3*4*4+0*4+1]
          + 4.0/3*GHPLs2[0*4+1]
          - 4.0/3*GHPLs2[1*4+1]
          )

       + C_F*double_complex(0,1)*M_PI*pow(u,-2)*pow(v,2) * (
          - 4*GHPLs3[3*4*4+2*4+2]
          - 4*GHPLs2[2*4+2]*HPLs1[0]
          - 4*GHPLs1[2]*HPLs2[0*2+0]
          + 4*GHPLs3[3*4*4+0*4+2]
          - 2.0/3*GHPLs2[1*4+2]
          - 4*GHPLs3[3*4*4+2*4+1]
          - 2.0/3*GHPLs2[2*4+1]
          - 4*GHPLs2[2*4+1]*HPLs1[0]
          + GHPLs1[1]
          + 8*GHPLs1[1]*zeta2
          + 4*GHPLs1[1]*HPLs2[0*2+0]
          + 2.0/3*GHPLs1[1]*HPLs1[1]
          + 4*GHPLs1[1]*HPLs2[0*2+1]
          - 4*GHPLs3[3*4*4+0*4+1]
          - 2.0/3*GHPLs2[0*4+1]
          + 2.0/3*GHPLs2[1*4+1]
          )

       + C_F*double_complex(0,1)*M_PI*pow(u,-2)*pow(v,3) * (
          + 2.0/3*GHPLs2[1*4+2]
          - 2.0/3*GHPLs2[2*4+3]
          + 2.0/3*GHPLs2[3*4+3]
          + 2.0/3*GHPLs1[3]*HPLs1[0]
          + 2.0/3*GHPLs1[3]*HPLs1[1]
          - 2.0/3*GHPLs2[0*4+3]
          - GHPLs1[1]
          )

       + C_F*double_complex(0,1)*M_PI*pow(u,-2)*pow(v,4) * (
          - 4.0/3*GHPLs2[1*4+2]
          + 4.0/3*GHPLs2[2*4+3]
          - 4.0/3*GHPLs2[3*4+3]
          - 4.0/3*GHPLs1[3]*HPLs1[0]
          - 4.0/3*GHPLs1[3]*HPLs1[1]
          + 4.0/3*GHPLs2[0*4+3]
          + 2.0/3*GHPLs1[1]
          )

       + C_F*double_complex(0,1)*M_PI*pow(u,-2)*pow(v,5) * (
          + 2.0/3*GHPLs2[1*4+2]
          - 2.0/3*GHPLs2[2*4+3]
          + 2.0/3*GHPLs2[3*4+3]
          + 2.0/3*GHPLs1[3]*HPLs1[0]
          + 2.0/3*GHPLs1[3]*HPLs1[1]
          - 2.0/3*GHPLs2[0*4+3]
          )

       + C_F*double_complex(0,1)*M_PI*pow(u,-1) * (
          + 5.0/3
          + 8*zeta2
          + 6*GHPLs3[3*4*4+2*4+2]
          + 6*GHPLs2[2*4+2]*HPLs1[0]
          - 8*GHPLs2[3*4+2]
          - 2.0/3*GHPLs1[2]
          - 7*GHPLs1[2]*HPLs1[0]
          + 6*GHPLs1[2]*HPLs2[0*2+0]
          - 6*GHPLs3[3*4*4+0*4+2]
          + GHPLs2[1*4+2]
          - 2.0/3*GHPLs1[0]
          + 6*GHPLs3[3*4*4+2*4+1]
          + 2*GHPLs2[2*4+1]
          + 6*GHPLs2[2*4+1]*HPLs1[0]
          + GHPLs1[1]
          - 12*GHPLs1[1]*zeta2
          - GHPLs1[1]*HPLs1[0]
          - 6*GHPLs1[1]*HPLs2[0*2+0]
          - 2*GHPLs1[1]*HPLs1[1]
          - 6*GHPLs1[1]*HPLs2[0*2+1]
          + 6*GHPLs3[3*4*4+0*4+1]
          + 2*GHPLs2[0*4+1]
          - GHPLs2[1*4+1]
          + 2.0/3*HPLs1[1]
          + 4*HPLs2[0*2+1]
          )

       + C_F*double_complex(0,1)*M_PI*pow(u,-1)*v * (
          - 3
          - 16*zeta2
          - 6*GHPLs3[3*4*4+2*4+2]
          - 6*GHPLs2[2*4+2]*HPLs1[0]
          + 12*GHPLs2[3*4+2]
          + 4.0/3*GHPLs1[2]
          + 11*GHPLs1[2]*HPLs1[0]
          - 6*GHPLs1[2]*HPLs2[0*2+0]
          + 6*GHPLs3[3*4*4+0*4+2]
          - GHPLs2[1*4+2]
          - 4*GHPLs1[3]
          + 4*GHPLs2[3*4+0]
          + 4.0/3*GHPLs1[0]
          - 6*GHPLs3[3*4*4+2*4+1]
          - 2*GHPLs2[2*4+1]
          - 6*GHPLs2[2*4+1]*HPLs1[0]
          - 13.0/6*GHPLs1[1]
          + 12*GHPLs1[1]*zeta2
          + GHPLs1[1]*HPLs1[0]
          + 6*GHPLs1[1]*HPLs2[0*2+0]
          + 2*GHPLs1[1]*HPLs1[1]
          + 6*GHPLs1[1]*HPLs2[0*2+1]
          - 6*GHPLs3[3*4*4+0*4+1]
          - 2*GHPLs2[0*4+1]
          + GHPLs2[1*4+1]
          - 4*HPLs2[0*2+0]
          - 4.0/3*HPLs1[1]
          - 8*HPLs2[0*2+1]
          )

       + C_F*double_complex(0,1)*M_PI*pow(u,-1)*pow(v,2) * (
          + 1
          + 8*zeta2
          - 4*GHPLs2[3*4+2]
          - 4*GHPLs1[2]*HPLs1[0]
          + GHPLs2[1*4+2]
          - GHPLs2[2*4+3]
          + GHPLs2[3*4+3]
          + 10.0/3*GHPLs1[3]
          + GHPLs1[3]*HPLs1[0]
          + GHPLs1[3]*HPLs1[1]
          - GHPLs2[0*4+3]
          - 4*GHPLs2[3*4+0]
          - 5.0/6*GHPLs1[1]
          - 2.0/3*HPLs1[0]
          + 4*HPLs2[0*2+0]
          + 4*HPLs2[0*2+1]
          )

       + C_F*double_complex(0,1)*M_PI*pow(u,-1)*pow(v,3) * (
          + 1.0/3
          - 4.0/3*GHPLs1[2]
          - 3*GHPLs2[1*4+2]
          + 3*GHPLs2[2*4+3]
          - 3*GHPLs2[3*4+3]
          + 4.0/3*GHPLs1[3]
          - 3*GHPLs1[3]*HPLs1[0]
          - 3*GHPLs1[3]*HPLs1[1]
          + 3*GHPLs2[0*4+3]
          - 4.0/3*GHPLs1[0]
          + 8.0/3*GHPLs1[1]
          + 4.0/3*HPLs1[0]
          + 4.0/3*HPLs1[1]
          )

       + C_F*double_complex(0,1)*M_PI*pow(u,-1)*pow(v,4) * (
          + 2.0/3*GHPLs1[2]
          + 2*GHPLs2[1*4+2]
          - 2*GHPLs2[2*4+3]
          + 2*GHPLs2[3*4+3]
          - 2.0/3*GHPLs1[3]
          + 2*GHPLs1[3]*HPLs1[0]
          + 2*GHPLs1[3]*HPLs1[1]
          - 2*GHPLs2[0*4+3]
          + 2.0/3*GHPLs1[0]
          - 2.0/3*GHPLs1[1]
          - 2.0/3*HPLs1[0]
          - 2.0/3*HPLs1[1]
          )

       + C_F*double_complex(0,1)*M_PI*pow(1-u,-1) * (
          + 3.0/2*GHPLs1[3]
          + 3.0/2*HPLs1[0]
          )

       + C_F*double_complex(0,1)*M_PI * (
          + 4.0/3
          - 8*zeta2
          - 2*GHPLs3[3*4*4+2*4+2]
          - 2*GHPLs2[2*4+2]*HPLs1[0]
          + 8*GHPLs2[3*4+2]
          + 5.0/3*GHPLs1[2]
          + 7*GHPLs1[2]*HPLs1[0]
          - 2*GHPLs1[2]*HPLs2[0*2+0]
          + 2*GHPLs3[3*4*4+0*4+2]
          - GHPLs2[1*4+2]
          - 11.0/2*GHPLs1[3]
          + 5.0/3*GHPLs1[0]
          - 2*GHPLs3[3*4*4+2*4+1]
          - 2*GHPLs2[2*4+1]
          - 2*GHPLs2[2*4+1]*HPLs1[0]
          - 3*GHPLs1[1]
          + 4*GHPLs1[1]*zeta2
          + GHPLs1[1]*HPLs1[0]
          + 2*GHPLs1[1]*HPLs2[0*2+0]
          + 2*GHPLs1[1]*HPLs1[1]
          + 2*GHPLs1[1]*HPLs2[0*2+1]
          - 2*GHPLs3[3*4*4+0*4+1]
          - 2*GHPLs2[0*4+1]
          + GHPLs2[1*4+1]
          - 11.0/2*HPLs1[0]
          - 5.0/3*HPLs1[1]
          - 4*HPLs2[0*2+1]
          )

       + C_F*double_complex(0,1)*M_PI*v*pow(1-u,-2) * (
          - 6*zeta2
          + 3*GHPLs2[3*4+2]
          + 3*GHPLs1[2]*HPLs1[0]
          - 3*GHPLs1[3]
          + 3*GHPLs2[3*4+0]
          - 3*HPLs1[0]
          - 3*HPLs2[0*2+0]
          - 3*HPLs2[0*2+1]
          )

       + C_F*double_complex(0,1)*M_PI*v*pow(1-u,-1) * (
          - 3.0/2
          + 10*zeta2
          - 5*GHPLs2[3*4+2]
          - 5*GHPLs1[2]*HPLs1[0]
          + 8*GHPLs1[3]
          - 5*GHPLs2[3*4+0]
          + 5*HPLs1[0]
          + 5*HPLs2[0*2+0]
          + 5*HPLs2[0*2+1]
          )

       + C_F*double_complex(0,1)*M_PI*v * (
          - 5.0/3
          - 2.0/3*GHPLs1[2]
          + GHPLs2[1*4+2]
          - GHPLs2[2*4+3]
          + GHPLs2[3*4+3]
          + 1.0/3*GHPLs1[3]
          + GHPLs1[3]*HPLs1[0]
          + GHPLs1[3]*HPLs1[1]
          - GHPLs2[0*4+3]
          - 2.0/3*GHPLs1[0]
          + 1.0/3*GHPLs1[1]
          + 1.0/3*HPLs1[0]
          + 2.0/3*HPLs1[1]
          )

       + C_F*double_complex(0,1)*M_PI*pow(v,2)*pow(1-u,-3) * (
          + 6*zeta2
          - 3*GHPLs2[3*4+2]
          - 3*GHPLs1[2]*HPLs1[0]
          - 3*GHPLs2[3*4+0]
          + 3*HPLs2[0*2+0]
          + 3*HPLs2[0*2+1]
          )

       + C_F*double_complex(0,1)*M_PI*pow(v,2)*pow(1-u,-2) * (
          - 10*zeta2
          + 5*GHPLs2[3*4+2]
          + 5*GHPLs1[2]*HPLs1[0]
          - 3*GHPLs1[3]
          + 5*GHPLs2[3*4+0]
          - 5*HPLs2[0*2+0]
          - 5*HPLs2[0*2+1]
          )

       + C_F*double_complex(0,1)*M_PI*pow(v,2)*pow(1-u,-1) * (
          + 3.0/2
          + 8*zeta2
          - 4*GHPLs2[3*4+2]
          - 1.0/2*GHPLs1[2]
          - 4*GHPLs1[2]*HPLs1[0]
          + 7.0/2*GHPLs1[3]
          - 4*GHPLs2[3*4+0]
          - 1.0/2*GHPLs1[0]
          + GHPLs1[1]
          - 1.0/2*HPLs1[0]
          + 4*HPLs2[0*2+0]
          + 1.0/2*HPLs1[1]
          + 4*HPLs2[0*2+1]
          )

       + C_F*double_complex(0,1)*M_PI*pow(v,2) * (
          + 1.0/3
          - 13.0/6*GHPLs1[2]
          - 2*GHPLs2[1*4+2]
          + 2*GHPLs2[2*4+3]
          - 2*GHPLs2[3*4+3]
          + 17.0/6*GHPLs1[3]
          - 2*GHPLs1[3]*HPLs1[0]
          - 2*GHPLs1[3]*HPLs1[1]
          + 2*GHPLs2[0*4+3]
          - 13.0/6*GHPLs1[0]
          + 17.0/6*GHPLs1[1]
          + 17.0/6*HPLs1[0]
          + 13.0/6*HPLs1[1]
          )

       + C_F*double_complex(0,1)*M_PI*pow(v,3) * (
          + 5.0/3*GHPLs1[2]
          + 2*GHPLs2[1*4+2]
          - 2*GHPLs2[2*4+3]
          + 2*GHPLs2[3*4+3]
          - 5.0/3*GHPLs1[3]
          + 2*GHPLs1[3]*HPLs1[0]
          + 2*GHPLs1[3]*HPLs1[1]
          - 2*GHPLs2[0*4+3]
          + 5.0/3*GHPLs1[0]
          - 5.0/3*GHPLs1[1]
          - 5.0/3*HPLs1[0]
          - 5.0/3*HPLs1[1]
          )

       + C_F*double_complex(0,1)*M_PI*u*pow(1-u-v,-1) * (
          + 3.0/2*GHPLs1[3]
          + 3.0/2*HPLs1[0]
          )

       + C_F*double_complex(0,1)*M_PI*u * (
          - 2.0/3*zeta2
          - GHPLs1[2]
          + 2.0/3*GHPLs2[1*4+2]
          - 2.0/3*GHPLs2[2*4+3]
          + 2.0/3*GHPLs2[3*4+3]
          + GHPLs1[3]
          + 2.0/3*GHPLs1[3]*HPLs1[0]
          + 2.0/3*GHPLs1[3]*HPLs1[1]
          - 2.0/3*GHPLs2[0*4+3]
          - 2.0/3*GHPLs2[3*4+0]
          - GHPLs1[0]
          - 2.0/3*GHPLs1[0]*HPLs1[0]
          + 2.0/3*GHPLs2[2*4+1]
          + GHPLs1[1]
          - 2.0/3*GHPLs1[1]*HPLs1[1]
          + 2.0/3*GHPLs2[0*4+1]
          - 2.0/3*GHPLs2[1*4+1]
          + HPLs1[0]
          + 2.0/3*HPLs2[0*2+0]
          + 2.0/3*HPLs2[1*2+0]
          + HPLs1[1]
          )

       + C_F*double_complex(0,1)*M_PI*u*v * (
          + 1.0/3*zeta2
          - 3.0/2*GHPLs1[2]
          - 1.0/3*GHPLs2[1*4+2]
          + 1.0/3*GHPLs2[2*4+3]
          - 1.0/3*GHPLs2[3*4+3]
          + 3.0/2*GHPLs1[3]
          - 1.0/3*GHPLs1[3]*HPLs1[0]
          - 1.0/3*GHPLs1[3]*HPLs1[1]
          + 1.0/3*GHPLs2[0*4+3]
          + 1.0/3*GHPLs2[3*4+0]
          - 3.0/2*GHPLs1[0]
          + 1.0/3*GHPLs1[0]*HPLs1[0]
          - 1.0/3*GHPLs2[2*4+1]
          + 3.0/2*GHPLs1[1]
          + 1.0/3*GHPLs1[1]*HPLs1[1]
          - 1.0/3*GHPLs2[0*4+1]
          + 1.0/3*GHPLs2[1*4+1]
          + 3.0/2*HPLs1[0]
          - 1.0/3*HPLs2[0*2+0]
          - 1.0/3*HPLs2[1*2+0]
          + 3.0/2*HPLs1[1]
          )

       + C_F*double_complex(0,1)*M_PI*u*pow(v,2) * (
          - 2.0/3*zeta2
          + 2*GHPLs1[2]
          + 2.0/3*GHPLs2[1*4+2]
          - 2.0/3*GHPLs2[2*4+3]
          + 2.0/3*GHPLs2[3*4+3]
          - 2*GHPLs1[3]
          + 2.0/3*GHPLs1[3]*HPLs1[0]
          + 2.0/3*GHPLs1[3]*HPLs1[1]
          - 2.0/3*GHPLs2[0*4+3]
          - 2.0/3*GHPLs2[3*4+0]
          + 2*GHPLs1[0]
          - 2.0/3*GHPLs1[0]*HPLs1[0]
          + 2.0/3*GHPLs2[2*4+1]
          - 2*GHPLs1[1]
          - 2.0/3*GHPLs1[1]*HPLs1[1]
          + 2.0/3*GHPLs2[0*4+1]
          - 2.0/3*GHPLs2[1*4+1]
          - 2*HPLs1[0]
          + 2.0/3*HPLs2[0*2+0]
          + 2.0/3*HPLs2[1*2+0]
          - 2*HPLs1[1]
          )

       + C_F*double_complex(0,1)*M_PI*pow(u,2)*v * (
          + GHPLs1[2]
          - GHPLs1[3]
          + GHPLs1[0]
          - GHPLs1[1]
          - HPLs1[0]
          - HPLs1[1]
          );
}

void beta_2_1(double u, double v, int n_f, double *GHPLs1, double *GHPLs2, double *GHPLs3, double *GHPLs4, double *HPLs1, double *HPLs2, double *HPLs3, double *HPLs4, double_complex &beta) {
  //  const double zeta2 = M_PI*M_PI/6;
  //  const double zeta3 = 1.20205690315959429;
  //  const double zeta4 = pow(M_PI,4)/90;
  //  const double dN_c=3;
  //  const double C_F=(dN_c*dN_c-1)/(2*dN_c);
  double NF=(double)n_f;

  beta =
    (dN_c*dN_c-1)*pow(u,-2) * (
          - 1.0/4*GHPLs3[3*4*4+2*4+2]*HPLs1[0]
          + 1.0/4*GHPLs4[0*4*4*4+3*4*4+2*4+2]
          + 1.0/4*GHPLs2[2*4+2]*zeta2
          - 1.0/4*GHPLs2[2*4+2]*HPLs2[0*2+0]
          + 1.0/4*GHPLs2[2*4+2]*HPLs2[0*2+1]
          + 1.0/4*GHPLs3[0*4*4+2*4+2]*HPLs1[0]
          + 1.0/4*GHPLs1[2]*zeta3
          + 1.0/4*GHPLs1[2]*HPLs1[0]*zeta2
          - 1.0/4*GHPLs1[2]*HPLs3[0*2*2+0*2+0]
          + 1.0/4*GHPLs1[2]*HPLs3[0*2*2+1*2+0]
          + 1.0/4*GHPLs1[2]*HPLs3[0*2*2+0*2+1]
          + 1.0/4*GHPLs3[3*4*4+0*4+2]*HPLs1[0]
          - 1.0/4*GHPLs4[0*4*4*4+3*4*4+0*4+2]
          + 1.0/4*GHPLs2[0*4+2]*HPLs2[0*2+0]
          - 1.0/4*GHPLs3[3*4*4+2*4+1]*HPLs1[0]
          + 1.0/4*GHPLs4[0*4*4*4+3*4*4+2*4+1]
          + 1.0/4*GHPLs2[2*4+1]*zeta2
          - 1.0/4*GHPLs2[2*4+1]*HPLs2[0*2+0]
          + 1.0/4*GHPLs2[2*4+1]*HPLs2[0*2+1]
          + 1.0/4*GHPLs3[0*4*4+2*4+1]*HPLs1[0]
          + 1.0/4*GHPLs1[1]*zeta3
          - 1.0/4*GHPLs1[1]*HPLs1[0]*zeta2
          + 1.0/4*GHPLs1[1]*HPLs3[0*2*2+0*2+0]
          - 1.0/4*GHPLs1[1]*HPLs3[0*2*2+1*2+0]
          - 1.0/4*GHPLs1[1]*HPLs1[1]*zeta2
          + 1.0/4*GHPLs1[1]*HPLs3[0*2*2+0*2+1]
          - 1.0/4*GHPLs1[1]*HPLs3[0*2*2+1*2+1]
          - 1.0/4*GHPLs3[3*4*4+0*4+1]*HPLs1[0]
          + 1.0/4*GHPLs4[0*4*4*4+3*4*4+0*4+1]
          - 1.0/2*GHPLs2[0*4+1]*zeta2
          - 1.0/4*GHPLs2[0*4+1]*HPLs2[0*2+0]
          - 1.0/4*GHPLs2[0*4+1]*HPLs2[0*2+1]
          )

       + (dN_c*dN_c-1)*pow(u,-2)*v * (
          + 1.0/4*GHPLs3[3*4*4+2*4+2]*HPLs1[0]
          - 1.0/4*GHPLs4[0*4*4*4+3*4*4+2*4+2]
          - 1.0/4*GHPLs2[2*4+2]*zeta2
          + 1.0/4*GHPLs2[2*4+2]*HPLs2[0*2+0]
          - 1.0/4*GHPLs2[2*4+2]*HPLs2[0*2+1]
          - 1.0/4*GHPLs3[0*4*4+2*4+2]*HPLs1[0]
          - 1.0/4*GHPLs1[2]*zeta3
          - 1.0/4*GHPLs1[2]*HPLs1[0]*zeta2
          + 1.0/4*GHPLs1[2]*HPLs3[0*2*2+0*2+0]
          - 1.0/4*GHPLs1[2]*HPLs3[0*2*2+1*2+0]
          - 1.0/4*GHPLs1[2]*HPLs3[0*2*2+0*2+1]
          - 1.0/4*GHPLs3[3*4*4+0*4+2]*HPLs1[0]
          + 1.0/4*GHPLs4[0*4*4*4+3*4*4+0*4+2]
          - 1.0/4*GHPLs2[0*4+2]*HPLs2[0*2+0]
          + 1.0/4*GHPLs3[3*4*4+2*4+1]*HPLs1[0]
          - 1.0/4*GHPLs4[0*4*4*4+3*4*4+2*4+1]
          - 1.0/4*GHPLs2[2*4+1]*zeta2
          + 1.0/4*GHPLs2[2*4+1]*HPLs2[0*2+0]
          - 1.0/4*GHPLs2[2*4+1]*HPLs2[0*2+1]
          - 1.0/4*GHPLs3[0*4*4+2*4+1]*HPLs1[0]
          - 1.0/4*GHPLs1[1]*zeta3
          + 1.0/4*GHPLs1[1]*HPLs1[0]*zeta2
          - 1.0/4*GHPLs1[1]*HPLs3[0*2*2+0*2+0]
          + 1.0/4*GHPLs1[1]*HPLs3[0*2*2+1*2+0]
          + 1.0/4*GHPLs1[1]*HPLs1[1]*zeta2
          - 1.0/4*GHPLs1[1]*HPLs3[0*2*2+0*2+1]
          + 1.0/4*GHPLs1[1]*HPLs3[0*2*2+1*2+1]
          + 1.0/4*GHPLs3[3*4*4+0*4+1]*HPLs1[0]
          - 1.0/4*GHPLs4[0*4*4*4+3*4*4+0*4+1]
          + 1.0/2*GHPLs2[0*4+1]*zeta2
          + 1.0/4*GHPLs2[0*4+1]*HPLs2[0*2+0]
          + 1.0/4*GHPLs2[0*4+1]*HPLs2[0*2+1]
          )

       + (dN_c*dN_c-1)*pow(u,-1) * (
          - 1.0/2
          + 1.0/2*zeta2
          + 1.0/2*zeta3
          - 1.0/2*GHPLs2[3*4+2]*HPLs1[0]
          + 1.0/2*GHPLs3[0*4*4+3*4+2]
          + 1.0/2*GHPLs1[2]*zeta2
          - 1.0/2*GHPLs1[2]*HPLs2[0*2+0]
          + 1.0/2*GHPLs1[2]*HPLs2[0*2+1]
          + 1.0/2*GHPLs2[0*4+2]*HPLs1[0]
          - 1.0/2*GHPLs1[0]*zeta2
          - 1.0/4*GHPLs1[0]*HPLs2[0*2+1]
          - 1.0/4*HPLs1[1]*zeta2
          + 1.0/4*HPLs2[0*2+1]
          + 1.0/2*HPLs3[0*2*2+0*2+1]
          - 1.0/4*HPLs3[0*2*2+1*2+1]
          )

       + (dN_c*dN_c-1)*pow(u,-1)*v * (
          - 1.0/2*zeta2
          - 1.0/4*zeta3
          - 1.0/4*GHPLs3[3*4*4+2*4+2]*HPLs1[0]
          + 1.0/4*GHPLs4[0*4*4*4+3*4*4+2*4+2]
          + 1.0/4*GHPLs2[2*4+2]*zeta2
          - 1.0/4*GHPLs2[2*4+2]*HPLs2[0*2+0]
          + 1.0/4*GHPLs2[2*4+2]*HPLs2[0*2+1]
          + 1.0/4*GHPLs3[0*4*4+2*4+2]*HPLs1[0]
          + 1.0/4*GHPLs2[3*4+2]*HPLs1[0]
          - 1.0/4*GHPLs3[0*4*4+3*4+2]
          - 1.0/4*GHPLs1[2]*zeta2
          + 1.0/4*GHPLs1[2]*zeta3
          + 1.0/4*GHPLs1[2]*HPLs1[0]*zeta2
          + 1.0/4*GHPLs1[2]*HPLs2[0*2+0]
          - 1.0/4*GHPLs1[2]*HPLs3[0*2*2+0*2+0]
          + 1.0/4*GHPLs1[2]*HPLs3[0*2*2+1*2+0]
          - 1.0/4*GHPLs1[2]*HPLs2[0*2+1]
          + 1.0/4*GHPLs1[2]*HPLs3[0*2*2+0*2+1]
          + 1.0/4*GHPLs3[3*4*4+0*4+2]*HPLs1[0]
          - 1.0/4*GHPLs4[0*4*4*4+3*4*4+0*4+2]
          - 1.0/4*GHPLs2[0*4+2]*HPLs1[0]
          + 1.0/4*GHPLs2[0*4+2]*HPLs2[0*2+0]
          - 1.0/4*GHPLs1[3]*HPLs1[0]
          + 1.0/4*GHPLs2[0*4+3]
          + 1.0/4*GHPLs2[3*4+0]*HPLs1[0]
          - 1.0/4*GHPLs3[0*4*4+3*4+0]
          + 1.0/2*GHPLs1[0]*zeta2
          + 1.0/4*GHPLs1[0]*HPLs2[0*2+0]
          + 1.0/4*GHPLs1[0]*HPLs2[0*2+1]
          - 1.0/4*GHPLs3[3*4*4+2*4+1]*HPLs1[0]
          + 1.0/4*GHPLs4[0*4*4*4+3*4*4+2*4+1]
          + 1.0/4*GHPLs2[2*4+1]*zeta2
          - 1.0/4*GHPLs2[2*4+1]*HPLs2[0*2+0]
          + 1.0/4*GHPLs2[2*4+1]*HPLs2[0*2+1]
          + 1.0/4*GHPLs3[0*4*4+2*4+1]*HPLs1[0]
          + 1.0/4*GHPLs1[1]*zeta3
          - 1.0/4*GHPLs1[1]*HPLs1[0]*zeta2
          + 1.0/4*GHPLs1[1]*HPLs3[0*2*2+0*2+0]
          - 1.0/4*GHPLs1[1]*HPLs3[0*2*2+1*2+0]
          - 1.0/4*GHPLs1[1]*HPLs1[1]*zeta2
          + 1.0/4*GHPLs1[1]*HPLs3[0*2*2+0*2+1]
          - 1.0/4*GHPLs1[1]*HPLs3[0*2*2+1*2+1]
          - 1.0/4*GHPLs3[3*4*4+0*4+1]*HPLs1[0]
          + 1.0/4*GHPLs4[0*4*4*4+3*4*4+0*4+1]
          - 1.0/2*GHPLs2[0*4+1]*zeta2
          - 1.0/4*GHPLs2[0*4+1]*HPLs2[0*2+0]
          - 1.0/4*GHPLs2[0*4+1]*HPLs2[0*2+1]
          + 1.0/4*HPLs1[0]*zeta2
          - 1.0/4*HPLs2[0*2+0]
          - 1.0/4*HPLs3[0*2*2+0*2+0]
          + 1.0/4*HPLs3[0*2*2+1*2+0]
          + 1.0/4*HPLs1[1]*zeta2
          - 1.0/4*HPLs2[0*2+1]
          - 1.0/4*HPLs3[0*2*2+0*2+1]
          + 1.0/4*HPLs3[0*2*2+1*2+1]
          )

       + (dN_c*dN_c-1)*pow(1-u,-1) * (
          - 1.0/4*zeta2
          + 1.0/4*GHPLs1[3]*HPLs1[0]
          - 1.0/4*GHPLs2[0*4+3]
          - 1.0/4*GHPLs1[0]*HPLs1[0]
          + 1.0/4*HPLs2[0*2+0]
          - 1.0/4*HPLs2[0*2+1]
          )

       + (dN_c*dN_c-1)*pow(1-v,-1) * (
          + 15.0/16*zeta2
          - 3.0/8*zeta3
          + 3.0/8*GHPLs2[3*4+2]*HPLs1[0]
          - 3.0/8*GHPLs3[0*4*4+3*4+2]
          - 3.0/8*GHPLs1[2]*zeta2
          + 3.0/8*GHPLs1[2]*HPLs2[0*2+0]
          - 3.0/8*GHPLs1[2]*HPLs2[0*2+1]
          - 3.0/8*GHPLs2[0*4+2]*HPLs1[0]
          - 1.0/8*GHPLs1[3]*HPLs1[0]
          + 1.0/8*GHPLs2[0*4+3]
          - 3.0/8*GHPLs2[3*4+0]*HPLs1[0]
          + 3.0/8*GHPLs3[0*4*4+3*4+0]
          + 15.0/16*GHPLs1[0]*HPLs1[0]
          - 3.0/8*GHPLs1[0]*HPLs2[0*2+0]
          - 263.0/96*HPLs1[0]
          - 3.0/8*HPLs1[0]*zeta2
          - 23.0/8*HPLs2[0*2+0]
          + 3.0/8*HPLs3[0*2*2+0*2+0]
          - 3.0/8*HPLs3[0*2*2+1*2+0]
          + 15.0/16*HPLs2[0*2+1]
          - 3.0/8*HPLs3[0*2*2+0*2+1]
          )

       + (dN_c*dN_c-1)*pow(u+v,-1) * (
          - 1.0/16
          - 1.0/16*GHPLs1[0]
          + 1.0/16*HPLs1[0]
          )

       + (dN_c*dN_c-1)*pow(1-u-v,-1) * (
          + 1.0/4*zeta2
          - 1.0/4*GHPLs1[3]*HPLs1[0]
          + 1.0/4*GHPLs2[0*4+3]
          + 1.0/4*GHPLs1[0]*HPLs1[0]
          - 1.0/4*HPLs2[0*2+0]
          + 1.0/4*HPLs2[0*2+1]
          )

       + (dN_c*dN_c-1) * (
          - 85799.0/10368
          + 39.0/32*zeta4
          + 7.0/36*zeta2
          + 611.0/144*zeta3
          + 1.0/4*GHPLs3[3*4*4+2*4+2]*HPLs1[0]
          - 1.0/4*GHPLs4[0*4*4*4+3*4*4+2*4+2]
          - 1.0/4*GHPLs2[2*4+2]*zeta2
          + 1.0/4*GHPLs2[2*4+2]*HPLs2[0*2+0]
          - 1.0/4*GHPLs2[2*4+2]*HPLs2[0*2+1]
          - 1.0/4*GHPLs3[0*4*4+2*4+2]*HPLs1[0]
          - 5.0/8*GHPLs2[3*4+2]*HPLs1[0]
          + 5.0/8*GHPLs3[0*4*4+3*4+2]
          + 5.0/8*GHPLs1[2]*zeta2
          - 1.0/4*GHPLs1[2]*zeta3
          - 1.0/4*GHPLs1[2]*HPLs1[0]*zeta2
          - 5.0/8*GHPLs1[2]*HPLs2[0*2+0]
          + 1.0/4*GHPLs1[2]*HPLs3[0*2*2+0*2+0]
          - 1.0/4*GHPLs1[2]*HPLs3[0*2*2+1*2+0]
          + 5.0/8*GHPLs1[2]*HPLs2[0*2+1]
          - 1.0/4*GHPLs1[2]*HPLs3[0*2*2+0*2+1]
          - 1.0/4*GHPLs3[3*4*4+0*4+2]*HPLs1[0]
          + 1.0/4*GHPLs4[0*4*4*4+3*4*4+0*4+2]
          + 5.0/8*GHPLs2[0*4+2]*HPLs1[0]
          - 1.0/4*GHPLs2[0*4+2]*HPLs2[0*2+0]
          + 1.0/4*GHPLs3[3*4*4+2*4+3]*HPLs1[0]
          - 1.0/4*GHPLs4[0*4*4*4+3*4*4+2*4+3]
          - 1.0/4*GHPLs2[2*4+3]*zeta2
          + 1.0/4*GHPLs2[2*4+3]*HPLs2[0*2+0]
          - 1.0/4*GHPLs2[2*4+3]*HPLs2[0*2+1]
          - 1.0/4*GHPLs3[0*4*4+2*4+3]*HPLs1[0]
          + 1.0/2*GHPLs3[3*4*4+3*4+3]*HPLs1[0]
          - 1.0/2*GHPLs4[0*4*4*4+3*4*4+3*4+3]
          - GHPLs2[3*4+3]*zeta2
          + 11.0/12*GHPLs2[3*4+3]*HPLs1[0]
          + 1.0/2*GHPLs2[3*4+3]*HPLs2[0*2+0]
          - 11.0/12*GHPLs3[0*4*4+3*4+3]
          - 1.0/2*GHPLs3[0*4*4+3*4+3]*HPLs1[0]
          + 1.0/2*GHPLs4[0*4*4*4+0*4*4+3*4+3]
          - 11.0/6*GHPLs1[3]*zeta2
          - 1.0/2*GHPLs1[3]*zeta3
          - 277.0/144*GHPLs1[3]*HPLs1[0]
          - 5.0/4*GHPLs1[3]*HPLs1[0]*zeta2
          - 11.0/12*GHPLs1[3]*HPLs2[0*2+0]
          + 3.0/4*GHPLs1[3]*HPLs3[0*2*2+0*2+0]
          - 1.0/4*GHPLs1[3]*HPLs3[0*2*2+1*2+0]
          + 1.0/4*GHPLs1[3]*HPLs1[1]*zeta2
          - 1.0/4*GHPLs1[3]*HPLs3[0*2*2+0*2+1]
          + 1.0/4*GHPLs1[3]*HPLs3[0*2*2+1*2+1]
          - 3.0/4*GHPLs3[3*4*4+0*4+3]*HPLs1[0]
          + 3.0/4*GHPLs4[0*4*4*4+3*4*4+0*4+3]
          + 277.0/144*GHPLs2[0*4+3]
          - 1.0/4*GHPLs2[0*4+3]*zeta2
          + 11.0/12*GHPLs2[0*4+3]*HPLs1[0]
          - 3.0/4*GHPLs2[0*4+3]*HPLs2[0*2+0]
          + 1.0/4*GHPLs2[0*4+3]*HPLs2[0*2+1]
          - 11.0/12*GHPLs3[0*4*4+0*4+3]
          + 1.0/2*GHPLs3[0*4*4+0*4+3]*HPLs1[0]
          - 1.0/2*GHPLs3[3*4*4+2*4+0]*HPLs1[0]
          + 1.0/2*GHPLs4[0*4*4*4+3*4*4+2*4+0]
          + 1.0/2*GHPLs2[2*4+0]*zeta2
          - 1.0/2*GHPLs2[2*4+0]*HPLs2[0*2+0]
          + 1.0/2*GHPLs2[2*4+0]*HPLs2[0*2+1]
          + 1.0/2*GHPLs3[0*4*4+2*4+0]*HPLs1[0]
          - 1.0/2*GHPLs3[3*4*4+3*4+0]*HPLs1[0]
          + 1.0/2*GHPLs4[0*4*4*4+3*4*4+3*4+0]
          - 1.0/2*GHPLs2[3*4+0]*zeta2
          + 3.0/8*GHPLs2[3*4+0]*HPLs1[0]
          - 1.0/2*GHPLs2[3*4+0]*HPLs2[0*2+0]
          - 3.0/8*GHPLs3[0*4*4+3*4+0]
          + 1.0/4*GHPLs3[0*4*4+3*4+0]*HPLs1[0]
          + 1.0/3*GHPLs1[0]
          - 7.0/6*GHPLs1[0]*zeta2
          + 10.0/9*GHPLs1[0]*HPLs1[0]
          - 1.0/4*GHPLs1[0]*HPLs1[0]*zeta2
          + 53.0/24*GHPLs1[0]*HPLs2[0*2+0]
          - 3.0/4*GHPLs1[0]*HPLs3[0*2*2+0*2+0]
          + 1.0/4*GHPLs1[0]*HPLs3[0*2*2+1*2+0]
          - 25.0/24*GHPLs1[0]*HPLs2[0*2+1]
          + 1.0/2*GHPLs1[0]*HPLs3[0*2*2+0*2+1]
          + 1.0/2*GHPLs3[3*4*4+0*4+0]*HPLs1[0]
          - 1.0/2*GHPLs4[0*4*4*4+3*4*4+0*4+0]
          - 11.0/12*GHPLs2[0*4+0]*HPLs1[0]
          + 1.0/2*GHPLs2[0*4+0]*HPLs2[0*2+0]
          + 1.0/4*GHPLs3[3*4*4+2*4+1]*HPLs1[0]
          - 1.0/4*GHPLs4[0*4*4*4+3*4*4+2*4+1]
          - 1.0/4*GHPLs2[2*4+1]*zeta2
          + 1.0/4*GHPLs2[2*4+1]*HPLs2[0*2+0]
          - 1.0/4*GHPLs2[2*4+1]*HPLs2[0*2+1]
          - 1.0/4*GHPLs3[0*4*4+2*4+1]*HPLs1[0]
          - 1.0/4*GHPLs1[1]*zeta3
          + 1.0/4*GHPLs1[1]*HPLs1[0]*zeta2
          - 1.0/4*GHPLs1[1]*HPLs3[0*2*2+0*2+0]
          + 1.0/4*GHPLs1[1]*HPLs3[0*2*2+1*2+0]
          + 1.0/4*GHPLs1[1]*HPLs1[1]*zeta2
          - 1.0/4*GHPLs1[1]*HPLs3[0*2*2+0*2+1]
          + 1.0/4*GHPLs1[1]*HPLs3[0*2*2+1*2+1]
          + 1.0/4*GHPLs3[3*4*4+0*4+1]*HPLs1[0]
          - 1.0/4*GHPLs4[0*4*4*4+3*4*4+0*4+1]
          + 1.0/2*GHPLs2[0*4+1]*zeta2
          + 1.0/4*GHPLs2[0*4+1]*HPLs2[0*2+0]
          + 1.0/4*GHPLs2[0*4+1]*HPLs2[0*2+1]
          - 529.0/432*HPLs1[0]
          - 59.0/48*HPLs1[0]*zeta2
          + 5.0/4*HPLs1[0]*zeta3
          + 119.0/144*HPLs2[0*2+0]
          - 5.0/4*HPLs2[0*2+0]*zeta2
          - 53.0/24*HPLs3[0*2*2+0*2+0]
          + 3.0/4*HPLs4[0*2*2*2+0*2*2+0*2+0]
          - 1.0/4*HPLs4[0*2*2*2+1*2*2+0*2+0]
          + 1.0/4*HPLs2[1*2+0]*zeta2
          + 31.0/24*HPLs3[0*2*2+1*2+0]
          - 1.0/4*HPLs4[0*2*2*2+0*2*2+1*2+0]
          + 1.0/4*HPLs4[0*2*2*2+1*2*2+1*2+0]
          - 25.0/24*HPLs1[1]*zeta2
          + 1.0/2*HPLs1[1]*zeta3
          + 31.0/36*HPLs2[0*2+1]
          + 1.0/2*HPLs2[0*2+1]*zeta2
          + 59.0/24*HPLs3[0*2*2+0*2+1]
          - 1.0/2*HPLs4[0*2*2*2+0*2*2+0*2+1]
          + 1.0/2*HPLs4[0*2*2*2+1*2*2+0*2+1]
          - 25.0/24*HPLs3[0*2*2+1*2+1]
          + 1.0/2*HPLs4[0*2*2*2+0*2*2+1*2+1]
          )

       + (dN_c*dN_c-1)*v*pow(1-u,-2) * (
          - 1.0/4*zeta3
          + 1.0/4*GHPLs2[3*4+2]*HPLs1[0]
          - 1.0/4*GHPLs3[0*4*4+3*4+2]
          - 1.0/4*GHPLs1[2]*zeta2
          + 1.0/4*GHPLs1[2]*HPLs2[0*2+0]
          - 1.0/4*GHPLs1[2]*HPLs2[0*2+1]
          - 1.0/4*GHPLs2[0*4+2]*HPLs1[0]
          + 1.0/4*GHPLs2[3*4+0]*HPLs1[0]
          - 1.0/4*GHPLs3[0*4*4+3*4+0]
          + 1.0/2*GHPLs1[0]*zeta2
          + 1.0/4*GHPLs1[0]*HPLs2[0*2+0]
          + 1.0/4*GHPLs1[0]*HPLs2[0*2+1]
          + 1.0/4*HPLs1[0]*zeta2
          - 1.0/4*HPLs3[0*2*2+0*2+0]
          + 1.0/4*HPLs3[0*2*2+1*2+0]
          + 1.0/4*HPLs1[1]*zeta2
          - 1.0/4*HPLs3[0*2*2+0*2+1]
          + 1.0/4*HPLs3[0*2*2+1*2+1]
          )

       + (dN_c*dN_c-1)*v*pow(1-u,-1) * (
          + 1.0/2*zeta2
          + 3.0/8*zeta3
          - 3.0/8*GHPLs2[3*4+2]*HPLs1[0]
          + 3.0/8*GHPLs3[0*4*4+3*4+2]
          + 3.0/8*GHPLs1[2]*zeta2
          - 3.0/8*GHPLs1[2]*HPLs2[0*2+0]
          + 3.0/8*GHPLs1[2]*HPLs2[0*2+1]
          + 3.0/8*GHPLs2[0*4+2]*HPLs1[0]
          + 1.0/4*GHPLs1[3]*HPLs1[0]
          - 1.0/4*GHPLs2[0*4+3]
          - 3.0/8*GHPLs2[3*4+0]*HPLs1[0]
          + 3.0/8*GHPLs3[0*4*4+3*4+0]
          - 3.0/4*GHPLs1[0]*zeta2
          - 3.0/8*GHPLs1[0]*HPLs2[0*2+0]
          - 3.0/8*GHPLs1[0]*HPLs2[0*2+1]
          - 3.0/8*HPLs1[0]*zeta2
          + 1.0/4*HPLs2[0*2+0]
          + 3.0/8*HPLs3[0*2*2+0*2+0]
          - 3.0/8*HPLs3[0*2*2+1*2+0]
          - 3.0/8*HPLs1[1]*zeta2
          + 1.0/4*HPLs2[0*2+1]
          + 3.0/8*HPLs3[0*2*2+0*2+1]
          - 3.0/8*HPLs3[0*2*2+1*2+1]
          )

       + (dN_c*dN_c-1)*u*pow(1-v,-2) * (
          - 13.0/48*zeta2
          + 1.0/8*zeta3
          - 1.0/8*GHPLs2[3*4+2]*HPLs1[0]
          + 1.0/8*GHPLs3[0*4*4+3*4+2]
          + 1.0/8*GHPLs1[2]*zeta2
          - 1.0/8*GHPLs1[2]*HPLs2[0*2+0]
          + 1.0/8*GHPLs1[2]*HPLs2[0*2+1]
          + 1.0/8*GHPLs2[0*4+2]*HPLs1[0]
          + 1.0/8*GHPLs2[3*4+0]*HPLs1[0]
          - 1.0/8*GHPLs3[0*4*4+3*4+0]
          - 13.0/48*GHPLs1[0]*HPLs1[0]
          + 1.0/8*GHPLs1[0]*HPLs2[0*2+0]
          + 163.0/288*HPLs1[0]
          + 1.0/8*HPLs1[0]*zeta2
          + 11.0/12*HPLs2[0*2+0]
          - 1.0/8*HPLs3[0*2*2+0*2+0]
          + 1.0/8*HPLs3[0*2*2+1*2+0]
          - 13.0/48*HPLs2[0*2+1]
          + 1.0/8*HPLs3[0*2*2+0*2+1]
          )

       + (dN_c*dN_c-1)*u*pow(1-v,-1) * (
          + 277.0/288
          + 19.0/48*zeta2
          - 1.0/8*zeta3
          + 1.0/8*GHPLs2[3*4+2]*HPLs1[0]
          - 1.0/8*GHPLs3[0*4*4+3*4+2]
          - 1.0/8*GHPLs1[2]*zeta2
          + 1.0/8*GHPLs1[2]*HPLs2[0*2+0]
          - 1.0/8*GHPLs1[2]*HPLs2[0*2+1]
          - 1.0/8*GHPLs2[0*4+2]*HPLs1[0]
          - 1.0/8*GHPLs1[3]*HPLs1[0]
          + 1.0/8*GHPLs2[0*4+3]
          - 1.0/8*GHPLs2[3*4+0]*HPLs1[0]
          + 1.0/8*GHPLs3[0*4*4+3*4+0]
          - 19.0/48*GHPLs1[0]
          + 19.0/48*GHPLs1[0]*HPLs1[0]
          - 1.0/8*GHPLs1[0]*HPLs2[0*2+0]
          - 31.0/288*HPLs1[0]
          - 1.0/8*HPLs1[0]*zeta2
          - 25.0/24*HPLs2[0*2+0]
          + 1.0/8*HPLs3[0*2*2+0*2+0]
          - 1.0/8*HPLs3[0*2*2+1*2+0]
          + 19.0/48*HPLs2[0*2+1]
          - 1.0/8*HPLs3[0*2*2+0*2+1]
          )

       + (dN_c*dN_c-1)*u*pow(u+v,-2) * (
          + 1.0/16*GHPLs1[0]
          - 1.0/16*HPLs1[0]
          )

       + (dN_c*dN_c-1)*u*pow(u+v,-1) * (
          - 5.0/16*GHPLs1[0]
          + 5.0/16*HPLs1[0]
          )

       + (dN_c*dN_c-1)*u*pow(1-u-v,-1) * (
          - 3.0/8*zeta2
          + 3.0/8*GHPLs1[3]*HPLs1[0]
          - 3.0/8*GHPLs2[0*4+3]
          - 3.0/8*GHPLs1[0]*HPLs1[0]
          + 3.0/8*HPLs2[0*2+0]
          - 3.0/8*HPLs2[0*2+1]
          )

       + (dN_c*dN_c-1)*double_complex(0,1)*M_PI*pow(u,-2) * (
          + 1.0/4*GHPLs3[3*4*4+2*4+2]
          + 1.0/4*GHPLs2[2*4+2]*HPLs1[0]
          + 1.0/4*GHPLs1[2]*HPLs2[0*2+0]
          - 1.0/4*GHPLs3[3*4*4+0*4+2]
          + 1.0/4*GHPLs3[3*4*4+2*4+1]
          + 1.0/4*GHPLs2[2*4+1]*HPLs1[0]
          - 1.0/2*GHPLs1[1]*zeta2
          - 1.0/4*GHPLs1[1]*HPLs2[0*2+0]
          - 1.0/4*GHPLs1[1]*HPLs2[0*2+1]
          + 1.0/4*GHPLs3[3*4*4+0*4+1]
          )

       + (dN_c*dN_c-1)*double_complex(0,1)*M_PI*pow(u,-2)*v * (
          - 1.0/4*GHPLs3[3*4*4+2*4+2]
          - 1.0/4*GHPLs2[2*4+2]*HPLs1[0]
          - 1.0/4*GHPLs1[2]*HPLs2[0*2+0]
          + 1.0/4*GHPLs3[3*4*4+0*4+2]
          - 1.0/4*GHPLs3[3*4*4+2*4+1]
          - 1.0/4*GHPLs2[2*4+1]*HPLs1[0]
          + 1.0/2*GHPLs1[1]*zeta2
          + 1.0/4*GHPLs1[1]*HPLs2[0*2+0]
          + 1.0/4*GHPLs1[1]*HPLs2[0*2+1]
          - 1.0/4*GHPLs3[3*4*4+0*4+1]
          )

       + (dN_c*dN_c-1)*double_complex(0,1)*M_PI*pow(u,-1) * (
          - 1.0/2*zeta2
          + 1.0/2*GHPLs2[3*4+2]
          + 1.0/2*GHPLs1[2]*HPLs1[0]
          - 1.0/4*HPLs2[0*2+1]
          )

       + (dN_c*dN_c-1)*double_complex(0,1)*M_PI*pow(u,-1)*v * (
          + 1.0/2*zeta2
          + 1.0/4*GHPLs3[3*4*4+2*4+2]
          + 1.0/4*GHPLs2[2*4+2]*HPLs1[0]
          - 1.0/4*GHPLs2[3*4+2]
          - 1.0/4*GHPLs1[2]*HPLs1[0]
          + 1.0/4*GHPLs1[2]*HPLs2[0*2+0]
          - 1.0/4*GHPLs3[3*4*4+0*4+2]
          + 1.0/4*GHPLs1[3]
          - 1.0/4*GHPLs2[3*4+0]
          + 1.0/4*GHPLs3[3*4*4+2*4+1]
          + 1.0/4*GHPLs2[2*4+1]*HPLs1[0]
          - 1.0/2*GHPLs1[1]*zeta2
          - 1.0/4*GHPLs1[1]*HPLs2[0*2+0]
          - 1.0/4*GHPLs1[1]*HPLs2[0*2+1]
          + 1.0/4*GHPLs3[3*4*4+0*4+1]
          + 1.0/4*HPLs2[0*2+0]
          + 1.0/4*HPLs2[0*2+1]
          )

       + (dN_c*dN_c-1)*double_complex(0,1)*M_PI*pow(1-u,-1) * (
          - 1.0/4*GHPLs1[3]
          - 1.0/4*HPLs1[0]
          )

       + (dN_c*dN_c-1)*double_complex(0,1)*M_PI*pow(1-v,-1) * (
          - 3.0/8*GHPLs2[3*4+2]
          - 3.0/8*GHPLs1[2]*HPLs1[0]
          + 1.0/8*GHPLs1[3]
          + 3.0/8*GHPLs2[3*4+0]
          - 7.0/16*HPLs1[0]
          - 3.0/8*HPLs2[0*2+0]
          )

       + (dN_c*dN_c-1)*double_complex(0,1)*M_PI*pow(u+v,-1) * (
          - 1.0/16
          )

       + (dN_c*dN_c-1)*double_complex(0,1)*M_PI*pow(1-u-v,-1) * (
          + 1.0/4*GHPLs1[3]
          + 1.0/4*HPLs1[0]
          )

       + (dN_c*dN_c-1)*double_complex(0,1)*M_PI * (
          - 2867.0/864
          - 15.0/16*zeta2
          + 7.0/4*zeta3
          - 1.0/4*GHPLs3[3*4*4+2*4+2]
          - 1.0/4*GHPLs2[2*4+2]*HPLs1[0]
          + 5.0/8*GHPLs2[3*4+2]
          + 5.0/8*GHPLs1[2]*HPLs1[0]
          - 1.0/4*GHPLs1[2]*HPLs2[0*2+0]
          + 1.0/4*GHPLs3[3*4*4+0*4+2]
          - 1.0/4*GHPLs3[3*4*4+2*4+3]
          - 1.0/4*GHPLs2[2*4+3]*HPLs1[0]
          - 1.0/2*GHPLs3[3*4*4+3*4+3]
          - 11.0/12*GHPLs2[3*4+3]
          - 1.0/2*GHPLs2[3*4+3]*HPLs1[0]
          + 1.0/2*GHPLs3[0*4*4+3*4+3]
          + 277.0/144*GHPLs1[3]
          - 1.0/4*GHPLs1[3]*zeta2
          - 3.0/4*GHPLs1[3]*HPLs2[0*2+0]
          + 1.0/4*GHPLs1[3]*HPLs2[0*2+1]
          + 3.0/4*GHPLs3[3*4*4+0*4+3]
          + 1.0/2*GHPLs2[0*4+3]*HPLs1[0]
          + 1.0/2*GHPLs3[3*4*4+2*4+0]
          + 1.0/2*GHPLs2[2*4+0]*HPLs1[0]
          + 1.0/2*GHPLs3[3*4*4+3*4+0]
          - 3.0/8*GHPLs2[3*4+0]
          + 1.0/4*GHPLs2[3*4+0]*HPLs1[0]
          + 1.0/2*GHPLs1[0]*HPLs2[0*2+0]
          - 1.0/2*GHPLs3[3*4*4+0*4+0]
          - 1.0/4*GHPLs3[3*4*4+2*4+1]
          - 1.0/4*GHPLs2[2*4+1]*HPLs1[0]
          + 1.0/2*GHPLs1[1]*zeta2
          + 1.0/4*GHPLs1[1]*HPLs2[0*2+0]
          + 1.0/4*GHPLs1[1]*HPLs2[0*2+1]
          - 1.0/4*GHPLs3[3*4*4+0*4+1]
          + 179.0/72*HPLs1[0]
          - 1.0/4*HPLs1[0]*zeta2
          + 31.0/24*HPLs2[0*2+0]
          - 3.0/4*HPLs3[0*2*2+0*2+0]
          + 1.0/4*HPLs3[0*2*2+1*2+0]
          - 1.0/8*HPLs2[0*2+1]
          + 1.0/2*HPLs3[0*2*2+0*2+1]
          )

       + (dN_c*dN_c-1)*double_complex(0,1)*M_PI*v*pow(1-u,-2) * (
          + 1.0/2*zeta2
          - 1.0/4*GHPLs2[3*4+2]
          - 1.0/4*GHPLs1[2]*HPLs1[0]
          - 1.0/4*GHPLs2[3*4+0]
          + 1.0/4*HPLs2[0*2+0]
          + 1.0/4*HPLs2[0*2+1]
          )

       + (dN_c*dN_c-1)*double_complex(0,1)*M_PI*v*pow(1-u,-1) * (
          - 3.0/4*zeta2
          + 3.0/8*GHPLs2[3*4+2]
          + 3.0/8*GHPLs1[2]*HPLs1[0]
          - 1.0/4*GHPLs1[3]
          + 3.0/8*GHPLs2[3*4+0]
          - 3.0/8*HPLs2[0*2+0]
          - 3.0/8*HPLs2[0*2+1]
          )

       + (dN_c*dN_c-1)*double_complex(0,1)*M_PI*u*pow(1-v,-2) * (
          + 1.0/8*GHPLs2[3*4+2]
          + 1.0/8*GHPLs1[2]*HPLs1[0]
          - 1.0/8*GHPLs2[3*4+0]
          + 3.0/16*HPLs1[0]
          + 1.0/8*HPLs2[0*2+0]
          )

       + (dN_c*dN_c-1)*double_complex(0,1)*M_PI*u*pow(1-v,-1) * (
          + 1.0/16
          - 1.0/8*GHPLs2[3*4+2]
          - 1.0/8*GHPLs1[2]*HPLs1[0]
          + 1.0/8*GHPLs1[3]
          + 1.0/8*GHPLs2[3*4+0]
          - 1.0/16*HPLs1[0]
          - 1.0/8*HPLs2[0*2+0]
          )

       + (dN_c*dN_c-1)*double_complex(0,1)*M_PI*u*pow(u+v,-2) * (
          + 1.0/16
          )

       + (dN_c*dN_c-1)*double_complex(0,1)*M_PI*u*pow(u+v,-1) * (
          - 5.0/16
          )

       + (dN_c*dN_c-1)*double_complex(0,1)*M_PI*u*pow(1-u-v,-1) * (
          - 3.0/8*GHPLs1[3]
          - 3.0/8*HPLs1[0]
          )

       + (dN_c*dN_c-1)/(dN_c*dN_c)*pow(u,-2) * (
          + 1.0/4*GHPLs3[3*4*4+2*4+2]*HPLs1[0]
          - 1.0/4*GHPLs4[0*4*4*4+3*4*4+2*4+2]
          - 1.0/4*GHPLs2[2*4+2]*zeta2
          + 1.0/4*GHPLs2[2*4+2]*HPLs2[0*2+0]
          - 1.0/4*GHPLs2[2*4+2]*HPLs2[0*2+1]
          - 1.0/4*GHPLs3[0*4*4+2*4+2]*HPLs1[0]
          + 3.0/8*GHPLs1[2]*zeta2
          - 1.0/4*GHPLs1[2]*zeta3
          + 1.0/4*GHPLs1[2]*HPLs1[0]
          - 1.0/4*GHPLs1[2]*HPLs1[0]*zeta2
          - 1.0/8*GHPLs1[2]*HPLs2[0*2+0]
          + 1.0/4*GHPLs1[2]*HPLs3[0*2*2+0*2+0]
          - 1.0/4*GHPLs1[2]*HPLs2[1*2+0]
          - 1.0/4*GHPLs1[2]*HPLs3[0*2*2+1*2+0]
          + 1.0/8*GHPLs1[2]*HPLs2[0*2+1]
          - 1.0/4*GHPLs1[2]*HPLs3[0*2*2+0*2+1]
          - 1.0/4*GHPLs3[3*4*4+0*4+2]*HPLs1[0]
          + 1.0/4*GHPLs4[0*4*4*4+3*4*4+0*4+2]
          - 1.0/4*GHPLs2[0*4+2]*HPLs2[0*2+0]
          - 1.0/4*GHPLs3[2*4*4+1*4+2]
          + 1.0/4*GHPLs2[1*4+2]*HPLs1[0]
          + 1.0/4*GHPLs2[1*4+2]*HPLs1[1]
          + 1.0/8*GHPLs2[2*4+0]*HPLs1[0]
          + 1.0/8*GHPLs3[2*4*4+1*4+0]
          - 1.0/8*GHPLs2[1*4+0]*HPLs1[0]
          - 1.0/8*GHPLs2[1*4+0]*HPLs1[1]
          + 1.0/4*GHPLs3[3*4*4+2*4+1]*HPLs1[0]
          - 1.0/4*GHPLs4[0*4*4*4+3*4*4+2*4+1]
          + 1.0/4*GHPLs2[2*4+1]
          - 1.0/4*GHPLs2[2*4+1]*zeta2
          + 1.0/4*GHPLs2[2*4+1]*HPLs2[0*2+0]
          - 1.0/4*GHPLs2[2*4+1]*HPLs2[0*2+1]
          - 1.0/4*GHPLs3[0*4*4+2*4+1]*HPLs1[0]
          - 1.0/4*GHPLs1[1]*zeta2
          - 1.0/4*GHPLs1[1]*zeta3
          - 1.0/4*GHPLs1[1]*HPLs1[0]
          + 1.0/4*GHPLs1[1]*HPLs1[0]*zeta2
          + 1.0/8*GHPLs1[1]*HPLs2[0*2+0]
          - 1.0/4*GHPLs1[1]*HPLs3[0*2*2+0*2+0]
          + 1.0/8*GHPLs1[1]*HPLs2[1*2+0]
          + 1.0/4*GHPLs1[1]*HPLs3[0*2*2+1*2+0]
          - 1.0/4*GHPLs1[1]*HPLs1[1]
          + 1.0/4*GHPLs1[1]*HPLs1[1]*zeta2
          - 1.0/4*GHPLs1[1]*HPLs3[0*2*2+0*2+1]
          + 1.0/4*GHPLs1[1]*HPLs3[0*2*2+1*2+1]
          + 1.0/4*GHPLs3[3*4*4+0*4+1]*HPLs1[0]
          - 1.0/4*GHPLs4[0*4*4*4+3*4*4+0*4+1]
          + 1.0/2*GHPLs2[0*4+1]*zeta2
          + 1.0/4*GHPLs2[0*4+1]*HPLs2[0*2+0]
          + 1.0/4*GHPLs2[0*4+1]*HPLs2[0*2+1]
          + 1.0/8*GHPLs3[2*4*4+1*4+1]
          - 1.0/8*GHPLs2[1*4+1]*HPLs1[0]
          - 1.0/8*GHPLs2[1*4+1]*HPLs1[1]
          )

       + (dN_c*dN_c-1)/(dN_c*dN_c)*pow(u,-2)*v * (
          - 1.0/4*GHPLs3[3*4*4+2*4+2]*HPLs1[0]
          + 1.0/4*GHPLs4[0*4*4*4+3*4*4+2*4+2]
          + 1.0/4*GHPLs2[2*4+2]*zeta2
          - 1.0/4*GHPLs2[2*4+2]*HPLs2[0*2+0]
          + 1.0/4*GHPLs2[2*4+2]*HPLs2[0*2+1]
          + 1.0/4*GHPLs3[0*4*4+2*4+2]*HPLs1[0]
          - 3.0/8*GHPLs1[2]*zeta2
          + 1.0/4*GHPLs1[2]*zeta3
          - 1.0/8*GHPLs1[2]*HPLs1[0]
          + 1.0/4*GHPLs1[2]*HPLs1[0]*zeta2
          + 1.0/8*GHPLs1[2]*HPLs2[0*2+0]
          - 1.0/4*GHPLs1[2]*HPLs3[0*2*2+0*2+0]
          + 1.0/4*GHPLs1[2]*HPLs2[1*2+0]
          + 1.0/4*GHPLs1[2]*HPLs3[0*2*2+1*2+0]
          - 1.0/8*GHPLs1[2]*HPLs2[0*2+1]
          + 1.0/4*GHPLs1[2]*HPLs3[0*2*2+0*2+1]
          + 1.0/4*GHPLs3[3*4*4+0*4+2]*HPLs1[0]
          - 1.0/4*GHPLs4[0*4*4*4+3*4*4+0*4+2]
          + 1.0/4*GHPLs2[0*4+2]*HPLs2[0*2+0]
          + 1.0/4*GHPLs3[2*4*4+1*4+2]
          - 1.0/4*GHPLs2[1*4+2]*HPLs1[0]
          - 1.0/4*GHPLs2[1*4+2]*HPLs1[1]
          - 1.0/8*GHPLs2[2*4+0]*HPLs1[0]
          - 1.0/8*GHPLs3[2*4*4+1*4+0]
          + 1.0/8*GHPLs2[1*4+0]*HPLs1[0]
          + 1.0/8*GHPLs2[1*4+0]*HPLs1[1]
          - 1.0/4*GHPLs3[3*4*4+2*4+1]*HPLs1[0]
          + 1.0/4*GHPLs4[0*4*4*4+3*4*4+2*4+1]
          - 1.0/8*GHPLs2[2*4+1]
          + 1.0/4*GHPLs2[2*4+1]*zeta2
          - 1.0/4*GHPLs2[2*4+1]*HPLs2[0*2+0]
          + 1.0/4*GHPLs2[2*4+1]*HPLs2[0*2+1]
          + 1.0/4*GHPLs3[0*4*4+2*4+1]*HPLs1[0]
          + 1.0/4*GHPLs1[1]*zeta2
          + 1.0/4*GHPLs1[1]*zeta3
          + 1.0/8*GHPLs1[1]*HPLs1[0]
          - 1.0/4*GHPLs1[1]*HPLs1[0]*zeta2
          - 1.0/8*GHPLs1[1]*HPLs2[0*2+0]
          + 1.0/4*GHPLs1[1]*HPLs3[0*2*2+0*2+0]
          - 1.0/8*GHPLs1[1]*HPLs2[1*2+0]
          - 1.0/4*GHPLs1[1]*HPLs3[0*2*2+1*2+0]
          + 1.0/8*GHPLs1[1]*HPLs1[1]
          - 1.0/4*GHPLs1[1]*HPLs1[1]*zeta2
          + 1.0/4*GHPLs1[1]*HPLs3[0*2*2+0*2+1]
          - 1.0/4*GHPLs1[1]*HPLs3[0*2*2+1*2+1]
          - 1.0/4*GHPLs3[3*4*4+0*4+1]*HPLs1[0]
          + 1.0/4*GHPLs4[0*4*4*4+3*4*4+0*4+1]
          - 1.0/2*GHPLs2[0*4+1]*zeta2
          - 1.0/4*GHPLs2[0*4+1]*HPLs2[0*2+0]
          - 1.0/4*GHPLs2[0*4+1]*HPLs2[0*2+1]
          - 1.0/8*GHPLs3[2*4*4+1*4+1]
          + 1.0/8*GHPLs2[1*4+1]*HPLs1[0]
          + 1.0/8*GHPLs2[1*4+1]*HPLs1[1]
          )

       + (dN_c*dN_c-1)/(dN_c*dN_c)*pow(u,-2)*pow(v,2) * (
          - 1.0/8*GHPLs1[2]*zeta2
          - 1.0/8*GHPLs1[2]*HPLs1[0]
          - 1.0/8*GHPLs1[2]*HPLs2[0*2+0]
          + 1.0/8*GHPLs1[2]*HPLs2[1*2+0]
          + 1.0/8*GHPLs2[0*4+2]*HPLs1[0]
          + 1.0/8*GHPLs3[2*4*4+1*4+2]
          - 1.0/8*GHPLs2[1*4+2]*HPLs1[0]
          - 1.0/8*GHPLs2[1*4+2]*HPLs1[1]
          + 1.0/8*GHPLs2[2*4+3]*HPLs1[0]
          - 1.0/8*GHPLs3[0*4*4+2*4+3]
          - 1.0/8*GHPLs2[3*4+3]*HPLs1[0]
          + 1.0/8*GHPLs3[0*4*4+3*4+3]
          + 5.0/8*GHPLs1[3]*zeta2
          - 1.0/8*GHPLs1[3]*HPLs2[1*2+0]
          - 1.0/8*GHPLs1[3]*HPLs2[0*2+1]
          - 1.0/8*GHPLs3[2*4*4+0*4+3]
          + 1.0/8*GHPLs2[0*4+3]*HPLs1[1]
          - 1.0/8*GHPLs2[2*4+1]
          + 1.0/8*GHPLs1[1]*HPLs1[0]
          + 1.0/8*GHPLs1[1]*HPLs1[1]
          )

       + (dN_c*dN_c-1)/(dN_c*dN_c)*pow(u,-2)*pow(v,3) * (
          + 1.0/8*GHPLs1[2]*zeta2
          + 1.0/8*GHPLs1[2]*HPLs2[0*2+0]
          - 1.0/8*GHPLs1[2]*HPLs2[1*2+0]
          - 1.0/8*GHPLs2[0*4+2]*HPLs1[0]
          - 1.0/8*GHPLs3[2*4*4+1*4+2]
          + 1.0/8*GHPLs2[1*4+2]*HPLs1[0]
          + 1.0/8*GHPLs2[1*4+2]*HPLs1[1]
          - 1.0/8*GHPLs2[2*4+3]*HPLs1[0]
          + 1.0/8*GHPLs3[0*4*4+2*4+3]
          + 1.0/8*GHPLs2[3*4+3]*HPLs1[0]
          - 1.0/8*GHPLs3[0*4*4+3*4+3]
          - 5.0/8*GHPLs1[3]*zeta2
          + 1.0/8*GHPLs1[3]*HPLs2[1*2+0]
          + 1.0/8*GHPLs1[3]*HPLs2[0*2+1]
          + 1.0/8*GHPLs3[2*4*4+0*4+3]
          - 1.0/8*GHPLs2[0*4+3]*HPLs1[1]
          )

       + (dN_c*dN_c-1)/(dN_c*dN_c)*pow(u,-1)*pow(u+v,-1) * (
          - 1.0/8*GHPLs1[2]*HPLs1[0]
          - 1.0/8*GHPLs2[2*4+1]
          + 1.0/8*GHPLs1[1]*HPLs1[0]
          + 1.0/8*GHPLs1[1]*HPLs1[1]
          )

       + (dN_c*dN_c-1)/(dN_c*dN_c)*pow(u,-1) * (
          + 1.0/2
          - 3.0/8*zeta2
          - 1.0/2*zeta3
          + 1.0/2*GHPLs2[3*4+2]*HPLs1[0]
          - 1.0/2*GHPLs3[0*4*4+3*4+2]
          + 3.0/8*GHPLs1[2]
          - 2*GHPLs1[2]*zeta2
          - 5.0/8*GHPLs1[2]*HPLs1[0]
          + GHPLs1[2]*HPLs2[0*2+0]
          + GHPLs1[2]*HPLs2[1*2+0]
          - GHPLs1[2]*HPLs2[0*2+1]
          - 1.0/2*GHPLs2[0*4+2]*HPLs1[0]
          + GHPLs3[2*4*4+1*4+2]
          - GHPLs2[1*4+2]*HPLs1[0]
          - GHPLs2[1*4+2]*HPLs1[1]
          - 1.0/2*GHPLs2[2*4+0]*HPLs1[0]
          + 1.0/2*GHPLs1[0]*zeta2
          + 1.0/4*GHPLs1[0]*HPLs2[0*2+1]
          - 1.0/2*GHPLs3[2*4*4+1*4+0]
          + 1.0/2*GHPLs2[1*4+0]*HPLs1[0]
          + 1.0/2*GHPLs2[1*4+0]*HPLs1[1]
          - 3.0/4*GHPLs2[2*4+1]
          + GHPLs1[1]*zeta2
          + 3.0/4*GHPLs1[1]*HPLs1[0]
          - 1.0/2*GHPLs1[1]*HPLs2[0*2+0]
          - 1.0/2*GHPLs1[1]*HPLs2[1*2+0]
          + 3.0/4*GHPLs1[1]*HPLs1[1]
          - 1.0/2*GHPLs3[2*4*4+1*4+1]
          + 1.0/2*GHPLs2[1*4+1]*HPLs1[0]
          + 1.0/2*GHPLs2[1*4+1]*HPLs1[1]
          - 1.0/8*HPLs2[1*2+0]
          - 3.0/8*HPLs1[1]
          + 1.0/4*HPLs1[1]*zeta2
          - 1.0/8*HPLs2[0*2+1]
          - 1.0/2*HPLs3[0*2*2+0*2+1]
          + 1.0/4*HPLs3[0*2*2+1*2+1]
          )

       + (dN_c*dN_c-1)/(dN_c*dN_c)*pow(u,-1)*v * (
          + 1.0/8*zeta2
          + 1.0/4*zeta3
          + 1.0/4*GHPLs3[3*4*4+2*4+2]*HPLs1[0]
          - 1.0/4*GHPLs4[0*4*4*4+3*4*4+2*4+2]
          - 1.0/4*GHPLs2[2*4+2]*zeta2
          + 1.0/4*GHPLs2[2*4+2]*HPLs2[0*2+0]
          - 1.0/4*GHPLs2[2*4+2]*HPLs2[0*2+1]
          - 1.0/4*GHPLs3[0*4*4+2*4+2]*HPLs1[0]
          - 1.0/4*GHPLs2[3*4+2]*HPLs1[0]
          + 1.0/4*GHPLs3[0*4*4+3*4+2]
          - 3.0/8*GHPLs1[2]
          + 7.0/8*GHPLs1[2]*zeta2
          - 1.0/4*GHPLs1[2]*zeta3
          - 3.0/8*GHPLs1[2]*HPLs1[0]
          - 1.0/4*GHPLs1[2]*HPLs1[0]*zeta2
          - 1.0/8*GHPLs1[2]*HPLs2[0*2+0]
          + 1.0/4*GHPLs1[2]*HPLs3[0*2*2+0*2+0]
          - 1.0/2*GHPLs1[2]*HPLs2[1*2+0]
          - 1.0/4*GHPLs1[2]*HPLs3[0*2*2+1*2+0]
          + 3.0/8*GHPLs1[2]*HPLs2[0*2+1]
          - 1.0/4*GHPLs1[2]*HPLs3[0*2*2+0*2+1]
          - 1.0/4*GHPLs3[3*4*4+0*4+2]*HPLs1[0]
          + 1.0/4*GHPLs4[0*4*4*4+3*4*4+0*4+2]
          + 1.0/8*GHPLs2[0*4+2]
          - 1.0/4*GHPLs2[0*4+2]*HPLs2[0*2+0]
          - 1.0/2*GHPLs3[2*4*4+1*4+2]
          + 1.0/2*GHPLs2[1*4+2]*HPLs1[0]
          + 1.0/2*GHPLs2[1*4+2]*HPLs1[1]
          - 1.0/4*GHPLs2[2*4+3]*HPLs1[0]
          + 1.0/4*GHPLs3[0*4*4+2*4+3]
          + 1.0/4*GHPLs2[3*4+3]*HPLs1[0]
          - 1.0/4*GHPLs3[0*4*4+3*4+3]
          - 5.0/4*GHPLs1[3]*zeta2
          + 3.0/8*GHPLs1[3]*HPLs1[0]
          + 1.0/4*GHPLs1[3]*HPLs2[1*2+0]
          + 1.0/4*GHPLs1[3]*HPLs2[0*2+1]
          + 1.0/4*GHPLs3[2*4*4+0*4+3]
          - 3.0/8*GHPLs2[0*4+3]
          - 1.0/4*GHPLs2[0*4+3]*HPLs1[1]
          + 1.0/8*GHPLs2[2*4+0]
          + 1.0/8*GHPLs2[2*4+0]*HPLs1[0]
          - 1.0/4*GHPLs2[3*4+0]*HPLs1[0]
          + 1.0/4*GHPLs3[0*4*4+3*4+0]
          - 1.0/2*GHPLs1[0]*zeta2
          - 1.0/4*GHPLs1[0]*HPLs2[0*2+0]
          - 1.0/8*GHPLs1[0]*HPLs1[1]
          - 1.0/4*GHPLs1[0]*HPLs2[0*2+1]
          + 1.0/8*GHPLs3[2*4*4+1*4+0]
          - 1.0/8*GHPLs2[1*4+0]*HPLs1[0]
          - 1.0/8*GHPLs2[1*4+0]*HPLs1[1]
          + 1.0/4*GHPLs3[3*4*4+2*4+1]*HPLs1[0]
          - 1.0/4*GHPLs4[0*4*4*4+3*4*4+2*4+1]
          - 3.0/8*GHPLs2[2*4+1]
          - 1.0/4*GHPLs2[2*4+1]*zeta2
          + 1.0/4*GHPLs2[2*4+1]*HPLs2[0*2+0]
          - 1.0/4*GHPLs2[2*4+1]*HPLs2[0*2+1]
          - 1.0/4*GHPLs3[0*4*4+2*4+1]*HPLs1[0]
          - 1.0/4*GHPLs1[1]*zeta2
          - 1.0/4*GHPLs1[1]*zeta3
          + 3.0/8*GHPLs1[1]*HPLs1[0]
          + 1.0/4*GHPLs1[1]*HPLs1[0]*zeta2
          + 1.0/8*GHPLs1[1]*HPLs2[0*2+0]
          - 1.0/4*GHPLs1[1]*HPLs3[0*2*2+0*2+0]
          + 1.0/8*GHPLs1[1]*HPLs2[1*2+0]
          + 1.0/4*GHPLs1[1]*HPLs3[0*2*2+1*2+0]
          + 3.0/8*GHPLs1[1]*HPLs1[1]
          + 1.0/4*GHPLs1[1]*HPLs1[1]*zeta2
          - 1.0/4*GHPLs1[1]*HPLs3[0*2*2+0*2+1]
          + 1.0/4*GHPLs1[1]*HPLs3[0*2*2+1*2+1]
          + 1.0/4*GHPLs3[3*4*4+0*4+1]*HPLs1[0]
          - 1.0/4*GHPLs4[0*4*4*4+3*4*4+0*4+1]
          + 1.0/2*GHPLs2[0*4+1]*zeta2
          + 1.0/4*GHPLs2[0*4+1]*HPLs2[0*2+0]
          + 1.0/4*GHPLs2[0*4+1]*HPLs2[0*2+1]
          + 1.0/8*GHPLs3[2*4*4+1*4+1]
          - 1.0/8*GHPLs2[1*4+1]*HPLs1[0]
          - 1.0/8*GHPLs2[1*4+1]*HPLs1[1]
          + 3.0/8*HPLs1[0]
          - 1.0/4*HPLs1[0]*zeta2
          + 1.0/8*HPLs2[0*2+0]
          + 1.0/4*HPLs3[0*2*2+0*2+0]
          - 1.0/4*HPLs3[0*2*2+1*2+0]
          + 3.0/8*HPLs1[1]
          - 1.0/4*HPLs1[1]*zeta2
          + 3.0/8*HPLs2[0*2+1]
          + 1.0/4*HPLs3[0*2*2+0*2+1]
          - 1.0/4*HPLs3[0*2*2+1*2+1]
          )

       + (dN_c*dN_c-1)/(dN_c*dN_c)*pow(u,-1)*pow(v,2) * (
          + 1.0/2*zeta2
          + 1.0/4*GHPLs1[2]*zeta2
          + 1.0/4*GHPLs1[2]*HPLs1[0]
          + 1.0/4*GHPLs1[2]*HPLs2[0*2+0]
          - 1.0/4*GHPLs1[2]*HPLs2[1*2+0]
          - 1.0/8*GHPLs2[0*4+2]
          - 1.0/4*GHPLs2[0*4+2]*HPLs1[0]
          - 1.0/4*GHPLs3[2*4*4+1*4+2]
          + 1.0/4*GHPLs2[1*4+2]*HPLs1[0]
          + 1.0/4*GHPLs2[1*4+2]*HPLs1[1]
          - 1.0/4*GHPLs2[2*4+3]*HPLs1[0]
          + 1.0/4*GHPLs3[0*4*4+2*4+3]
          + 1.0/4*GHPLs2[3*4+3]*HPLs1[0]
          - 1.0/4*GHPLs3[0*4*4+3*4+3]
          - 5.0/4*GHPLs1[3]*zeta2
          - 1.0/8*GHPLs1[3]*HPLs1[0]
          + 1.0/4*GHPLs1[3]*HPLs2[1*2+0]
          + 1.0/4*GHPLs1[3]*HPLs2[0*2+1]
          + 1.0/4*GHPLs3[2*4*4+0*4+3]
          + 1.0/8*GHPLs2[0*4+3]
          - 1.0/4*GHPLs2[0*4+3]*HPLs1[1]
          - 1.0/8*GHPLs2[2*4+0]
          + 1.0/8*GHPLs1[0]*HPLs1[0]
          + 1.0/8*GHPLs1[0]*HPLs1[1]
          + 1.0/4*GHPLs2[2*4+1]
          - 1.0/4*GHPLs1[1]*HPLs1[0]
          - 1.0/4*GHPLs1[1]*HPLs1[1]
          - 1.0/8*HPLs2[0*2+0]
          - 1.0/8*HPLs2[0*2+1]
          )

       + (dN_c*dN_c-1)/(dN_c*dN_c)*pow(u,-1)*pow(v,3) * (
          - 1.0/8*GHPLs1[2]*zeta2
          - 1.0/8*GHPLs1[2]*HPLs2[0*2+0]
          + 1.0/8*GHPLs1[2]*HPLs2[1*2+0]
          + 1.0/8*GHPLs2[0*4+2]*HPLs1[0]
          + 1.0/8*GHPLs3[2*4*4+1*4+2]
          - 1.0/8*GHPLs2[1*4+2]*HPLs1[0]
          - 1.0/8*GHPLs2[1*4+2]*HPLs1[1]
          + 1.0/8*GHPLs2[2*4+3]*HPLs1[0]
          - 1.0/8*GHPLs3[0*4*4+2*4+3]
          - 1.0/8*GHPLs2[3*4+3]*HPLs1[0]
          + 1.0/8*GHPLs3[0*4*4+3*4+3]
          + 5.0/8*GHPLs1[3]*zeta2
          - 1.0/8*GHPLs1[3]*HPLs2[1*2+0]
          - 1.0/8*GHPLs1[3]*HPLs2[0*2+1]
          - 1.0/8*GHPLs3[2*4*4+0*4+3]
          + 1.0/8*GHPLs2[0*4+3]*HPLs1[1]
          )

       + (dN_c*dN_c-1)/(dN_c*dN_c)*pow(1-u,-1) * (
          - 1.0/2*zeta2
          + 1.0/2*GHPLs1[3]*HPLs1[0]
          - 1.0/2*GHPLs2[0*4+3]
          - 1.0/2*GHPLs1[0]*HPLs1[0]
          + 1.0/2*HPLs2[0*2+0]
          - 1.0/2*HPLs2[0*2+1]
          )

       + (dN_c*dN_c-1)/(dN_c*dN_c)*pow(1-v,-1) * (
          - 1.0/16*zeta2
          - 3.0/4*zeta3
          + 3.0/4*GHPLs1[2]*zeta2
          + 9.0/8*GHPLs1[2]*HPLs1[0]
          - 3.0/4*GHPLs1[2]*HPLs2[0*2+0]
          - 9.0/8*GHPLs1[2]*HPLs2[1*2+0]
          - 3.0/8*GHPLs1[2]*HPLs2[0*2+1]
          - 3.0/8*GHPLs2[0*4+2]*HPLs1[0]
          - 9.0/8*GHPLs3[2*4*4+1*4+2]
          + 9.0/8*GHPLs2[1*4+2]*HPLs1[0]
          + 9.0/8*GHPLs2[1*4+2]*HPLs1[1]
          + 7.0/8*GHPLs1[3]*HPLs1[0]
          - 7.0/8*GHPLs2[0*4+3]
          + 3.0/4*GHPLs2[2*4+0]*HPLs1[0]
          - 3.0/8*GHPLs1[0]*zeta2
          + 1.0/16*GHPLs1[0]*HPLs1[0]
          + 3.0/4*GHPLs1[0]*HPLs2[0*2+0]
          + 3.0/8*GHPLs1[0]*HPLs2[1*2+0]
          + 9.0/8*GHPLs3[2*4*4+1*4+0]
          - 9.0/8*GHPLs2[1*4+0]*HPLs1[0]
          - 9.0/8*GHPLs2[1*4+0]*HPLs1[1]
          + 5.0/4*GHPLs2[2*4+1]
          - 5.0/4*GHPLs1[1]*HPLs1[0]
          - 5.0/4*GHPLs1[1]*HPLs1[1]
          - 65.0/32*HPLs1[0]
          + 9.0/8*HPLs1[0]*zeta2
          + 5.0/8*HPLs2[0*2+0]
          + 3.0/4*HPLs3[1*2*2+0*2+0]
          + 1.0/8*HPLs2[1*2+0]
          - 3.0/8*HPLs1[1]*zeta2
          + 1.0/16*HPLs2[0*2+1]
          + 3.0/4*HPLs3[0*2*2+0*2+1]
          + 3.0/8*HPLs3[1*2*2+0*2+1]
          )

       + (dN_c*dN_c-1)/(dN_c*dN_c)*pow(u+v,-2) * (
          - 3.0/8*GHPLs1[2]*zeta2
          + 1.0/8*GHPLs1[2]*HPLs2[1*2+0]
          - 1.0/8*GHPLs1[2]*HPLs2[0*2+1]
          + 1.0/8*GHPLs3[2*4*4+1*4+2]
          - 1.0/8*GHPLs2[1*4+2]*HPLs1[0]
          - 1.0/8*GHPLs2[1*4+2]*HPLs1[1]
          + 1.0/8*GHPLs2[2*4+0]*HPLs1[0]
          + 1.0/8*GHPLs3[2*4*4+1*4+0]
          - 1.0/8*GHPLs2[1*4+0]*HPLs1[0]
          - 1.0/8*GHPLs2[1*4+0]*HPLs1[1]
          + 3.0/8*HPLs1[1]*zeta2
          - 1.0/8*HPLs3[1*2*2+0*2+1]
          + 1.0/8*HPLs3[0*2*2+1*2+1]
          )

       + (dN_c*dN_c-1)/(dN_c*dN_c)*pow(u+v,-1) * (
          + 1.0/16
          - 3.0/8*zeta2
          + 3.0/2*GHPLs1[2]*zeta2
          - 1.0/2*GHPLs1[2]*HPLs2[1*2+0]
          + 1.0/2*GHPLs1[2]*HPLs2[0*2+1]
          - 1.0/2*GHPLs3[2*4*4+1*4+2]
          + 1.0/2*GHPLs2[1*4+2]*HPLs1[0]
          + 1.0/2*GHPLs2[1*4+2]*HPLs1[1]
          - 1.0/2*GHPLs2[2*4+0]*HPLs1[0]
          + 1.0/16*GHPLs1[0]
          - 1.0/2*GHPLs3[2*4*4+1*4+0]
          + 1.0/2*GHPLs2[1*4+0]*HPLs1[0]
          + 1.0/2*GHPLs2[1*4+0]*HPLs1[1]
          + 1.0/8*GHPLs2[2*4+1]
          - 1.0/8*GHPLs1[1]*HPLs1[0]
          - 1.0/8*GHPLs1[1]*HPLs1[1]
          - 1.0/16*HPLs1[0]
          + 1.0/8*HPLs2[1*2+0]
          - 3.0/2*HPLs1[1]*zeta2
          - 1.0/8*HPLs2[0*2+1]
          + 1.0/2*HPLs3[1*2*2+0*2+1]
          - 1.0/2*HPLs3[0*2*2+1*2+1]
          )

       + (dN_c*dN_c-1)/(dN_c*dN_c)*pow(1-u-v,-1) * (
          - 1.0/2*zeta2
          + 1.0/2*GHPLs1[3]*HPLs1[0]
          - 1.0/2*GHPLs2[0*4+3]
          - 1.0/2*GHPLs1[0]*HPLs1[0]
          + 1.0/2*HPLs2[0*2+0]
          - 1.0/2*HPLs2[0*2+1]
          )

       + (dN_c*dN_c-1)/(dN_c*dN_c) * (
          - 395.0/128
          + 29.0/16*zeta4
          + 33.0/16*zeta2
          + 2*zeta3
          - 1.0/4*GHPLs3[3*4*4+2*4+2]*HPLs1[0]
          + 1.0/4*GHPLs4[0*4*4*4+3*4*4+2*4+2]
          + 1.0/4*GHPLs2[2*4+2]*zeta2
          - 1.0/4*GHPLs2[2*4+2]*HPLs2[0*2+0]
          + 1.0/4*GHPLs2[2*4+2]*HPLs2[0*2+1]
          + 1.0/4*GHPLs3[0*4*4+2*4+2]*HPLs1[0]
          + GHPLs2[3*4+2]*HPLs1[0]
          - GHPLs3[0*4*4+3*4+2]
          - 3.0/8*GHPLs1[2]
          - 7.0/4*GHPLs1[2]*zeta2
          + 1.0/4*GHPLs1[2]*zeta3
          + 1.0/4*GHPLs1[2]*HPLs1[0]*zeta2
          + 11.0/8*GHPLs1[2]*HPLs2[0*2+0]
          - 1.0/4*GHPLs1[2]*HPLs3[0*2*2+0*2+0]
          + 3.0/4*GHPLs1[2]*HPLs2[1*2+0]
          + 1.0/4*GHPLs1[2]*HPLs3[0*2*2+1*2+0]
          - 5.0/8*GHPLs1[2]*HPLs2[0*2+1]
          + 1.0/4*GHPLs1[2]*HPLs3[0*2*2+0*2+1]
          + 1.0/4*GHPLs3[3*4*4+0*4+2]*HPLs1[0]
          - 1.0/4*GHPLs4[0*4*4*4+3*4*4+0*4+2]
          - 3.0/8*GHPLs2[0*4+2]
          - 5.0/8*GHPLs2[0*4+2]*HPLs1[0]
          + 1.0/4*GHPLs2[0*4+2]*HPLs2[0*2+0]
          + 3.0/4*GHPLs3[2*4*4+1*4+2]
          - 3.0/4*GHPLs2[1*4+2]*HPLs1[0]
          - 3.0/4*GHPLs2[1*4+2]*HPLs1[1]
          - 1.0/4*GHPLs3[3*4*4+2*4+3]*HPLs1[0]
          + 1.0/4*GHPLs4[0*4*4*4+3*4*4+2*4+3]
          + 1.0/4*GHPLs2[2*4+3]*zeta2
          - 1.0/4*GHPLs2[2*4+3]*HPLs2[0*2+0]
          + 1.0/4*GHPLs2[2*4+3]*HPLs2[0*2+1]
          + 1.0/4*GHPLs3[0*4*4+2*4+3]*HPLs1[0]
          - 1.0/2*GHPLs3[3*4*4+3*4+3]*HPLs1[0]
          + 1.0/2*GHPLs4[0*4*4*4+3*4*4+3*4+3]
          + GHPLs2[3*4+3]*zeta2
          + 3.0/8*GHPLs2[3*4+3]*HPLs1[0]
          - 1.0/2*GHPLs2[3*4+3]*HPLs2[0*2+0]
          - 3.0/8*GHPLs3[0*4*4+3*4+3]
          + 1.0/2*GHPLs3[0*4*4+3*4+3]*HPLs1[0]
          - 1.0/2*GHPLs4[0*4*4*4+0*4*4+3*4+3]
          + 3.0/8*GHPLs1[3]*zeta2
          - 1.0/2*GHPLs1[3]*zeta3
          - 45.0/16*GHPLs1[3]*HPLs1[0]
          + 7.0/4*GHPLs1[3]*HPLs1[0]*zeta2
          - 3.0/4*GHPLs1[3]*HPLs3[0*2*2+0*2+0]
          + 1.0/4*GHPLs1[3]*HPLs3[0*2*2+1*2+0]
          - 1.0/4*GHPLs1[3]*HPLs1[1]*zeta2
          + 1.0/4*GHPLs1[3]*HPLs3[0*2*2+0*2+1]
          - 1.0/4*GHPLs1[3]*HPLs3[0*2*2+1*2+1]
          + 1.0/4*GHPLs3[3*4*4+0*4+3]*HPLs1[0]
          - 1.0/4*GHPLs4[0*4*4*4+3*4*4+0*4+3]
          + 45.0/16*GHPLs2[0*4+3]
          - 1.0/4*GHPLs2[0*4+3]*zeta2
          + 3.0/4*GHPLs2[0*4+3]*HPLs2[0*2+0]
          - 1.0/4*GHPLs2[0*4+3]*HPLs2[0*2+1]
          - 1.0/2*GHPLs3[0*4*4+0*4+3]*HPLs1[0]
          - 3.0/8*GHPLs2[2*4+0]
          - 1.0/2*GHPLs2[2*4+0]*zeta2
          + 1.0/2*GHPLs2[2*4+0]*HPLs2[0*2+0]
          + 1.0/2*GHPLs2[2*4+0]*HPLs2[1*2+0]
          + 1.0/2*GHPLs4[2*4*4*4+1*4*4+2*4+0]
          - 1.0/2*GHPLs3[1*4*4+2*4+0]*HPLs1[0]
          - 1.0/2*GHPLs3[1*4*4+2*4+0]*HPLs1[1]
          + 1.0/2*GHPLs3[3*4*4+3*4+0]*HPLs1[0]
          - 1.0/2*GHPLs4[0*4*4*4+3*4*4+3*4+0]
          + 1.0/2*GHPLs2[3*4+0]*zeta2
          - 3.0/8*GHPLs2[3*4+0]*HPLs1[0]
          + 1.0/2*GHPLs2[3*4+0]*HPLs2[0*2+0]
          + 3.0/8*GHPLs3[0*4*4+3*4+0]
          - 1.0/4*GHPLs3[0*4*4+3*4+0]*HPLs1[0]
          - 1.0/4*GHPLs1[0]
          + GHPLs1[0]*zeta2
          + 15.0/8*GHPLs1[0]*HPLs1[0]
          - 1.0/4*GHPLs1[0]*HPLs1[0]*zeta2
          - 3.0/4*GHPLs1[0]*HPLs2[0*2+0]
          + 3.0/4*GHPLs1[0]*HPLs3[0*2*2+0*2+0]
          - 3.0/8*GHPLs1[0]*HPLs2[1*2+0]
          - 1.0/4*GHPLs1[0]*HPLs3[0*2*2+1*2+0]
          + 3.0/8*GHPLs1[0]*HPLs1[1]
          + 1.0/8*GHPLs1[0]*HPLs2[0*2+1]
          - 1.0/2*GHPLs1[0]*HPLs3[0*2*2+0*2+1]
          - 1.0/2*GHPLs3[2*4*4+0*4+0]*HPLs1[0]
          - 1.0/2*GHPLs2[0*4+0]*HPLs2[0*2+0]
          - 1.0/2*GHPLs4[2*4*4*4+1*4*4+0*4+0]
          + 1.0/2*GHPLs3[1*4*4+0*4+0]*HPLs1[0]
          + 1.0/2*GHPLs3[1*4*4+0*4+0]*HPLs1[1]
          - 3.0/8*GHPLs3[2*4*4+1*4+0]
          + GHPLs2[1*4+0]*zeta2
          + 3.0/8*GHPLs2[1*4+0]*HPLs1[0]
          - 1.0/2*GHPLs2[1*4+0]*HPLs2[0*2+0]
          - 1.0/2*GHPLs2[1*4+0]*HPLs2[1*2+0]
          + 3.0/8*GHPLs2[1*4+0]*HPLs1[1]
          - 1.0/2*GHPLs4[2*4*4*4+1*4*4+1*4+0]
          + 1.0/2*GHPLs3[1*4*4+1*4+0]*HPLs1[0]
          + 1.0/2*GHPLs3[1*4*4+1*4+0]*HPLs1[1]
          - 1.0/4*GHPLs3[3*4*4+2*4+1]*HPLs1[0]
          + 1.0/4*GHPLs4[0*4*4*4+3*4*4+2*4+1]
          - 1.0/8*GHPLs2[2*4+1]
          + 1.0/4*GHPLs2[2*4+1]*zeta2
          - 1.0/4*GHPLs2[2*4+1]*HPLs2[0*2+0]
          + 1.0/4*GHPLs2[2*4+1]*HPLs2[0*2+1]
          + 1.0/4*GHPLs3[0*4*4+2*4+1]*HPLs1[0]
          - 3.0/4*GHPLs1[1]*zeta2
          + 1.0/4*GHPLs1[1]*zeta3
          + 1.0/8*GHPLs1[1]*HPLs1[0]
          - 1.0/4*GHPLs1[1]*HPLs1[0]*zeta2
          + 3.0/8*GHPLs1[1]*HPLs2[0*2+0]
          + 1.0/4*GHPLs1[1]*HPLs3[0*2*2+0*2+0]
          + 3.0/8*GHPLs1[1]*HPLs2[1*2+0]
          - 1.0/4*GHPLs1[1]*HPLs3[0*2*2+1*2+0]
          + 1.0/8*GHPLs1[1]*HPLs1[1]
          - 1.0/4*GHPLs1[1]*HPLs1[1]*zeta2
          + 1.0/4*GHPLs1[1]*HPLs3[0*2*2+0*2+1]
          - 1.0/4*GHPLs1[1]*HPLs3[0*2*2+1*2+1]
          - 1.0/4*GHPLs3[3*4*4+0*4+1]*HPLs1[0]
          + 1.0/4*GHPLs4[0*4*4*4+3*4*4+0*4+1]
          - 1.0/2*GHPLs2[0*4+1]*zeta2
          - 1.0/4*GHPLs2[0*4+1]*HPLs2[0*2+0]
          - 1.0/4*GHPLs2[0*4+1]*HPLs2[0*2+1]
          + 3.0/8*GHPLs3[2*4*4+1*4+1]
          - 3.0/8*GHPLs2[1*4+1]*HPLs1[0]
          - 3.0/8*GHPLs2[1*4+1]*HPLs1[1]
          + 27.0/16*HPLs1[0]
          - 3.0/2*HPLs1[0]*zeta2
          + HPLs1[0]*zeta3
          - 41.0/16*HPLs2[0*2+0]
          + 7.0/4*HPLs2[0*2+0]*zeta2
          - 3.0/4*HPLs4[0*2*2*2+0*2*2+0*2+0]
          - 3.0/4*HPLs3[1*2*2+0*2+0]
          + 1.0/4*HPLs4[0*2*2*2+1*2*2+0*2+0]
          - 1.0/8*HPLs2[1*2+0]
          - 1.0/4*HPLs2[1*2+0]*zeta2
          + 1.0/4*HPLs4[0*2*2*2+0*2*2+1*2+0]
          - 1.0/4*HPLs4[0*2*2*2+1*2*2+1*2+0]
          + 3.0/8*HPLs1[1]
          + 5.0/4*HPLs1[1]*zeta2
          + 11.0/8*HPLs2[0*2+1]
          - 11.0/8*HPLs3[0*2*2+0*2+1]
          - 1.0/2*HPLs4[1*2*2*2+0*2*2+0*2+1]
          - 3.0/4*HPLs3[1*2*2+0*2+1]
          - 1.0/2*HPLs4[0*2*2*2+1*2*2+0*2+1]
          + 1.0/8*HPLs3[0*2*2+1*2+1]
          - 1.0/2*HPLs4[0*2*2*2+0*2*2+1*2+1]
          )

       + (dN_c*dN_c-1)/(dN_c*dN_c)*v*pow(1-u,-2) * (
          - 1.0/2*zeta3
          + 1.0/2*GHPLs2[3*4+2]*HPLs1[0]
          - 1.0/2*GHPLs3[0*4*4+3*4+2]
          - 1.0/2*GHPLs1[2]*zeta2
          + 1.0/2*GHPLs1[2]*HPLs2[0*2+0]
          - 1.0/2*GHPLs1[2]*HPLs2[0*2+1]
          - 1.0/2*GHPLs2[0*4+2]*HPLs1[0]
          + 1.0/2*GHPLs2[3*4+0]*HPLs1[0]
          - 1.0/2*GHPLs3[0*4*4+3*4+0]
          + GHPLs1[0]*zeta2
          + 1.0/2*GHPLs1[0]*HPLs2[0*2+0]
          + 1.0/2*GHPLs1[0]*HPLs2[0*2+1]
          + 1.0/2*HPLs1[0]*zeta2
          - 1.0/2*HPLs3[0*2*2+0*2+0]
          + 1.0/2*HPLs3[0*2*2+1*2+0]
          + 1.0/2*HPLs1[1]*zeta2
          - 1.0/2*HPLs3[0*2*2+0*2+1]
          + 1.0/2*HPLs3[0*2*2+1*2+1]
          )

       + (dN_c*dN_c-1)/(dN_c*dN_c)*v*pow(1-u,-1) * (
          + zeta2
          + 1.0/4*zeta3
          - 1.0/4*GHPLs2[3*4+2]*HPLs1[0]
          + 1.0/4*GHPLs3[0*4*4+3*4+2]
          + 1.0/4*GHPLs1[2]*zeta2
          - 1.0/4*GHPLs1[2]*HPLs2[0*2+0]
          + 1.0/4*GHPLs1[2]*HPLs2[0*2+1]
          + 1.0/4*GHPLs2[0*4+2]*HPLs1[0]
          + 1.0/2*GHPLs1[3]*HPLs1[0]
          - 1.0/2*GHPLs2[0*4+3]
          - 1.0/4*GHPLs2[3*4+0]*HPLs1[0]
          + 1.0/4*GHPLs3[0*4*4+3*4+0]
          - 1.0/2*GHPLs1[0]*zeta2
          - 1.0/4*GHPLs1[0]*HPLs2[0*2+0]
          - 1.0/4*GHPLs1[0]*HPLs2[0*2+1]
          - 1.0/4*HPLs1[0]*zeta2
          + 1.0/2*HPLs2[0*2+0]
          + 1.0/4*HPLs3[0*2*2+0*2+0]
          - 1.0/4*HPLs3[0*2*2+1*2+0]
          - 1.0/4*HPLs1[1]*zeta2
          + 1.0/2*HPLs2[0*2+1]
          + 1.0/4*HPLs3[0*2*2+0*2+1]
          - 1.0/4*HPLs3[0*2*2+1*2+1]
          )

       + (dN_c*dN_c-1)/(dN_c*dN_c)*v * (
          + 17.0/8*zeta2
          + 1.0/8*GHPLs1[2]*zeta2
          + 7.0/8*GHPLs1[2]*HPLs1[0]
          + 1.0/8*GHPLs1[2]*HPLs2[0*2+0]
          - 1.0/8*GHPLs1[2]*HPLs2[1*2+0]
          - 1.0/2*GHPLs2[0*4+2]
          - 1.0/8*GHPLs2[0*4+2]*HPLs1[0]
          - 1.0/8*GHPLs3[2*4*4+1*4+2]
          + 1.0/8*GHPLs2[1*4+2]*HPLs1[0]
          + 1.0/8*GHPLs2[1*4+2]*HPLs1[1]
          - 1.0/8*GHPLs2[2*4+3]*HPLs1[0]
          + 1.0/8*GHPLs3[0*4*4+2*4+3]
          + 1.0/8*GHPLs2[3*4+3]*HPLs1[0]
          - 1.0/8*GHPLs3[0*4*4+3*4+3]
          - 5.0/8*GHPLs1[3]*zeta2
          - 5.0/8*GHPLs1[3]*HPLs1[0]
          + 1.0/8*GHPLs1[3]*HPLs2[1*2+0]
          + 1.0/8*GHPLs1[3]*HPLs2[0*2+1]
          + 1.0/8*GHPLs3[2*4*4+0*4+3]
          + 5.0/8*GHPLs2[0*4+3]
          - 1.0/8*GHPLs2[0*4+3]*HPLs1[1]
          - 1.0/2*GHPLs2[2*4+0]
          + 1.0/8*GHPLs2[2*4+0]*HPLs1[0]
          - 1.0/8*GHPLs2[3*4+0]*HPLs1[0]
          + 1.0/8*GHPLs3[0*4*4+3*4+0]
          + 3.0/8*GHPLs1[0]*HPLs1[0]
          - 1.0/4*GHPLs1[0]*HPLs2[0*2+0]
          - 1.0/8*GHPLs1[0]*HPLs2[1*2+0]
          + 1.0/2*GHPLs1[0]*HPLs1[1]
          - 1.0/8*GHPLs1[0]*HPLs2[0*2+1]
          + 5.0/8*GHPLs2[2*4+1]
          - 1.0/8*GHPLs3[0*4*4+2*4+1]
          + 1.0/2*GHPLs1[1]*zeta2
          - 5.0/8*GHPLs1[1]*HPLs1[0]
          + 1.0/8*GHPLs1[1]*HPLs2[0*2+0]
          + 1.0/8*GHPLs1[1]*HPLs2[1*2+0]
          - 5.0/8*GHPLs1[1]*HPLs1[1]
          - 1.0/8*GHPLs3[2*4*4+0*4+1]
          + 1.0/8*GHPLs2[0*4+1]*HPLs1[0]
          + 1.0/8*GHPLs2[0*4+1]*HPLs1[1]
          + 1.0/8*GHPLs3[2*4*4+1*4+1]
          - 1.0/8*GHPLs2[1*4+1]*HPLs1[0]
          - 1.0/8*GHPLs2[1*4+1]*HPLs1[1]
          - 5.0/8*HPLs1[0]*zeta2
          - 5.0/8*HPLs2[0*2+0]
          - 1.0/8*HPLs3[1*2*2+0*2+0]
          - 1.0/4*HPLs2[1*2+0]
          - 1.0/8*HPLs3[0*2*2+1*2+0]
          - 1.0/8*HPLs1[1]*zeta2
          - 5.0/8*HPLs2[0*2+1]
          - 1.0/8*HPLs3[0*2*2+0*2+1]
          - 1.0/8*HPLs3[1*2*2+0*2+1]
          - 1.0/4*HPLs3[0*2*2+1*2+1]
          )

       + (dN_c*dN_c-1)/(dN_c*dN_c)*pow(v,2) * (
          - 1.0/2*zeta2
          - 1.0/4*GHPLs1[2]*zeta2
          - 1.0/8*GHPLs1[2]*HPLs1[0]
          - 1.0/4*GHPLs1[2]*HPLs2[0*2+0]
          + 1.0/4*GHPLs1[2]*HPLs2[1*2+0]
          + 1.0/8*GHPLs2[0*4+2]
          + 1.0/4*GHPLs2[0*4+2]*HPLs1[0]
          + 1.0/4*GHPLs3[2*4*4+1*4+2]
          - 1.0/4*GHPLs2[1*4+2]*HPLs1[0]
          - 1.0/4*GHPLs2[1*4+2]*HPLs1[1]
          + 1.0/4*GHPLs2[2*4+3]*HPLs1[0]
          - 1.0/4*GHPLs3[0*4*4+2*4+3]
          - 1.0/4*GHPLs2[3*4+3]*HPLs1[0]
          + 1.0/4*GHPLs3[0*4*4+3*4+3]
          + 5.0/4*GHPLs1[3]*zeta2
          + 1.0/8*GHPLs1[3]*HPLs1[0]
          - 1.0/4*GHPLs1[3]*HPLs2[1*2+0]
          - 1.0/4*GHPLs1[3]*HPLs2[0*2+1]
          - 1.0/4*GHPLs3[2*4*4+0*4+3]
          - 1.0/8*GHPLs2[0*4+3]
          + 1.0/4*GHPLs2[0*4+3]*HPLs1[1]
          + 1.0/8*GHPLs2[2*4+0]
          - 1.0/8*GHPLs1[0]*HPLs1[0]
          - 1.0/8*GHPLs1[0]*HPLs1[1]
          - 1.0/8*GHPLs2[2*4+1]
          + 1.0/8*GHPLs1[1]*HPLs1[0]
          + 1.0/8*GHPLs1[1]*HPLs1[1]
          + 1.0/8*HPLs2[0*2+0]
          + 1.0/8*HPLs2[0*2+1]
          )

       + (dN_c*dN_c-1)/(dN_c*dN_c)*u*pow(1-v,-2) * (
          + 39.0/16*zeta2
          + 9.0/4*zeta3
          + 2*GHPLs2[3*4+2]*HPLs1[0]
          - 2*GHPLs3[0*4*4+3*4+2]
          - 9.0/4*GHPLs1[2]*zeta2
          - 5.0/8*GHPLs1[2]*HPLs1[0]
          + 9.0/4*GHPLs1[2]*HPLs2[0*2+0]
          + 19.0/8*GHPLs1[2]*HPLs2[1*2+0]
          + 1.0/8*GHPLs1[2]*HPLs2[0*2+1]
          + 1.0/8*GHPLs2[0*4+2]*HPLs1[0]
          + 19.0/8*GHPLs3[2*4*4+1*4+2]
          - 19.0/8*GHPLs2[1*4+2]*HPLs1[0]
          - 19.0/8*GHPLs2[1*4+2]*HPLs1[1]
          - 21.0/8*GHPLs1[3]*HPLs1[0]
          + 21.0/8*GHPLs2[0*4+3]
          - 1.0/4*GHPLs2[2*4+0]*HPLs1[0]
          - 2*GHPLs2[3*4+0]*HPLs1[0]
          + 2*GHPLs3[0*4*4+3*4+0]
          + 17.0/8*GHPLs1[0]*zeta2
          + 7.0/16*GHPLs1[0]*HPLs1[0]
          - 9.0/4*GHPLs1[0]*HPLs2[0*2+0]
          - 17.0/8*GHPLs1[0]*HPLs2[1*2+0]
          - 19.0/8*GHPLs3[2*4*4+1*4+0]
          + 19.0/8*GHPLs2[1*4+0]*HPLs1[0]
          + 19.0/8*GHPLs2[1*4+0]*HPLs1[1]
          - 21.0/8*GHPLs2[2*4+1]
          + 21.0/8*GHPLs1[1]*HPLs1[0]
          + 21.0/8*GHPLs1[1]*HPLs1[1]
          + 27.0/32*HPLs1[0]
          - 67.0/8*HPLs1[0]*zeta2
          - 21.0/8*HPLs2[0*2+0]
          + 2*HPLs3[0*2*2+0*2+0]
          - 1.0/4*HPLs3[1*2*2+0*2+0]
          - 2*HPLs2[1*2+0]
          + 2*HPLs3[0*2*2+1*2+0]
          + 17.0/8*HPLs1[1]*zeta2
          + 7.0/16*HPLs2[0*2+1]
          - 9.0/4*HPLs3[0*2*2+0*2+1]
          - 17.0/8*HPLs3[1*2*2+0*2+1]
          )

       + (dN_c*dN_c-1)/(dN_c*dN_c)*u*pow(1-v,-1) * (
          + 17.0/32
          - 173.0/16*zeta2
          - 9.0/4*zeta3
          - 2*GHPLs2[3*4+2]*HPLs1[0]
          + 2*GHPLs3[0*4*4+3*4+2]
          + 9.0/8*GHPLs1[2]
          + 9.0/4*GHPLs1[2]*zeta2
          - 2*GHPLs1[2]*HPLs1[0]
          - 9.0/4*GHPLs1[2]*HPLs2[0*2+0]
          - 19.0/8*GHPLs1[2]*HPLs2[1*2+0]
          - 1.0/8*GHPLs1[2]*HPLs2[0*2+1]
          + 17.0/8*GHPLs2[0*4+2]
          - 1.0/8*GHPLs2[0*4+2]*HPLs1[0]
          - 19.0/8*GHPLs3[2*4*4+1*4+2]
          + 19.0/8*GHPLs2[1*4+2]*HPLs1[0]
          + 19.0/8*GHPLs2[1*4+2]*HPLs1[1]
          + 37.0/8*GHPLs1[3]*HPLs1[0]
          - 37.0/8*GHPLs2[0*4+3]
          + 17.0/8*GHPLs2[2*4+0]
          + 1.0/4*GHPLs2[2*4+0]*HPLs1[0]
          + 2*GHPLs2[3*4+0]*HPLs1[0]
          - 2*GHPLs3[0*4*4+3*4+0]
          - 13.0/16*GHPLs1[0]
          - 17.0/8*GHPLs1[0]*zeta2
          - 35.0/16*GHPLs1[0]*HPLs1[0]
          + 9.0/4*GHPLs1[0]*HPLs2[0*2+0]
          + 17.0/8*GHPLs1[0]*HPLs2[1*2+0]
          - 17.0/8*GHPLs1[0]*HPLs1[1]
          + 19.0/8*GHPLs3[2*4*4+1*4+0]
          - 19.0/8*GHPLs2[1*4+0]*HPLs1[0]
          - 19.0/8*GHPLs2[1*4+0]*HPLs1[1]
          + 1.0/4*GHPLs2[2*4+1]
          - 1.0/4*GHPLs1[1]*HPLs1[0]
          - 1.0/4*GHPLs1[1]*HPLs1[1]
          - 39.0/32*HPLs1[0]
          + 67.0/8*HPLs1[0]*zeta2
          + 37.0/8*HPLs2[0*2+0]
          - 2*HPLs3[0*2*2+0*2+0]
          + 1.0/4*HPLs3[1*2*2+0*2+0]
          + 9.0/4*HPLs2[1*2+0]
          - 2*HPLs3[0*2*2+1*2+0]
          - 9.0/8*HPLs1[1]
          - 17.0/8*HPLs1[1]*zeta2
          + 33.0/16*HPLs2[0*2+1]
          + 9.0/4*HPLs3[0*2*2+0*2+1]
          + 17.0/8*HPLs3[1*2*2+0*2+1]
          )

       + (dN_c*dN_c-1)/(dN_c*dN_c)*u*pow(u+v,-2) * (
          - 1.0/16*GHPLs1[0]
          + 1.0/16*HPLs1[0]
          )

       + (dN_c*dN_c-1)/(dN_c*dN_c)*u*pow(u+v,-1) * (
          - 7.0/16*GHPLs1[0]
          + 7.0/16*HPLs1[0]
          )

       + (dN_c*dN_c-1)/(dN_c*dN_c)*u*pow(1-u-v,-1) * (
          + 1.0/4*zeta2
          - 1.0/4*GHPLs1[3]*HPLs1[0]
          + 1.0/4*GHPLs2[0*4+3]
          + 1.0/4*GHPLs1[0]*HPLs1[0]
          - 1.0/4*HPLs2[0*2+0]
          + 1.0/4*HPLs2[0*2+1]
          )

       + (dN_c*dN_c-1)/(dN_c*dN_c)*u * (
          + 5*zeta2
          - 3.0/8*GHPLs1[2]
          + 3.0/2*GHPLs1[2]*HPLs1[0]
          - 5.0/4*GHPLs2[0*4+2]
          - 5.0/4*GHPLs1[3]*HPLs1[0]
          + 5.0/4*GHPLs2[0*4+3]
          - 5.0/4*GHPLs2[2*4+0]
          + GHPLs1[0]*HPLs1[0]
          + 5.0/4*GHPLs1[0]*HPLs1[1]
          + 5.0/4*GHPLs2[2*4+1]
          - 5.0/4*GHPLs1[1]*HPLs1[0]
          - 5.0/4*GHPLs1[1]*HPLs1[1]
          + 3.0/8*HPLs1[0]
          - 5.0/4*HPLs2[0*2+0]
          - 1.0/4*HPLs2[1*2+0]
          + 3.0/8*HPLs1[1]
          - 3.0/2*HPLs2[0*2+1]
          )

       + (dN_c*dN_c-1)/(dN_c*dN_c)*u*v * (
          - 3.0/2*zeta2
          - 1.0/8*GHPLs1[2]*zeta2
          - 3.0/8*GHPLs1[2]*HPLs1[0]
          - 1.0/8*GHPLs1[2]*HPLs2[0*2+0]
          + 1.0/8*GHPLs1[2]*HPLs2[1*2+0]
          + 3.0/8*GHPLs2[0*4+2]
          + 1.0/8*GHPLs2[0*4+2]*HPLs1[0]
          + 1.0/8*GHPLs3[2*4*4+1*4+2]
          - 1.0/8*GHPLs2[1*4+2]*HPLs1[0]
          - 1.0/8*GHPLs2[1*4+2]*HPLs1[1]
          + 1.0/8*GHPLs2[2*4+3]*HPLs1[0]
          - 1.0/8*GHPLs3[0*4*4+2*4+3]
          - 1.0/8*GHPLs2[3*4+3]*HPLs1[0]
          + 1.0/8*GHPLs3[0*4*4+3*4+3]
          + 5.0/8*GHPLs1[3]*zeta2
          + 3.0/8*GHPLs1[3]*HPLs1[0]
          - 1.0/8*GHPLs1[3]*HPLs2[1*2+0]
          - 1.0/8*GHPLs1[3]*HPLs2[0*2+1]
          - 1.0/8*GHPLs3[2*4*4+0*4+3]
          - 3.0/8*GHPLs2[0*4+3]
          + 1.0/8*GHPLs2[0*4+3]*HPLs1[1]
          + 3.0/8*GHPLs2[2*4+0]
          - 1.0/8*GHPLs2[2*4+0]*HPLs1[0]
          + 1.0/8*GHPLs2[3*4+0]*HPLs1[0]
          - 1.0/8*GHPLs3[0*4*4+3*4+0]
          - 3.0/8*GHPLs1[0]*HPLs1[0]
          + 1.0/4*GHPLs1[0]*HPLs2[0*2+0]
          + 1.0/8*GHPLs1[0]*HPLs2[1*2+0]
          - 3.0/8*GHPLs1[0]*HPLs1[1]
          + 1.0/8*GHPLs1[0]*HPLs2[0*2+1]
          - 3.0/8*GHPLs2[2*4+1]
          + 1.0/8*GHPLs3[0*4*4+2*4+1]
          - 1.0/2*GHPLs1[1]*zeta2
          + 3.0/8*GHPLs1[1]*HPLs1[0]
          - 1.0/8*GHPLs1[1]*HPLs2[0*2+0]
          - 1.0/8*GHPLs1[1]*HPLs2[1*2+0]
          + 3.0/8*GHPLs1[1]*HPLs1[1]
          + 1.0/8*GHPLs3[2*4*4+0*4+1]
          - 1.0/8*GHPLs2[0*4+1]*HPLs1[0]
          - 1.0/8*GHPLs2[0*4+1]*HPLs1[1]
          - 1.0/8*GHPLs3[2*4*4+1*4+1]
          + 1.0/8*GHPLs2[1*4+1]*HPLs1[0]
          + 1.0/8*GHPLs2[1*4+1]*HPLs1[1]
          + 5.0/8*HPLs1[0]*zeta2
          + 3.0/8*HPLs2[0*2+0]
          + 1.0/8*HPLs3[1*2*2+0*2+0]
          + 1.0/8*HPLs3[0*2*2+1*2+0]
          + 1.0/8*HPLs1[1]*zeta2
          + 3.0/8*HPLs2[0*2+1]
          + 1.0/8*HPLs3[0*2*2+0*2+1]
          + 1.0/8*HPLs3[1*2*2+0*2+1]
          + 1.0/4*HPLs3[0*2*2+1*2+1]
          )

       + (dN_c*dN_c-1)/(dN_c*dN_c)*pow(u,2)*pow(1-v,-3) * (
          - 9.0/4*zeta2
          - 15.0/4*zeta3
          - 15.0/4*GHPLs2[3*4+2]*HPLs1[0]
          + 15.0/4*GHPLs3[0*4*4+3*4+2]
          + 15.0/4*GHPLs1[2]*zeta2
          - 15.0/4*GHPLs1[2]*HPLs2[0*2+0]
          - 15.0/4*GHPLs1[2]*HPLs2[1*2+0]
          - 15.0/4*GHPLs3[2*4*4+1*4+2]
          + 15.0/4*GHPLs2[1*4+2]*HPLs1[0]
          + 15.0/4*GHPLs2[1*4+2]*HPLs1[1]
          + 9.0/4*GHPLs1[3]*HPLs1[0]
          - 9.0/4*GHPLs2[0*4+3]
          + 15.0/4*GHPLs2[3*4+0]*HPLs1[0]
          - 15.0/4*GHPLs3[0*4*4+3*4+0]
          - 15.0/4*GHPLs1[0]*zeta2
          + 15.0/4*GHPLs1[0]*HPLs2[0*2+0]
          + 15.0/4*GHPLs1[0]*HPLs2[1*2+0]
          + 15.0/4*GHPLs3[2*4*4+1*4+0]
          - 15.0/4*GHPLs2[1*4+0]*HPLs1[0]
          - 15.0/4*GHPLs2[1*4+0]*HPLs1[1]
          + 9.0/4*GHPLs2[2*4+1]
          - 9.0/4*GHPLs1[1]*HPLs1[0]
          - 9.0/4*GHPLs1[1]*HPLs1[1]
          + 15*HPLs1[0]*zeta2
          + 9.0/4*HPLs2[0*2+0]
          - 15.0/4*HPLs3[0*2*2+0*2+0]
          + 9.0/4*HPLs2[1*2+0]
          - 15.0/4*HPLs3[0*2*2+1*2+0]
          - 15.0/4*HPLs1[1]*zeta2
          + 15.0/4*HPLs3[0*2*2+0*2+1]
          + 15.0/4*HPLs3[1*2*2+0*2+1]
          )

       + (dN_c*dN_c-1)/(dN_c*dN_c)*pow(u,2)*pow(1-v,-2) * (
          + 69.0/4*zeta2
          + 15.0/4*zeta3
          + 15.0/4*GHPLs2[3*4+2]*HPLs1[0]
          - 15.0/4*GHPLs3[0*4*4+3*4+2]
          - 9.0/8*GHPLs1[2]
          - 15.0/4*GHPLs1[2]*zeta2
          + 15.0/4*GHPLs1[2]*HPLs1[0]
          + 15.0/4*GHPLs1[2]*HPLs2[0*2+0]
          + 15.0/4*GHPLs1[2]*HPLs2[1*2+0]
          - 15.0/4*GHPLs2[0*4+2]
          + 15.0/4*GHPLs3[2*4*4+1*4+2]
          - 15.0/4*GHPLs2[1*4+2]*HPLs1[0]
          - 15.0/4*GHPLs2[1*4+2]*HPLs1[1]
          - 6*GHPLs1[3]*HPLs1[0]
          + 6*GHPLs2[0*4+3]
          - 15.0/4*GHPLs2[2*4+0]
          - 15.0/4*GHPLs2[3*4+0]*HPLs1[0]
          + 15.0/4*GHPLs3[0*4*4+3*4+0]
          + 9.0/8*GHPLs1[0]
          + 15.0/4*GHPLs1[0]*zeta2
          + 15.0/4*GHPLs1[0]*HPLs1[0]
          - 15.0/4*GHPLs1[0]*HPLs2[0*2+0]
          - 15.0/4*GHPLs1[0]*HPLs2[1*2+0]
          + 15.0/4*GHPLs1[0]*HPLs1[1]
          - 15.0/4*GHPLs3[2*4*4+1*4+0]
          + 15.0/4*GHPLs2[1*4+0]*HPLs1[0]
          + 15.0/4*GHPLs2[1*4+0]*HPLs1[1]
          + 3.0/2*GHPLs2[2*4+1]
          - 3.0/2*GHPLs1[1]*HPLs1[0]
          - 3.0/2*GHPLs1[1]*HPLs1[1]
          - 15*HPLs1[0]*zeta2
          - 6*HPLs2[0*2+0]
          + 15.0/4*HPLs3[0*2*2+0*2+0]
          - 9.0/4*HPLs2[1*2+0]
          + 15.0/4*HPLs3[0*2*2+1*2+0]
          + 9.0/8*HPLs1[1]
          + 15.0/4*HPLs1[1]*zeta2
          - 15.0/4*HPLs2[0*2+1]
          - 15.0/4*HPLs3[0*2*2+0*2+1]
          - 15.0/4*HPLs3[1*2*2+0*2+1]
          )

       + (dN_c*dN_c-1)/(dN_c*dN_c)*pow(u,2)*pow(1-v,-1) * (
          - 15.0/2*zeta2
          + 3.0/8*GHPLs1[2]
          - 15.0/8*GHPLs1[2]*HPLs1[0]
          + 15.0/8*GHPLs2[0*4+2]
          + 15.0/8*GHPLs1[3]*HPLs1[0]
          - 15.0/8*GHPLs2[0*4+3]
          + 15.0/8*GHPLs2[2*4+0]
          - 3.0/8*GHPLs1[0]
          - 15.0/8*GHPLs1[0]*HPLs1[0]
          - 15.0/8*GHPLs1[0]*HPLs1[1]
          - 15.0/8*GHPLs2[2*4+1]
          + 15.0/8*GHPLs1[1]*HPLs1[0]
          + 15.0/8*GHPLs1[1]*HPLs1[1]
          + 15.0/8*HPLs2[0*2+0]
          - 3.0/8*HPLs1[1]
          + 15.0/8*HPLs2[0*2+1]
          )

       + (dN_c*dN_c-1)/(dN_c*dN_c)*pow(u,2) * (
          - 5.0/2*zeta2
          - 5.0/8*GHPLs1[2]*HPLs1[0]
          + 5.0/8*GHPLs2[0*4+2]
          + 5.0/8*GHPLs1[3]*HPLs1[0]
          - 5.0/8*GHPLs2[0*4+3]
          + 5.0/8*GHPLs2[2*4+0]
          - 5.0/8*GHPLs1[0]*HPLs1[0]
          - 5.0/8*GHPLs1[0]*HPLs1[1]
          - 5.0/8*GHPLs2[2*4+1]
          + 5.0/8*GHPLs1[1]*HPLs1[0]
          + 5.0/8*GHPLs1[1]*HPLs1[1]
          + 5.0/8*HPLs2[0*2+0]
          + 5.0/8*HPLs2[0*2+1]
          )

       + (dN_c*dN_c-1)/(dN_c*dN_c)*pow(u,3)*pow(1-v,-4) * (
          + 9.0/4*zeta3
          + 9.0/4*GHPLs2[3*4+2]*HPLs1[0]
          - 9.0/4*GHPLs3[0*4*4+3*4+2]
          - 9.0/4*GHPLs1[2]*zeta2
          + 9.0/4*GHPLs1[2]*HPLs2[0*2+0]
          + 9.0/4*GHPLs1[2]*HPLs2[1*2+0]
          + 9.0/4*GHPLs3[2*4*4+1*4+2]
          - 9.0/4*GHPLs2[1*4+2]*HPLs1[0]
          - 9.0/4*GHPLs2[1*4+2]*HPLs1[1]
          - 9.0/4*GHPLs2[3*4+0]*HPLs1[0]
          + 9.0/4*GHPLs3[0*4*4+3*4+0]
          + 9.0/4*GHPLs1[0]*zeta2
          - 9.0/4*GHPLs1[0]*HPLs2[0*2+0]
          - 9.0/4*GHPLs1[0]*HPLs2[1*2+0]
          - 9.0/4*GHPLs3[2*4*4+1*4+0]
          + 9.0/4*GHPLs2[1*4+0]*HPLs1[0]
          + 9.0/4*GHPLs2[1*4+0]*HPLs1[1]
          - 9*HPLs1[0]*zeta2
          + 9.0/4*HPLs3[0*2*2+0*2+0]
          + 9.0/4*HPLs3[0*2*2+1*2+0]
          + 9.0/4*HPLs1[1]*zeta2
          - 9.0/4*HPLs3[0*2*2+0*2+1]
          - 9.0/4*HPLs3[1*2*2+0*2+1]
          )

       + (dN_c*dN_c-1)/(dN_c*dN_c)*pow(u,3)*pow(1-v,-3) * (
          - 9*zeta2
          - 9.0/4*zeta3
          - 9.0/4*GHPLs2[3*4+2]*HPLs1[0]
          + 9.0/4*GHPLs3[0*4*4+3*4+2]
          + 9.0/4*GHPLs1[2]*zeta2
          - 9.0/4*GHPLs1[2]*HPLs1[0]
          - 9.0/4*GHPLs1[2]*HPLs2[0*2+0]
          - 9.0/4*GHPLs1[2]*HPLs2[1*2+0]
          + 9.0/4*GHPLs2[0*4+2]
          - 9.0/4*GHPLs3[2*4*4+1*4+2]
          + 9.0/4*GHPLs2[1*4+2]*HPLs1[0]
          + 9.0/4*GHPLs2[1*4+2]*HPLs1[1]
          + 9.0/4*GHPLs1[3]*HPLs1[0]
          - 9.0/4*GHPLs2[0*4+3]
          + 9.0/4*GHPLs2[2*4+0]
          + 9.0/4*GHPLs2[3*4+0]*HPLs1[0]
          - 9.0/4*GHPLs3[0*4*4+3*4+0]
          - 9.0/4*GHPLs1[0]*zeta2
          - 9.0/4*GHPLs1[0]*HPLs1[0]
          + 9.0/4*GHPLs1[0]*HPLs2[0*2+0]
          + 9.0/4*GHPLs1[0]*HPLs2[1*2+0]
          - 9.0/4*GHPLs1[0]*HPLs1[1]
          + 9.0/4*GHPLs3[2*4*4+1*4+0]
          - 9.0/4*GHPLs2[1*4+0]*HPLs1[0]
          - 9.0/4*GHPLs2[1*4+0]*HPLs1[1]
          - 9.0/4*GHPLs2[2*4+1]
          + 9.0/4*GHPLs1[1]*HPLs1[0]
          + 9.0/4*GHPLs1[1]*HPLs1[1]
          + 9*HPLs1[0]*zeta2
          + 9.0/4*HPLs2[0*2+0]
          - 9.0/4*HPLs3[0*2*2+0*2+0]
          - 9.0/4*HPLs3[0*2*2+1*2+0]
          - 9.0/4*HPLs1[1]*zeta2
          + 9.0/4*HPLs2[0*2+1]
          + 9.0/4*HPLs3[0*2*2+0*2+1]
          + 9.0/4*HPLs3[1*2*2+0*2+1]
          )

       + (dN_c*dN_c-1)/(dN_c*dN_c)*pow(u,3)*pow(1-v,-2) * (
          + 9.0/2*zeta2
          + 9.0/8*GHPLs1[2]*HPLs1[0]
          - 9.0/8*GHPLs2[0*4+2]
          - 9.0/8*GHPLs1[3]*HPLs1[0]
          + 9.0/8*GHPLs2[0*4+3]
          - 9.0/8*GHPLs2[2*4+0]
          + 9.0/8*GHPLs1[0]*HPLs1[0]
          + 9.0/8*GHPLs1[0]*HPLs1[1]
          + 9.0/8*GHPLs2[2*4+1]
          - 9.0/8*GHPLs1[1]*HPLs1[0]
          - 9.0/8*GHPLs1[1]*HPLs1[1]
          - 9.0/8*HPLs2[0*2+0]
          - 9.0/8*HPLs2[0*2+1]
          )

       + (dN_c*dN_c-1)/(dN_c*dN_c)*pow(u,3)*pow(1-v,-1) * (
          + 3.0/2*zeta2
          + 3.0/8*GHPLs1[2]*HPLs1[0]
          - 3.0/8*GHPLs2[0*4+2]
          - 3.0/8*GHPLs1[3]*HPLs1[0]
          + 3.0/8*GHPLs2[0*4+3]
          - 3.0/8*GHPLs2[2*4+0]
          + 3.0/8*GHPLs1[0]*HPLs1[0]
          + 3.0/8*GHPLs1[0]*HPLs1[1]
          + 3.0/8*GHPLs2[2*4+1]
          - 3.0/8*GHPLs1[1]*HPLs1[0]
          - 3.0/8*GHPLs1[1]*HPLs1[1]
          - 3.0/8*HPLs2[0*2+0]
          - 3.0/8*HPLs2[0*2+1]
          )

       + (dN_c*dN_c-1)/(dN_c*dN_c)*double_complex(0,1)*M_PI*pow(u,-2) * (
          - 1.0/4*GHPLs3[3*4*4+2*4+2]
          - 1.0/4*GHPLs2[2*4+2]*HPLs1[0]
          + 1.0/4*GHPLs1[2]*HPLs1[0]
          - 1.0/4*GHPLs1[2]*HPLs2[0*2+0]
          + 1.0/4*GHPLs3[3*4*4+0*4+2]
          - 1.0/4*GHPLs2[1*4+2]
          + 1.0/8*GHPLs2[1*4+0]
          - 1.0/4*GHPLs3[3*4*4+2*4+1]
          - 1.0/4*GHPLs2[2*4+1]*HPLs1[0]
          + 1.0/4*GHPLs1[1]
          + 1.0/2*GHPLs1[1]*zeta2
          - 1.0/8*GHPLs1[1]*HPLs1[0]
          + 1.0/4*GHPLs1[1]*HPLs2[0*2+0]
          + 1.0/4*GHPLs1[1]*HPLs2[0*2+1]
          - 1.0/4*GHPLs3[3*4*4+0*4+1]
          + 1.0/8*GHPLs2[1*4+1]
          )

       + (dN_c*dN_c-1)/(dN_c*dN_c)*double_complex(0,1)*M_PI*pow(u,-2)*v * (
          + 1.0/4*GHPLs3[3*4*4+2*4+2]
          + 1.0/4*GHPLs2[2*4+2]*HPLs1[0]
          - 1.0/4*GHPLs1[2]*HPLs1[0]
          + 1.0/4*GHPLs1[2]*HPLs2[0*2+0]
          - 1.0/4*GHPLs3[3*4*4+0*4+2]
          + 1.0/4*GHPLs2[1*4+2]
          - 1.0/8*GHPLs2[1*4+0]
          + 1.0/4*GHPLs3[3*4*4+2*4+1]
          + 1.0/4*GHPLs2[2*4+1]*HPLs1[0]
          - 1.0/8*GHPLs1[1]
          - 1.0/2*GHPLs1[1]*zeta2
          + 1.0/8*GHPLs1[1]*HPLs1[0]
          - 1.0/4*GHPLs1[1]*HPLs2[0*2+0]
          - 1.0/4*GHPLs1[1]*HPLs2[0*2+1]
          + 1.0/4*GHPLs3[3*4*4+0*4+1]
          - 1.0/8*GHPLs2[1*4+1]
          )

       + (dN_c*dN_c-1)/(dN_c*dN_c)*double_complex(0,1)*M_PI*pow(u,-2)*pow(v,2) * (
          + 1.0/8*GHPLs2[1*4+2]
          - 1.0/8*GHPLs2[2*4+3]
          + 1.0/8*GHPLs2[3*4+3]
          + 1.0/8*GHPLs1[3]*HPLs1[0]
          + 1.0/8*GHPLs1[3]*HPLs1[1]
          - 1.0/8*GHPLs2[0*4+3]
          - 1.0/8*GHPLs1[1]
          )

       + (dN_c*dN_c-1)/(dN_c*dN_c)*double_complex(0,1)*M_PI*pow(u,-2)*pow(v,3) * (
          - 1.0/8*GHPLs2[1*4+2]
          + 1.0/8*GHPLs2[2*4+3]
          - 1.0/8*GHPLs2[3*4+3]
          - 1.0/8*GHPLs1[3]*HPLs1[0]
          - 1.0/8*GHPLs1[3]*HPLs1[1]
          + 1.0/8*GHPLs2[0*4+3]
          )

       + (dN_c*dN_c-1)/(dN_c*dN_c)*double_complex(0,1)*M_PI*pow(u,-1)*pow(u+v,-1) * (
          - 1.0/8*GHPLs1[1]
          )

       + (dN_c*dN_c-1)/(dN_c*dN_c)*double_complex(0,1)*M_PI*pow(u,-1) * (
          + 3.0/8
          + 1.0/2*zeta2
          - 1.0/2*GHPLs2[3*4+2]
          - 3.0/2*GHPLs1[2]*HPLs1[0]
          + GHPLs2[1*4+2]
          - 1.0/2*GHPLs2[1*4+0]
          - 3.0/4*GHPLs1[1]
          + 1.0/2*GHPLs1[1]*HPLs1[0]
          - 1.0/2*GHPLs2[1*4+1]
          + 1.0/8*HPLs1[0]
          + 1.0/4*HPLs2[0*2+1]
          )

       + (dN_c*dN_c-1)/(dN_c*dN_c)*double_complex(0,1)*M_PI*pow(u,-1)*v * (
          - 3.0/8
          - 1.0/2*zeta2
          - 1.0/4*GHPLs3[3*4*4+2*4+2]
          - 1.0/4*GHPLs2[2*4+2]*HPLs1[0]
          + 1.0/4*GHPLs2[3*4+2]
          + 1.0/8*GHPLs1[2]
          + 1.0/2*GHPLs1[2]*HPLs1[0]
          - 1.0/4*GHPLs1[2]*HPLs2[0*2+0]
          + 1.0/4*GHPLs3[3*4*4+0*4+2]
          - 1.0/2*GHPLs2[1*4+2]
          + 1.0/4*GHPLs2[2*4+3]
          - 1.0/4*GHPLs2[3*4+3]
          - 3.0/8*GHPLs1[3]
          - 1.0/4*GHPLs1[3]*HPLs1[0]
          - 1.0/4*GHPLs1[3]*HPLs1[1]
          + 1.0/4*GHPLs2[0*4+3]
          + 1.0/4*GHPLs2[3*4+0]
          + 1.0/8*GHPLs1[0]
          + 1.0/8*GHPLs2[1*4+0]
          - 1.0/4*GHPLs3[3*4*4+2*4+1]
          - 1.0/4*GHPLs2[2*4+1]*HPLs1[0]
          - 3.0/8*GHPLs1[1]
          + 1.0/2*GHPLs1[1]*zeta2
          - 1.0/8*GHPLs1[1]*HPLs1[0]
          + 1.0/4*GHPLs1[1]*HPLs2[0*2+0]
          + 1.0/4*GHPLs1[1]*HPLs2[0*2+1]
          - 1.0/4*GHPLs3[3*4*4+0*4+1]
          + 1.0/8*GHPLs2[1*4+1]
          - 1.0/4*HPLs2[0*2+0]
          - 1.0/8*HPLs1[1]
          - 1.0/4*HPLs2[0*2+1]
          )

       + (dN_c*dN_c-1)/(dN_c*dN_c)*double_complex(0,1)*M_PI*pow(u,-1)*pow(v,2) * (
          - 1.0/8*GHPLs1[2]
          - 1.0/4*GHPLs2[1*4+2]
          + 1.0/4*GHPLs2[2*4+3]
          - 1.0/4*GHPLs2[3*4+3]
          + 1.0/8*GHPLs1[3]
          - 1.0/4*GHPLs1[3]*HPLs1[0]
          - 1.0/4*GHPLs1[3]*HPLs1[1]
          + 1.0/4*GHPLs2[0*4+3]
          - 1.0/8*GHPLs1[0]
          + 1.0/4*GHPLs1[1]
          + 1.0/8*HPLs1[0]
          + 1.0/8*HPLs1[1]
          )

       + (dN_c*dN_c-1)/(dN_c*dN_c)*double_complex(0,1)*M_PI*pow(u,-1)*pow(v,3) * (
          + 1.0/8*GHPLs2[1*4+2]
          - 1.0/8*GHPLs2[2*4+3]
          + 1.0/8*GHPLs2[3*4+3]
          + 1.0/8*GHPLs1[3]*HPLs1[0]
          + 1.0/8*GHPLs1[3]*HPLs1[1]
          - 1.0/8*GHPLs2[0*4+3]
          )

       + (dN_c*dN_c-1)/(dN_c*dN_c)*double_complex(0,1)*M_PI*pow(1-u,-1) * (
          - 1.0/2*GHPLs1[3]
          - 1.0/2*HPLs1[0]
          )

       + (dN_c*dN_c-1)/(dN_c*dN_c)*double_complex(0,1)*M_PI*pow(1-v,-1) * (
          - 3.0/4*zeta2
          + 3.0/4*GHPLs1[2]*HPLs1[0]
          - 9.0/8*GHPLs2[1*4+2]
          - 7.0/8*GHPLs1[3]
          - 3.0/8*GHPLs1[0]*HPLs1[0]
          + 9.0/8*GHPLs2[1*4+0]
          + 5.0/4*GHPLs1[1]
          - 1.0/16*HPLs1[0]
          + 3.0/8*HPLs2[1*2+0]
          - 3.0/8*HPLs2[0*2+1]
          )

       + (dN_c*dN_c-1)/(dN_c*dN_c)*double_complex(0,1)*M_PI*pow(u+v,-2) * (
          - 1.0/8*GHPLs1[2]*HPLs1[0]
          + 1.0/8*GHPLs2[1*4+2]
          + 1.0/8*GHPLs2[1*4+0]
          + 1.0/8*HPLs2[0*2+1]
          )

       + (dN_c*dN_c-1)/(dN_c*dN_c)*double_complex(0,1)*M_PI*pow(u+v,-1) * (
          + 1.0/16
          + 1.0/2*GHPLs1[2]*HPLs1[0]
          - 1.0/2*GHPLs2[1*4+2]
          - 1.0/2*GHPLs2[1*4+0]
          + 1.0/8*GHPLs1[1]
          - 1.0/8*HPLs1[0]
          - 1.0/2*HPLs2[0*2+1]
          )

       + (dN_c*dN_c-1)/(dN_c*dN_c)*double_complex(0,1)*M_PI*pow(1-u-v,-1) * (
          - 1.0/2*GHPLs1[3]
          - 1.0/2*HPLs1[0]
          )

       + (dN_c*dN_c-1)/(dN_c*dN_c)*double_complex(0,1)*M_PI * (
          - 17.0/32
          + 5.0/8*zeta2
          + zeta3
          + 1.0/4*GHPLs3[3*4*4+2*4+2]
          + 1.0/4*GHPLs2[2*4+2]*HPLs1[0]
          - GHPLs2[3*4+2]
          - 3.0/8*GHPLs1[2]
          - 11.0/8*GHPLs1[2]*HPLs1[0]
          + 1.0/4*GHPLs1[2]*HPLs2[0*2+0]
          - 1.0/4*GHPLs3[3*4*4+0*4+2]
          + 3.0/4*GHPLs2[1*4+2]
          + 1.0/4*GHPLs3[3*4*4+2*4+3]
          + 1.0/4*GHPLs2[2*4+3]*HPLs1[0]
          + 1.0/2*GHPLs3[3*4*4+3*4+3]
          - 3.0/8*GHPLs2[3*4+3]
          + 1.0/2*GHPLs2[3*4+3]*HPLs1[0]
          - 1.0/2*GHPLs3[0*4*4+3*4+3]
          + 45.0/16*GHPLs1[3]
          - 1.0/4*GHPLs1[3]*zeta2
          + 3.0/4*GHPLs1[3]*HPLs2[0*2+0]
          - 1.0/4*GHPLs1[3]*HPLs2[0*2+1]
          - 1.0/4*GHPLs3[3*4*4+0*4+3]
          - 1.0/2*GHPLs2[0*4+3]*HPLs1[0]
          - 1.0/2*GHPLs2[2*4+0]*HPLs1[0]
          + 1.0/2*GHPLs3[1*4*4+2*4+0]
          - 1.0/2*GHPLs3[3*4*4+3*4+0]
          + 3.0/8*GHPLs2[3*4+0]
          - 1.0/4*GHPLs2[3*4+0]*HPLs1[0]
          - 3.0/8*GHPLs1[0]
          + 3.0/8*GHPLs1[0]*HPLs1[0]
          - 1.0/2*GHPLs1[0]*HPLs2[0*2+0]
          - 1.0/2*GHPLs3[1*4*4+0*4+0]
          - 3.0/8*GHPLs2[1*4+0]
          + 1.0/2*GHPLs2[1*4+0]*HPLs1[0]
          - 1.0/2*GHPLs3[1*4*4+1*4+0]
          + 1.0/4*GHPLs3[3*4*4+2*4+1]
          + 1.0/4*GHPLs2[2*4+1]*HPLs1[0]
          - 1.0/8*GHPLs1[1]
          - 1.0/2*GHPLs1[1]*zeta2
          - 3.0/8*GHPLs1[1]*HPLs1[0]
          - 1.0/4*GHPLs1[1]*HPLs2[0*2+0]
          - 1.0/4*GHPLs1[1]*HPLs2[0*2+1]
          + 1.0/4*GHPLs3[3*4*4+0*4+1]
          + 3.0/8*GHPLs2[1*4+1]
          + 2*HPLs1[0]
          - 1.0/4*HPLs1[0]*zeta2
          + 3.0/4*HPLs3[0*2*2+0*2+0]
          - 3.0/8*HPLs2[1*2+0]
          - 1.0/4*HPLs3[0*2*2+1*2+0]
          + 3.0/8*HPLs1[1]
          + 7.0/8*HPLs2[0*2+1]
          )

       + (dN_c*dN_c-1)/(dN_c*dN_c)*double_complex(0,1)*M_PI*v*pow(1-u,-2) * (
          + zeta2
          - 1.0/2*GHPLs2[3*4+2]
          - 1.0/2*GHPLs1[2]*HPLs1[0]
          - 1.0/2*GHPLs2[3*4+0]
          + 1.0/2*HPLs2[0*2+0]
          + 1.0/2*HPLs2[0*2+1]
          )

       + (dN_c*dN_c-1)/(dN_c*dN_c)*double_complex(0,1)*M_PI*v*pow(1-u,-1) * (
          - 1.0/2*zeta2
          + 1.0/4*GHPLs2[3*4+2]
          + 1.0/4*GHPLs1[2]*HPLs1[0]
          - 1.0/2*GHPLs1[3]
          + 1.0/4*GHPLs2[3*4+0]
          - 1.0/4*HPLs2[0*2+0]
          - 1.0/4*HPLs2[0*2+1]
          )

       + (dN_c*dN_c-1)/(dN_c*dN_c)*double_complex(0,1)*M_PI*v * (
          + 1.0/8*zeta2
          - 1.0/2*GHPLs1[2]
          - 1.0/8*GHPLs2[1*4+2]
          + 1.0/8*GHPLs2[2*4+3]
          - 1.0/8*GHPLs2[3*4+3]
          + 5.0/8*GHPLs1[3]
          - 1.0/8*GHPLs1[3]*HPLs1[0]
          - 1.0/8*GHPLs1[3]*HPLs1[1]
          + 1.0/8*GHPLs2[0*4+3]
          + 1.0/8*GHPLs2[3*4+0]
          - 1.0/2*GHPLs1[0]
          + 1.0/8*GHPLs1[0]*HPLs1[0]
          - 1.0/8*GHPLs2[2*4+1]
          + 5.0/8*GHPLs1[1]
          + 1.0/8*GHPLs1[1]*HPLs1[1]
          - 1.0/8*GHPLs2[0*4+1]
          + 1.0/8*GHPLs2[1*4+1]
          + 5.0/8*HPLs1[0]
          - 1.0/8*HPLs2[0*2+0]
          - 1.0/8*HPLs2[1*2+0]
          + 1.0/2*HPLs1[1]
          )

       + (dN_c*dN_c-1)/(dN_c*dN_c)*double_complex(0,1)*M_PI*pow(v,2) * (
          + 1.0/8*GHPLs1[2]
          + 1.0/4*GHPLs2[1*4+2]
          - 1.0/4*GHPLs2[2*4+3]
          + 1.0/4*GHPLs2[3*4+3]
          - 1.0/8*GHPLs1[3]
          + 1.0/4*GHPLs1[3]*HPLs1[0]
          + 1.0/4*GHPLs1[3]*HPLs1[1]
          - 1.0/4*GHPLs2[0*4+3]
          + 1.0/8*GHPLs1[0]
          - 1.0/8*GHPLs1[1]
          - 1.0/8*HPLs1[0]
          - 1.0/8*HPLs1[1]
          )

       + (dN_c*dN_c-1)/(dN_c*dN_c)*double_complex(0,1)*M_PI*u*pow(1-v,-2) * (
          + 17.0/4*zeta2
          - 2*GHPLs2[3*4+2]
          - 9.0/4*GHPLs1[2]*HPLs1[0]
          + 19.0/8*GHPLs2[1*4+2]
          + 21.0/8*GHPLs1[3]
          + 2*GHPLs2[3*4+0]
          + 17.0/8*GHPLs1[0]*HPLs1[0]
          - 19.0/8*GHPLs2[1*4+0]
          - 21.0/8*GHPLs1[1]
          + 39.0/16*HPLs1[0]
          - 2*HPLs2[0*2+0]
          - 17.0/8*HPLs2[1*2+0]
          + 17.0/8*HPLs2[0*2+1]
          )

       + (dN_c*dN_c-1)/(dN_c*dN_c)*double_complex(0,1)*M_PI*u*pow(1-v,-1) * (
          + 5.0/16
          - 17.0/4*zeta2
          + 2*GHPLs2[3*4+2]
          + 17.0/8*GHPLs1[2]
          + 9.0/4*GHPLs1[2]*HPLs1[0]
          - 19.0/8*GHPLs2[1*4+2]
          - 37.0/8*GHPLs1[3]
          - 2*GHPLs2[3*4+0]
          + 17.0/8*GHPLs1[0]
          - 17.0/8*GHPLs1[0]*HPLs1[0]
          + 19.0/8*GHPLs2[1*4+0]
          + 1.0/4*GHPLs1[1]
          - 71.0/16*HPLs1[0]
          + 2*HPLs2[0*2+0]
          + 17.0/8*HPLs2[1*2+0]
          - 17.0/8*HPLs1[1]
          - 17.0/8*HPLs2[0*2+1]
          )

       + (dN_c*dN_c-1)/(dN_c*dN_c)*double_complex(0,1)*M_PI*u*pow(u+v,-2) * (
          - 1.0/16
          )

       + (dN_c*dN_c-1)/(dN_c*dN_c)*double_complex(0,1)*M_PI*u*pow(u+v,-1) * (
          - 7.0/16
          )

       + (dN_c*dN_c-1)/(dN_c*dN_c)*double_complex(0,1)*M_PI*u*pow(1-u-v,-1) * (
          + 1.0/4*GHPLs1[3]
          + 1.0/4*HPLs1[0]
          )

       + (dN_c*dN_c-1)/(dN_c*dN_c)*double_complex(0,1)*M_PI*u * (
          - 3.0/8
          - 5.0/4*GHPLs1[2]
          + 5.0/4*GHPLs1[3]
          - 5.0/4*GHPLs1[0]
          + 5.0/4*GHPLs1[1]
          + 5.0/4*HPLs1[0]
          + 5.0/4*HPLs1[1]
          )

       + (dN_c*dN_c-1)/(dN_c*dN_c)*double_complex(0,1)*M_PI*u*v * (
          - 1.0/8*zeta2
          + 3.0/8*GHPLs1[2]
          + 1.0/8*GHPLs2[1*4+2]
          - 1.0/8*GHPLs2[2*4+3]
          + 1.0/8*GHPLs2[3*4+3]
          - 3.0/8*GHPLs1[3]
          + 1.0/8*GHPLs1[3]*HPLs1[0]
          + 1.0/8*GHPLs1[3]*HPLs1[1]
          - 1.0/8*GHPLs2[0*4+3]
          - 1.0/8*GHPLs2[3*4+0]
          + 3.0/8*GHPLs1[0]
          - 1.0/8*GHPLs1[0]*HPLs1[0]
          + 1.0/8*GHPLs2[2*4+1]
          - 3.0/8*GHPLs1[1]
          - 1.0/8*GHPLs1[1]*HPLs1[1]
          + 1.0/8*GHPLs2[0*4+1]
          - 1.0/8*GHPLs2[1*4+1]
          - 3.0/8*HPLs1[0]
          + 1.0/8*HPLs2[0*2+0]
          + 1.0/8*HPLs2[1*2+0]
          - 3.0/8*HPLs1[1]
          )

       + (dN_c*dN_c-1)/(dN_c*dN_c)*double_complex(0,1)*M_PI*pow(u,2)*pow(1-v,-3) * (
          - 15.0/2*zeta2
          + 15.0/4*GHPLs2[3*4+2]
          + 15.0/4*GHPLs1[2]*HPLs1[0]
          - 15.0/4*GHPLs2[1*4+2]
          - 9.0/4*GHPLs1[3]
          - 15.0/4*GHPLs2[3*4+0]
          - 15.0/4*GHPLs1[0]*HPLs1[0]
          + 15.0/4*GHPLs2[1*4+0]
          + 9.0/4*GHPLs1[1]
          - 9.0/4*HPLs1[0]
          + 15.0/4*HPLs2[0*2+0]
          + 15.0/4*HPLs2[1*2+0]
          - 15.0/4*HPLs2[0*2+1]
          )

       + (dN_c*dN_c-1)/(dN_c*dN_c)*double_complex(0,1)*M_PI*pow(u,2)*pow(1-v,-2) * (
          + 15.0/2*zeta2
          - 15.0/4*GHPLs2[3*4+2]
          - 15.0/4*GHPLs1[2]
          - 15.0/4*GHPLs1[2]*HPLs1[0]
          + 15.0/4*GHPLs2[1*4+2]
          + 6*GHPLs1[3]
          + 15.0/4*GHPLs2[3*4+0]
          - 15.0/4*GHPLs1[0]
          + 15.0/4*GHPLs1[0]*HPLs1[0]
          - 15.0/4*GHPLs2[1*4+0]
          + 3.0/2*GHPLs1[1]
          + 6*HPLs1[0]
          - 15.0/4*HPLs2[0*2+0]
          - 15.0/4*HPLs2[1*2+0]
          + 15.0/4*HPLs1[1]
          + 15.0/4*HPLs2[0*2+1]
          )

       + (dN_c*dN_c-1)/(dN_c*dN_c)*double_complex(0,1)*M_PI*pow(u,2)*pow(1-v,-1) * (
          + 15.0/8*GHPLs1[2]
          - 15.0/8*GHPLs1[3]
          + 15.0/8*GHPLs1[0]
          - 15.0/8*GHPLs1[1]
          - 15.0/8*HPLs1[0]
          - 15.0/8*HPLs1[1]
          )

       + (dN_c*dN_c-1)/(dN_c*dN_c)*double_complex(0,1)*M_PI*pow(u,2) * (
          + 5.0/8*GHPLs1[2]
          - 5.0/8*GHPLs1[3]
          + 5.0/8*GHPLs1[0]
          - 5.0/8*GHPLs1[1]
          - 5.0/8*HPLs1[0]
          - 5.0/8*HPLs1[1]
          )

       + (dN_c*dN_c-1)/(dN_c*dN_c)*double_complex(0,1)*M_PI*pow(u,3)*pow(1-v,-4) * (
          + 9.0/2*zeta2
          - 9.0/4*GHPLs2[3*4+2]
          - 9.0/4*GHPLs1[2]*HPLs1[0]
          + 9.0/4*GHPLs2[1*4+2]
          + 9.0/4*GHPLs2[3*4+0]
          + 9.0/4*GHPLs1[0]*HPLs1[0]
          - 9.0/4*GHPLs2[1*4+0]
          - 9.0/4*HPLs2[0*2+0]
          - 9.0/4*HPLs2[1*2+0]
          + 9.0/4*HPLs2[0*2+1]
          )

       + (dN_c*dN_c-1)/(dN_c*dN_c)*double_complex(0,1)*M_PI*pow(u,3)*pow(1-v,-3) * (
          - 9.0/2*zeta2
          + 9.0/4*GHPLs2[3*4+2]
          + 9.0/4*GHPLs1[2]
          + 9.0/4*GHPLs1[2]*HPLs1[0]
          - 9.0/4*GHPLs2[1*4+2]
          - 9.0/4*GHPLs1[3]
          - 9.0/4*GHPLs2[3*4+0]
          + 9.0/4*GHPLs1[0]
          - 9.0/4*GHPLs1[0]*HPLs1[0]
          + 9.0/4*GHPLs2[1*4+0]
          - 9.0/4*GHPLs1[1]
          - 9.0/4*HPLs1[0]
          + 9.0/4*HPLs2[0*2+0]
          + 9.0/4*HPLs2[1*2+0]
          - 9.0/4*HPLs1[1]
          - 9.0/4*HPLs2[0*2+1]
          )

       + (dN_c*dN_c-1)/(dN_c*dN_c)*double_complex(0,1)*M_PI*pow(u,3)*pow(1-v,-2) * (
          - 9.0/8*GHPLs1[2]
          + 9.0/8*GHPLs1[3]
          - 9.0/8*GHPLs1[0]
          + 9.0/8*GHPLs1[1]
          + 9.0/8*HPLs1[0]
          + 9.0/8*HPLs1[1]
          )

       + (dN_c*dN_c-1)/(dN_c*dN_c)*double_complex(0,1)*M_PI*pow(u,3)*pow(1-v,-1) * (
          - 3.0/8*GHPLs1[2]
          + 3.0/8*GHPLs1[3]
          - 3.0/8*GHPLs1[0]
          + 3.0/8*GHPLs1[1]
          + 3.0/8*HPLs1[0]
          + 3.0/8*HPLs1[1]
          )

       + C_F*NF*pow(1-v,-1) * (
          - 1.0/2*zeta2
          - 1.0/2*GHPLs1[0]*HPLs1[0]
          + 17.0/12*HPLs1[0]
          + HPLs2[0*2+0]
          - 1.0/2*HPLs2[0*2+1]
          )

       + C_F*NF * (
          + 4769.0/1296
          + 1.0/36*zeta2
          - 13.0/36*zeta3
          - 1.0/3*GHPLs2[3*4+3]*HPLs1[0]
          + 1.0/3*GHPLs3[0*4*4+3*4+3]
          + 2.0/3*GHPLs1[3]*zeta2
          + 19.0/18*GHPLs1[3]*HPLs1[0]
          + 1.0/3*GHPLs1[3]*HPLs2[0*2+0]
          - 19.0/18*GHPLs2[0*4+3]
          - 1.0/3*GHPLs2[0*4+3]*HPLs1[0]
          + 1.0/3*GHPLs3[0*4*4+0*4+3]
          - 1.0/6*GHPLs1[0]
          + 1.0/3*GHPLs1[0]*zeta2
          - 5.0/9*GHPLs1[0]*HPLs1[0]
          - 2.0/3*GHPLs1[0]*HPLs2[0*2+0]
          + 1.0/3*GHPLs1[0]*HPLs2[0*2+1]
          + 1.0/3*GHPLs2[0*4+0]*HPLs1[0]
          - 4.0/27*HPLs1[0]
          + 7.0/12*HPLs1[0]*zeta2
          + 1.0/18*HPLs2[0*2+0]
          + 2.0/3*HPLs3[0*2*2+0*2+0]
          - 1.0/3*HPLs3[0*2*2+1*2+0]
          + 1.0/3*HPLs1[1]*zeta2
          - 5.0/9*HPLs2[0*2+1]
          - 2.0/3*HPLs3[0*2*2+0*2+1]
          + 1.0/3*HPLs3[0*2*2+1*2+1]
          )

       + C_F*NF*u*pow(1-v,-2) * (
          + 1.0/6*zeta2
          + 1.0/6*GHPLs1[0]*HPLs1[0]
          - 13.0/36*HPLs1[0]
          - 1.0/3*HPLs2[0*2+0]
          + 1.0/6*HPLs2[0*2+1]
          )

       + C_F*NF*u*pow(1-v,-1) * (
          - 19.0/36
          - 1.0/6*zeta2
          + 1.0/6*GHPLs1[0]
          - 1.0/6*GHPLs1[0]*HPLs1[0]
          + 7.0/36*HPLs1[0]
          + 1.0/3*HPLs2[0*2+0]
          - 1.0/6*HPLs2[0*2+1]
          )

       + C_F*NF*double_complex(0,1)*M_PI * (
          + 119.0/108
          + 1.0/4*zeta2
          + 1.0/3*GHPLs2[3*4+3]
          - 19.0/18*GHPLs1[3]
          - 19.0/18*HPLs1[0]
          - 1.0/3*HPLs2[0*2+0]
          );
}

void beta_2_2(double u, double v, int n_f, double *GHPLs1, double *GHPLs2, double *GHPLs3, double *GHPLs4, double *HPLs1, double *HPLs2, double *HPLs3, double *HPLs4, double_complex &beta) {
  //  const double zeta2 = M_PI*M_PI/6;
  //  const double zeta3 = 1.20205690315959429;
  //  const double zeta4 = pow(M_PI,4)/90;
  //  const double dN_c=3;
  //  const double C_F=(dN_c*dN_c-1)/(2*dN_c);
  double NF=(double)n_f;

  beta =
    (dN_c*dN_c-1)*pow(u,-2) * (
          + 1.0/2*GHPLs2[2*4+2]*zeta2
          - 13.0/24*GHPLs2[2*4+2]*HPLs1[0]
          - 1.0/2*GHPLs2[2*4+2]*HPLs2[1*2+0]
          - 1.0/2*GHPLs4[2*4*4*4+1*4*4+2*4+2]
          + 1.0/2*GHPLs3[1*4*4+2*4+2]*HPLs1[0]
          + 1.0/2*GHPLs3[1*4*4+2*4+2]*HPLs1[1]
          - 13.0/24*GHPLs1[2]*zeta2
          + 277.0/144*GHPLs1[2]*HPLs1[0]
          + 11.0/6*GHPLs1[2]*HPLs2[0*2+0]
          + 13.0/24*GHPLs1[2]*HPLs2[1*2+0]
          + 1.0/2*GHPLs3[2*4*4+0*4+2]*HPLs1[0]
          + 1.0/2*GHPLs4[2*4*4*4+1*4*4+0*4+2]
          - 1.0/2*GHPLs3[1*4*4+0*4+2]*HPLs1[0]
          - 1.0/2*GHPLs3[1*4*4+0*4+2]*HPLs1[1]
          + 1.0/4*GHPLs3[2*4*4+1*4+2]*HPLs1[0]
          - GHPLs2[1*4+2]*zeta2
          + 1.0/4*GHPLs2[1*4+2]*HPLs2[1*2+0]
          - 1.0/4*GHPLs2[1*4+2]*HPLs2[0*2+1]
          + 1.0/2*GHPLs4[2*4*4*4+1*4*4+1*4+2]
          - 1.0/2*GHPLs3[1*4*4+1*4+2]*HPLs1[0]
          - 1.0/2*GHPLs3[1*4*4+1*4+2]*HPLs1[1]
          - 13.0/24*GHPLs3[2*4*4+2*4+1]
          + 1.0/2*GHPLs3[2*4*4+2*4+1]*HPLs1[0]
          + 277.0/144*GHPLs2[2*4+1]
          - GHPLs2[2*4+1]*zeta2
          + 11.0/12*GHPLs2[2*4+1]*HPLs1[0]
          + 1.0/4*GHPLs2[2*4+1]*HPLs2[1*2+0]
          + 13.0/24*GHPLs2[2*4+1]*HPLs1[1]
          - 1.0/4*GHPLs2[2*4+1]*HPLs2[0*2+1]
          + 3.0/4*GHPLs4[2*4*4*4+1*4*4+2*4+1]
          - 3.0/4*GHPLs3[1*4*4+2*4+1]*HPLs1[0]
          - 3.0/4*GHPLs3[1*4*4+2*4+1]*HPLs1[1]
          - 67.0/24*GHPLs1[1]*zeta2
          - 3.0/4*GHPLs1[1]*zeta3
          - 277.0/144*GHPLs1[1]*HPLs1[0]
          - 11.0/6*GHPLs1[1]*HPLs2[0*2+0]
          - 35.0/24*GHPLs1[1]*HPLs2[1*2+0]
          - 277.0/144*GHPLs1[1]*HPLs1[1]
          + GHPLs1[1]*HPLs1[1]*zeta2
          - 11.0/12*GHPLs1[1]*HPLs2[0*2+1]
          - 1.0/4*GHPLs1[1]*HPLs3[1*2*2+0*2+1]
          - 13.0/24*GHPLs1[1]*HPLs2[1*2+1]
          + 1.0/4*GHPLs1[1]*HPLs3[0*2*2+1*2+1]
          - 1.0/4*GHPLs3[2*4*4+0*4+1]*HPLs1[0]
          - 1.0/4*GHPLs4[2*4*4*4+1*4*4+0*4+1]
          + 1.0/4*GHPLs3[1*4*4+0*4+1]*HPLs1[0]
          + 1.0/4*GHPLs3[1*4*4+0*4+1]*HPLs1[1]
          + 1.0/2*GHPLs4[2*4*4*4+2*4*4+1*4+1]
          - 13.0/24*GHPLs3[2*4*4+1*4+1]
          - 1.0/2*GHPLs3[2*4*4+1*4+1]*HPLs1[0]
          - 1.0/2*GHPLs3[2*4*4+1*4+1]*HPLs1[1]
          - 1.0/2*GHPLs2[1*4+1]*zeta2
          + 13.0/24*GHPLs2[1*4+1]*HPLs1[0]
          + 13.0/24*GHPLs2[1*4+1]*HPLs1[1]
          + 1.0/2*GHPLs2[1*4+1]*HPLs2[0*2+1]
          + 1.0/2*GHPLs2[1*4+1]*HPLs2[1*2+1]
          - 1.0/2*GHPLs4[2*4*4*4+1*4*4+1*4+1]
          + 1.0/2*GHPLs3[1*4*4+1*4+1]*HPLs1[0]
          + 1.0/2*GHPLs3[1*4*4+1*4+1]*HPLs1[1]
          )

       + (dN_c*dN_c-1)*pow(u,-2)*v * (
          - 1.0/2*GHPLs2[2*4+2]*zeta2
          + 13.0/24*GHPLs2[2*4+2]*HPLs1[0]
          + 1.0/2*GHPLs2[2*4+2]*HPLs2[1*2+0]
          + 1.0/2*GHPLs4[2*4*4*4+1*4*4+2*4+2]
          - 1.0/2*GHPLs3[1*4*4+2*4+2]*HPLs1[0]
          - 1.0/2*GHPLs3[1*4*4+2*4+2]*HPLs1[1]
          + 13.0/24*GHPLs1[2]*zeta2
          - 277.0/144*GHPLs1[2]*HPLs1[0]
          - 11.0/6*GHPLs1[2]*HPLs2[0*2+0]
          - 13.0/24*GHPLs1[2]*HPLs2[1*2+0]
          - 1.0/2*GHPLs3[2*4*4+0*4+2]*HPLs1[0]
          - 1.0/2*GHPLs4[2*4*4*4+1*4*4+0*4+2]
          + 1.0/2*GHPLs3[1*4*4+0*4+2]*HPLs1[0]
          + 1.0/2*GHPLs3[1*4*4+0*4+2]*HPLs1[1]
          - 1.0/4*GHPLs3[2*4*4+1*4+2]*HPLs1[0]
          + GHPLs2[1*4+2]*zeta2
          - 1.0/4*GHPLs2[1*4+2]*HPLs2[1*2+0]
          + 1.0/4*GHPLs2[1*4+2]*HPLs2[0*2+1]
          - 1.0/2*GHPLs4[2*4*4*4+1*4*4+1*4+2]
          + 1.0/2*GHPLs3[1*4*4+1*4+2]*HPLs1[0]
          + 1.0/2*GHPLs3[1*4*4+1*4+2]*HPLs1[1]
          + 13.0/24*GHPLs3[2*4*4+2*4+1]
          - 1.0/2*GHPLs3[2*4*4+2*4+1]*HPLs1[0]
          - 277.0/144*GHPLs2[2*4+1]
          + GHPLs2[2*4+1]*zeta2
          - 11.0/12*GHPLs2[2*4+1]*HPLs1[0]
          - 1.0/4*GHPLs2[2*4+1]*HPLs2[1*2+0]
          - 13.0/24*GHPLs2[2*4+1]*HPLs1[1]
          + 1.0/4*GHPLs2[2*4+1]*HPLs2[0*2+1]
          - 3.0/4*GHPLs4[2*4*4*4+1*4*4+2*4+1]
          + 3.0/4*GHPLs3[1*4*4+2*4+1]*HPLs1[0]
          + 3.0/4*GHPLs3[1*4*4+2*4+1]*HPLs1[1]
          + 67.0/24*GHPLs1[1]*zeta2
          + 3.0/4*GHPLs1[1]*zeta3
          + 277.0/144*GHPLs1[1]*HPLs1[0]
          + 11.0/6*GHPLs1[1]*HPLs2[0*2+0]
          + 35.0/24*GHPLs1[1]*HPLs2[1*2+0]
          + 277.0/144*GHPLs1[1]*HPLs1[1]
          - GHPLs1[1]*HPLs1[1]*zeta2
          + 11.0/12*GHPLs1[1]*HPLs2[0*2+1]
          + 1.0/4*GHPLs1[1]*HPLs3[1*2*2+0*2+1]
          + 13.0/24*GHPLs1[1]*HPLs2[1*2+1]
          - 1.0/4*GHPLs1[1]*HPLs3[0*2*2+1*2+1]
          + 1.0/4*GHPLs3[2*4*4+0*4+1]*HPLs1[0]
          + 1.0/4*GHPLs4[2*4*4*4+1*4*4+0*4+1]
          - 1.0/4*GHPLs3[1*4*4+0*4+1]*HPLs1[0]
          - 1.0/4*GHPLs3[1*4*4+0*4+1]*HPLs1[1]
          - 1.0/2*GHPLs4[2*4*4*4+2*4*4+1*4+1]
          + 13.0/24*GHPLs3[2*4*4+1*4+1]
          + 1.0/2*GHPLs3[2*4*4+1*4+1]*HPLs1[0]
          + 1.0/2*GHPLs3[2*4*4+1*4+1]*HPLs1[1]
          + 1.0/2*GHPLs2[1*4+1]*zeta2
          - 13.0/24*GHPLs2[1*4+1]*HPLs1[0]
          - 13.0/24*GHPLs2[1*4+1]*HPLs1[1]
          - 1.0/2*GHPLs2[1*4+1]*HPLs2[0*2+1]
          - 1.0/2*GHPLs2[1*4+1]*HPLs2[1*2+1]
          + 1.0/2*GHPLs4[2*4*4*4+1*4*4+1*4+1]
          - 1.0/2*GHPLs3[1*4*4+1*4+1]*HPLs1[0]
          - 1.0/2*GHPLs3[1*4*4+1*4+1]*HPLs1[1]
          )

       + (dN_c*dN_c-1)*pow(u,-1) * (
          + 1.0/2
          - 10.0/3*zeta2
          - 3.0/4*zeta3
          - 13.0/24*GHPLs2[2*4+2]
          + 1.0/4*GHPLs2[2*4+2]*HPLs1[0]
          + 277.0/144*GHPLs1[2]
          - 3.0/4*GHPLs1[2]*zeta2
          + 3.0/8*GHPLs1[2]*HPLs1[0]
          + 13.0/24*GHPLs1[2]*HPLs1[1]
          - 1.0/4*GHPLs1[2]*HPLs2[0*2+1]
          + 1.0/4*GHPLs3[2*4*4+1*4+2]
          - 1.0/4*GHPLs2[1*4+2]*HPLs1[0]
          - 1.0/4*GHPLs2[1*4+2]*HPLs1[1]
          + 1.0/4*GHPLs2[2*4+0]*HPLs1[0]
          + 1.0/4*GHPLs3[2*4*4+1*4+0]
          - 1.0/4*GHPLs2[1*4+0]*HPLs1[0]
          - 1.0/4*GHPLs2[1*4+0]*HPLs1[1]
          + 1.0/4*GHPLs3[2*4*4+2*4+1]
          - 13.0/24*GHPLs2[2*4+1]
          - 1.0/4*GHPLs2[2*4+1]*HPLs1[0]
          - 1.0/4*GHPLs2[2*4+1]*HPLs1[1]
          - 1.0/4*GHPLs1[1]*zeta2
          + 13.0/24*GHPLs1[1]*HPLs1[0]
          + 13.0/24*GHPLs1[1]*HPLs1[1]
          + 1.0/4*GHPLs1[1]*HPLs2[0*2+1]
          + 1.0/4*GHPLs1[1]*HPLs2[1*2+1]
          - 1.0/4*GHPLs3[2*4*4+1*4+1]
          + 1.0/4*GHPLs2[1*4+1]*HPLs1[0]
          + 1.0/4*GHPLs2[1*4+1]*HPLs1[1]
          - 11.0/12*HPLs2[1*2+0]
          - 277.0/144*HPLs1[1]
          + HPLs1[1]*zeta2
          - 11.0/12*HPLs2[0*2+1]
          - 1.0/4*HPLs3[1*2*2+0*2+1]
          - 13.0/24*HPLs2[1*2+1]
          + 1.0/4*HPLs3[0*2*2+1*2+1]
          )

       + (dN_c*dN_c-1)*pow(u,-1)*v * (
          + 67.0/24*zeta2
          + 3.0/4*zeta3
          + 13.0/24*GHPLs2[2*4+2]
          + 1.0/2*GHPLs2[2*4+2]*zeta2
          - 25.0/24*GHPLs2[2*4+2]*HPLs1[0]
          - 1.0/2*GHPLs2[2*4+2]*HPLs2[1*2+0]
          - 1.0/2*GHPLs4[2*4*4*4+1*4*4+2*4+2]
          + 1.0/2*GHPLs3[1*4*4+2*4+2]*HPLs1[0]
          + 1.0/2*GHPLs3[1*4*4+2*4+2]*HPLs1[1]
          - 277.0/144*GHPLs1[2]
          + 11.0/24*GHPLs1[2]*zeta2
          + 127.0/144*GHPLs1[2]*HPLs1[0]
          + 11.0/6*GHPLs1[2]*HPLs2[0*2+0]
          + 7.0/24*GHPLs1[2]*HPLs2[1*2+0]
          - 13.0/24*GHPLs1[2]*HPLs1[1]
          + 1.0/4*GHPLs1[2]*HPLs2[0*2+1]
          + 1.0/2*GHPLs3[2*4*4+0*4+2]*HPLs1[0]
          + 1.0/2*GHPLs4[2*4*4*4+1*4*4+0*4+2]
          - 1.0/2*GHPLs3[1*4*4+0*4+2]*HPLs1[0]
          - 1.0/2*GHPLs3[1*4*4+0*4+2]*HPLs1[1]
          - 3.0/4*GHPLs3[2*4*4+1*4+2]
          + 1.0/4*GHPLs3[2*4*4+1*4+2]*HPLs1[0]
          - GHPLs2[1*4+2]*zeta2
          + 3.0/4*GHPLs2[1*4+2]*HPLs1[0]
          + 1.0/4*GHPLs2[1*4+2]*HPLs2[1*2+0]
          + 3.0/4*GHPLs2[1*4+2]*HPLs1[1]
          - 1.0/4*GHPLs2[1*4+2]*HPLs2[0*2+1]
          + 1.0/2*GHPLs4[2*4*4*4+1*4*4+1*4+2]
          - 1.0/2*GHPLs3[1*4*4+1*4+2]*HPLs1[0]
          - 1.0/2*GHPLs3[1*4*4+1*4+2]*HPLs1[1]
          + 1.0/4*GHPLs2[2*4+0]*HPLs1[0]
          + 1.0/4*GHPLs3[2*4*4+1*4+0]
          - 1.0/4*GHPLs2[1*4+0]*HPLs1[0]
          - 1.0/4*GHPLs2[1*4+0]*HPLs1[1]
          - 25.0/24*GHPLs3[2*4*4+2*4+1]
          + 1.0/2*GHPLs3[2*4*4+2*4+1]*HPLs1[0]
          + 337.0/144*GHPLs2[2*4+1]
          - GHPLs2[2*4+1]*zeta2
          + 17.0/12*GHPLs2[2*4+1]*HPLs1[0]
          + 1.0/4*GHPLs2[2*4+1]*HPLs2[1*2+0]
          + 25.0/24*GHPLs2[2*4+1]*HPLs1[1]
          - 1.0/4*GHPLs2[2*4+1]*HPLs2[0*2+1]
          + 3.0/4*GHPLs4[2*4*4*4+1*4*4+2*4+1]
          - 3.0/4*GHPLs3[1*4*4+2*4+1]*HPLs1[0]
          - 3.0/4*GHPLs3[1*4*4+2*4+1]*HPLs1[1]
          - 55.0/24*GHPLs1[1]*zeta2
          - 3.0/4*GHPLs1[1]*zeta3
          - 337.0/144*GHPLs1[1]*HPLs1[0]
          - 11.0/6*GHPLs1[1]*HPLs2[0*2+0]
          - 35.0/24*GHPLs1[1]*HPLs2[1*2+0]
          - 337.0/144*GHPLs1[1]*HPLs1[1]
          + GHPLs1[1]*HPLs1[1]*zeta2
          - 17.0/12*GHPLs1[1]*HPLs2[0*2+1]
          - 1.0/4*GHPLs1[1]*HPLs3[1*2*2+0*2+1]
          - 25.0/24*GHPLs1[1]*HPLs2[1*2+1]
          + 1.0/4*GHPLs1[1]*HPLs3[0*2*2+1*2+1]
          - 1.0/4*GHPLs3[2*4*4+0*4+1]*HPLs1[0]
          - 1.0/4*GHPLs4[2*4*4*4+1*4*4+0*4+1]
          + 1.0/4*GHPLs3[1*4*4+0*4+1]*HPLs1[0]
          + 1.0/4*GHPLs3[1*4*4+0*4+1]*HPLs1[1]
          + 1.0/2*GHPLs4[2*4*4*4+2*4*4+1*4+1]
          - 1.0/24*GHPLs3[2*4*4+1*4+1]
          - 1.0/2*GHPLs3[2*4*4+1*4+1]*HPLs1[0]
          - 1.0/2*GHPLs3[2*4*4+1*4+1]*HPLs1[1]
          - 1.0/2*GHPLs2[1*4+1]*zeta2
          + 1.0/24*GHPLs2[1*4+1]*HPLs1[0]
          + 1.0/24*GHPLs2[1*4+1]*HPLs1[1]
          + 1.0/2*GHPLs2[1*4+1]*HPLs2[0*2+1]
          + 1.0/2*GHPLs2[1*4+1]*HPLs2[1*2+1]
          - 1.0/2*GHPLs4[2*4*4*4+1*4*4+1*4+1]
          + 1.0/2*GHPLs3[1*4*4+1*4+1]*HPLs1[0]
          + 1.0/2*GHPLs3[1*4*4+1*4+1]*HPLs1[1]
          + 277.0/144*HPLs1[0]
          + 11.0/6*HPLs2[0*2+0]
          + 35.0/24*HPLs2[1*2+0]
          + 277.0/144*HPLs1[1]
          - HPLs1[1]*zeta2
          + 11.0/12*HPLs2[0*2+1]
          + 1.0/4*HPLs3[1*2*2+0*2+1]
          + 13.0/24*HPLs2[1*2+1]
          - 1.0/4*HPLs3[0*2*2+1*2+1]
          )

       + (dN_c*dN_c-1)*pow(1-v,-1) * (
          - 13.0/16*zeta2
          + 3.0/8*GHPLs1[2]*zeta2
          - 15.0/16*GHPLs1[2]*HPLs1[0]
          - 3.0/8*GHPLs1[2]*HPLs2[1*2+0]
          - 3.0/8*GHPLs3[2*4*4+1*4+2]
          + 3.0/8*GHPLs2[1*4+2]*HPLs1[0]
          + 3.0/8*GHPLs2[1*4+2]*HPLs1[1]
          + 3.0/8*GHPLs2[2*4+0]*HPLs1[0]
          + 3.0/8*GHPLs3[2*4*4+1*4+0]
          - 3.0/8*GHPLs2[1*4+0]*HPLs1[0]
          - 3.0/8*GHPLs2[1*4+0]*HPLs1[1]
          - 1.0/8*GHPLs2[2*4+1]
          + 1.0/8*GHPLs1[1]*HPLs1[0]
          + 1.0/8*GHPLs1[1]*HPLs1[1]
          + 263.0/96*HPLs1[0]
          + 11.0/4*HPLs2[0*2+0]
          + 13.0/16*HPLs2[1*2+0]
          )

       + (dN_c*dN_c-1) * (
          + 133.0/288
          - 41.0/48*zeta2
          - 3.0/8*zeta3
          - 13.0/48*GHPLs2[2*4+2]
          + 1.0/8*GHPLs2[2*4+2]*HPLs1[0]
          + 157.0/288*GHPLs1[2]
          - 3.0/4*GHPLs1[2]*zeta2
          + GHPLs1[2]*HPLs1[0]
          + 3.0/8*GHPLs1[2]*HPLs2[1*2+0]
          + 13.0/48*GHPLs1[2]*HPLs1[1]
          - 1.0/8*GHPLs1[2]*HPLs2[0*2+1]
          + 1.0/2*GHPLs3[2*4*4+1*4+2]
          - 1.0/2*GHPLs2[1*4+2]*HPLs1[0]
          - 1.0/2*GHPLs2[1*4+2]*HPLs1[1]
          - 1.0/4*GHPLs2[2*4+0]*HPLs1[0]
          - 1.0/4*GHPLs3[2*4*4+1*4+0]
          + 1.0/4*GHPLs2[1*4+0]*HPLs1[0]
          + 1.0/4*GHPLs2[1*4+0]*HPLs1[1]
          + 1.0/8*GHPLs3[2*4*4+2*4+1]
          - 13.0/48*GHPLs2[2*4+1]
          - 1.0/8*GHPLs2[2*4+1]*HPLs1[0]
          - 1.0/8*GHPLs2[2*4+1]*HPLs1[1]
          - 1.0/8*GHPLs1[1]*zeta2
          + 13.0/48*GHPLs1[1]*HPLs1[0]
          + 13.0/48*GHPLs1[1]*HPLs1[1]
          + 1.0/8*GHPLs1[1]*HPLs2[0*2+1]
          + 1.0/8*GHPLs1[1]*HPLs2[1*2+1]
          - 1.0/8*GHPLs3[2*4*4+1*4+1]
          + 1.0/8*GHPLs2[1*4+1]*HPLs1[0]
          + 1.0/8*GHPLs2[1*4+1]*HPLs1[1]
          - 73.0/32*HPLs1[0]
          - 11.0/4*HPLs2[0*2+0]
          - 61.0/48*HPLs2[1*2+0]
          - 157.0/288*HPLs1[1]
          + 1.0/2*HPLs1[1]*zeta2
          - 11.0/24*HPLs2[0*2+1]
          - 1.0/8*HPLs3[1*2*2+0*2+1]
          - 13.0/48*HPLs2[1*2+1]
          + 1.0/8*HPLs3[0*2*2+1*2+1]
          )

       + (dN_c*dN_c-1)*v*pow(1-u,-1) * (
          - 55.0/48*zeta2
          - 3.0/8*zeta3
          - 25.0/48*GHPLs2[2*4+2]
          + 1.0/4*GHPLs2[2*4+2]*HPLs1[0]
          + 355.0/288*GHPLs1[2]
          - 1.0/2*GHPLs1[2]*zeta2
          + 17.0/24*GHPLs1[2]*HPLs1[0]
          + 1.0/8*GHPLs1[2]*HPLs2[1*2+0]
          + 25.0/48*GHPLs1[2]*HPLs1[1]
          - 1.0/8*GHPLs1[2]*HPLs2[0*2+1]
          + 3.0/8*GHPLs3[2*4*4+1*4+2]
          - 3.0/8*GHPLs2[1*4+2]*HPLs1[0]
          - 3.0/8*GHPLs2[1*4+2]*HPLs1[1]
          - 1.0/8*GHPLs2[2*4+0]*HPLs1[0]
          - 1.0/8*GHPLs3[2*4*4+1*4+0]
          + 1.0/8*GHPLs2[1*4+0]*HPLs1[0]
          + 1.0/8*GHPLs2[1*4+0]*HPLs1[1]
          + 1.0/4*GHPLs3[2*4*4+2*4+1]
          - 1.0/48*GHPLs2[2*4+1]
          - 1.0/4*GHPLs2[2*4+1]*HPLs1[0]
          - 1.0/4*GHPLs2[2*4+1]*HPLs1[1]
          - 1.0/4*GHPLs1[1]*zeta2
          + 1.0/48*GHPLs1[1]*HPLs1[0]
          + 1.0/48*GHPLs1[1]*HPLs1[1]
          + 1.0/4*GHPLs1[1]*HPLs2[0*2+1]
          + 1.0/4*GHPLs1[1]*HPLs2[1*2+1]
          - 1.0/4*GHPLs3[2*4*4+1*4+1]
          + 1.0/4*GHPLs2[1*4+1]*HPLs1[0]
          + 1.0/4*GHPLs2[1*4+1]*HPLs1[1]
          - 355.0/288*HPLs1[0]
          - 11.0/12*HPLs2[0*2+0]
          - 35.0/48*HPLs2[1*2+0]
          - 355.0/288*HPLs1[1]
          + 1.0/2*HPLs1[1]*zeta2
          - 17.0/24*HPLs2[0*2+1]
          - 1.0/8*HPLs3[1*2*2+0*2+1]
          - 25.0/48*HPLs2[1*2+1]
          + 1.0/8*HPLs3[0*2*2+1*2+1]
          )

       + (dN_c*dN_c-1)*u*pow(1-v,-2) * (
          - 13.0/48*zeta2
          + 1.0/8*GHPLs1[2]*zeta2
          - 13.0/48*GHPLs1[2]*HPLs1[0]
          - 1.0/8*GHPLs1[2]*HPLs2[1*2+0]
          - 1.0/8*GHPLs3[2*4*4+1*4+2]
          + 1.0/8*GHPLs2[1*4+2]*HPLs1[0]
          + 1.0/8*GHPLs2[1*4+2]*HPLs1[1]
          + 1.0/8*GHPLs2[2*4+0]*HPLs1[0]
          + 1.0/8*GHPLs3[2*4*4+1*4+0]
          - 1.0/8*GHPLs2[1*4+0]*HPLs1[0]
          - 1.0/8*GHPLs2[1*4+0]*HPLs1[1]
          + 163.0/288*HPLs1[0]
          + 11.0/12*HPLs2[0*2+0]
          + 13.0/48*HPLs2[1*2+0]
          )

       + (dN_c*dN_c-1)*u*pow(1-v,-1) * (
          + 277.0/288
          + 13.0/48*zeta2
          - 19.0/48*GHPLs1[2]
          - 1.0/8*GHPLs1[2]*zeta2
          + 19.0/48*GHPLs1[2]*HPLs1[0]
          + 1.0/8*GHPLs1[2]*HPLs2[1*2+0]
          + 1.0/8*GHPLs3[2*4*4+1*4+2]
          - 1.0/8*GHPLs2[1*4+2]*HPLs1[0]
          - 1.0/8*GHPLs2[1*4+2]*HPLs1[1]
          - 1.0/8*GHPLs2[2*4+0]*HPLs1[0]
          - 1.0/8*GHPLs3[2*4*4+1*4+0]
          + 1.0/8*GHPLs2[1*4+0]*HPLs1[0]
          + 1.0/8*GHPLs2[1*4+0]*HPLs1[1]
          + 1.0/8*GHPLs2[2*4+1]
          - 1.0/8*GHPLs1[1]*HPLs1[0]
          - 1.0/8*GHPLs1[1]*HPLs1[1]
          - 31.0/288*HPLs1[0]
          - 11.0/12*HPLs2[0*2+0]
          - 13.0/48*HPLs2[1*2+0]
          + 19.0/48*HPLs1[1]
          )

       + (dN_c*dN_c-1)*double_complex(0,1)*M_PI*pow(u,-2) * (
          + 1.0/2*GHPLs2[2*4+2]*HPLs1[0]
          - 1.0/2*GHPLs3[1*4*4+2*4+2]
          + 3.0/8*GHPLs1[2]*HPLs1[0]
          + 1.0/2*GHPLs3[1*4*4+0*4+2]
          - 1.0/4*GHPLs2[1*4+2]*HPLs1[0]
          + 1.0/2*GHPLs3[1*4*4+1*4+2]
          + 3.0/8*GHPLs2[2*4+1]
          - 1.0/4*GHPLs2[2*4+1]*HPLs1[0]
          + 3.0/4*GHPLs3[1*4*4+2*4+1]
          + 277.0/144*GHPLs1[1]
          - 1.0/4*GHPLs1[1]*zeta2
          + 13.0/24*GHPLs1[1]*HPLs1[0]
          - 3.0/8*GHPLs1[1]*HPLs1[1]
          + 1.0/4*GHPLs1[1]*HPLs2[0*2+1]
          - 1.0/4*GHPLs3[1*4*4+0*4+1]
          + 1.0/2*GHPLs3[2*4*4+1*4+1]
          - 13.0/24*GHPLs2[1*4+1]
          - 1.0/2*GHPLs2[1*4+1]*HPLs1[1]
          - 1.0/2*GHPLs3[1*4*4+1*4+1]
          )

       + (dN_c*dN_c-1)*double_complex(0,1)*M_PI*pow(u,-2)*v * (
          - 1.0/2*GHPLs2[2*4+2]*HPLs1[0]
          + 1.0/2*GHPLs3[1*4*4+2*4+2]
          - 3.0/8*GHPLs1[2]*HPLs1[0]
          - 1.0/2*GHPLs3[1*4*4+0*4+2]
          + 1.0/4*GHPLs2[1*4+2]*HPLs1[0]
          - 1.0/2*GHPLs3[1*4*4+1*4+2]
          - 3.0/8*GHPLs2[2*4+1]
          + 1.0/4*GHPLs2[2*4+1]*HPLs1[0]
          - 3.0/4*GHPLs3[1*4*4+2*4+1]
          - 277.0/144*GHPLs1[1]
          + 1.0/4*GHPLs1[1]*zeta2
          - 13.0/24*GHPLs1[1]*HPLs1[0]
          + 3.0/8*GHPLs1[1]*HPLs1[1]
          - 1.0/4*GHPLs1[1]*HPLs2[0*2+1]
          + 1.0/4*GHPLs3[1*4*4+0*4+1]
          - 1.0/2*GHPLs3[2*4*4+1*4+1]
          + 13.0/24*GHPLs2[1*4+1]
          + 1.0/2*GHPLs2[1*4+1]*HPLs1[1]
          + 1.0/2*GHPLs3[1*4*4+1*4+1]
          )

       + (dN_c*dN_c-1)*double_complex(0,1)*M_PI*pow(u,-1) * (
          + 277.0/144
          - 1.0/4*zeta2
          + 3.0/8*GHPLs1[2]
          + 1.0/4*GHPLs2[1*4+2]
          + 1.0/4*GHPLs2[1*4+0]
          + 1.0/4*GHPLs2[2*4+1]
          - 13.0/24*GHPLs1[1]
          - 1.0/4*GHPLs1[1]*HPLs1[1]
          - 1.0/4*GHPLs2[1*4+1]
          + 11.0/12*HPLs1[0]
          - 3.0/8*HPLs1[1]
          + 1.0/4*HPLs2[0*2+1]
          )

       + (dN_c*dN_c-1)*double_complex(0,1)*M_PI*pow(u,-1)*v * (
          - 277.0/144
          + 1.0/4*zeta2
          + 1.0/2*GHPLs2[2*4+2]*HPLs1[0]
          - 1.0/2*GHPLs3[1*4*4+2*4+2]
          - 3.0/8*GHPLs1[2]
          + 5.0/8*GHPLs1[2]*HPLs1[0]
          + 1.0/2*GHPLs3[1*4*4+0*4+2]
          - 3.0/4*GHPLs2[1*4+2]
          - 1.0/4*GHPLs2[1*4+2]*HPLs1[0]
          + 1.0/2*GHPLs3[1*4*4+1*4+2]
          + 1.0/4*GHPLs2[1*4+0]
          - 1.0/8*GHPLs2[2*4+1]
          - 1.0/4*GHPLs2[2*4+1]*HPLs1[0]
          + 3.0/4*GHPLs3[1*4*4+2*4+1]
          + 337.0/144*GHPLs1[1]
          - 1.0/4*GHPLs1[1]*zeta2
          + 13.0/24*GHPLs1[1]*HPLs1[0]
          + 1.0/8*GHPLs1[1]*HPLs1[1]
          + 1.0/4*GHPLs1[1]*HPLs2[0*2+1]
          - 1.0/4*GHPLs3[1*4*4+0*4+1]
          + 1.0/2*GHPLs3[2*4*4+1*4+1]
          - 1.0/24*GHPLs2[1*4+1]
          - 1.0/2*GHPLs2[1*4+1]*HPLs1[1]
          - 1.0/2*GHPLs3[1*4*4+1*4+1]
          - 13.0/24*HPLs1[0]
          + 3.0/8*HPLs1[1]
          - 1.0/4*HPLs2[0*2+1]
          )

       + (dN_c*dN_c-1)*double_complex(0,1)*M_PI*pow(1-v,-1) * (
          + 3.0/8*GHPLs1[2]*HPLs1[0]
          - 3.0/8*GHPLs2[1*4+2]
          + 3.0/8*GHPLs2[1*4+0]
          - 1.0/8*GHPLs1[1]
          + 9.0/16*HPLs1[0]
          )

       + (dN_c*dN_c-1)*double_complex(0,1)*M_PI * (
          + 289.0/288
          - 1.0/8*zeta2
          + 3.0/16*GHPLs1[2]
          - 3.0/8*GHPLs1[2]*HPLs1[0]
          + 1.0/2*GHPLs2[1*4+2]
          - 1.0/4*GHPLs2[1*4+0]
          + 1.0/8*GHPLs2[2*4+1]
          - 13.0/48*GHPLs1[1]
          - 1.0/8*GHPLs1[1]*HPLs1[1]
          - 1.0/8*GHPLs2[1*4+1]
          - 5.0/48*HPLs1[0]
          - 3.0/16*HPLs1[1]
          + 1.0/8*HPLs2[0*2+1]
          )

       + (dN_c*dN_c-1)*double_complex(0,1)*M_PI*v*pow(1-u,-1) * (
          + 355.0/288
          - 1.0/8*zeta2
          - 1.0/16*GHPLs1[2]
          - 1.0/8*GHPLs1[2]*HPLs1[0]
          + 3.0/8*GHPLs2[1*4+2]
          - 1.0/8*GHPLs2[1*4+0]
          + 1.0/4*GHPLs2[2*4+1]
          - 1.0/48*GHPLs1[1]
          - 1.0/4*GHPLs1[1]*HPLs1[1]
          - 1.0/4*GHPLs2[1*4+1]
          + 13.0/48*HPLs1[0]
          + 1.0/16*HPLs1[1]
          + 1.0/8*HPLs2[0*2+1]
          )

       + (dN_c*dN_c-1)*double_complex(0,1)*M_PI*u*pow(1-v,-2) * (
          + 1.0/8*GHPLs1[2]*HPLs1[0]
          - 1.0/8*GHPLs2[1*4+2]
          + 1.0/8*GHPLs2[1*4+0]
          + 3.0/16*HPLs1[0]
          )

       + (dN_c*dN_c-1)*double_complex(0,1)*M_PI*u*pow(1-v,-1) * (
          + 1.0/16
          - 1.0/8*GHPLs1[2]*HPLs1[0]
          + 1.0/8*GHPLs2[1*4+2]
          - 1.0/8*GHPLs2[1*4+0]
          + 1.0/8*GHPLs1[1]
          - 3.0/16*HPLs1[0]
          )

       + (dN_c*dN_c-1)/(dN_c*dN_c)*pow(u,-2)*pow(1-u-v,-1) * (
          - 1.0/8*GHPLs2[2*4+3]*HPLs1[0]
          + 1.0/8*GHPLs3[0*4*4+2*4+3]
          - 1.0/8*GHPLs2[3*4+3]*HPLs1[0]
          + 1.0/8*GHPLs3[0*4*4+3*4+3]
          - 7.0/8*GHPLs1[3]*zeta2
          + 1.0/8*GHPLs1[3]*HPLs2[1*2+0]
          + 1.0/8*GHPLs1[3]*HPLs2[0*2+1]
          + 1.0/8*GHPLs3[2*4*4+0*4+3]
          - 1.0/8*GHPLs2[0*4+3]*HPLs1[1]
          + 1.0/8*GHPLs3[0*4*4+2*4+1]
          - GHPLs1[1]*zeta2
          + 1.0/8*GHPLs1[1]*HPLs2[0*2+0]
          + 1.0/8*GHPLs1[1]*HPLs2[1*2+0]
          + 1.0/8*GHPLs3[2*4*4+0*4+1]
          - 1.0/8*GHPLs2[0*4+1]*HPLs1[0]
          - 1.0/8*GHPLs2[0*4+1]*HPLs1[1]
          + 1.0/8*GHPLs3[2*4*4+1*4+1]
          - 1.0/8*GHPLs2[1*4+1]*HPLs1[0]
          - 1.0/8*GHPLs2[1*4+1]*HPLs1[1]
          )

       + (dN_c*dN_c-1)/(dN_c*dN_c)*pow(u,-2) * (
          + 7.0/4*GHPLs3[3*4*4+2*4+2]*HPLs1[0]
          - 7.0/4*GHPLs4[0*4*4*4+3*4*4+2*4+2]
          - 7.0/4*GHPLs2[2*4+2]*zeta2
          + 5.0/4*GHPLs2[2*4+2]*HPLs2[0*2+0]
          + 5.0/4*GHPLs2[2*4+2]*HPLs2[1*2+0]
          - 1.0/2*GHPLs2[2*4+2]*HPLs2[0*2+1]
          - 1.0/2*GHPLs3[0*4*4+2*4+2]*HPLs1[0]
          + 5.0/4*GHPLs4[2*4*4*4+1*4*4+2*4+2]
          - 5.0/4*GHPLs3[1*4*4+2*4+2]*HPLs1[0]
          - 5.0/4*GHPLs3[1*4*4+2*4+2]*HPLs1[1]
          + 1.0/2*GHPLs3[3*4*4+3*4+2]*HPLs1[0]
          - 1.0/2*GHPLs4[0*4*4*4+3*4*4+3*4+2]
          + 1.0/2*GHPLs2[3*4+2]*zeta2
          - 3.0/2*GHPLs1[2]*zeta2
          + 3.0/4*GHPLs1[2]*zeta3
          + 11.0/16*GHPLs1[2]*HPLs1[0]
          - 11.0/2*GHPLs1[2]*HPLs1[0]*zeta2
          + 3.0/8*GHPLs1[2]*HPLs2[0*2+0]
          + 7.0/4*GHPLs1[2]*HPLs3[0*2*2+0*2+0]
          + 1.0/2*GHPLs1[2]*HPLs3[1*2*2+0*2+0]
          + 3.0/8*GHPLs1[2]*HPLs2[1*2+0]
          + 5.0/4*GHPLs1[2]*HPLs3[0*2*2+1*2+0]
          + 5.0/4*GHPLs1[2]*HPLs1[1]*zeta2
          - 9.0/8*GHPLs1[2]*HPLs2[0*2+1]
          - 5.0/4*GHPLs1[2]*HPLs3[0*2*2+0*2+1]
          - 5.0/4*GHPLs1[2]*HPLs3[1*2*2+0*2+1]
          - 7.0/4*GHPLs3[3*4*4+0*4+2]*HPLs1[0]
          + 7.0/4*GHPLs4[0*4*4*4+3*4*4+0*4+2]
          + 5.0/4*GHPLs2[0*4+2]*zeta2
          - 3.0/4*GHPLs2[0*4+2]*HPLs1[0]
          - 5.0/4*GHPLs2[0*4+2]*HPLs2[0*2+0]
          - 5.0/4*GHPLs2[0*4+2]*HPLs2[1*2+0]
          - 5.0/4*GHPLs4[2*4*4*4+1*4*4+0*4+2]
          + 5.0/4*GHPLs3[1*4*4+0*4+2]*HPLs1[0]
          + 5.0/4*GHPLs3[1*4*4+0*4+2]*HPLs1[1]
          + 3.0/8*GHPLs3[2*4*4+1*4+2]
          - 1.0/4*GHPLs3[2*4*4+1*4+2]*HPLs1[0]
          + GHPLs2[1*4+2]*zeta2
          - 3.0/8*GHPLs2[1*4+2]*HPLs1[0]
          - 1.0/4*GHPLs2[1*4+2]*HPLs2[1*2+0]
          - 3.0/8*GHPLs2[1*4+2]*HPLs1[1]
          + 1.0/4*GHPLs2[1*4+2]*HPLs2[0*2+1]
          - 1.0/2*GHPLs4[2*4*4*4+1*4*4+1*4+2]
          + 1.0/2*GHPLs3[1*4*4+1*4+2]*HPLs1[0]
          + 1.0/2*GHPLs3[1*4*4+1*4+2]*HPLs1[1]
          + 1.0/8*GHPLs2[2*4+3]*HPLs1[0]
          - 1.0/8*GHPLs3[0*4*4+2*4+3]
          + 1.0/8*GHPLs2[3*4+3]*HPLs1[0]
          - 1.0/8*GHPLs3[0*4*4+3*4+3]
          + 7.0/8*GHPLs1[3]*zeta2
          - 1.0/8*GHPLs1[3]*HPLs2[1*2+0]
          - 1.0/8*GHPLs1[3]*HPLs2[0*2+1]
          - 1.0/8*GHPLs3[2*4*4+0*4+3]
          + 1.0/8*GHPLs2[0*4+3]*HPLs1[1]
          - 7.0/4*GHPLs3[2*4*4+2*4+1]*HPLs1[0]
          + 5.0/4*GHPLs4[0*4*4*4+2*4*4+2*4+1]
          + 5.0/4*GHPLs3[3*4*4+2*4+1]*HPLs1[0]
          - 5.0/4*GHPLs4[0*4*4*4+3*4*4+2*4+1]
          + 11.0/16*GHPLs2[2*4+1]
          - 5*GHPLs2[2*4+1]*zeta2
          + 7.0/4*GHPLs2[2*4+1]*HPLs2[0*2+0]
          + 1.0/4*GHPLs2[2*4+1]*HPLs2[1*2+0]
          + 3.0/2*GHPLs2[2*4+1]*HPLs2[0*2+1]
          + 5.0/4*GHPLs4[2*4*4*4+0*4*4+2*4+1]
          - 7.0/8*GHPLs3[0*4*4+2*4+1]
          - 5.0/4*GHPLs3[0*4*4+2*4+1]*HPLs1[0]
          - 5.0/4*GHPLs3[0*4*4+2*4+1]*HPLs1[1]
          - 3.0/2*GHPLs4[2*4*4*4+1*4*4+2*4+1]
          + 3.0/2*GHPLs3[1*4*4+2*4+1]*HPLs1[0]
          + 3.0/2*GHPLs3[1*4*4+2*4+1]*HPLs1[1]
          + 25.0/4*GHPLs1[1]*zeta2
          + GHPLs1[1]*zeta3
          - 11.0/16*GHPLs1[1]*HPLs1[0]
          + 6*GHPLs1[1]*HPLs1[0]*zeta2
          - 1.0/2*GHPLs1[1]*HPLs2[0*2+0]
          - 7.0/4*GHPLs1[1]*HPLs3[0*2*2+0*2+0]
          - 1.0/2*GHPLs1[1]*HPLs3[1*2*2+0*2+0]
          - 1.0/2*GHPLs1[1]*HPLs2[1*2+0]
          - 5.0/4*GHPLs1[1]*HPLs3[0*2*2+1*2+0]
          - 11.0/16*GHPLs1[1]*HPLs1[1]
          + 5*GHPLs1[1]*HPLs1[1]*zeta2
          - 7.0/4*GHPLs1[1]*HPLs3[0*2*2+0*2+1]
          - 1.0/4*GHPLs1[1]*HPLs3[1*2*2+0*2+1]
          - 3.0/2*GHPLs1[1]*HPLs3[0*2*2+1*2+1]
          + 5.0/4*GHPLs4[2*4*4*4+2*4*4+0*4+1]
          - 7.0/8*GHPLs3[2*4*4+0*4+1]
          - GHPLs3[2*4*4+0*4+1]*HPLs1[0]
          - 5.0/4*GHPLs3[2*4*4+0*4+1]*HPLs1[1]
          + 5.0/4*GHPLs3[3*4*4+0*4+1]*HPLs1[0]
          - 5.0/4*GHPLs4[0*4*4*4+3*4*4+0*4+1]
          - 15.0/4*GHPLs2[0*4+1]*zeta2
          + 7.0/8*GHPLs2[0*4+1]*HPLs1[0]
          + 5.0/4*GHPLs2[0*4+1]*HPLs2[0*2+0]
          + 5.0/4*GHPLs2[0*4+1]*HPLs2[1*2+0]
          + 7.0/8*GHPLs2[0*4+1]*HPLs1[1]
          + 5.0/4*GHPLs2[0*4+1]*HPLs2[0*2+1]
          + 5.0/4*GHPLs2[0*4+1]*HPLs2[1*2+1]
          + 1.0/4*GHPLs4[2*4*4*4+1*4*4+0*4+1]
          - 1.0/4*GHPLs3[1*4*4+0*4+1]*HPLs1[0]
          - 1.0/4*GHPLs3[1*4*4+0*4+1]*HPLs1[1]
          - 7.0/4*GHPLs4[2*4*4*4+2*4*4+1*4+1]
          - 1.0/2*GHPLs3[2*4*4+1*4+1]
          + 1.0/2*GHPLs3[2*4*4+1*4+1]*HPLs1[0]
          + 7.0/4*GHPLs3[2*4*4+1*4+1]*HPLs1[1]
          + 5.0/4*GHPLs4[0*4*4*4+2*4*4+1*4+1]
          - 3.0/4*GHPLs2[1*4+1]*zeta2
          + 1.0/2*GHPLs2[1*4+1]*HPLs1[0]
          - 5.0/4*GHPLs2[1*4+1]*HPLs2[1*2+0]
          + 1.0/2*GHPLs2[1*4+1]*HPLs1[1]
          - 1.0/2*GHPLs2[1*4+1]*HPLs2[0*2+1]
          - 7.0/4*GHPLs2[1*4+1]*HPLs2[1*2+1]
          + 5.0/4*GHPLs4[2*4*4*4+0*4*4+1*4+1]
          - 5.0/4*GHPLs3[0*4*4+1*4+1]*HPLs1[0]
          - 5.0/4*GHPLs3[0*4*4+1*4+1]*HPLs1[1]
          - 3.0/4*GHPLs4[2*4*4*4+1*4*4+1*4+1]
          + 3.0/4*GHPLs3[1*4*4+1*4+1]*HPLs1[0]
          + 3.0/4*GHPLs3[1*4*4+1*4+1]*HPLs1[1]
          )

       + (dN_c*dN_c-1)/(dN_c*dN_c)*pow(u,-2)*v * (
          - 7.0/4*GHPLs3[3*4*4+2*4+2]*HPLs1[0]
          + 7.0/4*GHPLs4[0*4*4*4+3*4*4+2*4+2]
          + 7.0/4*GHPLs2[2*4+2]*zeta2
          - 5.0/4*GHPLs2[2*4+2]*HPLs2[0*2+0]
          - 5.0/4*GHPLs2[2*4+2]*HPLs2[1*2+0]
          + 1.0/2*GHPLs2[2*4+2]*HPLs2[0*2+1]
          + 1.0/2*GHPLs3[0*4*4+2*4+2]*HPLs1[0]
          - 5.0/4*GHPLs4[2*4*4*4+1*4*4+2*4+2]
          + 5.0/4*GHPLs3[1*4*4+2*4+2]*HPLs1[0]
          + 5.0/4*GHPLs3[1*4*4+2*4+2]*HPLs1[1]
          - 1.0/2*GHPLs3[3*4*4+3*4+2]*HPLs1[0]
          + 1.0/2*GHPLs4[0*4*4*4+3*4*4+3*4+2]
          - 1.0/2*GHPLs2[3*4+2]*zeta2
          + 7.0/4*GHPLs1[2]*zeta2
          - 3.0/4*GHPLs1[2]*zeta3
          - 15.0/16*GHPLs1[2]*HPLs1[0]
          + 11.0/2*GHPLs1[2]*HPLs1[0]*zeta2
          - 1.0/8*GHPLs1[2]*HPLs2[0*2+0]
          - 7.0/4*GHPLs1[2]*HPLs3[0*2*2+0*2+0]
          - 1.0/2*GHPLs1[2]*HPLs3[1*2*2+0*2+0]
          - 5.0/8*GHPLs1[2]*HPLs2[1*2+0]
          - 5.0/4*GHPLs1[2]*HPLs3[0*2*2+1*2+0]
          - 5.0/4*GHPLs1[2]*HPLs1[1]*zeta2
          + 9.0/8*GHPLs1[2]*HPLs2[0*2+1]
          + 5.0/4*GHPLs1[2]*HPLs3[0*2*2+0*2+1]
          + 5.0/4*GHPLs1[2]*HPLs3[1*2*2+0*2+1]
          + 7.0/4*GHPLs3[3*4*4+0*4+2]*HPLs1[0]
          - 7.0/4*GHPLs4[0*4*4*4+3*4*4+0*4+2]
          - 5.0/4*GHPLs2[0*4+2]*zeta2
          + 1.0/2*GHPLs2[0*4+2]*HPLs1[0]
          + 5.0/4*GHPLs2[0*4+2]*HPLs2[0*2+0]
          + 5.0/4*GHPLs2[0*4+2]*HPLs2[1*2+0]
          + 5.0/4*GHPLs4[2*4*4*4+1*4*4+0*4+2]
          - 5.0/4*GHPLs3[1*4*4+0*4+2]*HPLs1[0]
          - 5.0/4*GHPLs3[1*4*4+0*4+2]*HPLs1[1]
          - 5.0/8*GHPLs3[2*4*4+1*4+2]
          + 1.0/4*GHPLs3[2*4*4+1*4+2]*HPLs1[0]
          - GHPLs2[1*4+2]*zeta2
          + 5.0/8*GHPLs2[1*4+2]*HPLs1[0]
          + 1.0/4*GHPLs2[1*4+2]*HPLs2[1*2+0]
          + 5.0/8*GHPLs2[1*4+2]*HPLs1[1]
          - 1.0/4*GHPLs2[1*4+2]*HPLs2[0*2+1]
          + 1.0/2*GHPLs4[2*4*4*4+1*4*4+1*4+2]
          - 1.0/2*GHPLs3[1*4*4+1*4+2]*HPLs1[0]
          - 1.0/2*GHPLs3[1*4*4+1*4+2]*HPLs1[1]
          + 1.0/8*GHPLs2[2*4+3]*HPLs1[0]
          - 1.0/8*GHPLs3[0*4*4+2*4+3]
          + 5.0/8*GHPLs2[3*4+3]*HPLs1[0]
          - 5.0/8*GHPLs3[0*4*4+3*4+3]
          + 11.0/8*GHPLs1[3]*zeta2
          - 1.0/8*GHPLs1[3]*HPLs2[1*2+0]
          - 1.0/8*GHPLs1[3]*HPLs2[0*2+1]
          - 1.0/8*GHPLs3[2*4*4+0*4+3]
          + 1.0/8*GHPLs2[0*4+3]*HPLs1[1]
          + 7.0/4*GHPLs3[2*4*4+2*4+1]*HPLs1[0]
          - 5.0/4*GHPLs4[0*4*4*4+2*4*4+2*4+1]
          - 5.0/4*GHPLs3[3*4*4+2*4+1]*HPLs1[0]
          + 5.0/4*GHPLs4[0*4*4*4+3*4*4+2*4+1]
          - 15.0/16*GHPLs2[2*4+1]
          + 5*GHPLs2[2*4+1]*zeta2
          - 7.0/4*GHPLs2[2*4+1]*HPLs2[0*2+0]
          - 1.0/4*GHPLs2[2*4+1]*HPLs2[1*2+0]
          - 3.0/2*GHPLs2[2*4+1]*HPLs2[0*2+1]
          - 5.0/4*GHPLs4[2*4*4*4+0*4*4+2*4+1]
          + 3.0/8*GHPLs3[0*4*4+2*4+1]
          + 5.0/4*GHPLs3[0*4*4+2*4+1]*HPLs1[0]
          + 5.0/4*GHPLs3[0*4*4+2*4+1]*HPLs1[1]
          + 3.0/2*GHPLs4[2*4*4*4+1*4*4+2*4+1]
          - 3.0/2*GHPLs3[1*4*4+2*4+1]*HPLs1[0]
          - 3.0/2*GHPLs3[1*4*4+2*4+1]*HPLs1[1]
          - 9.0/4*GHPLs1[1]*zeta2
          - GHPLs1[1]*zeta3
          + 15.0/16*GHPLs1[1]*HPLs1[0]
          - 6*GHPLs1[1]*HPLs1[0]*zeta2
          + 7.0/4*GHPLs1[1]*HPLs3[0*2*2+0*2+0]
          + 1.0/2*GHPLs1[1]*HPLs3[1*2*2+0*2+0]
          + 5.0/4*GHPLs1[1]*HPLs3[0*2*2+1*2+0]
          + 15.0/16*GHPLs1[1]*HPLs1[1]
          - 5*GHPLs1[1]*HPLs1[1]*zeta2
          + 7.0/4*GHPLs1[1]*HPLs3[0*2*2+0*2+1]
          + 1.0/4*GHPLs1[1]*HPLs3[1*2*2+0*2+1]
          + 3.0/2*GHPLs1[1]*HPLs3[0*2*2+1*2+1]
          - 5.0/4*GHPLs4[2*4*4*4+2*4*4+0*4+1]
          + 3.0/8*GHPLs3[2*4*4+0*4+1]
          + GHPLs3[2*4*4+0*4+1]*HPLs1[0]
          + 5.0/4*GHPLs3[2*4*4+0*4+1]*HPLs1[1]
          - 5.0/4*GHPLs3[3*4*4+0*4+1]*HPLs1[0]
          + 5.0/4*GHPLs4[0*4*4*4+3*4*4+0*4+1]
          + 15.0/4*GHPLs2[0*4+1]*zeta2
          - 3.0/8*GHPLs2[0*4+1]*HPLs1[0]
          - 5.0/4*GHPLs2[0*4+1]*HPLs2[0*2+0]
          - 5.0/4*GHPLs2[0*4+1]*HPLs2[1*2+0]
          - 3.0/8*GHPLs2[0*4+1]*HPLs1[1]
          - 5.0/4*GHPLs2[0*4+1]*HPLs2[0*2+1]
          - 5.0/4*GHPLs2[0*4+1]*HPLs2[1*2+1]
          - 1.0/4*GHPLs4[2*4*4*4+1*4*4+0*4+1]
          + 1.0/4*GHPLs3[1*4*4+0*4+1]*HPLs1[0]
          + 1.0/4*GHPLs3[1*4*4+0*4+1]*HPLs1[1]
          + 7.0/4*GHPLs4[2*4*4*4+2*4*4+1*4+1]
          - 1.0/2*GHPLs3[2*4*4+1*4+1]*HPLs1[0]
          - 7.0/4*GHPLs3[2*4*4+1*4+1]*HPLs1[1]
          - 5.0/4*GHPLs4[0*4*4*4+2*4*4+1*4+1]
          + 3.0/4*GHPLs2[1*4+1]*zeta2
          + 5.0/4*GHPLs2[1*4+1]*HPLs2[1*2+0]
          + 1.0/2*GHPLs2[1*4+1]*HPLs2[0*2+1]
          + 7.0/4*GHPLs2[1*4+1]*HPLs2[1*2+1]
          - 5.0/4*GHPLs4[2*4*4*4+0*4*4+1*4+1]
          + 5.0/4*GHPLs3[0*4*4+1*4+1]*HPLs1[0]
          + 5.0/4*GHPLs3[0*4*4+1*4+1]*HPLs1[1]
          + 3.0/4*GHPLs4[2*4*4*4+1*4*4+1*4+1]
          - 3.0/4*GHPLs3[1*4*4+1*4+1]*HPLs1[0]
          - 3.0/4*GHPLs3[1*4*4+1*4+1]*HPLs1[1]
          )

       + (dN_c*dN_c-1)/(dN_c*dN_c)*pow(u,-2)*pow(v,2) * (
          - 1.0/8*GHPLs1[2]*zeta2
          + 1.0/8*GHPLs1[2]*HPLs1[0]
          - 1.0/8*GHPLs1[2]*HPLs2[0*2+0]
          + 1.0/8*GHPLs1[2]*HPLs2[1*2+0]
          + 1.0/8*GHPLs2[0*4+2]*HPLs1[0]
          + 1.0/8*GHPLs3[2*4*4+1*4+2]
          - 1.0/8*GHPLs2[1*4+2]*HPLs1[0]
          - 1.0/8*GHPLs2[1*4+2]*HPLs1[1]
          + 1.0/8*GHPLs2[2*4+3]*HPLs1[0]
          - 1.0/8*GHPLs3[0*4*4+2*4+3]
          - 1.0/8*GHPLs2[3*4+3]*HPLs1[0]
          + 1.0/8*GHPLs3[0*4*4+3*4+3]
          + 5.0/8*GHPLs1[3]*zeta2
          - 1.0/8*GHPLs1[3]*HPLs2[1*2+0]
          - 1.0/8*GHPLs1[3]*HPLs2[0*2+1]
          - 1.0/8*GHPLs3[2*4*4+0*4+3]
          + 1.0/8*GHPLs2[0*4+3]*HPLs1[1]
          + 1.0/8*GHPLs2[2*4+1]
          - 1.0/8*GHPLs1[1]*HPLs1[0]
          - 1.0/8*GHPLs1[1]*HPLs1[1]
          )

       + (dN_c*dN_c-1)/(dN_c*dN_c)*pow(u,-2)*pow(v,3) * (
          - 1.0/8*GHPLs1[2]*zeta2
          - 1.0/8*GHPLs1[2]*HPLs2[0*2+0]
          + 1.0/8*GHPLs1[2]*HPLs2[1*2+0]
          + 1.0/8*GHPLs2[0*4+2]*HPLs1[0]
          + 1.0/8*GHPLs3[2*4*4+1*4+2]
          - 1.0/8*GHPLs2[1*4+2]*HPLs1[0]
          - 1.0/8*GHPLs2[1*4+2]*HPLs1[1]
          + 1.0/8*GHPLs2[2*4+3]*HPLs1[0]
          - 1.0/8*GHPLs3[0*4*4+2*4+3]
          - 1.0/8*GHPLs2[3*4+3]*HPLs1[0]
          + 1.0/8*GHPLs3[0*4*4+3*4+3]
          + 5.0/8*GHPLs1[3]*zeta2
          - 1.0/8*GHPLs1[3]*HPLs2[1*2+0]
          - 1.0/8*GHPLs1[3]*HPLs2[0*2+1]
          - 1.0/8*GHPLs3[2*4*4+0*4+3]
          + 1.0/8*GHPLs2[0*4+3]*HPLs1[1]
          )

       + (dN_c*dN_c-1)/(dN_c*dN_c)*pow(u,-1)*pow(1-u-v,-1) * (
          - 1.0/8*zeta2
          + 5.0/8*GHPLs2[2*4+3]*HPLs1[0]
          - 5.0/8*GHPLs3[0*4*4+2*4+3]
          + 5.0/8*GHPLs2[3*4+3]*HPLs1[0]
          - 5.0/8*GHPLs3[0*4*4+3*4+3]
          + 35.0/8*GHPLs1[3]*zeta2
          + 1.0/8*GHPLs1[3]*HPLs1[0]
          - 5.0/8*GHPLs1[3]*HPLs2[1*2+0]
          - 5.0/8*GHPLs1[3]*HPLs2[0*2+1]
          - 5.0/8*GHPLs3[2*4*4+0*4+3]
          - 1.0/8*GHPLs2[0*4+3]
          + 5.0/8*GHPLs2[0*4+3]*HPLs1[1]
          - 1.0/8*GHPLs1[0]*HPLs1[0]
          - 5.0/8*GHPLs3[0*4*4+2*4+1]
          + 5*GHPLs1[1]*zeta2
          - 5.0/8*GHPLs1[1]*HPLs2[0*2+0]
          - 5.0/8*GHPLs1[1]*HPLs2[1*2+0]
          - 5.0/8*GHPLs3[2*4*4+0*4+1]
          + 5.0/8*GHPLs2[0*4+1]*HPLs1[0]
          + 5.0/8*GHPLs2[0*4+1]*HPLs1[1]
          - 5.0/8*GHPLs3[2*4*4+1*4+1]
          + 5.0/8*GHPLs2[1*4+1]*HPLs1[0]
          + 5.0/8*GHPLs2[1*4+1]*HPLs1[1]
          + 1.0/8*HPLs2[0*2+0]
          - 1.0/8*HPLs2[0*2+1]
          )

       + (dN_c*dN_c-1)/(dN_c*dN_c)*pow(u,-1) * (
          - 1.0/2
          + 47.0/8*zeta2
          + 7.0/4*zeta3
          - 3.0/2*GHPLs3[3*4*4+2*4+2]*HPLs1[0]
          + 3.0/2*GHPLs4[0*4*4*4+3*4*4+2*4+2]
          - 5.0/4*GHPLs2[2*4+2]
          + 3.0/2*GHPLs2[2*4+2]*zeta2
          - 3.0/2*GHPLs2[2*4+2]*HPLs1[0]
          - 3.0/2*GHPLs2[2*4+2]*HPLs2[0*2+0]
          - 3.0/2*GHPLs2[2*4+2]*HPLs2[1*2+0]
          + 5.0/4*GHPLs3[0*4*4+2*4+2]
          - 3.0/2*GHPLs4[2*4*4*4+1*4*4+2*4+2]
          + 3.0/2*GHPLs3[1*4*4+2*4+2]*HPLs1[0]
          + 3.0/2*GHPLs3[1*4*4+2*4+2]*HPLs1[1]
          + 3*GHPLs2[3*4+2]*HPLs1[0]
          - 3*GHPLs3[0*4*4+3*4+2]
          + 23.0/16*GHPLs1[2]
          - 13.0/2*GHPLs1[2]*zeta2
          - 3.0/2*GHPLs1[2]*zeta3
          + 13.0/8*GHPLs1[2]*HPLs1[0]
          + 6*GHPLs1[2]*HPLs1[0]*zeta2
          + 3*GHPLs1[2]*HPLs2[0*2+0]
          - 3.0/2*GHPLs1[2]*HPLs3[0*2*2+0*2+0]
          + 5.0/4*GHPLs1[2]*HPLs2[1*2+0]
          - 3.0/2*GHPLs1[2]*HPLs3[0*2*2+1*2+0]
          + 5.0/4*GHPLs1[2]*HPLs1[1]
          - 3.0/2*GHPLs1[2]*HPLs1[1]*zeta2
          + GHPLs1[2]*HPLs2[0*2+1]
          + 3.0/2*GHPLs1[2]*HPLs3[0*2*2+0*2+1]
          + 3.0/2*GHPLs1[2]*HPLs3[1*2*2+0*2+1]
          + 5.0/4*GHPLs3[2*4*4+0*4+2]
          + 3.0/2*GHPLs3[3*4*4+0*4+2]*HPLs1[0]
          - 3.0/2*GHPLs4[0*4*4*4+3*4*4+0*4+2]
          - 3.0/4*GHPLs2[0*4+2]
          - 3.0/2*GHPLs2[0*4+2]*zeta2
          - 7.0/4*GHPLs2[0*4+2]*HPLs1[0]
          + 3.0/2*GHPLs2[0*4+2]*HPLs2[0*2+0]
          + 3.0/2*GHPLs2[0*4+2]*HPLs2[1*2+0]
          - 5.0/4*GHPLs2[0*4+2]*HPLs1[1]
          + 3.0/2*GHPLs4[2*4*4*4+1*4*4+0*4+2]
          - 3.0/2*GHPLs3[1*4*4+0*4+2]*HPLs1[0]
          - 3.0/2*GHPLs3[1*4*4+0*4+2]*HPLs1[1]
          - 1.0/4*GHPLs3[2*4*4+1*4+2]
          + 1.0/4*GHPLs2[1*4+2]*HPLs1[0]
          + 1.0/4*GHPLs2[1*4+2]*HPLs1[1]
          - 1.0/2*GHPLs2[2*4+3]*HPLs1[0]
          + 1.0/2*GHPLs3[0*4*4+2*4+3]
          - 3*GHPLs1[3]*zeta2
          - 1.0/8*GHPLs1[3]*HPLs1[0]
          + 1.0/2*GHPLs1[3]*HPLs2[1*2+0]
          + 1.0/2*GHPLs1[3]*HPLs2[0*2+1]
          + 1.0/2*GHPLs3[2*4*4+0*4+3]
          + 1.0/8*GHPLs2[0*4+3]
          - 1.0/2*GHPLs2[0*4+3]*HPLs1[1]
          + 5.0/4*GHPLs3[2*4*4+2*4+0]
          - 3.0/4*GHPLs2[2*4+0]
          - GHPLs2[2*4+0]*HPLs1[0]
          - 5.0/4*GHPLs2[2*4+0]*HPLs1[1]
          - 1.0/2*GHPLs2[3*4+0]*HPLs1[0]
          + 1.0/2*GHPLs3[0*4*4+3*4+0]
          - 5.0/2*GHPLs1[0]*zeta2
          + 1.0/8*GHPLs1[0]*HPLs1[0]
          + 3.0/4*GHPLs1[0]*HPLs1[1]
          + 5.0/4*GHPLs1[0]*HPLs2[0*2+1]
          + 5.0/4*GHPLs1[0]*HPLs2[1*2+1]
          - GHPLs3[2*4*4+1*4+0]
          + GHPLs2[1*4+0]*HPLs1[0]
          + GHPLs2[1*4+0]*HPLs1[1]
          - 3.0/2*GHPLs3[2*4*4+2*4+1]
          + 3.0/2*GHPLs3[2*4*4+2*4+1]*HPLs1[0]
          - 3.0/2*GHPLs4[0*4*4*4+2*4*4+2*4+1]
          - 3.0/2*GHPLs3[3*4*4+2*4+1]*HPLs1[0]
          + 3.0/2*GHPLs4[0*4*4*4+3*4*4+2*4+1]
          + 13.0/8*GHPLs2[2*4+1]
          + 6*GHPLs2[2*4+1]*zeta2
          + 1.0/4*GHPLs2[2*4+1]*HPLs1[0]
          - 3.0/2*GHPLs2[2*4+1]*HPLs2[0*2+0]
          + 3.0/2*GHPLs2[2*4+1]*HPLs1[1]
          - 3.0/2*GHPLs2[2*4+1]*HPLs2[0*2+1]
          - 3.0/2*GHPLs4[2*4*4*4+0*4*4+2*4+1]
          + 7.0/4*GHPLs3[0*4*4+2*4+1]
          + 3.0/2*GHPLs3[0*4*4+2*4+1]*HPLs1[0]
          + 3.0/2*GHPLs3[0*4*4+2*4+1]*HPLs1[1]
          + 3.0/2*GHPLs4[2*4*4*4+1*4*4+2*4+1]
          - 3.0/2*GHPLs3[1*4*4+2*4+1]*HPLs1[0]
          - 3.0/2*GHPLs3[1*4*4+2*4+1]*HPLs1[1]
          - 5*GHPLs1[1]*zeta2
          - 3.0/2*GHPLs1[1]*zeta3
          - 13.0/8*GHPLs1[1]*HPLs1[0]
          - 6*GHPLs1[1]*HPLs1[0]*zeta2
          + 1.0/2*GHPLs1[1]*HPLs2[0*2+0]
          + 3.0/2*GHPLs1[1]*HPLs3[0*2*2+0*2+0]
          - 3.0/4*GHPLs1[1]*HPLs2[1*2+0]
          + 3.0/2*GHPLs1[1]*HPLs3[0*2*2+1*2+0]
          - 13.0/8*GHPLs1[1]*HPLs1[1]
          - 6*GHPLs1[1]*HPLs1[1]*zeta2
          - 1.0/4*GHPLs1[1]*HPLs2[0*2+1]
          + 3.0/2*GHPLs1[1]*HPLs3[0*2*2+0*2+1]
          - 3.0/2*GHPLs1[1]*HPLs2[1*2+1]
          + 3.0/2*GHPLs1[1]*HPLs3[0*2*2+1*2+1]
          - 3.0/2*GHPLs4[2*4*4*4+2*4*4+0*4+1]
          + 7.0/4*GHPLs3[2*4*4+0*4+1]
          + 3.0/2*GHPLs3[2*4*4+0*4+1]*HPLs1[0]
          + 3.0/2*GHPLs3[2*4*4+0*4+1]*HPLs1[1]
          - 3.0/2*GHPLs3[3*4*4+0*4+1]*HPLs1[0]
          + 3.0/2*GHPLs4[0*4*4*4+3*4*4+0*4+1]
          + 9.0/2*GHPLs2[0*4+1]*zeta2
          - 7.0/4*GHPLs2[0*4+1]*HPLs1[0]
          - 3.0/2*GHPLs2[0*4+1]*HPLs2[0*2+0]
          - 3.0/2*GHPLs2[0*4+1]*HPLs2[1*2+0]
          - 7.0/4*GHPLs2[0*4+1]*HPLs1[1]
          - 3.0/2*GHPLs2[0*4+1]*HPLs2[0*2+1]
          - 3.0/2*GHPLs2[0*4+1]*HPLs2[1*2+1]
          + 3.0/2*GHPLs4[2*4*4*4+2*4*4+1*4+1]
          - 1.0/2*GHPLs3[2*4*4+1*4+1]
          - 3.0/2*GHPLs3[2*4*4+1*4+1]*HPLs1[1]
          - 3.0/2*GHPLs4[0*4*4*4+2*4*4+1*4+1]
          + 3.0/2*GHPLs2[1*4+1]*zeta2
          + 1.0/2*GHPLs2[1*4+1]*HPLs1[0]
          + 3.0/2*GHPLs2[1*4+1]*HPLs2[1*2+0]
          + 1.0/2*GHPLs2[1*4+1]*HPLs1[1]
          + 3.0/2*GHPLs2[1*4+1]*HPLs2[1*2+1]
          - 3.0/2*GHPLs4[2*4*4*4+0*4*4+1*4+1]
          + 3.0/2*GHPLs3[0*4*4+1*4+1]*HPLs1[0]
          + 3.0/2*GHPLs3[0*4*4+1*4+1]*HPLs1[1]
          + 3.0/2*GHPLs4[2*4*4*4+1*4*4+1*4+1]
          - 3.0/2*GHPLs3[1*4*4+1*4+1]*HPLs1[0]
          - 3.0/2*GHPLs3[1*4*4+1*4+1]*HPLs1[1]
          + 1.0/2*HPLs1[0]*zeta2
          - 1.0/8*HPLs2[0*2+0]
          - 23.0/16*HPLs1[1]
          + 25.0/4*HPLs1[1]*zeta2
          - 9.0/4*HPLs2[0*2+1]
          - 3*HPLs3[0*2*2+0*2+1]
          - 3.0/2*HPLs3[1*2*2+0*2+1]
          - 5.0/4*HPLs2[1*2+1]
          - 3.0/2*HPLs3[0*2*2+1*2+1]
          )

       + (dN_c*dN_c-1)/(dN_c*dN_c)*pow(u,-1)*v * (
          - 51.0/8*zeta2
          - zeta3
          + 7.0/4*GHPLs3[3*4*4+2*4+2]*HPLs1[0]
          - 7.0/4*GHPLs4[0*4*4*4+3*4*4+2*4+2]
          + 5.0/4*GHPLs2[2*4+2]
          - 7.0/4*GHPLs2[2*4+2]*zeta2
          + 3.0/2*GHPLs2[2*4+2]*HPLs1[0]
          + 5.0/4*GHPLs2[2*4+2]*HPLs2[0*2+0]
          + 5.0/4*GHPLs2[2*4+2]*HPLs2[1*2+0]
          - 1.0/2*GHPLs2[2*4+2]*HPLs2[0*2+1]
          - 5.0/4*GHPLs3[0*4*4+2*4+2]
          - 1.0/2*GHPLs3[0*4*4+2*4+2]*HPLs1[0]
          + 5.0/4*GHPLs4[2*4*4*4+1*4*4+2*4+2]
          - 5.0/4*GHPLs3[1*4*4+2*4+2]*HPLs1[0]
          - 5.0/4*GHPLs3[1*4*4+2*4+2]*HPLs1[1]
          + 1.0/2*GHPLs3[3*4*4+3*4+2]*HPLs1[0]
          - 1.0/2*GHPLs4[0*4*4*4+3*4*4+3*4+2]
          + 1.0/2*GHPLs2[3*4+2]*zeta2
          - 5.0/4*GHPLs2[3*4+2]*HPLs1[0]
          + 5.0/4*GHPLs3[0*4*4+3*4+2]
          - 23.0/16*GHPLs1[2]
          + 15.0/4*GHPLs1[2]*zeta2
          + 3.0/4*GHPLs1[2]*zeta3
          - 1.0/16*GHPLs1[2]*HPLs1[0]
          - 11.0/2*GHPLs1[2]*HPLs1[0]*zeta2
          - 9.0/8*GHPLs1[2]*HPLs2[0*2+0]
          + 7.0/4*GHPLs1[2]*HPLs3[0*2*2+0*2+0]
          + 1.0/2*GHPLs1[2]*HPLs3[1*2*2+0*2+0]
          + 3.0/8*GHPLs1[2]*HPLs2[1*2+0]
          + 5.0/4*GHPLs1[2]*HPLs3[0*2*2+1*2+0]
          - 5.0/4*GHPLs1[2]*HPLs1[1]
          + 5.0/4*GHPLs1[2]*HPLs1[1]*zeta2
          - 17.0/8*GHPLs1[2]*HPLs2[0*2+1]
          - 5.0/4*GHPLs1[2]*HPLs3[0*2*2+0*2+1]
          - 5.0/4*GHPLs1[2]*HPLs3[1*2*2+0*2+1]
          - 5.0/4*GHPLs3[2*4*4+0*4+2]
          - 7.0/4*GHPLs3[3*4*4+0*4+2]*HPLs1[0]
          + 7.0/4*GHPLs4[0*4*4*4+3*4*4+0*4+2]
          + 1.0/2*GHPLs2[0*4+2]
          + 5.0/4*GHPLs2[0*4+2]*zeta2
          + 3.0/4*GHPLs2[0*4+2]*HPLs1[0]
          - 5.0/4*GHPLs2[0*4+2]*HPLs2[0*2+0]
          - 5.0/4*GHPLs2[0*4+2]*HPLs2[1*2+0]
          + 5.0/4*GHPLs2[0*4+2]*HPLs1[1]
          - 5.0/4*GHPLs4[2*4*4*4+1*4*4+0*4+2]
          + 5.0/4*GHPLs3[1*4*4+0*4+2]*HPLs1[0]
          + 5.0/4*GHPLs3[1*4*4+0*4+2]*HPLs1[1]
          + 15.0/8*GHPLs3[2*4*4+1*4+2]
          - 1.0/4*GHPLs3[2*4*4+1*4+2]*HPLs1[0]
          + GHPLs2[1*4+2]*zeta2
          - 15.0/8*GHPLs2[1*4+2]*HPLs1[0]
          - 1.0/4*GHPLs2[1*4+2]*HPLs2[1*2+0]
          - 15.0/8*GHPLs2[1*4+2]*HPLs1[1]
          + 1.0/4*GHPLs2[1*4+2]*HPLs2[0*2+1]
          - 1.0/2*GHPLs4[2*4*4*4+1*4*4+1*4+2]
          + 1.0/2*GHPLs3[1*4*4+1*4+2]*HPLs1[0]
          + 1.0/2*GHPLs3[1*4*4+1*4+2]*HPLs1[1]
          - 3.0/8*GHPLs2[2*4+3]*HPLs1[0]
          + 3.0/8*GHPLs3[0*4*4+2*4+3]
          - 3.0/8*GHPLs2[3*4+3]*HPLs1[0]
          + 3.0/8*GHPLs3[0*4*4+3*4+3]
          - 21.0/8*GHPLs1[3]*zeta2
          + 11.0/8*GHPLs1[3]*HPLs1[0]
          + 3.0/8*GHPLs1[3]*HPLs2[1*2+0]
          + 3.0/8*GHPLs1[3]*HPLs2[0*2+1]
          + 3.0/8*GHPLs3[2*4*4+0*4+3]
          - 11.0/8*GHPLs2[0*4+3]
          - 3.0/8*GHPLs2[0*4+3]*HPLs1[1]
          - 5.0/4*GHPLs3[2*4*4+2*4+0]
          + 1.0/2*GHPLs2[2*4+0]
          + 3.0/4*GHPLs2[2*4+0]*HPLs1[0]
          + 5.0/4*GHPLs2[2*4+0]*HPLs1[1]
          - 5.0/4*GHPLs2[3*4+0]*HPLs1[0]
          + 5.0/4*GHPLs3[0*4*4+3*4+0]
          + 15.0/4*GHPLs1[0]*zeta2
          - 5.0/8*GHPLs1[0]*HPLs1[0]
          - 5.0/4*GHPLs1[0]*HPLs2[0*2+0]
          - 5.0/4*GHPLs1[0]*HPLs2[1*2+0]
          - 1.0/2*GHPLs1[0]*HPLs1[1]
          - 5.0/4*GHPLs1[0]*HPLs2[0*2+1]
          - 5.0/4*GHPLs1[0]*HPLs2[1*2+1]
          - 1.0/2*GHPLs3[2*4*4+1*4+0]
          + 1.0/2*GHPLs2[1*4+0]*HPLs1[0]
          + 1.0/2*GHPLs2[1*4+0]*HPLs1[1]
          + 3.0/2*GHPLs3[2*4*4+2*4+1]
          - 7.0/4*GHPLs3[2*4*4+2*4+1]*HPLs1[0]
          + 5.0/4*GHPLs4[0*4*4*4+2*4*4+2*4+1]
          + 5.0/4*GHPLs3[3*4*4+2*4+1]*HPLs1[0]
          - 5.0/4*GHPLs4[0*4*4*4+3*4*4+2*4+1]
          + 17.0/16*GHPLs2[2*4+1]
          - 5*GHPLs2[2*4+1]*zeta2
          - 1.0/4*GHPLs2[2*4+1]*HPLs1[0]
          + 7.0/4*GHPLs2[2*4+1]*HPLs2[0*2+0]
          + 1.0/4*GHPLs2[2*4+1]*HPLs2[1*2+0]
          - 3.0/2*GHPLs2[2*4+1]*HPLs1[1]
          + 3.0/2*GHPLs2[2*4+1]*HPLs2[0*2+1]
          + 5.0/4*GHPLs4[2*4*4*4+0*4*4+2*4+1]
          - 11.0/8*GHPLs3[0*4*4+2*4+1]
          - 5.0/4*GHPLs3[0*4*4+2*4+1]*HPLs1[0]
          - 5.0/4*GHPLs3[0*4*4+2*4+1]*HPLs1[1]
          - 3.0/2*GHPLs4[2*4*4*4+1*4*4+2*4+1]
          + 3.0/2*GHPLs3[1*4*4+2*4+1]*HPLs1[0]
          + 3.0/2*GHPLs3[1*4*4+2*4+1]*HPLs1[1]
          + 9.0/4*GHPLs1[1]*zeta2
          + GHPLs1[1]*zeta3
          - 17.0/16*GHPLs1[1]*HPLs1[0]
          + 6*GHPLs1[1]*HPLs1[0]*zeta2
          - 1.0/4*GHPLs1[1]*HPLs2[0*2+0]
          - 7.0/4*GHPLs1[1]*HPLs3[0*2*2+0*2+0]
          - 1.0/2*GHPLs1[1]*HPLs3[1*2*2+0*2+0]
          + GHPLs1[1]*HPLs2[1*2+0]
          - 5.0/4*GHPLs1[1]*HPLs3[0*2*2+1*2+0]
          - 17.0/16*GHPLs1[1]*HPLs1[1]
          + 5*GHPLs1[1]*HPLs1[1]*zeta2
          + 1.0/4*GHPLs1[1]*HPLs2[0*2+1]
          - 7.0/4*GHPLs1[1]*HPLs3[0*2*2+0*2+1]
          - 1.0/4*GHPLs1[1]*HPLs3[1*2*2+0*2+1]
          + 3.0/2*GHPLs1[1]*HPLs2[1*2+1]
          - 3.0/2*GHPLs1[1]*HPLs3[0*2*2+1*2+1]
          + 5.0/4*GHPLs4[2*4*4*4+2*4*4+0*4+1]
          - 11.0/8*GHPLs3[2*4*4+0*4+1]
          - GHPLs3[2*4*4+0*4+1]*HPLs1[0]
          - 5.0/4*GHPLs3[2*4*4+0*4+1]*HPLs1[1]
          + 5.0/4*GHPLs3[3*4*4+0*4+1]*HPLs1[0]
          - 5.0/4*GHPLs4[0*4*4*4+3*4*4+0*4+1]
          - 15.0/4*GHPLs2[0*4+1]*zeta2
          + 11.0/8*GHPLs2[0*4+1]*HPLs1[0]
          + 5.0/4*GHPLs2[0*4+1]*HPLs2[0*2+0]
          + 5.0/4*GHPLs2[0*4+1]*HPLs2[1*2+0]
          + 11.0/8*GHPLs2[0*4+1]*HPLs1[1]
          + 5.0/4*GHPLs2[0*4+1]*HPLs2[0*2+1]
          + 5.0/4*GHPLs2[0*4+1]*HPLs2[1*2+1]
          + 1.0/4*GHPLs4[2*4*4*4+1*4*4+0*4+1]
          - 1.0/4*GHPLs3[1*4*4+0*4+1]*HPLs1[0]
          - 1.0/4*GHPLs3[1*4*4+0*4+1]*HPLs1[1]
          - 7.0/4*GHPLs4[2*4*4*4+2*4*4+1*4+1]
          + 3.0/4*GHPLs3[2*4*4+1*4+1]
          + 1.0/2*GHPLs3[2*4*4+1*4+1]*HPLs1[0]
          + 7.0/4*GHPLs3[2*4*4+1*4+1]*HPLs1[1]
          + 5.0/4*GHPLs4[0*4*4*4+2*4*4+1*4+1]
          - 3.0/4*GHPLs2[1*4+1]*zeta2
          - 3.0/4*GHPLs2[1*4+1]*HPLs1[0]
          - 5.0/4*GHPLs2[1*4+1]*HPLs2[1*2+0]
          - 3.0/4*GHPLs2[1*4+1]*HPLs1[1]
          - 1.0/2*GHPLs2[1*4+1]*HPLs2[0*2+1]
          - 7.0/4*GHPLs2[1*4+1]*HPLs2[1*2+1]
          + 5.0/4*GHPLs4[2*4*4*4+0*4*4+1*4+1]
          - 5.0/4*GHPLs3[0*4*4+1*4+1]*HPLs1[0]
          - 5.0/4*GHPLs3[0*4*4+1*4+1]*HPLs1[1]
          - 3.0/4*GHPLs4[2*4*4*4+1*4*4+1*4+1]
          + 3.0/4*GHPLs3[1*4*4+1*4+1]*HPLs1[0]
          + 3.0/4*GHPLs3[1*4*4+1*4+1]*HPLs1[1]
          + 23.0/16*HPLs1[0]
          - 6*HPLs1[0]*zeta2
          + 3.0/2*HPLs2[0*2+0]
          + 7.0/4*HPLs3[0*2*2+0*2+0]
          + 1.0/2*HPLs3[1*2*2+0*2+0]
          + 9.0/8*HPLs2[1*2+0]
          + 5.0/4*HPLs3[0*2*2+1*2+0]
          + 23.0/16*HPLs1[1]
          - 5*HPLs1[1]*zeta2
          + 11.0/8*HPLs2[0*2+1]
          + 7.0/4*HPLs3[0*2*2+0*2+1]
          + 1.0/4*HPLs3[1*2*2+0*2+1]
          + 5.0/4*HPLs2[1*2+1]
          + 3.0/2*HPLs3[0*2*2+1*2+1]
          )

       + (dN_c*dN_c-1)/(dN_c*dN_c)*pow(u,-1)*pow(v,2) * (
          - 1.0/2*zeta2
          - 1.0/4*GHPLs1[2]*HPLs1[0]
          + 1.0/8*GHPLs2[0*4+2]
          + 1.0/8*GHPLs1[3]*HPLs1[0]
          - 1.0/8*GHPLs2[0*4+3]
          + 1.0/8*GHPLs2[2*4+0]
          - 1.0/8*GHPLs1[0]*HPLs1[0]
          - 1.0/8*GHPLs1[0]*HPLs1[1]
          - 1.0/4*GHPLs2[2*4+1]
          + 1.0/4*GHPLs1[1]*HPLs1[0]
          + 1.0/4*GHPLs1[1]*HPLs1[1]
          + 1.0/8*HPLs2[0*2+0]
          + 1.0/8*HPLs2[0*2+1]
          )

       + (dN_c*dN_c-1)/(dN_c*dN_c)*pow(u,-1)*pow(v,3) * (
          + 1.0/8*GHPLs1[2]*zeta2
          + 1.0/8*GHPLs1[2]*HPLs2[0*2+0]
          - 1.0/8*GHPLs1[2]*HPLs2[1*2+0]
          - 1.0/8*GHPLs2[0*4+2]*HPLs1[0]
          - 1.0/8*GHPLs3[2*4*4+1*4+2]
          + 1.0/8*GHPLs2[1*4+2]*HPLs1[0]
          + 1.0/8*GHPLs2[1*4+2]*HPLs1[1]
          - 1.0/8*GHPLs2[2*4+3]*HPLs1[0]
          + 1.0/8*GHPLs3[0*4*4+2*4+3]
          + 1.0/8*GHPLs2[3*4+3]*HPLs1[0]
          - 1.0/8*GHPLs3[0*4*4+3*4+3]
          - 5.0/8*GHPLs1[3]*zeta2
          + 1.0/8*GHPLs1[3]*HPLs2[1*2+0]
          + 1.0/8*GHPLs1[3]*HPLs2[0*2+1]
          + 1.0/8*GHPLs3[2*4*4+0*4+3]
          - 1.0/8*GHPLs2[0*4+3]*HPLs1[1]
          )

       + (dN_c*dN_c-1)/(dN_c*dN_c)*pow(1-v,-1) * (
          - 33.0/16*zeta2
          - 3.0/8*zeta3
          + 9.0/8*GHPLs2[3*4+2]*HPLs1[0]
          - 9.0/8*GHPLs3[0*4*4+3*4+2]
          - 3.0/4*GHPLs1[2]*zeta2
          - 1.0/16*GHPLs1[2]*HPLs1[0]
          + 3.0/8*GHPLs1[2]*HPLs2[0*2+0]
          - 3.0/4*GHPLs1[2]*HPLs2[0*2+1]
          - 3.0/4*GHPLs2[0*4+2]*HPLs1[0]
          + 5.0/4*GHPLs1[3]*HPLs1[0]
          - 5.0/4*GHPLs2[0*4+3]
          + 3.0/8*GHPLs2[2*4+0]*HPLs1[0]
          - 9.0/8*GHPLs2[3*4+0]*HPLs1[0]
          + 9.0/8*GHPLs3[0*4*4+3*4+0]
          + 3.0/8*GHPLs1[0]*zeta2
          - 9.0/8*GHPLs1[0]*HPLs1[0]
          - 3.0/8*GHPLs1[0]*HPLs2[0*2+0]
          - 3.0/8*GHPLs1[0]*HPLs2[1*2+0]
          + 7.0/8*GHPLs2[2*4+1]
          - 7.0/8*GHPLs1[1]*HPLs1[0]
          - 7.0/8*GHPLs1[1]*HPLs1[1]
          + 65.0/32*HPLs1[0]
          - 9.0/4*HPLs1[0]*zeta2
          + 3.0/2*HPLs2[0*2+0]
          + 9.0/8*HPLs3[0*2*2+0*2+0]
          + 3.0/4*HPLs3[1*2*2+0*2+0]
          + 15.0/16*HPLs2[1*2+0]
          + 3.0/8*HPLs3[0*2*2+1*2+0]
          + 3.0/8*HPLs1[1]*zeta2
          - 9.0/8*HPLs2[0*2+1]
          - 3.0/8*HPLs3[0*2*2+0*2+1]
          - 3.0/8*HPLs3[1*2*2+0*2+1]
          )

       + (dN_c*dN_c-1)/(dN_c*dN_c)*pow(1-u-v,-1) * (
          + 1.0/4*zeta2
          - 1.0/2*GHPLs2[2*4+3]*HPLs1[0]
          + 1.0/2*GHPLs3[0*4*4+2*4+3]
          - 1.0/2*GHPLs2[3*4+3]*HPLs1[0]
          + 1.0/2*GHPLs3[0*4*4+3*4+3]
          - 7.0/2*GHPLs1[3]*zeta2
          - 1.0/4*GHPLs1[3]*HPLs1[0]
          + 1.0/2*GHPLs1[3]*HPLs2[1*2+0]
          + 1.0/2*GHPLs1[3]*HPLs2[0*2+1]
          + 1.0/2*GHPLs3[2*4*4+0*4+3]
          + 1.0/4*GHPLs2[0*4+3]
          - 1.0/2*GHPLs2[0*4+3]*HPLs1[1]
          + 1.0/4*GHPLs1[0]*HPLs1[0]
          + 1.0/2*GHPLs3[0*4*4+2*4+1]
          - 4*GHPLs1[1]*zeta2
          + 1.0/2*GHPLs1[1]*HPLs2[0*2+0]
          + 1.0/2*GHPLs1[1]*HPLs2[1*2+0]
          + 1.0/2*GHPLs3[2*4*4+0*4+1]
          - 1.0/2*GHPLs2[0*4+1]*HPLs1[0]
          - 1.0/2*GHPLs2[0*4+1]*HPLs1[1]
          + 1.0/2*GHPLs3[2*4*4+1*4+1]
          - 1.0/2*GHPLs2[1*4+1]*HPLs1[0]
          - 1.0/2*GHPLs2[1*4+1]*HPLs1[1]
          - 1.0/4*HPLs2[0*2+0]
          + 1.0/4*HPLs2[0*2+1]
          )

       + (dN_c*dN_c-1)/(dN_c*dN_c) * (
          + 33.0/32
          - 47.0/16*zeta2
          - 7.0/4*zeta3
          + 1.0/4*GHPLs3[3*4*4+2*4+2]*HPLs1[0]
          - 1.0/4*GHPLs4[0*4*4*4+3*4*4+2*4+2]
          + 9.0/16*GHPLs2[2*4+2]
          - 1.0/4*GHPLs2[2*4+2]*zeta2
          + 3.0/4*GHPLs2[2*4+2]*HPLs1[0]
          + 1.0/4*GHPLs2[2*4+2]*HPLs2[0*2+0]
          + 1.0/4*GHPLs2[2*4+2]*HPLs2[1*2+0]
          - 7.0/8*GHPLs3[0*4*4+2*4+2]
          + 1.0/4*GHPLs4[2*4*4*4+1*4*4+2*4+2]
          - 1.0/4*GHPLs3[1*4*4+2*4+2]*HPLs1[0]
          - 1.0/4*GHPLs3[1*4*4+2*4+2]*HPLs1[1]
          - 21.0/8*GHPLs2[3*4+2]*HPLs1[0]
          + 21.0/8*GHPLs3[0*4*4+3*4+2]
          + 13.0/32*GHPLs1[2]
          + 5*GHPLs1[2]*zeta2
          + 1.0/4*GHPLs1[2]*zeta3
          - 13.0/8*GHPLs1[2]*HPLs1[0]
          - GHPLs1[2]*HPLs1[0]*zeta2
          - 15.0/8*GHPLs1[2]*HPLs2[0*2+0]
          + 1.0/4*GHPLs1[2]*HPLs3[0*2*2+0*2+0]
          - 7.0/8*GHPLs1[2]*HPLs2[1*2+0]
          + 1.0/4*GHPLs1[2]*HPLs3[0*2*2+1*2+0]
          - 9.0/16*GHPLs1[2]*HPLs1[1]
          + 1.0/4*GHPLs1[2]*HPLs1[1]*zeta2
          - 1.0/4*GHPLs1[2]*HPLs2[0*2+1]
          - 1.0/4*GHPLs1[2]*HPLs3[0*2*2+0*2+1]
          - 1.0/4*GHPLs1[2]*HPLs3[1*2*2+0*2+1]
          - 7.0/8*GHPLs3[2*4*4+0*4+2]
          - 1.0/4*GHPLs3[3*4*4+0*4+2]*HPLs1[0]
          + 1.0/4*GHPLs4[0*4*4*4+3*4*4+0*4+2]
          + 7.0/8*GHPLs2[0*4+2]
          + 1.0/4*GHPLs2[0*4+2]*zeta2
          + 11.0/8*GHPLs2[0*4+2]*HPLs1[0]
          - 1.0/4*GHPLs2[0*4+2]*HPLs2[0*2+0]
          - 1.0/4*GHPLs2[0*4+2]*HPLs2[1*2+0]
          + 7.0/8*GHPLs2[0*4+2]*HPLs1[1]
          - 1.0/4*GHPLs4[2*4*4*4+1*4*4+0*4+2]
          + 1.0/4*GHPLs3[1*4*4+0*4+2]*HPLs1[0]
          + 1.0/4*GHPLs3[1*4*4+0*4+2]*HPLs1[1]
          - 1.0/8*GHPLs3[2*4*4+1*4+2]
          + 1.0/8*GHPLs2[1*4+2]*HPLs1[0]
          + 1.0/8*GHPLs2[1*4+2]*HPLs1[1]
          + 1.0/4*GHPLs2[3*4+3]*HPLs1[0]
          - 1.0/4*GHPLs3[0*4*4+3*4+3]
          + 1.0/4*GHPLs1[3]*zeta2
          + 3.0/8*GHPLs1[3]*HPLs1[0]
          - 3.0/8*GHPLs2[0*4+3]
          - 7.0/8*GHPLs3[2*4*4+2*4+0]
          + 7.0/8*GHPLs2[2*4+0]
          + 5.0/8*GHPLs2[2*4+0]*HPLs1[0]
          + 7.0/8*GHPLs2[2*4+0]*HPLs1[1]
          + 7.0/8*GHPLs2[3*4+0]*HPLs1[0]
          - 7.0/8*GHPLs3[0*4*4+3*4+0]
          + 3.0/8*GHPLs1[0]
          + 11.0/8*GHPLs1[0]*zeta2
          - 1.0/2*GHPLs1[0]*HPLs1[0]
          + 3.0/8*GHPLs1[0]*HPLs2[0*2+0]
          + 3.0/8*GHPLs1[0]*HPLs2[1*2+0]
          - 7.0/8*GHPLs1[0]*HPLs1[1]
          - 7.0/8*GHPLs1[0]*HPLs2[0*2+1]
          - 7.0/8*GHPLs1[0]*HPLs2[1*2+1]
          + GHPLs3[2*4*4+1*4+0]
          - GHPLs2[1*4+0]*HPLs1[0]
          - GHPLs2[1*4+0]*HPLs1[1]
          + 3.0/4*GHPLs3[2*4*4+2*4+1]
          - 1.0/4*GHPLs3[2*4*4+2*4+1]*HPLs1[0]
          + 1.0/4*GHPLs4[0*4*4*4+2*4*4+2*4+1]
          + 1.0/4*GHPLs3[3*4*4+2*4+1]*HPLs1[0]
          - 1.0/4*GHPLs4[0*4*4*4+3*4*4+2*4+1]
          - 41.0/16*GHPLs2[2*4+1]
          - GHPLs2[2*4+1]*zeta2
          + 1.0/8*GHPLs2[2*4+1]*HPLs1[0]
          + 1.0/4*GHPLs2[2*4+1]*HPLs2[0*2+0]
          - 3.0/4*GHPLs2[2*4+1]*HPLs1[1]
          + 1.0/4*GHPLs2[2*4+1]*HPLs2[0*2+1]
          + 1.0/4*GHPLs4[2*4*4*4+0*4*4+2*4+1]
          - 7.0/8*GHPLs3[0*4*4+2*4+1]
          - 1.0/4*GHPLs3[0*4*4+2*4+1]*HPLs1[0]
          - 1.0/4*GHPLs3[0*4*4+2*4+1]*HPLs1[1]
          - 1.0/4*GHPLs4[2*4*4*4+1*4*4+2*4+1]
          + 1.0/4*GHPLs3[1*4*4+2*4+1]*HPLs1[0]
          + 1.0/4*GHPLs3[1*4*4+2*4+1]*HPLs1[1]
          + GHPLs1[1]*zeta2
          + 1.0/4*GHPLs1[1]*zeta3
          + 41.0/16*GHPLs1[1]*HPLs1[0]
          + GHPLs1[1]*HPLs1[0]*zeta2
          - 1.0/4*GHPLs1[1]*HPLs3[0*2*2+0*2+0]
          + 7.0/8*GHPLs1[1]*HPLs2[1*2+0]
          - 1.0/4*GHPLs1[1]*HPLs3[0*2*2+1*2+0]
          + 41.0/16*GHPLs1[1]*HPLs1[1]
          + GHPLs1[1]*HPLs1[1]*zeta2
          - 1.0/8*GHPLs1[1]*HPLs2[0*2+1]
          - 1.0/4*GHPLs1[1]*HPLs3[0*2*2+0*2+1]
          + 3.0/4*GHPLs1[1]*HPLs2[1*2+1]
          - 1.0/4*GHPLs1[1]*HPLs3[0*2*2+1*2+1]
          + 1.0/4*GHPLs4[2*4*4*4+2*4*4+0*4+1]
          - 7.0/8*GHPLs3[2*4*4+0*4+1]
          - 1.0/4*GHPLs3[2*4*4+0*4+1]*HPLs1[0]
          - 1.0/4*GHPLs3[2*4*4+0*4+1]*HPLs1[1]
          + 1.0/4*GHPLs3[3*4*4+0*4+1]*HPLs1[0]
          - 1.0/4*GHPLs4[0*4*4*4+3*4*4+0*4+1]
          - 3.0/4*GHPLs2[0*4+1]*zeta2
          + 7.0/8*GHPLs2[0*4+1]*HPLs1[0]
          + 1.0/4*GHPLs2[0*4+1]*HPLs2[0*2+0]
          + 1.0/4*GHPLs2[0*4+1]*HPLs2[1*2+0]
          + 7.0/8*GHPLs2[0*4+1]*HPLs1[1]
          + 1.0/4*GHPLs2[0*4+1]*HPLs2[0*2+1]
          + 1.0/4*GHPLs2[0*4+1]*HPLs2[1*2+1]
          - 1.0/4*GHPLs4[2*4*4*4+2*4*4+1*4+1]
          + GHPLs3[2*4*4+1*4+1]
          + 1.0/4*GHPLs3[2*4*4+1*4+1]*HPLs1[1]
          + 1.0/4*GHPLs4[0*4*4*4+2*4*4+1*4+1]
          - 1.0/4*GHPLs2[1*4+1]*zeta2
          - GHPLs2[1*4+1]*HPLs1[0]
          - 1.0/4*GHPLs2[1*4+1]*HPLs2[1*2+0]
          - GHPLs2[1*4+1]*HPLs1[1]
          - 1.0/4*GHPLs2[1*4+1]*HPLs2[1*2+1]
          + 1.0/4*GHPLs4[2*4*4*4+0*4*4+1*4+1]
          - 1.0/4*GHPLs3[0*4*4+1*4+1]*HPLs1[0]
          - 1.0/4*GHPLs3[0*4*4+1*4+1]*HPLs1[1]
          - 1.0/4*GHPLs4[2*4*4*4+1*4*4+1*4+1]
          + 1.0/4*GHPLs3[1*4*4+1*4+1]*HPLs1[0]
          + 1.0/4*GHPLs3[1*4*4+1*4+1]*HPLs1[1]
          - 65.0/32*HPLs1[0]
          + 5.0/2*HPLs1[0]*zeta2
          + 1.0/8*HPLs2[0*2+0]
          - 9.0/8*HPLs3[0*2*2+0*2+0]
          - 3.0/4*HPLs3[1*2*2+0*2+0]
          - 15.0/16*HPLs2[1*2+0]
          - 3.0/8*HPLs3[0*2*2+1*2+0]
          - 13.0/32*HPLs1[1]
          - 19.0/4*HPLs1[1]*zeta2
          + 2*HPLs2[0*2+1]
          + 15.0/8*HPLs3[0*2*2+0*2+1]
          + 9.0/8*HPLs3[1*2*2+0*2+1]
          + 9.0/16*HPLs2[1*2+1]
          + 3.0/4*HPLs3[0*2*2+1*2+1]
          )

       + (dN_c*dN_c-1)/(dN_c*dN_c)*v*pow(1-u,-1) * (
          - 7.0/16*zeta2
          - 5.0/16*GHPLs2[2*4+2]
          - 1.0/4*GHPLs2[2*4+2]*HPLs1[0]
          + 1.0/8*GHPLs3[0*4*4+2*4+2]
          + 1.0/8*GHPLs2[3*4+2]*HPLs1[0]
          - 1.0/8*GHPLs3[0*4*4+3*4+2]
          + 23.0/32*GHPLs1[2]
          - 5.0/8*GHPLs1[2]*zeta2
          + 1.0/8*GHPLs1[2]*HPLs1[0]
          + 1.0/4*GHPLs1[2]*HPLs2[0*2+0]
          + 5.0/16*GHPLs1[2]*HPLs1[1]
          + 1.0/8*GHPLs3[2*4*4+0*4+2]
          + 3.0/8*GHPLs2[0*4+2]
          - 1.0/4*GHPLs2[0*4+2]*HPLs1[0]
          - 1.0/8*GHPLs2[0*4+2]*HPLs1[1]
          - 1.0/4*GHPLs3[2*4*4+1*4+2]
          + 1.0/4*GHPLs2[1*4+2]*HPLs1[0]
          + 1.0/4*GHPLs2[1*4+2]*HPLs1[1]
          + 1.0/8*GHPLs3[2*4*4+2*4+0]
          + 3.0/8*GHPLs2[2*4+0]
          - 1.0/8*GHPLs2[2*4+0]*HPLs1[1]
          + 1.0/8*GHPLs2[3*4+0]*HPLs1[0]
          - 1.0/8*GHPLs3[0*4*4+3*4+0]
          - 1.0/8*GHPLs1[0]*zeta2
          - 3.0/8*GHPLs1[0]*HPLs1[0]
          + 1.0/4*GHPLs1[0]*HPLs2[0*2+0]
          + 1.0/8*GHPLs1[0]*HPLs2[1*2+0]
          - 3.0/8*GHPLs1[0]*HPLs1[1]
          + 1.0/4*GHPLs1[0]*HPLs2[0*2+1]
          + 1.0/8*GHPLs1[0]*HPLs2[1*2+1]
          + 1.0/8*GHPLs3[2*4*4+1*4+0]
          - 1.0/8*GHPLs2[1*4+0]*HPLs1[0]
          - 1.0/8*GHPLs2[1*4+0]*HPLs1[1]
          - 1.0/4*GHPLs3[2*4*4+2*4+1]
          - 7.0/16*GHPLs2[2*4+1]
          + 1.0/4*GHPLs2[2*4+1]*HPLs1[0]
          + 1.0/4*GHPLs2[2*4+1]*HPLs1[1]
          + 1.0/4*GHPLs1[1]*zeta2
          + 7.0/16*GHPLs1[1]*HPLs1[0]
          + 7.0/16*GHPLs1[1]*HPLs1[1]
          - 1.0/4*GHPLs1[1]*HPLs2[0*2+1]
          - 1.0/4*GHPLs1[1]*HPLs2[1*2+1]
          + 1.0/4*GHPLs3[2*4*4+1*4+1]
          - 1.0/4*GHPLs2[1*4+1]*HPLs1[0]
          - 1.0/4*GHPLs2[1*4+1]*HPLs1[1]
          - 23.0/32*HPLs1[0]
          + 9.0/8*HPLs1[0]*zeta2
          - 3.0/8*HPLs2[0*2+0]
          - 1.0/4*HPLs3[0*2*2+0*2+0]
          - 1.0/8*HPLs3[1*2*2+0*2+0]
          - 9.0/16*HPLs2[1*2+0]
          + 1.0/8*HPLs3[0*2*2+1*2+0]
          - 23.0/32*HPLs1[1]
          + 5.0/8*HPLs1[1]*zeta2
          - 1.0/8*HPLs2[0*2+1]
          - 1.0/4*HPLs3[0*2*2+0*2+1]
          - 5.0/16*HPLs2[1*2+1]
          )

       + (dN_c*dN_c-1)/(dN_c*dN_c)*v * (
          + 33.0/8*zeta2
          + 1.0/2*zeta3
          - 1.0/2*GHPLs2[2*4+2]*HPLs1[0]
          + 1.0/2*GHPLs3[0*4*4+2*4+2]
          + 1.0/2*GHPLs2[3*4+2]*HPLs1[0]
          - 1.0/2*GHPLs3[0*4*4+3*4+2]
          - 15.0/8*GHPLs1[2]*zeta2
          + 5.0/8*GHPLs1[2]*HPLs1[0]
          + 5.0/8*GHPLs1[2]*HPLs2[0*2+0]
          - 1.0/8*GHPLs1[2]*HPLs2[1*2+0]
          + 1.0/2*GHPLs1[2]*HPLs2[0*2+1]
          + 1.0/2*GHPLs3[2*4*4+0*4+2]
          - GHPLs2[0*4+2]
          - 5.0/8*GHPLs2[0*4+2]*HPLs1[0]
          - 1.0/2*GHPLs2[0*4+2]*HPLs1[1]
          - 5.0/8*GHPLs3[2*4*4+1*4+2]
          + 5.0/8*GHPLs2[1*4+2]*HPLs1[0]
          + 5.0/8*GHPLs2[1*4+2]*HPLs1[1]
          - 1.0/8*GHPLs2[2*4+3]*HPLs1[0]
          + 1.0/8*GHPLs3[0*4*4+2*4+3]
          + 1.0/8*GHPLs2[3*4+3]*HPLs1[0]
          - 1.0/8*GHPLs3[0*4*4+3*4+3]
          - 5.0/8*GHPLs1[3]*zeta2
          - GHPLs1[3]*HPLs1[0]
          + 1.0/8*GHPLs1[3]*HPLs2[1*2+0]
          + 1.0/8*GHPLs1[3]*HPLs2[0*2+1]
          + 1.0/8*GHPLs3[2*4*4+0*4+3]
          + GHPLs2[0*4+3]
          - 1.0/8*GHPLs2[0*4+3]*HPLs1[1]
          + 1.0/2*GHPLs3[2*4*4+2*4+0]
          - GHPLs2[2*4+0]
          - 3.0/8*GHPLs2[2*4+0]*HPLs1[0]
          - 1.0/2*GHPLs2[2*4+0]*HPLs1[1]
          + 1.0/2*GHPLs2[3*4+0]*HPLs1[0]
          - 1.0/2*GHPLs3[0*4*4+3*4+0]
          - 7.0/4*GHPLs1[0]*zeta2
          + 9.0/8*GHPLs1[0]*HPLs1[0]
          + 3.0/8*GHPLs1[0]*HPLs2[0*2+0]
          + 1.0/2*GHPLs1[0]*HPLs2[1*2+0]
          + GHPLs1[0]*HPLs1[1]
          + 3.0/8*GHPLs1[0]*HPLs2[0*2+1]
          + 1.0/2*GHPLs1[0]*HPLs2[1*2+1]
          + 1.0/8*GHPLs3[2*4*4+1*4+0]
          - 1.0/8*GHPLs2[1*4+0]*HPLs1[0]
          - 1.0/8*GHPLs2[1*4+0]*HPLs1[1]
          - 1.0/2*GHPLs3[2*4*4+2*4+1]
          + 3.0/4*GHPLs2[2*4+1]
          - 1.0/8*GHPLs2[2*4+1]*HPLs1[0]
          + 1.0/2*GHPLs2[2*4+1]*HPLs1[1]
          + 1.0/2*GHPLs3[0*4*4+2*4+1]
          - 1.0/4*GHPLs1[1]*zeta2
          - 3.0/4*GHPLs1[1]*HPLs1[0]
          + 1.0/8*GHPLs1[1]*HPLs2[0*2+0]
          - 1.0/2*GHPLs1[1]*HPLs2[1*2+0]
          - 3.0/4*GHPLs1[1]*HPLs1[1]
          + 1.0/8*GHPLs1[1]*HPLs2[0*2+1]
          - 1.0/2*GHPLs1[1]*HPLs2[1*2+1]
          + 1.0/2*GHPLs3[2*4*4+0*4+1]
          - 1.0/2*GHPLs2[0*4+1]*HPLs1[0]
          - 1.0/2*GHPLs2[0*4+1]*HPLs1[1]
          - 5.0/8*GHPLs3[2*4*4+1*4+1]
          + 5.0/8*GHPLs2[1*4+1]*HPLs1[0]
          + 5.0/8*GHPLs2[1*4+1]*HPLs1[1]
          + 15.0/8*HPLs1[0]*zeta2
          - HPLs2[0*2+0]
          - 5.0/8*HPLs3[0*2*2+0*2+0]
          - 1.0/8*HPLs3[1*2*2+0*2+0]
          + 1.0/8*HPLs2[1*2+0]
          - 3.0/4*HPLs3[0*2*2+1*2+0]
          + 15.0/8*HPLs1[1]*zeta2
          - 7.0/8*HPLs2[0*2+1]
          - 5.0/8*HPLs3[0*2*2+0*2+1]
          - 1.0/8*HPLs3[1*2*2+0*2+1]
          - 3.0/4*HPLs3[0*2*2+1*2+1]
          )

       + (dN_c*dN_c-1)/(dN_c*dN_c)*pow(v,2) * (
          + 1.0/2*zeta2
          + 1.0/4*GHPLs1[2]*zeta2
          + 1.0/8*GHPLs1[2]*HPLs1[0]
          + 1.0/4*GHPLs1[2]*HPLs2[0*2+0]
          - 1.0/4*GHPLs1[2]*HPLs2[1*2+0]
          - 1.0/8*GHPLs2[0*4+2]
          - 1.0/4*GHPLs2[0*4+2]*HPLs1[0]
          - 1.0/4*GHPLs3[2*4*4+1*4+2]
          + 1.0/4*GHPLs2[1*4+2]*HPLs1[0]
          + 1.0/4*GHPLs2[1*4+2]*HPLs1[1]
          - 1.0/4*GHPLs2[2*4+3]*HPLs1[0]
          + 1.0/4*GHPLs3[0*4*4+2*4+3]
          + 1.0/4*GHPLs2[3*4+3]*HPLs1[0]
          - 1.0/4*GHPLs3[0*4*4+3*4+3]
          - 5.0/4*GHPLs1[3]*zeta2
          - 1.0/8*GHPLs1[3]*HPLs1[0]
          + 1.0/4*GHPLs1[3]*HPLs2[1*2+0]
          + 1.0/4*GHPLs1[3]*HPLs2[0*2+1]
          + 1.0/4*GHPLs3[2*4*4+0*4+3]
          + 1.0/8*GHPLs2[0*4+3]
          - 1.0/4*GHPLs2[0*4+3]*HPLs1[1]
          - 1.0/8*GHPLs2[2*4+0]
          + 1.0/8*GHPLs1[0]*HPLs1[0]
          + 1.0/8*GHPLs1[0]*HPLs1[1]
          + 1.0/8*GHPLs2[2*4+1]
          - 1.0/8*GHPLs1[1]*HPLs1[0]
          - 1.0/8*GHPLs1[1]*HPLs1[1]
          - 1.0/8*HPLs2[0*2+0]
          - 1.0/8*HPLs2[0*2+1]
          )

       + (dN_c*dN_c-1)/(dN_c*dN_c)*u*pow(1-v,-2) * (
          - 9.0/16*zeta2
          + 3.0/8*zeta3
          + 7.0/8*GHPLs2[3*4+2]*HPLs1[0]
          - 7.0/8*GHPLs3[0*4*4+3*4+2]
          - 3.0/4*GHPLs1[2]*zeta2
          + 7.0/16*GHPLs1[2]*HPLs1[0]
          + 5.0/8*GHPLs1[2]*HPLs2[0*2+0]
          + 1.0/2*GHPLs1[2]*HPLs2[1*2+0]
          - 1.0/4*GHPLs1[2]*HPLs2[0*2+1]
          - 1.0/4*GHPLs2[0*4+2]*HPLs1[0]
          + 1.0/2*GHPLs3[2*4*4+1*4+2]
          - 1.0/2*GHPLs2[1*4+2]*HPLs1[0]
          - 1.0/2*GHPLs2[1*4+2]*HPLs1[1]
          + 3.0/8*GHPLs1[3]*HPLs1[0]
          - 3.0/8*GHPLs2[0*4+3]
          + 1.0/8*GHPLs2[2*4+0]*HPLs1[0]
          - 7.0/8*GHPLs2[3*4+0]*HPLs1[0]
          + 7.0/8*GHPLs3[0*4*4+3*4+0]
          + 5.0/8*GHPLs1[0]*zeta2
          - 5.0/8*GHPLs1[0]*HPLs1[0]
          - 5.0/8*GHPLs1[0]*HPLs2[0*2+0]
          - 5.0/8*GHPLs1[0]*HPLs2[1*2+0]
          - 1.0/2*GHPLs3[2*4*4+1*4+0]
          + 1.0/2*GHPLs2[1*4+0]*HPLs1[0]
          + 1.0/2*GHPLs2[1*4+0]*HPLs1[1]
          + 3.0/8*GHPLs2[2*4+1]
          - 3.0/8*GHPLs1[1]*HPLs1[0]
          - 3.0/8*GHPLs1[1]*HPLs1[1]
          + 27.0/32*HPLs1[0]
          - 11.0/4*HPLs1[0]*zeta2
          + 3.0/8*HPLs2[0*2+0]
          + 7.0/8*HPLs3[0*2*2+0*2+0]
          + 1.0/4*HPLs3[1*2*2+0*2+0]
          - 1.0/16*HPLs2[1*2+0]
          + 5.0/8*HPLs3[0*2*2+1*2+0]
          + 5.0/8*HPLs1[1]*zeta2
          - 5.0/8*HPLs2[0*2+1]
          - 5.0/8*HPLs3[0*2*2+0*2+1]
          - 5.0/8*HPLs3[1*2*2+0*2+1]
          )

       + (dN_c*dN_c-1)/(dN_c*dN_c)*u*pow(1-v,-1) * (
          + 17.0/32
          - 35.0/16*zeta2
          - 3.0/8*zeta3
          - 7.0/8*GHPLs2[3*4+2]*HPLs1[0]
          + 7.0/8*GHPLs3[0*4*4+3*4+2]
          + 5.0/16*GHPLs1[2]
          + 3.0/4*GHPLs1[2]*zeta2
          - 11.0/16*GHPLs1[2]*HPLs1[0]
          - 5.0/8*GHPLs1[2]*HPLs2[0*2+0]
          - 1.0/2*GHPLs1[2]*HPLs2[1*2+0]
          + 1.0/4*GHPLs1[2]*HPLs2[0*2+1]
          + 5.0/8*GHPLs2[0*4+2]
          + 1.0/4*GHPLs2[0*4+2]*HPLs1[0]
          - 1.0/2*GHPLs3[2*4*4+1*4+2]
          + 1.0/2*GHPLs2[1*4+2]*HPLs1[0]
          + 1.0/2*GHPLs2[1*4+2]*HPLs1[1]
          + 1.0/2*GHPLs1[3]*HPLs1[0]
          - 1.0/2*GHPLs2[0*4+3]
          + 5.0/8*GHPLs2[2*4+0]
          - 1.0/8*GHPLs2[2*4+0]*HPLs1[0]
          + 7.0/8*GHPLs2[3*4+0]*HPLs1[0]
          - 7.0/8*GHPLs3[0*4*4+3*4+0]
          - 5.0/8*GHPLs1[0]*zeta2
          - 1.0/2*GHPLs1[0]*HPLs1[0]
          + 5.0/8*GHPLs1[0]*HPLs2[0*2+0]
          + 5.0/8*GHPLs1[0]*HPLs2[1*2+0]
          - 5.0/8*GHPLs1[0]*HPLs1[1]
          + 1.0/2*GHPLs3[2*4*4+1*4+0]
          - 1.0/2*GHPLs2[1*4+0]*HPLs1[0]
          - 1.0/2*GHPLs2[1*4+0]*HPLs1[1]
          - 7.0/8*GHPLs2[2*4+1]
          + 7.0/8*GHPLs1[1]*HPLs1[0]
          + 7.0/8*GHPLs1[1]*HPLs1[1]
          - 39.0/32*HPLs1[0]
          + 11.0/4*HPLs1[0]*zeta2
          + 1.0/2*HPLs2[0*2+0]
          - 7.0/8*HPLs3[0*2*2+0*2+0]
          - 1.0/4*HPLs3[1*2*2+0*2+0]
          - 3.0/16*HPLs2[1*2+0]
          - 5.0/8*HPLs3[0*2*2+1*2+0]
          - 5.0/16*HPLs1[1]
          - 5.0/8*HPLs1[1]*zeta2
          + 3.0/4*HPLs2[0*2+1]
          + 5.0/8*HPLs3[0*2*2+0*2+1]
          + 5.0/8*HPLs3[1*2*2+0*2+1]
          )

       + (dN_c*dN_c-1)/(dN_c*dN_c)*u * (
          + 5*zeta2
          - 3.0/8*GHPLs1[2]
          + GHPLs1[2]*HPLs1[0]
          - 5.0/4*GHPLs2[0*4+2]
          - 5.0/4*GHPLs1[3]*HPLs1[0]
          + 5.0/4*GHPLs2[0*4+3]
          - 5.0/4*GHPLs2[2*4+0]
          + 3.0/2*GHPLs1[0]*HPLs1[0]
          + 5.0/4*GHPLs1[0]*HPLs1[1]
          + 5.0/4*GHPLs2[2*4+1]
          - 5.0/4*GHPLs1[1]*HPLs1[0]
          - 5.0/4*GHPLs1[1]*HPLs1[1]
          + 3.0/8*HPLs1[0]
          - 5.0/4*HPLs2[0*2+0]
          + 1.0/4*HPLs2[1*2+0]
          + 3.0/8*HPLs1[1]
          - HPLs2[0*2+1]
          )

       + (dN_c*dN_c-1)/(dN_c*dN_c)*u*v * (
          + 3.0/2*zeta2
          + 1.0/8*GHPLs1[2]*zeta2
          + 3.0/8*GHPLs1[2]*HPLs1[0]
          + 1.0/8*GHPLs1[2]*HPLs2[0*2+0]
          - 1.0/8*GHPLs1[2]*HPLs2[1*2+0]
          - 3.0/8*GHPLs2[0*4+2]
          - 1.0/8*GHPLs2[0*4+2]*HPLs1[0]
          - 1.0/8*GHPLs3[2*4*4+1*4+2]
          + 1.0/8*GHPLs2[1*4+2]*HPLs1[0]
          + 1.0/8*GHPLs2[1*4+2]*HPLs1[1]
          - 1.0/8*GHPLs2[2*4+3]*HPLs1[0]
          + 1.0/8*GHPLs3[0*4*4+2*4+3]
          + 1.0/8*GHPLs2[3*4+3]*HPLs1[0]
          - 1.0/8*GHPLs3[0*4*4+3*4+3]
          - 5.0/8*GHPLs1[3]*zeta2
          - 3.0/8*GHPLs1[3]*HPLs1[0]
          + 1.0/8*GHPLs1[3]*HPLs2[1*2+0]
          + 1.0/8*GHPLs1[3]*HPLs2[0*2+1]
          + 1.0/8*GHPLs3[2*4*4+0*4+3]
          + 3.0/8*GHPLs2[0*4+3]
          - 1.0/8*GHPLs2[0*4+3]*HPLs1[1]
          - 3.0/8*GHPLs2[2*4+0]
          + 1.0/8*GHPLs2[2*4+0]*HPLs1[0]
          - 1.0/4*GHPLs1[0]*zeta2
          + 3.0/8*GHPLs1[0]*HPLs1[0]
          - 1.0/8*GHPLs1[0]*HPLs2[0*2+0]
          + 3.0/8*GHPLs1[0]*HPLs1[1]
          - 1.0/8*GHPLs1[0]*HPLs2[0*2+1]
          + 1.0/8*GHPLs3[2*4*4+1*4+0]
          - 1.0/8*GHPLs2[1*4+0]*HPLs1[0]
          - 1.0/8*GHPLs2[1*4+0]*HPLs1[1]
          + 3.0/8*GHPLs2[2*4+1]
          - 1.0/8*GHPLs2[2*4+1]*HPLs1[0]
          + 1.0/4*GHPLs1[1]*zeta2
          - 3.0/8*GHPLs1[1]*HPLs1[0]
          + 1.0/8*GHPLs1[1]*HPLs2[0*2+0]
          - 3.0/8*GHPLs1[1]*HPLs1[1]
          + 1.0/8*GHPLs1[1]*HPLs2[0*2+1]
          - 1.0/8*GHPLs3[2*4*4+1*4+1]
          + 1.0/8*GHPLs2[1*4+1]*HPLs1[0]
          + 1.0/8*GHPLs2[1*4+1]*HPLs1[1]
          - 1.0/8*HPLs1[0]*zeta2
          - 3.0/8*HPLs2[0*2+0]
          - 1.0/8*HPLs3[0*2*2+0*2+0]
          - 1.0/8*HPLs3[1*2*2+0*2+0]
          - 1.0/4*HPLs3[0*2*2+1*2+0]
          - 1.0/8*HPLs1[1]*zeta2
          - 3.0/8*HPLs2[0*2+1]
          - 1.0/8*HPLs3[0*2*2+0*2+1]
          - 1.0/8*HPLs3[1*2*2+0*2+1]
          - 1.0/4*HPLs3[0*2*2+1*2+1]
          )

       + (dN_c*dN_c-1)/(dN_c*dN_c)*pow(u,2)*pow(1-v,-3) * (
          - 9.0/4*zeta2
          - 3.0/4*zeta3
          - 3.0/4*GHPLs2[3*4+2]*HPLs1[0]
          + 3.0/4*GHPLs3[0*4*4+3*4+2]
          + 3.0/4*GHPLs1[2]*zeta2
          - 3.0/4*GHPLs1[2]*HPLs2[0*2+0]
          - 3.0/4*GHPLs1[2]*HPLs2[1*2+0]
          - 3.0/4*GHPLs3[2*4*4+1*4+2]
          + 3.0/4*GHPLs2[1*4+2]*HPLs1[0]
          + 3.0/4*GHPLs2[1*4+2]*HPLs1[1]
          + 9.0/4*GHPLs1[3]*HPLs1[0]
          - 9.0/4*GHPLs2[0*4+3]
          + 3.0/4*GHPLs2[3*4+0]*HPLs1[0]
          - 3.0/4*GHPLs3[0*4*4+3*4+0]
          - 3.0/4*GHPLs1[0]*zeta2
          + 3.0/4*GHPLs1[0]*HPLs2[0*2+0]
          + 3.0/4*GHPLs1[0]*HPLs2[1*2+0]
          + 3.0/4*GHPLs3[2*4*4+1*4+0]
          - 3.0/4*GHPLs2[1*4+0]*HPLs1[0]
          - 3.0/4*GHPLs2[1*4+0]*HPLs1[1]
          + 9.0/4*GHPLs2[2*4+1]
          - 9.0/4*GHPLs1[1]*HPLs1[0]
          - 9.0/4*GHPLs1[1]*HPLs1[1]
          + 3*HPLs1[0]*zeta2
          + 9.0/4*HPLs2[0*2+0]
          - 3.0/4*HPLs3[0*2*2+0*2+0]
          + 9.0/4*HPLs2[1*2+0]
          - 3.0/4*HPLs3[0*2*2+1*2+0]
          - 3.0/4*HPLs1[1]*zeta2
          + 3.0/4*HPLs3[0*2*2+0*2+1]
          + 3.0/4*HPLs3[1*2*2+0*2+1]
          )

       + (dN_c*dN_c-1)/(dN_c*dN_c)*pow(u,2)*pow(1-v,-2) * (
          + 21.0/4*zeta2
          + 3.0/4*zeta3
          + 3.0/4*GHPLs2[3*4+2]*HPLs1[0]
          - 3.0/4*GHPLs3[0*4*4+3*4+2]
          - 9.0/8*GHPLs1[2]
          - 3.0/4*GHPLs1[2]*zeta2
          + 3.0/4*GHPLs1[2]*HPLs1[0]
          + 3.0/4*GHPLs1[2]*HPLs2[0*2+0]
          + 3.0/4*GHPLs1[2]*HPLs2[1*2+0]
          - 3.0/4*GHPLs2[0*4+2]
          + 3.0/4*GHPLs3[2*4*4+1*4+2]
          - 3.0/4*GHPLs2[1*4+2]*HPLs1[0]
          - 3.0/4*GHPLs2[1*4+2]*HPLs1[1]
          - 3*GHPLs1[3]*HPLs1[0]
          + 3*GHPLs2[0*4+3]
          - 3.0/4*GHPLs2[2*4+0]
          - 3.0/4*GHPLs2[3*4+0]*HPLs1[0]
          + 3.0/4*GHPLs3[0*4*4+3*4+0]
          + 9.0/8*GHPLs1[0]
          + 3.0/4*GHPLs1[0]*zeta2
          + 3.0/4*GHPLs1[0]*HPLs1[0]
          - 3.0/4*GHPLs1[0]*HPLs2[0*2+0]
          - 3.0/4*GHPLs1[0]*HPLs2[1*2+0]
          + 3.0/4*GHPLs1[0]*HPLs1[1]
          - 3.0/4*GHPLs3[2*4*4+1*4+0]
          + 3.0/4*GHPLs2[1*4+0]*HPLs1[0]
          + 3.0/4*GHPLs2[1*4+0]*HPLs1[1]
          - 3.0/2*GHPLs2[2*4+1]
          + 3.0/2*GHPLs1[1]*HPLs1[0]
          + 3.0/2*GHPLs1[1]*HPLs1[1]
          - 3*HPLs1[0]*zeta2
          - 3*HPLs2[0*2+0]
          + 3.0/4*HPLs3[0*2*2+0*2+0]
          - 9.0/4*HPLs2[1*2+0]
          + 3.0/4*HPLs3[0*2*2+1*2+0]
          + 9.0/8*HPLs1[1]
          + 3.0/4*HPLs1[1]*zeta2
          - 3.0/4*HPLs2[0*2+1]
          - 3.0/4*HPLs3[0*2*2+0*2+1]
          - 3.0/4*HPLs3[1*2*2+0*2+1]
          )

       + (dN_c*dN_c-1)/(dN_c*dN_c)*pow(u,2)*pow(1-v,-1) * (
          - 3.0/2*zeta2
          + 3.0/8*GHPLs1[2]
          - 3.0/8*GHPLs1[2]*HPLs1[0]
          + 3.0/8*GHPLs2[0*4+2]
          + 3.0/8*GHPLs1[3]*HPLs1[0]
          - 3.0/8*GHPLs2[0*4+3]
          + 3.0/8*GHPLs2[2*4+0]
          - 3.0/8*GHPLs1[0]
          - 3.0/8*GHPLs1[0]*HPLs1[0]
          - 3.0/8*GHPLs1[0]*HPLs1[1]
          - 3.0/8*GHPLs2[2*4+1]
          + 3.0/8*GHPLs1[1]*HPLs1[0]
          + 3.0/8*GHPLs1[1]*HPLs1[1]
          + 3.0/8*HPLs2[0*2+0]
          - 3.0/8*HPLs1[1]
          + 3.0/8*HPLs2[0*2+1]
          )

       + (dN_c*dN_c-1)/(dN_c*dN_c)*pow(u,2) * (
          - 1.0/2*zeta2
          - 1.0/8*GHPLs1[2]*HPLs1[0]
          + 1.0/8*GHPLs2[0*4+2]
          + 1.0/8*GHPLs1[3]*HPLs1[0]
          - 1.0/8*GHPLs2[0*4+3]
          + 1.0/8*GHPLs2[2*4+0]
          - 1.0/8*GHPLs1[0]*HPLs1[0]
          - 1.0/8*GHPLs1[0]*HPLs1[1]
          - 1.0/8*GHPLs2[2*4+1]
          + 1.0/8*GHPLs1[1]*HPLs1[0]
          + 1.0/8*GHPLs1[1]*HPLs1[1]
          + 1.0/8*HPLs2[0*2+0]
          + 1.0/8*HPLs2[0*2+1]
          )

       + (dN_c*dN_c-1)/(dN_c*dN_c)*pow(u,3)*pow(1-v,-4) * (
          + 9.0/4*zeta3
          + 9.0/4*GHPLs2[3*4+2]*HPLs1[0]
          - 9.0/4*GHPLs3[0*4*4+3*4+2]
          - 9.0/4*GHPLs1[2]*zeta2
          + 9.0/4*GHPLs1[2]*HPLs2[0*2+0]
          + 9.0/4*GHPLs1[2]*HPLs2[1*2+0]
          + 9.0/4*GHPLs3[2*4*4+1*4+2]
          - 9.0/4*GHPLs2[1*4+2]*HPLs1[0]
          - 9.0/4*GHPLs2[1*4+2]*HPLs1[1]
          - 9.0/4*GHPLs2[3*4+0]*HPLs1[0]
          + 9.0/4*GHPLs3[0*4*4+3*4+0]
          + 9.0/4*GHPLs1[0]*zeta2
          - 9.0/4*GHPLs1[0]*HPLs2[0*2+0]
          - 9.0/4*GHPLs1[0]*HPLs2[1*2+0]
          - 9.0/4*GHPLs3[2*4*4+1*4+0]
          + 9.0/4*GHPLs2[1*4+0]*HPLs1[0]
          + 9.0/4*GHPLs2[1*4+0]*HPLs1[1]
          - 9*HPLs1[0]*zeta2
          + 9.0/4*HPLs3[0*2*2+0*2+0]
          + 9.0/4*HPLs3[0*2*2+1*2+0]
          + 9.0/4*HPLs1[1]*zeta2
          - 9.0/4*HPLs3[0*2*2+0*2+1]
          - 9.0/4*HPLs3[1*2*2+0*2+1]
          )

       + (dN_c*dN_c-1)/(dN_c*dN_c)*pow(u,3)*pow(1-v,-3) * (
          - 9*zeta2
          - 9.0/4*zeta3
          - 9.0/4*GHPLs2[3*4+2]*HPLs1[0]
          + 9.0/4*GHPLs3[0*4*4+3*4+2]
          + 9.0/4*GHPLs1[2]*zeta2
          - 9.0/4*GHPLs1[2]*HPLs1[0]
          - 9.0/4*GHPLs1[2]*HPLs2[0*2+0]
          - 9.0/4*GHPLs1[2]*HPLs2[1*2+0]
          + 9.0/4*GHPLs2[0*4+2]
          - 9.0/4*GHPLs3[2*4*4+1*4+2]
          + 9.0/4*GHPLs2[1*4+2]*HPLs1[0]
          + 9.0/4*GHPLs2[1*4+2]*HPLs1[1]
          + 9.0/4*GHPLs1[3]*HPLs1[0]
          - 9.0/4*GHPLs2[0*4+3]
          + 9.0/4*GHPLs2[2*4+0]
          + 9.0/4*GHPLs2[3*4+0]*HPLs1[0]
          - 9.0/4*GHPLs3[0*4*4+3*4+0]
          - 9.0/4*GHPLs1[0]*zeta2
          - 9.0/4*GHPLs1[0]*HPLs1[0]
          + 9.0/4*GHPLs1[0]*HPLs2[0*2+0]
          + 9.0/4*GHPLs1[0]*HPLs2[1*2+0]
          - 9.0/4*GHPLs1[0]*HPLs1[1]
          + 9.0/4*GHPLs3[2*4*4+1*4+0]
          - 9.0/4*GHPLs2[1*4+0]*HPLs1[0]
          - 9.0/4*GHPLs2[1*4+0]*HPLs1[1]
          - 9.0/4*GHPLs2[2*4+1]
          + 9.0/4*GHPLs1[1]*HPLs1[0]
          + 9.0/4*GHPLs1[1]*HPLs1[1]
          + 9*HPLs1[0]*zeta2
          + 9.0/4*HPLs2[0*2+0]
          - 9.0/4*HPLs3[0*2*2+0*2+0]
          - 9.0/4*HPLs3[0*2*2+1*2+0]
          - 9.0/4*HPLs1[1]*zeta2
          + 9.0/4*HPLs2[0*2+1]
          + 9.0/4*HPLs3[0*2*2+0*2+1]
          + 9.0/4*HPLs3[1*2*2+0*2+1]
          )

       + (dN_c*dN_c-1)/(dN_c*dN_c)*pow(u,3)*pow(1-v,-2) * (
          + 9.0/2*zeta2
          + 9.0/8*GHPLs1[2]*HPLs1[0]
          - 9.0/8*GHPLs2[0*4+2]
          - 9.0/8*GHPLs1[3]*HPLs1[0]
          + 9.0/8*GHPLs2[0*4+3]
          - 9.0/8*GHPLs2[2*4+0]
          + 9.0/8*GHPLs1[0]*HPLs1[0]
          + 9.0/8*GHPLs1[0]*HPLs1[1]
          + 9.0/8*GHPLs2[2*4+1]
          - 9.0/8*GHPLs1[1]*HPLs1[0]
          - 9.0/8*GHPLs1[1]*HPLs1[1]
          - 9.0/8*HPLs2[0*2+0]
          - 9.0/8*HPLs2[0*2+1]
          )

       + (dN_c*dN_c-1)/(dN_c*dN_c)*pow(u,3)*pow(1-v,-1) * (
          + 3.0/2*zeta2
          + 3.0/8*GHPLs1[2]*HPLs1[0]
          - 3.0/8*GHPLs2[0*4+2]
          - 3.0/8*GHPLs1[3]*HPLs1[0]
          + 3.0/8*GHPLs2[0*4+3]
          - 3.0/8*GHPLs2[2*4+0]
          + 3.0/8*GHPLs1[0]*HPLs1[0]
          + 3.0/8*GHPLs1[0]*HPLs1[1]
          + 3.0/8*GHPLs2[2*4+1]
          - 3.0/8*GHPLs1[1]*HPLs1[0]
          - 3.0/8*GHPLs1[1]*HPLs1[1]
          - 3.0/8*HPLs2[0*2+0]
          - 3.0/8*HPLs2[0*2+1]
          )

       + (dN_c*dN_c-1)/(dN_c*dN_c)*double_complex(0,1)*M_PI*pow(u,-2)*pow(1-u-v,-1) * (
          + 1.0/8*GHPLs2[2*4+3]
          + 1.0/8*GHPLs2[3*4+3]
          - 1.0/8*GHPLs1[3]*HPLs1[0]
          - 1.0/8*GHPLs1[3]*HPLs1[1]
          + 1.0/8*GHPLs2[0*4+3]
          + 1.0/8*GHPLs2[2*4+1]
          - 1.0/4*GHPLs1[1]*HPLs1[0]
          - 1.0/8*GHPLs1[1]*HPLs1[1]
          + 1.0/8*GHPLs2[0*4+1]
          + 1.0/8*GHPLs2[1*4+1]
          )

       + (dN_c*dN_c-1)/(dN_c*dN_c)*double_complex(0,1)*M_PI*pow(u,-2) * (
          - 7.0/4*GHPLs3[3*4*4+2*4+2]
          - 7.0/4*GHPLs2[2*4+2]*HPLs1[0]
          + 5.0/4*GHPLs3[1*4*4+2*4+2]
          - 1.0/2*GHPLs3[3*4*4+3*4+2]
          + 5.0/2*GHPLs1[2]*zeta2
          - 9.0/8*GHPLs1[2]*HPLs1[0]
          - 7.0/4*GHPLs1[2]*HPLs2[0*2+0]
          - 5.0/4*GHPLs1[2]*HPLs2[1*2+0]
          + 5.0/4*GHPLs1[2]*HPLs2[0*2+1]
          + 7.0/4*GHPLs3[3*4*4+0*4+2]
          + 5.0/4*GHPLs2[0*4+2]*HPLs1[0]
          - 5.0/4*GHPLs3[1*4*4+0*4+2]
          + 3.0/8*GHPLs2[1*4+2]
          + 1.0/4*GHPLs2[1*4+2]*HPLs1[0]
          - 1.0/2*GHPLs3[1*4*4+1*4+2]
          - 1.0/8*GHPLs2[2*4+3]
          - 1.0/8*GHPLs2[3*4+3]
          + 1.0/8*GHPLs1[3]*HPLs1[0]
          + 1.0/8*GHPLs1[3]*HPLs1[1]
          - 1.0/8*GHPLs2[0*4+3]
          + 5.0/4*GHPLs3[2*4*4+2*4+1]
          - 5.0/4*GHPLs3[3*4*4+2*4+1]
          - 7.0/8*GHPLs2[2*4+1]
          - 3.0/2*GHPLs2[2*4+1]*HPLs1[0]
          - 5.0/4*GHPLs2[2*4+1]*HPLs1[1]
          + 5.0/4*GHPLs3[0*4*4+2*4+1]
          - 3.0/2*GHPLs3[1*4*4+2*4+1]
          + 11.0/16*GHPLs1[1]
          - 9.0/4*GHPLs1[1]*zeta2
          + 11.0/8*GHPLs1[1]*HPLs1[0]
          + 7.0/4*GHPLs1[1]*HPLs2[0*2+0]
          + 5.0/4*GHPLs1[1]*HPLs2[1*2+0]
          + 7.0/8*GHPLs1[1]*HPLs1[1]
          + 3.0/2*GHPLs1[1]*HPLs2[0*2+1]
          + 5.0/4*GHPLs1[1]*HPLs2[1*2+1]
          + 5.0/4*GHPLs3[2*4*4+0*4+1]
          - 5.0/4*GHPLs3[3*4*4+0*4+1]
          - 7.0/8*GHPLs2[0*4+1]
          - 5.0/4*GHPLs2[0*4+1]*HPLs1[0]
          - 5.0/4*GHPLs2[0*4+1]*HPLs1[1]
          + 1.0/4*GHPLs3[1*4*4+0*4+1]
          - 1.0/2*GHPLs3[2*4*4+1*4+1]
          - 1.0/2*GHPLs2[1*4+1]
          + 1.0/2*GHPLs2[1*4+1]*HPLs1[1]
          + 5.0/4*GHPLs3[0*4*4+1*4+1]
          - 3.0/4*GHPLs3[1*4*4+1*4+1]
          )

       + (dN_c*dN_c-1)/(dN_c*dN_c)*double_complex(0,1)*M_PI*pow(u,-2)*v * (
          + 7.0/4*GHPLs3[3*4*4+2*4+2]
          + 7.0/4*GHPLs2[2*4+2]*HPLs1[0]
          - 5.0/4*GHPLs3[1*4*4+2*4+2]
          + 1.0/2*GHPLs3[3*4*4+3*4+2]
          - 5.0/2*GHPLs1[2]*zeta2
          + 9.0/8*GHPLs1[2]*HPLs1[0]
          + 7.0/4*GHPLs1[2]*HPLs2[0*2+0]
          + 5.0/4*GHPLs1[2]*HPLs2[1*2+0]
          - 5.0/4*GHPLs1[2]*HPLs2[0*2+1]
          - 7.0/4*GHPLs3[3*4*4+0*4+2]
          - 5.0/4*GHPLs2[0*4+2]*HPLs1[0]
          + 5.0/4*GHPLs3[1*4*4+0*4+2]
          - 5.0/8*GHPLs2[1*4+2]
          - 1.0/4*GHPLs2[1*4+2]*HPLs1[0]
          + 1.0/2*GHPLs3[1*4*4+1*4+2]
          - 1.0/8*GHPLs2[2*4+3]
          - 5.0/8*GHPLs2[3*4+3]
          + 1.0/8*GHPLs1[3]*HPLs1[0]
          + 1.0/8*GHPLs1[3]*HPLs1[1]
          - 1.0/8*GHPLs2[0*4+3]
          - 5.0/4*GHPLs3[2*4*4+2*4+1]
          + 5.0/4*GHPLs3[3*4*4+2*4+1]
          + 3.0/8*GHPLs2[2*4+1]
          + 3.0/2*GHPLs2[2*4+1]*HPLs1[0]
          + 5.0/4*GHPLs2[2*4+1]*HPLs1[1]
          - 5.0/4*GHPLs3[0*4*4+2*4+1]
          + 3.0/2*GHPLs3[1*4*4+2*4+1]
          - 15.0/16*GHPLs1[1]
          + 9.0/4*GHPLs1[1]*zeta2
          - 3.0/8*GHPLs1[1]*HPLs1[0]
          - 7.0/4*GHPLs1[1]*HPLs2[0*2+0]
          - 5.0/4*GHPLs1[1]*HPLs2[1*2+0]
          - 3.0/8*GHPLs1[1]*HPLs1[1]
          - 3.0/2*GHPLs1[1]*HPLs2[0*2+1]
          - 5.0/4*GHPLs1[1]*HPLs2[1*2+1]
          - 5.0/4*GHPLs3[2*4*4+0*4+1]
          + 5.0/4*GHPLs3[3*4*4+0*4+1]
          + 3.0/8*GHPLs2[0*4+1]
          + 5.0/4*GHPLs2[0*4+1]*HPLs1[0]
          + 5.0/4*GHPLs2[0*4+1]*HPLs1[1]
          - 1.0/4*GHPLs3[1*4*4+0*4+1]
          + 1.0/2*GHPLs3[2*4*4+1*4+1]
          - 1.0/2*GHPLs2[1*4+1]*HPLs1[1]
          - 5.0/4*GHPLs3[0*4*4+1*4+1]
          + 3.0/4*GHPLs3[1*4*4+1*4+1]
          )

       + (dN_c*dN_c-1)/(dN_c*dN_c)*double_complex(0,1)*M_PI*pow(u,-2)*pow(v,2) * (
          + 1.0/8*GHPLs2[1*4+2]
          - 1.0/8*GHPLs2[2*4+3]
          + 1.0/8*GHPLs2[3*4+3]
          + 1.0/8*GHPLs1[3]*HPLs1[0]
          + 1.0/8*GHPLs1[3]*HPLs1[1]
          - 1.0/8*GHPLs2[0*4+3]
          + 1.0/8*GHPLs1[1]
          )

       + (dN_c*dN_c-1)/(dN_c*dN_c)*double_complex(0,1)*M_PI*pow(u,-2)*pow(v,3) * (
          + 1.0/8*GHPLs2[1*4+2]
          - 1.0/8*GHPLs2[2*4+3]
          + 1.0/8*GHPLs2[3*4+3]
          + 1.0/8*GHPLs1[3]*HPLs1[0]
          + 1.0/8*GHPLs1[3]*HPLs1[1]
          - 1.0/8*GHPLs2[0*4+3]
          )

       + (dN_c*dN_c-1)/(dN_c*dN_c)*double_complex(0,1)*M_PI*pow(u,-1)*pow(1-u-v,-1) * (
          - 5.0/8*GHPLs2[2*4+3]
          - 5.0/8*GHPLs2[3*4+3]
          - 1.0/8*GHPLs1[3]
          + 5.0/8*GHPLs1[3]*HPLs1[0]
          + 5.0/8*GHPLs1[3]*HPLs1[1]
          - 5.0/8*GHPLs2[0*4+3]
          - 5.0/8*GHPLs2[2*4+1]
          + 5.0/4*GHPLs1[1]*HPLs1[0]
          + 5.0/8*GHPLs1[1]*HPLs1[1]
          - 5.0/8*GHPLs2[0*4+1]
          - 5.0/8*GHPLs2[1*4+1]
          - 1.0/8*HPLs1[0]
          )

       + (dN_c*dN_c-1)/(dN_c*dN_c)*double_complex(0,1)*M_PI*pow(u,-1) * (
          + 23.0/16
          + 1.0/4*zeta2
          + 3.0/2*GHPLs3[3*4*4+2*4+2]
          + 5.0/4*GHPLs2[2*4+2]
          + 3.0/2*GHPLs2[2*4+2]*HPLs1[0]
          - 3.0/2*GHPLs3[1*4*4+2*4+2]
          - 3*GHPLs2[3*4+2]
          - 2*GHPLs1[2]
          - 3*GHPLs1[2]*zeta2
          - 3*GHPLs1[2]*HPLs1[0]
          + 3.0/2*GHPLs1[2]*HPLs2[0*2+0]
          + 3.0/2*GHPLs1[2]*HPLs2[1*2+0]
          - 5.0/4*GHPLs1[2]*HPLs1[1]
          - 3.0/2*GHPLs1[2]*HPLs2[0*2+1]
          - 3.0/2*GHPLs3[3*4*4+0*4+2]
          + 5.0/4*GHPLs2[0*4+2]
          - 3.0/2*GHPLs2[0*4+2]*HPLs1[0]
          + 3.0/2*GHPLs3[1*4*4+0*4+2]
          - 1.0/4*GHPLs2[1*4+2]
          + 1.0/2*GHPLs2[2*4+3]
          + 1.0/8*GHPLs1[3]
          - 1.0/2*GHPLs1[3]*HPLs1[0]
          - 1.0/2*GHPLs1[3]*HPLs1[1]
          + 1.0/2*GHPLs2[0*4+3]
          + 5.0/4*GHPLs2[2*4+0]
          + 1.0/2*GHPLs2[3*4+0]
          - 3.0/4*GHPLs1[0]
          - 5.0/4*GHPLs1[0]*HPLs1[1]
          - GHPLs2[1*4+0]
          - 3.0/2*GHPLs3[2*4*4+2*4+1]
          + 3.0/2*GHPLs3[3*4*4+2*4+1]
          + 1.0/4*GHPLs2[2*4+1]
          + 3.0/2*GHPLs2[2*4+1]*HPLs1[0]
          + 3.0/2*GHPLs2[2*4+1]*HPLs1[1]
          - 3.0/2*GHPLs3[0*4*4+2*4+1]
          + 3.0/2*GHPLs3[1*4*4+2*4+1]
          + 13.0/8*GHPLs1[1]
          + 3*GHPLs1[1]*zeta2
          - GHPLs1[1]*HPLs1[0]
          - 3.0/2*GHPLs1[1]*HPLs2[0*2+0]
          - 3.0/2*GHPLs1[1]*HPLs2[1*2+0]
          - 1.0/4*GHPLs1[1]*HPLs1[1]
          - 3.0/2*GHPLs1[1]*HPLs2[0*2+1]
          - 3.0/2*GHPLs1[1]*HPLs2[1*2+1]
          - 3.0/2*GHPLs3[2*4*4+0*4+1]
          + 3.0/2*GHPLs3[3*4*4+0*4+1]
          + 7.0/4*GHPLs2[0*4+1]
          + 3.0/2*GHPLs2[0*4+1]*HPLs1[0]
          + 3.0/2*GHPLs2[0*4+1]*HPLs1[1]
          - 1.0/2*GHPLs2[1*4+1]
          - 3.0/2*GHPLs3[0*4*4+1*4+1]
          + 3.0/2*GHPLs3[1*4*4+1*4+1]
          + 1.0/8*HPLs1[0]
          + 2*HPLs1[1]
          + 11.0/4*HPLs2[0*2+1]
          + 5.0/4*HPLs2[1*2+1]
          )

       + (dN_c*dN_c-1)/(dN_c*dN_c)*double_complex(0,1)*M_PI*pow(u,-1)*v * (
          - 23.0/16
          + 9.0/4*zeta2
          - 7.0/4*GHPLs3[3*4*4+2*4+2]
          - 5.0/4*GHPLs2[2*4+2]
          - 7.0/4*GHPLs2[2*4+2]*HPLs1[0]
          + 5.0/4*GHPLs3[1*4*4+2*4+2]
          - 1.0/2*GHPLs3[3*4*4+3*4+2]
          + 5.0/4*GHPLs2[3*4+2]
          + 7.0/4*GHPLs1[2]
          + 5.0/2*GHPLs1[2]*zeta2
          + 3.0/8*GHPLs1[2]*HPLs1[0]
          - 7.0/4*GHPLs1[2]*HPLs2[0*2+0]
          - 5.0/4*GHPLs1[2]*HPLs2[1*2+0]
          + 5.0/4*GHPLs1[2]*HPLs1[1]
          + 5.0/4*GHPLs1[2]*HPLs2[0*2+1]
          + 7.0/4*GHPLs3[3*4*4+0*4+2]
          - 5.0/4*GHPLs2[0*4+2]
          + 5.0/4*GHPLs2[0*4+2]*HPLs1[0]
          - 5.0/4*GHPLs3[1*4*4+0*4+2]
          + 15.0/8*GHPLs2[1*4+2]
          + 1.0/4*GHPLs2[1*4+2]*HPLs1[0]
          - 1.0/2*GHPLs3[1*4*4+1*4+2]
          + 3.0/8*GHPLs2[2*4+3]
          + 3.0/8*GHPLs2[3*4+3]
          - 11.0/8*GHPLs1[3]
          - 3.0/8*GHPLs1[3]*HPLs1[0]
          - 3.0/8*GHPLs1[3]*HPLs1[1]
          + 3.0/8*GHPLs2[0*4+3]
          - 5.0/4*GHPLs2[2*4+0]
          + 5.0/4*GHPLs2[3*4+0]
          + 1.0/2*GHPLs1[0]
          + 5.0/4*GHPLs1[0]*HPLs1[0]
          + 5.0/4*GHPLs1[0]*HPLs1[1]
          - 1.0/2*GHPLs2[1*4+0]
          + 5.0/4*GHPLs3[2*4*4+2*4+1]
          - 5.0/4*GHPLs3[3*4*4+2*4+1]
          + 1.0/8*GHPLs2[2*4+1]
          - 3.0/2*GHPLs2[2*4+1]*HPLs1[0]
          - 5.0/4*GHPLs2[2*4+1]*HPLs1[1]
          + 5.0/4*GHPLs3[0*4*4+2*4+1]
          - 3.0/2*GHPLs3[1*4*4+2*4+1]
          + 17.0/16*GHPLs1[1]
          - 9.0/4*GHPLs1[1]*zeta2
          + 3.0/8*GHPLs1[1]*HPLs1[0]
          + 7.0/4*GHPLs1[1]*HPLs2[0*2+0]
          + 5.0/4*GHPLs1[1]*HPLs2[1*2+0]
          - 1.0/8*GHPLs1[1]*HPLs1[1]
          + 3.0/2*GHPLs1[1]*HPLs2[0*2+1]
          + 5.0/4*GHPLs1[1]*HPLs2[1*2+1]
          + 5.0/4*GHPLs3[2*4*4+0*4+1]
          - 5.0/4*GHPLs3[3*4*4+0*4+1]
          - 11.0/8*GHPLs2[0*4+1]
          - 5.0/4*GHPLs2[0*4+1]*HPLs1[0]
          - 5.0/4*GHPLs2[0*4+1]*HPLs1[1]
          + 1.0/4*GHPLs3[1*4*4+0*4+1]
          - 1.0/2*GHPLs3[2*4*4+1*4+1]
          + 3.0/4*GHPLs2[1*4+1]
          + 1.0/2*GHPLs2[1*4+1]*HPLs1[1]
          + 5.0/4*GHPLs3[0*4*4+1*4+1]
          - 3.0/4*GHPLs3[1*4*4+1*4+1]
          - 7.0/4*HPLs1[0]
          - 7.0/4*HPLs2[0*2+0]
          - 5.0/4*HPLs2[1*2+0]
          - 7.0/4*HPLs1[1]
          - 3.0/2*HPLs2[0*2+1]
          - 5.0/4*HPLs2[1*2+1]
          )

       + (dN_c*dN_c-1)/(dN_c*dN_c)*double_complex(0,1)*M_PI*pow(u,-1)*pow(v,2) * (
          + 1.0/8*GHPLs1[2]
          - 1.0/8*GHPLs1[3]
          + 1.0/8*GHPLs1[0]
          - 1.0/4*GHPLs1[1]
          - 1.0/8*HPLs1[0]
          - 1.0/8*HPLs1[1]
          )

       + (dN_c*dN_c-1)/(dN_c*dN_c)*double_complex(0,1)*M_PI*pow(u,-1)*pow(v,3) * (
          - 1.0/8*GHPLs2[1*4+2]
          + 1.0/8*GHPLs2[2*4+3]
          - 1.0/8*GHPLs2[3*4+3]
          - 1.0/8*GHPLs1[3]*HPLs1[0]
          - 1.0/8*GHPLs1[3]*HPLs1[1]
          + 1.0/8*GHPLs2[0*4+3]
          )

       + (dN_c*dN_c-1)/(dN_c*dN_c)*double_complex(0,1)*M_PI*pow(1-v,-1) * (
          + 3.0/4*zeta2
          - 9.0/8*GHPLs2[3*4+2]
          - 3.0/4*GHPLs1[2]*HPLs1[0]
          - 5.0/4*GHPLs1[3]
          + 9.0/8*GHPLs2[3*4+0]
          + 3.0/8*GHPLs1[0]*HPLs1[0]
          + 7.0/8*GHPLs1[1]
          - 33.0/16*HPLs1[0]
          - 9.0/8*HPLs2[0*2+0]
          - 3.0/8*HPLs2[1*2+0]
          + 3.0/8*HPLs2[0*2+1]
          )

       + (dN_c*dN_c-1)/(dN_c*dN_c)*double_complex(0,1)*M_PI*pow(1-u-v,-1) * (
          + 1.0/2*GHPLs2[2*4+3]
          + 1.0/2*GHPLs2[3*4+3]
          + 1.0/4*GHPLs1[3]
          - 1.0/2*GHPLs1[3]*HPLs1[0]
          - 1.0/2*GHPLs1[3]*HPLs1[1]
          + 1.0/2*GHPLs2[0*4+3]
          + 1.0/2*GHPLs2[2*4+1]
          - GHPLs1[1]*HPLs1[0]
          - 1.0/2*GHPLs1[1]*HPLs1[1]
          + 1.0/2*GHPLs2[0*4+1]
          + 1.0/2*GHPLs2[1*4+1]
          + 1.0/4*HPLs1[0]
          )

       + (dN_c*dN_c-1)/(dN_c*dN_c)*double_complex(0,1)*M_PI * (
          + 25.0/32
          - 5.0/8*zeta2
          - 1.0/4*GHPLs3[3*4*4+2*4+2]
          - 7.0/8*GHPLs2[2*4+2]
          - 1.0/4*GHPLs2[2*4+2]*HPLs1[0]
          + 1.0/4*GHPLs3[1*4*4+2*4+2]
          + 21.0/8*GHPLs2[3*4+2]
          + 23.0/16*GHPLs1[2]
          + 1.0/2*GHPLs1[2]*zeta2
          + 9.0/4*GHPLs1[2]*HPLs1[0]
          - 1.0/4*GHPLs1[2]*HPLs2[0*2+0]
          - 1.0/4*GHPLs1[2]*HPLs2[1*2+0]
          + 7.0/8*GHPLs1[2]*HPLs1[1]
          + 1.0/4*GHPLs1[2]*HPLs2[0*2+1]
          + 1.0/4*GHPLs3[3*4*4+0*4+2]
          - 7.0/8*GHPLs2[0*4+2]
          + 1.0/4*GHPLs2[0*4+2]*HPLs1[0]
          - 1.0/4*GHPLs3[1*4*4+0*4+2]
          - 1.0/8*GHPLs2[1*4+2]
          - 1.0/4*GHPLs2[3*4+3]
          - 3.0/8*GHPLs1[3]
          - 7.0/8*GHPLs2[2*4+0]
          - 7.0/8*GHPLs2[3*4+0]
          + 7.0/8*GHPLs1[0]
          - 3.0/8*GHPLs1[0]*HPLs1[0]
          + 7.0/8*GHPLs1[0]*HPLs1[1]
          + GHPLs2[1*4+0]
          + 1.0/4*GHPLs3[2*4*4+2*4+1]
          - 1.0/4*GHPLs3[3*4*4+2*4+1]
          - 1.0/8*GHPLs2[2*4+1]
          - 1.0/4*GHPLs2[2*4+1]*HPLs1[0]
          - 1.0/4*GHPLs2[2*4+1]*HPLs1[1]
          + 1.0/4*GHPLs3[0*4*4+2*4+1]
          - 1.0/4*GHPLs3[1*4*4+2*4+1]
          - 41.0/16*GHPLs1[1]
          - 1.0/2*GHPLs1[1]*zeta2
          + 1.0/4*GHPLs1[1]*HPLs2[0*2+0]
          + 1.0/4*GHPLs1[1]*HPLs2[1*2+0]
          + 1.0/8*GHPLs1[1]*HPLs1[1]
          + 1.0/4*GHPLs1[1]*HPLs2[0*2+1]
          + 1.0/4*GHPLs1[1]*HPLs2[1*2+1]
          + 1.0/4*GHPLs3[2*4*4+0*4+1]
          - 1.0/4*GHPLs3[3*4*4+0*4+1]
          - 7.0/8*GHPLs2[0*4+1]
          - 1.0/4*GHPLs2[0*4+1]*HPLs1[0]
          - 1.0/4*GHPLs2[0*4+1]*HPLs1[1]
          + GHPLs2[1*4+1]
          + 1.0/4*GHPLs3[0*4*4+1*4+1]
          - 1.0/4*GHPLs3[1*4*4+1*4+1]
          + 7.0/16*HPLs1[0]
          + 9.0/8*HPLs2[0*2+0]
          + 3.0/8*HPLs2[1*2+0]
          - 23.0/16*HPLs1[1]
          - 2*HPLs2[0*2+1]
          - 7.0/8*HPLs2[1*2+1]
          )

       + (dN_c*dN_c-1)/(dN_c*dN_c)*double_complex(0,1)*M_PI*v*pow(1-u,-1) * (
          + 23.0/32
          + 1.0/8*GHPLs2[2*4+2]
          - 1.0/8*GHPLs2[3*4+2]
          + 1.0/16*GHPLs1[2]
          - 1.0/4*GHPLs1[2]*HPLs1[0]
          - 1.0/8*GHPLs1[2]*HPLs1[1]
          + 1.0/8*GHPLs2[0*4+2]
          - 1.0/4*GHPLs2[1*4+2]
          + 1.0/8*GHPLs2[2*4+0]
          - 1.0/8*GHPLs2[3*4+0]
          + 3.0/8*GHPLs1[0]
          - 1.0/8*GHPLs1[0]*HPLs1[0]
          - 1.0/8*GHPLs1[0]*HPLs1[1]
          + 1.0/8*GHPLs2[1*4+0]
          - 1.0/4*GHPLs2[2*4+1]
          - 7.0/16*GHPLs1[1]
          + 1.0/4*GHPLs1[1]*HPLs1[1]
          + 1.0/4*GHPLs2[1*4+1]
          + 3.0/16*HPLs1[0]
          + 3.0/8*HPLs2[0*2+0]
          + 1.0/8*HPLs2[1*2+0]
          - 1.0/16*HPLs1[1]
          + 1.0/4*HPLs2[0*2+1]
          + 1.0/8*HPLs2[1*2+1]
          )

       + (dN_c*dN_c-1)/(dN_c*dN_c)*double_complex(0,1)*M_PI*v * (
          - 9.0/8*zeta2
          + 1.0/2*GHPLs2[2*4+2]
          - 1.0/2*GHPLs2[3*4+2]
          - GHPLs1[2]
          - 1.0/2*GHPLs1[2]*HPLs1[0]
          - 1.0/2*GHPLs1[2]*HPLs1[1]
          + 1.0/2*GHPLs2[0*4+2]
          - 5.0/8*GHPLs2[1*4+2]
          + 1.0/8*GHPLs2[2*4+3]
          - 1.0/8*GHPLs2[3*4+3]
          + GHPLs1[3]
          - 1.0/8*GHPLs1[3]*HPLs1[0]
          - 1.0/8*GHPLs1[3]*HPLs1[1]
          + 1.0/8*GHPLs2[0*4+3]
          + 1.0/2*GHPLs2[2*4+0]
          - 1.0/2*GHPLs2[3*4+0]
          - GHPLs1[0]
          - 1.0/2*GHPLs1[0]*HPLs1[0]
          - 1.0/2*GHPLs1[0]*HPLs1[1]
          + 1.0/8*GHPLs2[1*4+0]
          + 3.0/4*GHPLs1[1]
          + 1.0/2*GHPLs2[0*4+1]
          - 5.0/8*GHPLs2[1*4+1]
          + HPLs1[0]
          + 1.0/2*HPLs2[0*2+0]
          + 1.0/2*HPLs2[1*2+0]
          + HPLs1[1]
          + 1.0/2*HPLs2[0*2+1]
          + 1.0/2*HPLs2[1*2+1]
          )

       + (dN_c*dN_c-1)/(dN_c*dN_c)*double_complex(0,1)*M_PI*pow(v,2) * (
          - 1.0/8*GHPLs1[2]
          - 1.0/4*GHPLs2[1*4+2]
          + 1.0/4*GHPLs2[2*4+3]
          - 1.0/4*GHPLs2[3*4+3]
          + 1.0/8*GHPLs1[3]
          - 1.0/4*GHPLs1[3]*HPLs1[0]
          - 1.0/4*GHPLs1[3]*HPLs1[1]
          + 1.0/4*GHPLs2[0*4+3]
          - 1.0/8*GHPLs1[0]
          + 1.0/8*GHPLs1[1]
          + 1.0/8*HPLs1[0]
          + 1.0/8*HPLs1[1]
          )

       + (dN_c*dN_c-1)/(dN_c*dN_c)*double_complex(0,1)*M_PI*u*pow(1-v,-2) * (
          + 5.0/4*zeta2
          - 7.0/8*GHPLs2[3*4+2]
          - 3.0/4*GHPLs1[2]*HPLs1[0]
          + 1.0/2*GHPLs2[1*4+2]
          - 3.0/8*GHPLs1[3]
          + 7.0/8*GHPLs2[3*4+0]
          + 5.0/8*GHPLs1[0]*HPLs1[0]
          - 1.0/2*GHPLs2[1*4+0]
          + 3.0/8*GHPLs1[1]
          - 9.0/16*HPLs1[0]
          - 7.0/8*HPLs2[0*2+0]
          - 5.0/8*HPLs2[1*2+0]
          + 5.0/8*HPLs2[0*2+1]
          )

       + (dN_c*dN_c-1)/(dN_c*dN_c)*double_complex(0,1)*M_PI*u*pow(1-v,-1) * (
          + 5.0/16
          - 5.0/4*zeta2
          + 7.0/8*GHPLs2[3*4+2]
          + 5.0/8*GHPLs1[2]
          + 3.0/4*GHPLs1[2]*HPLs1[0]
          - 1.0/2*GHPLs2[1*4+2]
          - 1.0/2*GHPLs1[3]
          - 7.0/8*GHPLs2[3*4+0]
          + 5.0/8*GHPLs1[0]
          - 5.0/8*GHPLs1[0]*HPLs1[0]
          + 1.0/2*GHPLs2[1*4+0]
          - 7.0/8*GHPLs1[1]
          - 5.0/16*HPLs1[0]
          + 7.0/8*HPLs2[0*2+0]
          + 5.0/8*HPLs2[1*2+0]
          - 5.0/8*HPLs1[1]
          - 5.0/8*HPLs2[0*2+1]
          )

       + (dN_c*dN_c-1)/(dN_c*dN_c)*double_complex(0,1)*M_PI*u * (
          - 3.0/8
          - 5.0/4*GHPLs1[2]
          + 5.0/4*GHPLs1[3]
          - 5.0/4*GHPLs1[0]
          + 5.0/4*GHPLs1[1]
          + 5.0/4*HPLs1[0]
          + 5.0/4*HPLs1[1]
          )

       + (dN_c*dN_c-1)/(dN_c*dN_c)*double_complex(0,1)*M_PI*u*v * (
          - 1.0/8*zeta2
          - 3.0/8*GHPLs1[2]
          - 1.0/8*GHPLs2[1*4+2]
          + 1.0/8*GHPLs2[2*4+3]
          - 1.0/8*GHPLs2[3*4+3]
          + 3.0/8*GHPLs1[3]
          - 1.0/8*GHPLs1[3]*HPLs1[0]
          - 1.0/8*GHPLs1[3]*HPLs1[1]
          + 1.0/8*GHPLs2[0*4+3]
          - 3.0/8*GHPLs1[0]
          + 1.0/8*GHPLs2[1*4+0]
          + 3.0/8*GHPLs1[1]
          - 1.0/8*GHPLs2[1*4+1]
          + 3.0/8*HPLs1[0]
          + 3.0/8*HPLs1[1]
          )

       + (dN_c*dN_c-1)/(dN_c*dN_c)*double_complex(0,1)*M_PI*pow(u,2)*pow(1-v,-3) * (
          - 3.0/2*zeta2
          + 3.0/4*GHPLs2[3*4+2]
          + 3.0/4*GHPLs1[2]*HPLs1[0]
          - 3.0/4*GHPLs2[1*4+2]
          - 9.0/4*GHPLs1[3]
          - 3.0/4*GHPLs2[3*4+0]
          - 3.0/4*GHPLs1[0]*HPLs1[0]
          + 3.0/4*GHPLs2[1*4+0]
          + 9.0/4*GHPLs1[1]
          - 9.0/4*HPLs1[0]
          + 3.0/4*HPLs2[0*2+0]
          + 3.0/4*HPLs2[1*2+0]
          - 3.0/4*HPLs2[0*2+1]
          )

       + (dN_c*dN_c-1)/(dN_c*dN_c)*double_complex(0,1)*M_PI*pow(u,2)*pow(1-v,-2) * (
          + 3.0/2*zeta2
          - 3.0/4*GHPLs2[3*4+2]
          - 3.0/4*GHPLs1[2]
          - 3.0/4*GHPLs1[2]*HPLs1[0]
          + 3.0/4*GHPLs2[1*4+2]
          + 3*GHPLs1[3]
          + 3.0/4*GHPLs2[3*4+0]
          - 3.0/4*GHPLs1[0]
          + 3.0/4*GHPLs1[0]*HPLs1[0]
          - 3.0/4*GHPLs2[1*4+0]
          - 3.0/2*GHPLs1[1]
          + 3*HPLs1[0]
          - 3.0/4*HPLs2[0*2+0]
          - 3.0/4*HPLs2[1*2+0]
          + 3.0/4*HPLs1[1]
          + 3.0/4*HPLs2[0*2+1]
          )

       + (dN_c*dN_c-1)/(dN_c*dN_c)*double_complex(0,1)*M_PI*pow(u,2)*pow(1-v,-1) * (
          + 3.0/8*GHPLs1[2]
          - 3.0/8*GHPLs1[3]
          + 3.0/8*GHPLs1[0]
          - 3.0/8*GHPLs1[1]
          - 3.0/8*HPLs1[0]
          - 3.0/8*HPLs1[1]
          )

       + (dN_c*dN_c-1)/(dN_c*dN_c)*double_complex(0,1)*M_PI*pow(u,2) * (
          + 1.0/8*GHPLs1[2]
          - 1.0/8*GHPLs1[3]
          + 1.0/8*GHPLs1[0]
          - 1.0/8*GHPLs1[1]
          - 1.0/8*HPLs1[0]
          - 1.0/8*HPLs1[1]
          )

       + (dN_c*dN_c-1)/(dN_c*dN_c)*double_complex(0,1)*M_PI*pow(u,3)*pow(1-v,-4) * (
          + 9.0/2*zeta2
          - 9.0/4*GHPLs2[3*4+2]
          - 9.0/4*GHPLs1[2]*HPLs1[0]
          + 9.0/4*GHPLs2[1*4+2]
          + 9.0/4*GHPLs2[3*4+0]
          + 9.0/4*GHPLs1[0]*HPLs1[0]
          - 9.0/4*GHPLs2[1*4+0]
          - 9.0/4*HPLs2[0*2+0]
          - 9.0/4*HPLs2[1*2+0]
          + 9.0/4*HPLs2[0*2+1]
          )

       + (dN_c*dN_c-1)/(dN_c*dN_c)*double_complex(0,1)*M_PI*pow(u,3)*pow(1-v,-3) * (
          - 9.0/2*zeta2
          + 9.0/4*GHPLs2[3*4+2]
          + 9.0/4*GHPLs1[2]
          + 9.0/4*GHPLs1[2]*HPLs1[0]
          - 9.0/4*GHPLs2[1*4+2]
          - 9.0/4*GHPLs1[3]
          - 9.0/4*GHPLs2[3*4+0]
          + 9.0/4*GHPLs1[0]
          - 9.0/4*GHPLs1[0]*HPLs1[0]
          + 9.0/4*GHPLs2[1*4+0]
          - 9.0/4*GHPLs1[1]
          - 9.0/4*HPLs1[0]
          + 9.0/4*HPLs2[0*2+0]
          + 9.0/4*HPLs2[1*2+0]
          - 9.0/4*HPLs1[1]
          - 9.0/4*HPLs2[0*2+1]
          )

       + (dN_c*dN_c-1)/(dN_c*dN_c)*double_complex(0,1)*M_PI*pow(u,3)*pow(1-v,-2) * (
          - 9.0/8*GHPLs1[2]
          + 9.0/8*GHPLs1[3]
          - 9.0/8*GHPLs1[0]
          + 9.0/8*GHPLs1[1]
          + 9.0/8*HPLs1[0]
          + 9.0/8*HPLs1[1]
          )

       + (dN_c*dN_c-1)/(dN_c*dN_c)*double_complex(0,1)*M_PI*pow(u,3)*pow(1-v,-1) * (
          - 3.0/8*GHPLs1[2]
          + 3.0/8*GHPLs1[3]
          - 3.0/8*GHPLs1[0]
          + 3.0/8*GHPLs1[1]
          + 3.0/8*HPLs1[0]
          + 3.0/8*HPLs1[1]
          )

       + C_F*NF*pow(u,-2) * (
          + 1.0/3*GHPLs2[2*4+2]*HPLs1[0]
          + 1.0/3*GHPLs1[2]*zeta2
          - 19.0/18*GHPLs1[2]*HPLs1[0]
          - 2.0/3*GHPLs1[2]*HPLs2[0*2+0]
          - 1.0/3*GHPLs1[2]*HPLs2[1*2+0]
          + 1.0/3*GHPLs3[2*4*4+2*4+1]
          - 19.0/18*GHPLs2[2*4+1]
          - 1.0/3*GHPLs2[2*4+1]*HPLs1[0]
          - 1.0/3*GHPLs2[2*4+1]*HPLs1[1]
          + 1.0/3*GHPLs1[1]*zeta2
          + 19.0/18*GHPLs1[1]*HPLs1[0]
          + 2.0/3*GHPLs1[1]*HPLs2[0*2+0]
          + 2.0/3*GHPLs1[1]*HPLs2[1*2+0]
          + 19.0/18*GHPLs1[1]*HPLs1[1]
          + 1.0/3*GHPLs1[1]*HPLs2[0*2+1]
          + 1.0/3*GHPLs1[1]*HPLs2[1*2+1]
          + 1.0/3*GHPLs3[2*4*4+1*4+1]
          - 1.0/3*GHPLs2[1*4+1]*HPLs1[0]
          - 1.0/3*GHPLs2[1*4+1]*HPLs1[1]
          )

       + C_F*NF*pow(u,-2)*v * (
          - 1.0/3*GHPLs2[2*4+2]*HPLs1[0]
          - 1.0/3*GHPLs1[2]*zeta2
          + 19.0/18*GHPLs1[2]*HPLs1[0]
          + 2.0/3*GHPLs1[2]*HPLs2[0*2+0]
          + 1.0/3*GHPLs1[2]*HPLs2[1*2+0]
          - 1.0/3*GHPLs3[2*4*4+2*4+1]
          + 19.0/18*GHPLs2[2*4+1]
          + 1.0/3*GHPLs2[2*4+1]*HPLs1[0]
          + 1.0/3*GHPLs2[2*4+1]*HPLs1[1]
          - 1.0/3*GHPLs1[1]*zeta2
          - 19.0/18*GHPLs1[1]*HPLs1[0]
          - 2.0/3*GHPLs1[1]*HPLs2[0*2+0]
          - 2.0/3*GHPLs1[1]*HPLs2[1*2+0]
          - 19.0/18*GHPLs1[1]*HPLs1[1]
          - 1.0/3*GHPLs1[1]*HPLs2[0*2+1]
          - 1.0/3*GHPLs1[1]*HPLs2[1*2+1]
          - 1.0/3*GHPLs3[2*4*4+1*4+1]
          + 1.0/3*GHPLs2[1*4+1]*HPLs1[0]
          + 1.0/3*GHPLs2[1*4+1]*HPLs1[1]
          )

       + C_F*NF*pow(u,-1) * (
          + 2.0/3*zeta2
          + 1.0/3*GHPLs2[2*4+2]
          - 19.0/18*GHPLs1[2]
          - 1.0/3*GHPLs1[2]*HPLs1[1]
          + 1.0/3*GHPLs2[2*4+1]
          - 1.0/3*GHPLs1[1]*HPLs1[0]
          - 1.0/3*GHPLs1[1]*HPLs1[1]
          + 1.0/3*HPLs2[1*2+0]
          + 19.0/18*HPLs1[1]
          + 1.0/3*HPLs2[0*2+1]
          + 1.0/3*HPLs2[1*2+1]
          )

       + C_F*NF*pow(u,-1)*v * (
          - 1.0/3*zeta2
          - 1.0/3*GHPLs2[2*4+2]
          + 1.0/3*GHPLs2[2*4+2]*HPLs1[0]
          + 19.0/18*GHPLs1[2]
          + 1.0/3*GHPLs1[2]*zeta2
          - 13.0/18*GHPLs1[2]*HPLs1[0]
          - 2.0/3*GHPLs1[2]*HPLs2[0*2+0]
          - 1.0/3*GHPLs1[2]*HPLs2[1*2+0]
          + 1.0/3*GHPLs1[2]*HPLs1[1]
          + 1.0/3*GHPLs3[2*4*4+2*4+1]
          - 25.0/18*GHPLs2[2*4+1]
          - 1.0/3*GHPLs2[2*4+1]*HPLs1[0]
          - 1.0/3*GHPLs2[2*4+1]*HPLs1[1]
          + 1.0/3*GHPLs1[1]*zeta2
          + 25.0/18*GHPLs1[1]*HPLs1[0]
          + 2.0/3*GHPLs1[1]*HPLs2[0*2+0]
          + 2.0/3*GHPLs1[1]*HPLs2[1*2+0]
          + 25.0/18*GHPLs1[1]*HPLs1[1]
          + 1.0/3*GHPLs1[1]*HPLs2[0*2+1]
          + 1.0/3*GHPLs1[1]*HPLs2[1*2+1]
          + 1.0/3*GHPLs3[2*4*4+1*4+1]
          - 1.0/3*GHPLs2[1*4+1]*HPLs1[0]
          - 1.0/3*GHPLs2[1*4+1]*HPLs1[1]
          - 19.0/18*HPLs1[0]
          - 2.0/3*HPLs2[0*2+0]
          - 2.0/3*HPLs2[1*2+0]
          - 19.0/18*HPLs1[1]
          - 1.0/3*HPLs2[0*2+1]
          - 1.0/3*HPLs2[1*2+1]
          )

       + C_F*NF*pow(1-v,-1) * (
          + 1.0/2*zeta2
          + 1.0/2*GHPLs1[2]*HPLs1[0]
          - 17.0/12*HPLs1[0]
          - HPLs2[0*2+0]
          - 1.0/2*HPLs2[1*2+0]
          )

       + C_F*NF * (
          - 19.0/36
          - 1.0/6*zeta2
          + 1.0/6*GHPLs2[2*4+2]
          - 7.0/36*GHPLs1[2]
          - 1.0/2*GHPLs1[2]*HPLs1[0]
          - 1.0/6*GHPLs1[2]*HPLs1[1]
          + 1.0/6*GHPLs2[2*4+1]
          - 1.0/6*GHPLs1[1]*HPLs1[0]
          - 1.0/6*GHPLs1[1]*HPLs1[1]
          + 5.0/4*HPLs1[0]
          + HPLs2[0*2+0]
          + 2.0/3*HPLs2[1*2+0]
          + 7.0/36*HPLs1[1]
          + 1.0/6*HPLs2[0*2+1]
          + 1.0/6*HPLs2[1*2+1]
          )

       + C_F*NF*v*pow(1-u,-1) * (
          + 1.0/6*zeta2
          + 1.0/6*GHPLs2[2*4+2]
          - 25.0/36*GHPLs1[2]
          - 1.0/6*GHPLs1[2]*HPLs1[0]
          - 1.0/6*GHPLs1[2]*HPLs1[1]
          + 1.0/6*GHPLs2[2*4+1]
          - 1.0/6*GHPLs1[1]*HPLs1[0]
          - 1.0/6*GHPLs1[1]*HPLs1[1]
          + 25.0/36*HPLs1[0]
          + 1.0/3*HPLs2[0*2+0]
          + 1.0/3*HPLs2[1*2+0]
          + 25.0/36*HPLs1[1]
          + 1.0/6*HPLs2[0*2+1]
          + 1.0/6*HPLs2[1*2+1]
          )

       + C_F*NF*u*pow(1-v,-2) * (
          + 1.0/6*zeta2
          + 1.0/6*GHPLs1[2]*HPLs1[0]
          - 13.0/36*HPLs1[0]
          - 1.0/3*HPLs2[0*2+0]
          - 1.0/6*HPLs2[1*2+0]
          )

       + C_F*NF*u*pow(1-v,-1) * (
          - 19.0/36
          - 1.0/6*zeta2
          + 1.0/6*GHPLs1[2]
          - 1.0/6*GHPLs1[2]*HPLs1[0]
          + 7.0/36*HPLs1[0]
          + 1.0/3*HPLs2[0*2+0]
          + 1.0/6*HPLs2[1*2+0]
          - 1.0/6*HPLs1[1]
          )

       + C_F*NF*double_complex(0,1)*M_PI*pow(u,-2) * (
          - 19.0/18*GHPLs1[1]
          - 1.0/3*GHPLs1[1]*HPLs1[0]
          + 1.0/3*GHPLs2[1*4+1]
          )

       + C_F*NF*double_complex(0,1)*M_PI*pow(u,-2)*v * (
          + 19.0/18*GHPLs1[1]
          + 1.0/3*GHPLs1[1]*HPLs1[0]
          - 1.0/3*GHPLs2[1*4+1]
          )

       + C_F*NF*double_complex(0,1)*M_PI*pow(u,-1) * (
          - 19.0/18
          + 1.0/3*GHPLs1[1]
          - 1.0/3*HPLs1[0]
          )

       + C_F*NF*double_complex(0,1)*M_PI*pow(u,-1)*v * (
          + 19.0/18
          - 25.0/18*GHPLs1[1]
          - 1.0/3*GHPLs1[1]*HPLs1[0]
          + 1.0/3*GHPLs2[1*4+1]
          + 1.0/3*HPLs1[0]
          )

       + C_F*NF*double_complex(0,1)*M_PI * (
          - 13.0/36
          + 1.0/6*GHPLs1[1]
          - 1.0/6*HPLs1[0]
          )

       + C_F*NF*double_complex(0,1)*M_PI*v*pow(1-u,-1) * (
          - 25.0/36
          + 1.0/6*GHPLs1[1]
          - 1.0/6*HPLs1[0]
          );
}

void beta_2_3(double u, double v, int n_f, double *GHPLs1, double *GHPLs2, double *GHPLs3, double *GHPLs4, double *HPLs1, double *HPLs2, double *HPLs3, double *HPLs4, double_complex &beta) {
  //  const double zeta2 = M_PI*M_PI/6;
  //  const double zeta3 = 1.20205690315959429;
  //  const double zeta4 = pow(M_PI,4)/90;
  //  const double dN_c=3;
  //  const double C_F=(dN_c*dN_c-1)/(2*dN_c);
  double NF=(double)n_f;

  beta =
    (dN_c*dN_c-1)*u*pow(1-v,-1) * (
          + 81659.0/10368
          - 49.0/32*zeta4
          + 5.0/12*zeta2
          - 389.0/144*zeta3
          + 2759.0/864*HPLs1[0]
          + 11.0/16*HPLs1[0]*zeta2
          - 7.0/4*HPLs1[0]*zeta3
          )

       + (dN_c*dN_c-1)*double_complex(0,1)*M_PI*u*pow(1-v,-1) * (
          + 2759.0/864
          + 11.0/16*zeta2
          - 7.0/4*zeta3
          )

       + (dN_c*dN_c-1)/(dN_c*dN_c)*u*pow(1-v,-1) * (
          + 255.0/128
          - 11.0/8*zeta4
          + 29.0/16*zeta2
          - 15.0/8*zeta3
          - 3.0/32*HPLs1[0]
          + 3.0/4*HPLs1[0]*zeta2
          - 3.0/2*HPLs1[0]*zeta3
          )

       + (dN_c*dN_c-1)/(dN_c*dN_c)*double_complex(0,1)*M_PI*u*pow(1-v,-1) * (
          - 3.0/32
          + 3.0/4*zeta2
          - 3.0/2*zeta3
          )

       + C_F*NF*u*pow(1-v,-1) * (
          - 4085.0/1296
          - 7.0/12*zeta2
          + 1.0/36*zeta3
          - 119.0/108*HPLs1[0]
          - 1.0/4*HPLs1[0]*zeta2
          )

       + C_F*NF*double_complex(0,1)*M_PI*u*pow(1-v,-1) * (
          - 119.0/108
          - 1.0/4*zeta2
          );
}

void beta_2_4(double u, double v, int n_f, double *GHPLs1, double *GHPLs2, double *GHPLs3, double *GHPLs4, double *HPLs1, double *HPLs2, double *HPLs3, double *HPLs4, double_complex &beta) {
  //  const double zeta2 = M_PI*M_PI/6;
  //  const double zeta3 = 1.20205690315959429;
  //  const double zeta4 = pow(M_PI,4)/90;
  //  const double dN_c=3;
  //  const double CF=(dN_c*dN_c-1)/(2*dN_c);
  double NF=(double)n_f;

  beta =
    C_F*pow(u,-2) * (
          + 4*GHPLs3[3*4*4+2*4+2]*HPLs1[0]
          - 4*GHPLs4[0*4*4*4+3*4*4+2*4+2]
          - 4*GHPLs2[2*4+2]*zeta2
          + 4*GHPLs2[2*4+2]*HPLs2[0*2+0]
          - 4*GHPLs2[2*4+2]*HPLs2[0*2+1]
          - 4*GHPLs3[0*4*4+2*4+2]*HPLs1[0]
          + 2.0/3*GHPLs1[2]*zeta2
          - 4*GHPLs1[2]*zeta3
          + GHPLs1[2]*HPLs1[0]
          - 4*GHPLs1[2]*HPLs1[0]*zeta2
          - 2.0/3*GHPLs1[2]*HPLs2[0*2+0]
          + 4*GHPLs1[2]*HPLs3[0*2*2+0*2+0]
          - 2.0/3*GHPLs1[2]*HPLs2[1*2+0]
          - 4*GHPLs1[2]*HPLs3[0*2*2+1*2+0]
          - 4*GHPLs1[2]*HPLs3[0*2*2+0*2+1]
          - 4*GHPLs3[3*4*4+0*4+2]*HPLs1[0]
          + 4*GHPLs4[0*4*4*4+3*4*4+0*4+2]
          - 2.0/3*GHPLs2[0*4+2]*HPLs1[0]
          - 4*GHPLs2[0*4+2]*HPLs2[0*2+0]
          - 2.0/3*GHPLs3[2*4*4+1*4+2]
          + 2.0/3*GHPLs2[1*4+2]*HPLs1[0]
          + 2.0/3*GHPLs2[1*4+2]*HPLs1[1]
          + 4*GHPLs3[3*4*4+2*4+1]*HPLs1[0]
          - 4*GHPLs4[0*4*4*4+3*4*4+2*4+1]
          + GHPLs2[2*4+1]
          - 4*GHPLs2[2*4+1]*zeta2
          + 4*GHPLs2[2*4+1]*HPLs2[0*2+0]
          - 4*GHPLs2[2*4+1]*HPLs2[0*2+1]
          - 2.0/3*GHPLs3[0*4*4+2*4+1]
          - 4*GHPLs3[0*4*4+2*4+1]*HPLs1[0]
          + 8.0/3*GHPLs1[1]*zeta2
          - 4*GHPLs1[1]*zeta3
          - GHPLs1[1]*HPLs1[0]
          + 4*GHPLs1[1]*HPLs1[0]*zeta2
          + 2.0/3*GHPLs1[1]*HPLs2[0*2+0]
          - 4*GHPLs1[1]*HPLs3[0*2*2+0*2+0]
          + 2.0/3*GHPLs1[1]*HPLs2[1*2+0]
          + 4*GHPLs1[1]*HPLs3[0*2*2+1*2+0]
          - GHPLs1[1]*HPLs1[1]
          + 4*GHPLs1[1]*HPLs1[1]*zeta2
          - 4*GHPLs1[1]*HPLs3[0*2*2+0*2+1]
          + 4*GHPLs1[1]*HPLs3[0*2*2+1*2+1]
          - 2.0/3*GHPLs3[2*4*4+0*4+1]
          + 4*GHPLs3[3*4*4+0*4+1]*HPLs1[0]
          - 4*GHPLs4[0*4*4*4+3*4*4+0*4+1]
          + 8*GHPLs2[0*4+1]*zeta2
          + 2.0/3*GHPLs2[0*4+1]*HPLs1[0]
          + 4*GHPLs2[0*4+1]*HPLs2[0*2+0]
          + 2.0/3*GHPLs2[0*4+1]*HPLs1[1]
          + 4*GHPLs2[0*4+1]*HPLs2[0*2+1]
          + 2.0/3*GHPLs3[2*4*4+1*4+1]
          - 2.0/3*GHPLs2[1*4+1]*HPLs1[0]
          - 2.0/3*GHPLs2[1*4+1]*HPLs1[1]
          )

       + C_F*pow(u,-2)*v * (
          - 4*GHPLs3[3*4*4+2*4+2]*HPLs1[0]
          + 4*GHPLs4[0*4*4*4+3*4*4+2*4+2]
          + 4*GHPLs2[2*4+2]*zeta2
          - 4*GHPLs2[2*4+2]*HPLs2[0*2+0]
          + 4*GHPLs2[2*4+2]*HPLs2[0*2+1]
          + 4*GHPLs3[0*4*4+2*4+2]*HPLs1[0]
          - 2.0/3*GHPLs1[2]*zeta2
          + 4*GHPLs1[2]*zeta3
          - 2.0/3*GHPLs1[2]*HPLs1[0]
          + 4*GHPLs1[2]*HPLs1[0]*zeta2
          + 2.0/3*GHPLs1[2]*HPLs2[0*2+0]
          - 4*GHPLs1[2]*HPLs3[0*2*2+0*2+0]
          + 2.0/3*GHPLs1[2]*HPLs2[1*2+0]
          + 4*GHPLs1[2]*HPLs3[0*2*2+1*2+0]
          + 4*GHPLs1[2]*HPLs3[0*2*2+0*2+1]
          + 4*GHPLs3[3*4*4+0*4+2]*HPLs1[0]
          - 4*GHPLs4[0*4*4*4+3*4*4+0*4+2]
          + 2.0/3*GHPLs2[0*4+2]*HPLs1[0]
          + 4*GHPLs2[0*4+2]*HPLs2[0*2+0]
          + 2.0/3*GHPLs3[2*4*4+1*4+2]
          - 2.0/3*GHPLs2[1*4+2]*HPLs1[0]
          - 2.0/3*GHPLs2[1*4+2]*HPLs1[1]
          - 4*GHPLs3[3*4*4+2*4+1]*HPLs1[0]
          + 4*GHPLs4[0*4*4*4+3*4*4+2*4+1]
          - 2.0/3*GHPLs2[2*4+1]
          + 4*GHPLs2[2*4+1]*zeta2
          - 4*GHPLs2[2*4+1]*HPLs2[0*2+0]
          + 4*GHPLs2[2*4+1]*HPLs2[0*2+1]
          + 2.0/3*GHPLs3[0*4*4+2*4+1]
          + 4*GHPLs3[0*4*4+2*4+1]*HPLs1[0]
          - 8.0/3*GHPLs1[1]*zeta2
          + 4*GHPLs1[1]*zeta3
          + 2.0/3*GHPLs1[1]*HPLs1[0]
          - 4*GHPLs1[1]*HPLs1[0]*zeta2
          - 2.0/3*GHPLs1[1]*HPLs2[0*2+0]
          + 4*GHPLs1[1]*HPLs3[0*2*2+0*2+0]
          - 2.0/3*GHPLs1[1]*HPLs2[1*2+0]
          - 4*GHPLs1[1]*HPLs3[0*2*2+1*2+0]
          + 2.0/3*GHPLs1[1]*HPLs1[1]
          - 4*GHPLs1[1]*HPLs1[1]*zeta2
          + 4*GHPLs1[1]*HPLs3[0*2*2+0*2+1]
          - 4*GHPLs1[1]*HPLs3[0*2*2+1*2+1]
          + 2.0/3*GHPLs3[2*4*4+0*4+1]
          - 4*GHPLs3[3*4*4+0*4+1]*HPLs1[0]
          + 4*GHPLs4[0*4*4*4+3*4*4+0*4+1]
          - 8*GHPLs2[0*4+1]*zeta2
          - 2.0/3*GHPLs2[0*4+1]*HPLs1[0]
          - 4*GHPLs2[0*4+1]*HPLs2[0*2+0]
          - 2.0/3*GHPLs2[0*4+1]*HPLs1[1]
          - 4*GHPLs2[0*4+1]*HPLs2[0*2+1]
          - 2.0/3*GHPLs3[2*4*4+1*4+1]
          + 2.0/3*GHPLs2[1*4+1]*HPLs1[0]
          + 2.0/3*GHPLs2[1*4+1]*HPLs1[1]
          )

       + C_F*pow(u,-2)*pow(v,2) * (
          + 1.0/3*GHPLs1[2]*HPLs1[0]
          + 1.0/3*GHPLs2[2*4+1]
          - 1.0/3*GHPLs1[1]*HPLs1[0]
          - 1.0/3*GHPLs1[1]*HPLs1[1]
          )

       + C_F*pow(u,-2)*pow(v,3) * (
          - 2.0/3*GHPLs1[2]*zeta2
          - 2.0/3*GHPLs1[2]*HPLs1[0]
          - 2.0/3*GHPLs1[2]*HPLs2[0*2+0]
          + 2.0/3*GHPLs1[2]*HPLs2[1*2+0]
          + 2.0/3*GHPLs2[0*4+2]*HPLs1[0]
          + 2.0/3*GHPLs3[2*4*4+1*4+2]
          - 2.0/3*GHPLs2[1*4+2]*HPLs1[0]
          - 2.0/3*GHPLs2[1*4+2]*HPLs1[1]
          + 2.0/3*GHPLs2[2*4+3]*HPLs1[0]
          - 2.0/3*GHPLs3[0*4*4+2*4+3]
          - 2.0/3*GHPLs2[3*4+3]*HPLs1[0]
          + 2.0/3*GHPLs3[0*4*4+3*4+3]
          + 10.0/3*GHPLs1[3]*zeta2
          - 2.0/3*GHPLs1[3]*HPLs2[1*2+0]
          - 2.0/3*GHPLs1[3]*HPLs2[0*2+1]
          - 2.0/3*GHPLs3[2*4*4+0*4+3]
          + 2.0/3*GHPLs2[0*4+3]*HPLs1[1]
          - 2.0/3*GHPLs2[2*4+1]
          + 2.0/3*GHPLs1[1]*HPLs1[0]
          + 2.0/3*GHPLs1[1]*HPLs1[1]
          )

       + C_F*pow(u,-2)*pow(v,4) * (
          + 2.0/3*GHPLs1[2]*zeta2
          + 2.0/3*GHPLs1[2]*HPLs2[0*2+0]
          - 2.0/3*GHPLs1[2]*HPLs2[1*2+0]
          - 2.0/3*GHPLs2[0*4+2]*HPLs1[0]
          - 2.0/3*GHPLs3[2*4*4+1*4+2]
          + 2.0/3*GHPLs2[1*4+2]*HPLs1[0]
          + 2.0/3*GHPLs2[1*4+2]*HPLs1[1]
          - 2.0/3*GHPLs2[2*4+3]*HPLs1[0]
          + 2.0/3*GHPLs3[0*4*4+2*4+3]
          + 2.0/3*GHPLs2[3*4+3]*HPLs1[0]
          - 2.0/3*GHPLs3[0*4*4+3*4+3]
          - 10.0/3*GHPLs1[3]*zeta2
          + 2.0/3*GHPLs1[3]*HPLs2[1*2+0]
          + 2.0/3*GHPLs1[3]*HPLs2[0*2+1]
          + 2.0/3*GHPLs3[2*4*4+0*4+3]
          - 2.0/3*GHPLs2[0*4+3]*HPLs1[1]
          )

       + C_F*pow(u,-1) * (
          - 14.0/3*zeta2
          - 8*zeta3
          - 6*GHPLs3[3*4*4+2*4+2]*HPLs1[0]
          + 6*GHPLs4[0*4*4*4+3*4*4+2*4+2]
          + 6*GHPLs2[2*4+2]*zeta2
          - 6*GHPLs2[2*4+2]*HPLs2[0*2+0]
          + 6*GHPLs2[2*4+2]*HPLs2[0*2+1]
          + 6*GHPLs3[0*4*4+2*4+2]*HPLs1[0]
          + 8*GHPLs2[3*4+2]*HPLs1[0]
          - 8*GHPLs3[0*4*4+3*4+2]
          + 5.0/3*GHPLs1[2]
          - 8*GHPLs1[2]*zeta2
          + 6*GHPLs1[2]*zeta3
          - 1.0/2*GHPLs1[2]*HPLs1[0]
          + 6*GHPLs1[2]*HPLs1[0]*zeta2
          + 9*GHPLs1[2]*HPLs2[0*2+0]
          - 6*GHPLs1[2]*HPLs3[0*2*2+0*2+0]
          + GHPLs1[2]*HPLs2[1*2+0]
          + 6*GHPLs1[2]*HPLs3[0*2*2+1*2+0]
          - 7*GHPLs1[2]*HPLs2[0*2+1]
          + 6*GHPLs1[2]*HPLs3[0*2*2+0*2+1]
          + 6*GHPLs3[3*4*4+0*4+2]*HPLs1[0]
          - 6*GHPLs4[0*4*4*4+3*4*4+0*4+2]
          - 2.0/3*GHPLs2[0*4+2]
          - 6*GHPLs2[0*4+2]*HPLs1[0]
          + 6*GHPLs2[0*4+2]*HPLs2[0*2+0]
          + GHPLs3[2*4*4+1*4+2]
          - GHPLs2[1*4+2]*HPLs1[0]
          - GHPLs2[1*4+2]*HPLs1[1]
          - 2.0/3*GHPLs2[2*4+0]
          + 8*GHPLs1[0]*zeta2
          + 2.0/3*GHPLs1[0]*HPLs1[1]
          + 4*GHPLs1[0]*HPLs2[0*2+1]
          - 6*GHPLs3[3*4*4+2*4+1]*HPLs1[0]
          + 6*GHPLs4[0*4*4*4+3*4*4+2*4+1]
          - 1.0/2*GHPLs2[2*4+1]
          + 6*GHPLs2[2*4+1]*zeta2
          - 6*GHPLs2[2*4+1]*HPLs2[0*2+0]
          + 6*GHPLs2[2*4+1]*HPLs2[0*2+1]
          + 2*GHPLs3[0*4*4+2*4+1]
          + 6*GHPLs3[0*4*4+2*4+1]*HPLs1[0]
          - 10*GHPLs1[1]*zeta2
          + 6*GHPLs1[1]*zeta3
          + 1.0/2*GHPLs1[1]*HPLs1[0]
          - 6*GHPLs1[1]*HPLs1[0]*zeta2
          - GHPLs1[1]*HPLs2[0*2+0]
          + 6*GHPLs1[1]*HPLs3[0*2*2+0*2+0]
          - GHPLs1[1]*HPLs2[1*2+0]
          - 6*GHPLs1[1]*HPLs3[0*2*2+1*2+0]
          + 1.0/2*GHPLs1[1]*HPLs1[1]
          - 6*GHPLs1[1]*HPLs1[1]*zeta2
          + 6*GHPLs1[1]*HPLs3[0*2*2+0*2+1]
          - 6*GHPLs1[1]*HPLs3[0*2*2+1*2+1]
          + 2*GHPLs3[2*4*4+0*4+1]
          - 6*GHPLs3[3*4*4+0*4+1]*HPLs1[0]
          + 6*GHPLs4[0*4*4*4+3*4*4+0*4+1]
          - 12*GHPLs2[0*4+1]*zeta2
          - 2*GHPLs2[0*4+1]*HPLs1[0]
          - 6*GHPLs2[0*4+1]*HPLs2[0*2+0]
          - 2*GHPLs2[0*4+1]*HPLs1[1]
          - 6*GHPLs2[0*4+1]*HPLs2[0*2+1]
          - GHPLs3[2*4*4+1*4+1]
          + GHPLs2[1*4+1]*HPLs1[0]
          + GHPLs2[1*4+1]*HPLs1[1]
          - 5.0/3*HPLs1[1]
          + 4*HPLs1[1]*zeta2
          - 4*HPLs2[0*2+1]
          - 8*HPLs3[0*2*2+0*2+1]
          + 4*HPLs3[0*2*2+1*2+1]
          )

       + C_F*pow(u,-1)*v * (
          + 16.0/3*zeta2
          + 4*zeta3
          + 4*GHPLs3[3*4*4+2*4+2]*HPLs1[0]
          - 4*GHPLs4[0*4*4*4+3*4*4+2*4+2]
          - 4*GHPLs2[2*4+2]*zeta2
          + 4*GHPLs2[2*4+2]*HPLs2[0*2+0]
          - 4*GHPLs2[2*4+2]*HPLs2[0*2+1]
          - 4*GHPLs3[0*4*4+2*4+2]*HPLs1[0]
          - 4*GHPLs2[3*4+2]*HPLs1[0]
          + 4*GHPLs3[0*4*4+3*4+2]
          - 4.0/3*GHPLs1[2]
          + 14.0/3*GHPLs1[2]*zeta2
          - 4*GHPLs1[2]*zeta3
          + 1.0/2*GHPLs1[2]*HPLs1[0]
          - 4*GHPLs1[2]*HPLs1[0]*zeta2
          - 14.0/3*GHPLs1[2]*HPLs2[0*2+0]
          + 4*GHPLs1[2]*HPLs3[0*2*2+0*2+0]
          - 2.0/3*GHPLs1[2]*HPLs2[1*2+0]
          - 4*GHPLs1[2]*HPLs3[0*2*2+1*2+0]
          + 4*GHPLs1[2]*HPLs2[0*2+1]
          - 4*GHPLs1[2]*HPLs3[0*2*2+0*2+1]
          - 4*GHPLs3[3*4*4+0*4+2]*HPLs1[0]
          + 4*GHPLs4[0*4*4*4+3*4*4+0*4+2]
          + 2.0/3*GHPLs2[0*4+2]
          + 10.0/3*GHPLs2[0*4+2]*HPLs1[0]
          - 4*GHPLs2[0*4+2]*HPLs2[0*2+0]
          - 2.0/3*GHPLs3[2*4*4+1*4+2]
          + 2.0/3*GHPLs2[1*4+2]*HPLs1[0]
          + 2.0/3*GHPLs2[1*4+2]*HPLs1[1]
          + 4*GHPLs1[3]*HPLs1[0]
          - 4*GHPLs2[0*4+3]
          + 2.0/3*GHPLs2[2*4+0]
          - 4*GHPLs2[3*4+0]*HPLs1[0]
          + 4*GHPLs3[0*4*4+3*4+0]
          - 8*GHPLs1[0]*zeta2
          - 2.0/3*GHPLs1[0]*HPLs1[0]
          - 4*GHPLs1[0]*HPLs2[0*2+0]
          - 2.0/3*GHPLs1[0]*HPLs1[1]
          - 4*GHPLs1[0]*HPLs2[0*2+1]
          + 4*GHPLs3[3*4*4+2*4+1]*HPLs1[0]
          - 4*GHPLs4[0*4*4*4+3*4*4+2*4+1]
          - 1.0/6*GHPLs2[2*4+1]
          - 4*GHPLs2[2*4+1]*zeta2
          + 4*GHPLs2[2*4+1]*HPLs2[0*2+0]
          - 4*GHPLs2[2*4+1]*HPLs2[0*2+1]
          - 2.0/3*GHPLs3[0*4*4+2*4+1]
          - 4*GHPLs3[0*4*4+2*4+1]*HPLs1[0]
          + 8.0/3*GHPLs1[1]*zeta2
          - 4*GHPLs1[1]*zeta3
          + 1.0/6*GHPLs1[1]*HPLs1[0]
          + 4*GHPLs1[1]*HPLs1[0]*zeta2
          + 2.0/3*GHPLs1[1]*HPLs2[0*2+0]
          - 4*GHPLs1[1]*HPLs3[0*2*2+0*2+0]
          + 2.0/3*GHPLs1[1]*HPLs2[1*2+0]
          + 4*GHPLs1[1]*HPLs3[0*2*2+1*2+0]
          + 1.0/6*GHPLs1[1]*HPLs1[1]
          + 4*GHPLs1[1]*HPLs1[1]*zeta2
          - 4*GHPLs1[1]*HPLs3[0*2*2+0*2+1]
          + 4*GHPLs1[1]*HPLs3[0*2*2+1*2+1]
          - 2.0/3*GHPLs3[2*4*4+0*4+1]
          + 4*GHPLs3[3*4*4+0*4+1]*HPLs1[0]
          - 4*GHPLs4[0*4*4*4+3*4*4+0*4+1]
          + 8*GHPLs2[0*4+1]*zeta2
          + 2.0/3*GHPLs2[0*4+1]*HPLs1[0]
          + 4*GHPLs2[0*4+1]*HPLs2[0*2+0]
          + 2.0/3*GHPLs2[0*4+1]*HPLs1[1]
          + 4*GHPLs2[0*4+1]*HPLs2[0*2+1]
          + 2.0/3*GHPLs3[2*4*4+1*4+1]
          - 2.0/3*GHPLs2[1*4+1]*HPLs1[0]
          - 2.0/3*GHPLs2[1*4+1]*HPLs1[1]
          + 5.0/3*HPLs1[0]
          - 4*HPLs1[0]*zeta2
          + 10.0/3*HPLs2[0*2+0]
          + 4*HPLs3[0*2*2+0*2+0]
          - 2.0/3*HPLs2[1*2+0]
          - 4*HPLs3[0*2*2+1*2+0]
          + 4.0/3*HPLs1[1]
          - 4*HPLs1[1]*zeta2
          + 4*HPLs2[0*2+1]
          + 4*HPLs3[0*2*2+0*2+1]
          - 4*HPLs3[0*2*2+1*2+1]
          )

       + C_F*pow(u,-1)*pow(v,2) * (
          - 10.0/3*zeta2
          - 1.0/3*GHPLs1[2]
          - GHPLs1[2]*zeta2
          - 7.0/3*GHPLs1[2]*HPLs1[0]
          - GHPLs1[2]*HPLs2[0*2+0]
          + GHPLs1[2]*HPLs2[1*2+0]
          + 2.0/3*GHPLs2[0*4+2]
          + GHPLs2[0*4+2]*HPLs1[0]
          + GHPLs3[2*4*4+1*4+2]
          - GHPLs2[1*4+2]*HPLs1[0]
          - GHPLs2[1*4+2]*HPLs1[1]
          + GHPLs2[2*4+3]*HPLs1[0]
          - GHPLs3[0*4*4+2*4+3]
          - GHPLs2[3*4+3]*HPLs1[0]
          + GHPLs3[0*4*4+3*4+3]
          + 5*GHPLs1[3]*zeta2
          + 2.0/3*GHPLs1[3]*HPLs1[0]
          - GHPLs1[3]*HPLs2[1*2+0]
          - GHPLs1[3]*HPLs2[0*2+1]
          - GHPLs3[2*4*4+0*4+3]
          - 2.0/3*GHPLs2[0*4+3]
          + GHPLs2[0*4+3]*HPLs1[1]
          + 2.0/3*GHPLs2[2*4+0]
          - 2.0/3*GHPLs1[0]*HPLs1[1]
          - 5.0/3*GHPLs2[2*4+1]
          + 5.0/3*GHPLs1[1]*HPLs1[0]
          + 5.0/3*GHPLs1[1]*HPLs1[1]
          + 1.0/3*HPLs1[0]
          + 2.0/3*HPLs2[1*2+0]
          + 1.0/3*HPLs1[1]
          + 2.0/3*HPLs2[0*2+1]
          )

       + C_F*pow(u,-1)*pow(v,3) * (
          + 8.0/3*zeta2
          + 2*GHPLs1[2]*zeta2
          + 4.0/3*GHPLs1[2]*HPLs1[0]
          + 2*GHPLs1[2]*HPLs2[0*2+0]
          - 2*GHPLs1[2]*HPLs2[1*2+0]
          - 2.0/3*GHPLs2[0*4+2]
          - 2*GHPLs2[0*4+2]*HPLs1[0]
          - 2*GHPLs3[2*4*4+1*4+2]
          + 2*GHPLs2[1*4+2]*HPLs1[0]
          + 2*GHPLs2[1*4+2]*HPLs1[1]
          - 2*GHPLs2[2*4+3]*HPLs1[0]
          + 2*GHPLs3[0*4*4+2*4+3]
          + 2*GHPLs2[3*4+3]*HPLs1[0]
          - 2*GHPLs3[0*4*4+3*4+3]
          - 10*GHPLs1[3]*zeta2
          - 2.0/3*GHPLs1[3]*HPLs1[0]
          + 2*GHPLs1[3]*HPLs2[1*2+0]
          + 2*GHPLs1[3]*HPLs2[0*2+1]
          + 2*GHPLs3[2*4*4+0*4+3]
          + 2.0/3*GHPLs2[0*4+3]
          - 2*GHPLs2[0*4+3]*HPLs1[1]
          - 2.0/3*GHPLs2[2*4+0]
          + 2.0/3*GHPLs1[0]*HPLs1[0]
          + 2.0/3*GHPLs1[0]*HPLs1[1]
          + 4.0/3*GHPLs2[2*4+1]
          - 4.0/3*GHPLs1[1]*HPLs1[0]
          - 4.0/3*GHPLs1[1]*HPLs1[1]
          - 2.0/3*HPLs2[0*2+0]
          - 2.0/3*HPLs2[0*2+1]
          )

       + C_F*pow(u,-1)*pow(v,4) * (
          - 2.0/3*GHPLs1[2]*zeta2
          - 2.0/3*GHPLs1[2]*HPLs2[0*2+0]
          + 2.0/3*GHPLs1[2]*HPLs2[1*2+0]
          + 2.0/3*GHPLs2[0*4+2]*HPLs1[0]
          + 2.0/3*GHPLs3[2*4*4+1*4+2]
          - 2.0/3*GHPLs2[1*4+2]*HPLs1[0]
          - 2.0/3*GHPLs2[1*4+2]*HPLs1[1]
          + 2.0/3*GHPLs2[2*4+3]*HPLs1[0]
          - 2.0/3*GHPLs3[0*4*4+2*4+3]
          - 2.0/3*GHPLs2[3*4+3]*HPLs1[0]
          + 2.0/3*GHPLs3[0*4*4+3*4+3]
          + 10.0/3*GHPLs1[3]*zeta2
          - 2.0/3*GHPLs1[3]*HPLs2[1*2+0]
          - 2.0/3*GHPLs1[3]*HPLs2[0*2+1]
          - 2.0/3*GHPLs3[2*4*4+0*4+3]
          + 2.0/3*GHPLs2[0*4+3]*HPLs1[1]
          )

       + C_F*pow(1-u,-1) * (
          + 3*zeta2
          - 3*GHPLs1[3]*HPLs1[0]
          + 3*GHPLs2[0*4+3]
          + 3*GHPLs1[0]*HPLs1[0]
          - 3*HPLs2[0*2+0]
          + 3*HPLs2[0*2+1]
          )

       + C_F*pow(1-u-v,-1) * (
          - zeta2
          + GHPLs1[3]*HPLs1[0]
          - GHPLs2[0*4+3]
          - GHPLs1[0]*HPLs1[0]
          + HPLs2[0*2+0]
          - HPLs2[0*2+1]
          )

       + C_F * (
          - 13.0/3*zeta2
          + 8*zeta3
          + 2*GHPLs3[3*4*4+2*4+2]*HPLs1[0]
          - 2*GHPLs4[0*4*4*4+3*4*4+2*4+2]
          - 2*GHPLs2[2*4+2]*zeta2
          + 2*GHPLs2[2*4+2]*HPLs2[0*2+0]
          - 2*GHPLs2[2*4+2]*HPLs2[0*2+1]
          - 2*GHPLs3[0*4*4+2*4+2]*HPLs1[0]
          - 8*GHPLs2[3*4+2]*HPLs1[0]
          + 8*GHPLs3[0*4*4+3*4+2]
          - 11.0/6*GHPLs1[2]
          + 8*GHPLs1[2]*zeta2
          - 2*GHPLs1[2]*zeta3
          - 1.0/2*GHPLs1[2]*HPLs1[0]
          - 2*GHPLs1[2]*HPLs1[0]*zeta2
          - 9*GHPLs1[2]*HPLs2[0*2+0]
          + 2*GHPLs1[2]*HPLs3[0*2*2+0*2+0]
          - GHPLs1[2]*HPLs2[1*2+0]
          - 2*GHPLs1[2]*HPLs3[0*2*2+1*2+0]
          + 7*GHPLs1[2]*HPLs2[0*2+1]
          - 2*GHPLs1[2]*HPLs3[0*2*2+0*2+1]
          - 2*GHPLs3[3*4*4+0*4+2]*HPLs1[0]
          + 2*GHPLs4[0*4*4*4+3*4*4+0*4+2]
          + 5.0/3*GHPLs2[0*4+2]
          + 6*GHPLs2[0*4+2]*HPLs1[0]
          - 2*GHPLs2[0*4+2]*HPLs2[0*2+0]
          - GHPLs3[2*4*4+1*4+2]
          + GHPLs2[1*4+2]*HPLs1[0]
          + GHPLs2[1*4+2]*HPLs1[1]
          + 6*GHPLs1[3]*HPLs1[0]
          - 6*GHPLs2[0*4+3]
          + 5.0/3*GHPLs2[2*4+0]
          + 5.0/3*GHPLs1[0]
          - 8*GHPLs1[0]*zeta2
          - 6*GHPLs1[0]*HPLs1[0]
          - 5.0/3*GHPLs1[0]*HPLs1[1]
          - 4*GHPLs1[0]*HPLs2[0*2+1]
          + 2*GHPLs3[3*4*4+2*4+1]*HPLs1[0]
          - 2*GHPLs4[0*4*4*4+3*4*4+2*4+1]
          - 1.0/2*GHPLs2[2*4+1]
          - 2*GHPLs2[2*4+1]*zeta2
          + 2*GHPLs2[2*4+1]*HPLs2[0*2+0]
          - 2*GHPLs2[2*4+1]*HPLs2[0*2+1]
          - 2*GHPLs3[0*4*4+2*4+1]
          - 2*GHPLs3[0*4*4+2*4+1]*HPLs1[0]
          + 10*GHPLs1[1]*zeta2
          - 2*GHPLs1[1]*zeta3
          + 1.0/2*GHPLs1[1]*HPLs1[0]
          + 2*GHPLs1[1]*HPLs1[0]*zeta2
          + GHPLs1[1]*HPLs2[0*2+0]
          - 2*GHPLs1[1]*HPLs3[0*2*2+0*2+0]
          + GHPLs1[1]*HPLs2[1*2+0]
          + 2*GHPLs1[1]*HPLs3[0*2*2+1*2+0]
          + 1.0/2*GHPLs1[1]*HPLs1[1]
          + 2*GHPLs1[1]*HPLs1[1]*zeta2
          - 2*GHPLs1[1]*HPLs3[0*2*2+0*2+1]
          + 2*GHPLs1[1]*HPLs3[0*2*2+1*2+1]
          - 2*GHPLs3[2*4*4+0*4+1]
          + 2*GHPLs3[3*4*4+0*4+1]*HPLs1[0]
          - 2*GHPLs4[0*4*4*4+3*4*4+0*4+1]
          + 4*GHPLs2[0*4+1]*zeta2
          + 2*GHPLs2[0*4+1]*HPLs1[0]
          + 2*GHPLs2[0*4+1]*HPLs2[0*2+0]
          + 2*GHPLs2[0*4+1]*HPLs1[1]
          + 2*GHPLs2[0*4+1]*HPLs2[0*2+1]
          + GHPLs3[2*4*4+1*4+1]
          - GHPLs2[1*4+1]*HPLs1[0]
          - GHPLs2[1*4+1]*HPLs1[1]
          + 6*HPLs2[0*2+0]
          + 11.0/6*HPLs1[1]
          - 4*HPLs1[1]*zeta2
          + 8*HPLs3[0*2*2+0*2+1]
          - 4*HPLs3[0*2*2+1*2+1]
          )

       + C_F*v*pow(1-u,-2) * (
          + 3*zeta3
          - 3*GHPLs2[3*4+2]*HPLs1[0]
          + 3*GHPLs3[0*4*4+3*4+2]
          + 3*GHPLs1[2]*zeta2
          - 3*GHPLs1[2]*HPLs2[0*2+0]
          + 3*GHPLs1[2]*HPLs2[0*2+1]
          + 3*GHPLs2[0*4+2]*HPLs1[0]
          - 3*GHPLs2[3*4+0]*HPLs1[0]
          + 3*GHPLs3[0*4*4+3*4+0]
          - 6*GHPLs1[0]*zeta2
          - 3*GHPLs1[0]*HPLs2[0*2+0]
          - 3*GHPLs1[0]*HPLs2[0*2+1]
          - 3*HPLs1[0]*zeta2
          + 3*HPLs3[0*2*2+0*2+0]
          - 3*HPLs3[0*2*2+1*2+0]
          - 3*HPLs1[1]*zeta2
          + 3*HPLs3[0*2*2+0*2+1]
          - 3*HPLs3[0*2*2+1*2+1]
          )

       + C_F*v*pow(1-u,-1) * (
          - 6*zeta2
          - 5*zeta3
          + 5*GHPLs2[3*4+2]*HPLs1[0]
          - 5*GHPLs3[0*4*4+3*4+2]
          - 5*GHPLs1[2]*zeta2
          + 5*GHPLs1[2]*HPLs2[0*2+0]
          - 5*GHPLs1[2]*HPLs2[0*2+1]
          - 5*GHPLs2[0*4+2]*HPLs1[0]
          - 3*GHPLs1[3]*HPLs1[0]
          + 3*GHPLs2[0*4+3]
          + 5*GHPLs2[3*4+0]*HPLs1[0]
          - 5*GHPLs3[0*4*4+3*4+0]
          + 10*GHPLs1[0]*zeta2
          + 5*GHPLs1[0]*HPLs2[0*2+0]
          + 5*GHPLs1[0]*HPLs2[0*2+1]
          + 5*HPLs1[0]*zeta2
          - 3*HPLs2[0*2+0]
          - 5*HPLs3[0*2*2+0*2+0]
          + 5*HPLs3[0*2*2+1*2+0]
          + 5*HPLs1[1]*zeta2
          - 3*HPLs2[0*2+1]
          - 5*HPLs3[0*2*2+0*2+1]
          + 5*HPLs3[0*2*2+1*2+1]
          )

       + C_F*v * (
          - 2*zeta2
          - 1.0/2*GHPLs1[2]
          - GHPLs1[2]*zeta2
          - 5.0/3*GHPLs1[2]*HPLs1[0]
          - GHPLs1[2]*HPLs2[0*2+0]
          + GHPLs1[2]*HPLs2[1*2+0]
          + 1.0/3*GHPLs2[0*4+2]
          + GHPLs2[0*4+2]*HPLs1[0]
          + GHPLs3[2*4*4+1*4+2]
          - GHPLs2[1*4+2]*HPLs1[0]
          - GHPLs2[1*4+2]*HPLs1[1]
          + GHPLs2[2*4+3]*HPLs1[0]
          - GHPLs3[0*4*4+2*4+3]
          - GHPLs2[3*4+3]*HPLs1[0]
          + GHPLs3[0*4*4+3*4+3]
          + 5*GHPLs1[3]*zeta2
          + 2.0/3*GHPLs1[3]*HPLs1[0]
          - GHPLs1[3]*HPLs2[1*2+0]
          - GHPLs1[3]*HPLs2[0*2+1]
          - GHPLs3[2*4*4+0*4+3]
          - 2.0/3*GHPLs2[0*4+3]
          + GHPLs2[0*4+3]*HPLs1[1]
          + 1.0/3*GHPLs2[2*4+0]
          + 1.0/3*GHPLs1[0]
          + 1.0/3*GHPLs1[0]*HPLs1[0]
          - 1.0/3*GHPLs1[0]*HPLs1[1]
          - 2.0/3*GHPLs2[2*4+1]
          + 2.0/3*GHPLs1[1]*HPLs1[0]
          + 2.0/3*GHPLs1[1]*HPLs1[1]
          - 1.0/6*HPLs1[0]
          + 1.0/3*HPLs2[0*2+0]
          + HPLs2[1*2+0]
          + 1.0/2*HPLs1[1]
          + 2.0/3*HPLs2[0*2+1]
          )

       + C_F*pow(v,2) * (
          + 22.0/3*zeta2
          + 1.0/3*GHPLs1[2]
          + 2*GHPLs1[2]*zeta2
          + 11.0/3*GHPLs1[2]*HPLs1[0]
          + 2*GHPLs1[2]*HPLs2[0*2+0]
          - 2*GHPLs1[2]*HPLs2[1*2+0]
          - 5.0/3*GHPLs2[0*4+2]
          - 2*GHPLs2[0*4+2]*HPLs1[0]
          - 2*GHPLs3[2*4*4+1*4+2]
          + 2*GHPLs2[1*4+2]*HPLs1[0]
          + 2*GHPLs2[1*4+2]*HPLs1[1]
          - 2*GHPLs2[2*4+3]*HPLs1[0]
          + 2*GHPLs3[0*4*4+2*4+3]
          + 2*GHPLs2[3*4+3]*HPLs1[0]
          - 2*GHPLs3[0*4*4+3*4+3]
          - 10*GHPLs1[3]*zeta2
          - 5.0/3*GHPLs1[3]*HPLs1[0]
          + 2*GHPLs1[3]*HPLs2[1*2+0]
          + 2*GHPLs1[3]*HPLs2[0*2+1]
          + 2*GHPLs3[2*4*4+0*4+3]
          + 5.0/3*GHPLs2[0*4+3]
          - 2*GHPLs2[0*4+3]*HPLs1[1]
          - 5.0/3*GHPLs2[2*4+0]
          + GHPLs1[0]*HPLs1[0]
          + 5.0/3*GHPLs1[0]*HPLs1[1]
          + 3*GHPLs2[2*4+1]
          - 3*GHPLs1[1]*HPLs1[0]
          - 3*GHPLs1[1]*HPLs1[1]
          - 1.0/3*HPLs1[0]
          - HPLs2[0*2+0]
          - 2.0/3*HPLs2[1*2+0]
          - 1.0/3*HPLs1[1]
          - 5.0/3*HPLs2[0*2+1]
          )

       + C_F*pow(v,3) * (
          - 8.0/3*zeta2
          - 2*GHPLs1[2]*zeta2
          - 2.0/3*GHPLs1[2]*HPLs1[0]
          - 2*GHPLs1[2]*HPLs2[0*2+0]
          + 2*GHPLs1[2]*HPLs2[1*2+0]
          + 2.0/3*GHPLs2[0*4+2]
          + 2*GHPLs2[0*4+2]*HPLs1[0]
          + 2*GHPLs3[2*4*4+1*4+2]
          - 2*GHPLs2[1*4+2]*HPLs1[0]
          - 2*GHPLs2[1*4+2]*HPLs1[1]
          + 2*GHPLs2[2*4+3]*HPLs1[0]
          - 2*GHPLs3[0*4*4+2*4+3]
          - 2*GHPLs2[3*4+3]*HPLs1[0]
          + 2*GHPLs3[0*4*4+3*4+3]
          + 10*GHPLs1[3]*zeta2
          + 2.0/3*GHPLs1[3]*HPLs1[0]
          - 2*GHPLs1[3]*HPLs2[1*2+0]
          - 2*GHPLs1[3]*HPLs2[0*2+1]
          - 2*GHPLs3[2*4*4+0*4+3]
          - 2.0/3*GHPLs2[0*4+3]
          + 2*GHPLs2[0*4+3]*HPLs1[1]
          + 2.0/3*GHPLs2[2*4+0]
          - 2.0/3*GHPLs1[0]*HPLs1[0]
          - 2.0/3*GHPLs1[0]*HPLs1[1]
          - 2.0/3*GHPLs2[2*4+1]
          + 2.0/3*GHPLs1[1]*HPLs1[0]
          + 2.0/3*GHPLs1[1]*HPLs1[1]
          + 2.0/3*HPLs2[0*2+0]
          + 2.0/3*HPLs2[0*2+1]
          )

       + C_F*u*pow(1-v,-2) * (
          + 2*zeta2
          - 2*zeta3
          - GHPLs1[2]*zeta2
          + 3*GHPLs1[2]*HPLs1[0]
          - 2.0/3*GHPLs1[2]*HPLs2[0*2+0]
          - GHPLs1[2]*HPLs2[0*2+1]
          - GHPLs2[0*4+2]*HPLs1[0]
          - GHPLs2[2*4+0]*HPLs1[0]
          - GHPLs1[0]*zeta2
          - GHPLs1[0]*HPLs1[0]
          + 2.0/3*GHPLs1[0]*HPLs2[0*2+0]
          + GHPLs1[0]*HPLs2[1*2+0]
          + 4*HPLs1[0]
          + 3*HPLs1[0]*zeta2
          - 2.0/3*HPLs2[0*2+0]
          + 2.0/3*HPLs3[1*2*2+0*2+0]
          - 3*HPLs2[1*2+0]
          - 4.0/3*HPLs3[0*2*2+1*2+0]
          - HPLs1[1]*zeta2
          - HPLs2[0*2+1]
          + 2.0/3*HPLs3[0*2*2+0*2+1]
          + HPLs3[1*2*2+0*2+1]
          )

       + C_F*u*pow(1-v,-1) * (
          + 2*zeta3
          + 4*GHPLs1[2]
          + GHPLs1[2]*zeta2
          - 8.0/3*GHPLs1[2]*HPLs1[0]
          + 2*GHPLs1[2]*HPLs2[0*2+0]
          + GHPLs1[2]*HPLs2[0*2+1]
          - GHPLs2[0*4+2]
          + GHPLs2[0*4+2]*HPLs1[0]
          - GHPLs2[2*4+0]
          + GHPLs2[2*4+0]*HPLs1[0]
          + GHPLs1[0]*zeta2
          + 2.0/3*GHPLs1[0]*HPLs1[0]
          - 2*GHPLs1[0]*HPLs2[0*2+0]
          - GHPLs1[0]*HPLs2[1*2+0]
          + GHPLs1[0]*HPLs1[1]
          - 14.0/3*HPLs1[0]
          - 3*HPLs1[0]*zeta2
          - 1.0/3*HPLs2[0*2+0]
          - 2*HPLs3[1*2*2+0*2+0]
          + 8.0/3*HPLs2[1*2+0]
          - 4*HPLs1[1]
          + HPLs1[1]*zeta2
          - 7.0/3*HPLs2[0*2+1]
          - 2*HPLs3[0*2*2+0*2+1]
          - HPLs3[1*2*2+0*2+1]
          )

       + C_F*u*pow(1-u-v,-1) * (
          + 5.0/2*zeta2
          - 5.0/2*GHPLs1[3]*HPLs1[0]
          + 5.0/2*GHPLs2[0*4+3]
          + 5.0/2*GHPLs1[0]*HPLs1[0]
          - 5.0/2*HPLs2[0*2+0]
          + 5.0/2*HPLs2[0*2+1]
          )

       + C_F*u * (
          - zeta2
          - 5.0/6*GHPLs1[2]
          - 2.0/3*GHPLs1[2]*zeta2
          - 5.0/6*GHPLs1[2]*HPLs1[0]
          - 2.0/3*GHPLs1[2]*HPLs2[0*2+0]
          + 2.0/3*GHPLs1[2]*HPLs2[1*2+0]
          + 1.0/2*GHPLs2[0*4+2]
          + 2.0/3*GHPLs2[0*4+2]*HPLs1[0]
          + 2.0/3*GHPLs3[2*4*4+1*4+2]
          - 2.0/3*GHPLs2[1*4+2]*HPLs1[0]
          - 2.0/3*GHPLs2[1*4+2]*HPLs1[1]
          + 2.0/3*GHPLs2[2*4+3]*HPLs1[0]
          - 2.0/3*GHPLs3[0*4*4+2*4+3]
          - 2.0/3*GHPLs2[3*4+3]*HPLs1[0]
          + 2.0/3*GHPLs3[0*4*4+3*4+3]
          + 10.0/3*GHPLs1[3]*zeta2
          + 1.0/2*GHPLs1[3]*HPLs1[0]
          - 2.0/3*GHPLs1[3]*HPLs2[1*2+0]
          - 2.0/3*GHPLs1[3]*HPLs2[0*2+1]
          - 2.0/3*GHPLs3[2*4*4+0*4+3]
          - 1.0/2*GHPLs2[0*4+3]
          + 2.0/3*GHPLs2[0*4+3]*HPLs1[1]
          + 1.0/2*GHPLs2[2*4+0]
          - 2.0/3*GHPLs2[2*4+0]*HPLs1[0]
          + 2.0/3*GHPLs2[3*4+0]*HPLs1[0]
          - 2.0/3*GHPLs3[0*4*4+3*4+0]
          - 1.0/6*GHPLs1[0]
          - 1.0/6*GHPLs1[0]*HPLs1[0]
          + 4.0/3*GHPLs1[0]*HPLs2[0*2+0]
          + 2.0/3*GHPLs1[0]*HPLs2[1*2+0]
          - 1.0/2*GHPLs1[0]*HPLs1[1]
          + 2.0/3*GHPLs1[0]*HPLs2[0*2+1]
          - 1.0/2*GHPLs2[2*4+1]
          + 2.0/3*GHPLs3[0*4*4+2*4+1]
          - 8.0/3*GHPLs1[1]*zeta2
          + 1.0/2*GHPLs1[1]*HPLs1[0]
          - 2.0/3*GHPLs1[1]*HPLs2[0*2+0]
          - 2.0/3*GHPLs1[1]*HPLs2[1*2+0]
          + 1.0/2*GHPLs1[1]*HPLs1[1]
          + 2.0/3*GHPLs3[2*4*4+0*4+1]
          - 2.0/3*GHPLs2[0*4+1]*HPLs1[0]
          - 2.0/3*GHPLs2[0*4+1]*HPLs1[1]
          - 2.0/3*GHPLs3[2*4*4+1*4+1]
          + 2.0/3*GHPLs2[1*4+1]*HPLs1[0]
          + 2.0/3*GHPLs2[1*4+1]*HPLs1[1]
          + 2.0/3*HPLs1[0]
          + 10.0/3*HPLs1[0]*zeta2
          + 3.0/2*HPLs2[0*2+0]
          + 2.0/3*HPLs3[1*2*2+0*2+0]
          + 1.0/3*HPLs2[1*2+0]
          + 2.0/3*HPLs3[0*2*2+1*2+0]
          + 5.0/6*HPLs1[1]
          + 2.0/3*HPLs1[1]*zeta2
          + 11.0/6*HPLs2[0*2+1]
          + 2.0/3*HPLs3[0*2*2+0*2+1]
          + 2.0/3*HPLs3[1*2*2+0*2+1]
          + 4.0/3*HPLs3[0*2*2+1*2+1]
          )

       + C_F*u*v * (
          + 26.0/3*zeta2
          + 2.0/3*GHPLs1[2]
          + 2.0/3*GHPLs1[2]*zeta2
          + 9.0/2*GHPLs1[2]*HPLs1[0]
          + 2.0/3*GHPLs1[2]*HPLs2[0*2+0]
          - 2.0/3*GHPLs1[2]*HPLs2[1*2+0]
          - 11.0/6*GHPLs2[0*4+2]
          - 2.0/3*GHPLs2[0*4+2]*HPLs1[0]
          - 2.0/3*GHPLs3[2*4*4+1*4+2]
          + 2.0/3*GHPLs2[1*4+2]*HPLs1[0]
          + 2.0/3*GHPLs2[1*4+2]*HPLs1[1]
          - 2.0/3*GHPLs2[2*4+3]*HPLs1[0]
          + 2.0/3*GHPLs3[0*4*4+2*4+3]
          + 2.0/3*GHPLs2[3*4+3]*HPLs1[0]
          - 2.0/3*GHPLs3[0*4*4+3*4+3]
          - 10.0/3*GHPLs1[3]*zeta2
          - 5.0/2*GHPLs1[3]*HPLs1[0]
          + 2.0/3*GHPLs1[3]*HPLs2[1*2+0]
          + 2.0/3*GHPLs1[3]*HPLs2[0*2+1]
          + 2.0/3*GHPLs3[2*4*4+0*4+3]
          + 5.0/2*GHPLs2[0*4+3]
          - 2.0/3*GHPLs2[0*4+3]*HPLs1[1]
          - 11.0/6*GHPLs2[2*4+0]
          + 2.0/3*GHPLs2[2*4+0]*HPLs1[0]
          - 2.0/3*GHPLs2[3*4+0]*HPLs1[0]
          + 2.0/3*GHPLs3[0*4*4+3*4+0]
          - 1.0/3*GHPLs1[0]
          + 1.0/2*GHPLs1[0]*HPLs1[0]
          - 4.0/3*GHPLs1[0]*HPLs2[0*2+0]
          - 2.0/3*GHPLs1[0]*HPLs2[1*2+0]
          + 11.0/6*GHPLs1[0]*HPLs1[1]
          - 2.0/3*GHPLs1[0]*HPLs2[0*2+1]
          + 5.0/2*GHPLs2[2*4+1]
          - 2.0/3*GHPLs3[0*4*4+2*4+1]
          + 8.0/3*GHPLs1[1]*zeta2
          - 5.0/2*GHPLs1[1]*HPLs1[0]
          + 2.0/3*GHPLs1[1]*HPLs2[0*2+0]
          + 2.0/3*GHPLs1[1]*HPLs2[1*2+0]
          - 5.0/2*GHPLs1[1]*HPLs1[1]
          - 2.0/3*GHPLs3[2*4*4+0*4+1]
          + 2.0/3*GHPLs2[0*4+1]*HPLs1[0]
          + 2.0/3*GHPLs2[0*4+1]*HPLs1[1]
          + 2.0/3*GHPLs3[2*4*4+1*4+1]
          - 2.0/3*GHPLs2[1*4+1]*HPLs1[0]
          - 2.0/3*GHPLs2[1*4+1]*HPLs1[1]
          - 1.0/3*HPLs1[0]
          - 10.0/3*HPLs1[0]*zeta2
          - 11.0/6*HPLs2[0*2+0]
          - 2.0/3*HPLs3[1*2*2+0*2+0]
          - 2*HPLs2[1*2+0]
          - 2.0/3*HPLs3[0*2*2+1*2+0]
          - 2.0/3*HPLs1[1]
          - 2.0/3*HPLs1[1]*zeta2
          - 5.0/2*HPLs2[0*2+1]
          - 2.0/3*HPLs3[0*2*2+0*2+1]
          - 2.0/3*HPLs3[1*2*2+0*2+1]
          - 4.0/3*HPLs3[0*2*2+1*2+1]
          )

       + C_F*u*pow(v,2) * (
          - 20.0/3*zeta2
          - 2*GHPLs1[2]*zeta2
          - 5.0/3*GHPLs1[2]*HPLs1[0]
          - 2*GHPLs1[2]*HPLs2[0*2+0]
          + 2*GHPLs1[2]*HPLs2[1*2+0]
          + 5.0/3*GHPLs2[0*4+2]
          + 2*GHPLs2[0*4+2]*HPLs1[0]
          + 2*GHPLs3[2*4*4+1*4+2]
          - 2*GHPLs2[1*4+2]*HPLs1[0]
          - 2*GHPLs2[1*4+2]*HPLs1[1]
          + 2*GHPLs2[2*4+3]*HPLs1[0]
          - 2*GHPLs3[0*4*4+2*4+3]
          - 2*GHPLs2[3*4+3]*HPLs1[0]
          + 2*GHPLs3[0*4*4+3*4+3]
          + 10*GHPLs1[3]*zeta2
          + 5.0/3*GHPLs1[3]*HPLs1[0]
          - 2*GHPLs1[3]*HPLs2[1*2+0]
          - 2*GHPLs1[3]*HPLs2[0*2+1]
          - 2*GHPLs3[2*4*4+0*4+3]
          - 5.0/3*GHPLs2[0*4+3]
          + 2*GHPLs2[0*4+3]*HPLs1[1]
          + 5.0/3*GHPLs2[2*4+0]
          - 5.0/3*GHPLs1[0]*HPLs1[0]
          - 5.0/3*GHPLs1[0]*HPLs1[1]
          - 5.0/3*GHPLs2[2*4+1]
          + 5.0/3*GHPLs1[1]*HPLs1[0]
          + 5.0/3*GHPLs1[1]*HPLs1[1]
          + 5.0/3*HPLs2[0*2+0]
          + 5.0/3*HPLs2[0*2+1]
          )

       + C_F*pow(u,2)*pow(1-v,-3) * (
          - 4*GHPLs1[2]*HPLs1[0]
          + 4.0/3*GHPLs1[2]*HPLs2[0*2+0]
          + 4*GHPLs1[0]*HPLs1[0]
          - 4.0/3*GHPLs1[0]*HPLs2[0*2+0]
          - 4.0/3*HPLs3[1*2*2+0*2+0]
          + 4*HPLs2[1*2+0]
          - 4.0/3*HPLs3[0*2*2+1*2+0]
          + 4*HPLs2[0*2+1]
          - 4.0/3*HPLs3[0*2*2+0*2+1]
          )

       + C_F*pow(u,2)*pow(1-v,-2) * (
          - 4*GHPLs1[2]
          + 10.0/3*GHPLs1[2]*HPLs1[0]
          - 4.0/3*GHPLs1[2]*HPLs2[0*2+0]
          + 4*GHPLs1[0]
          - 10.0/3*GHPLs1[0]*HPLs1[0]
          + 4.0/3*GHPLs1[0]*HPLs2[0*2+0]
          + 4.0/3*HPLs3[1*2*2+0*2+0]
          - 10.0/3*HPLs2[1*2+0]
          + 4.0/3*HPLs3[0*2*2+1*2+0]
          + 4*HPLs1[1]
          - 10.0/3*HPLs2[0*2+1]
          + 4.0/3*HPLs3[0*2*2+0*2+1]
          )

       + C_F*pow(u,2)*pow(1-v,-1) * (
          + 2.0/3*GHPLs1[2]
          - 2.0/3*GHPLs1[2]*HPLs1[0]
          - 2.0/3*GHPLs1[0]
          + 2.0/3*GHPLs1[0]*HPLs1[0]
          + 2.0/3*HPLs2[1*2+0]
          - 2.0/3*HPLs1[1]
          + 2.0/3*HPLs2[0*2+1]
          )

       + C_F*pow(u,2) * (
          + 6*zeta2
          + 1.0/3*GHPLs1[2]
          + 17.0/6*GHPLs1[2]*HPLs1[0]
          - 3.0/2*GHPLs2[0*4+2]
          - 3.0/2*GHPLs1[3]*HPLs1[0]
          + 3.0/2*GHPLs2[0*4+3]
          - 3.0/2*GHPLs2[2*4+0]
          - 1.0/3*GHPLs1[0]
          + 1.0/6*GHPLs1[0]*HPLs1[0]
          + 3.0/2*GHPLs1[0]*HPLs1[1]
          + 3.0/2*GHPLs2[2*4+1]
          - 3.0/2*GHPLs1[1]*HPLs1[0]
          - 3.0/2*GHPLs1[1]*HPLs1[1]
          - 3.0/2*HPLs2[0*2+0]
          - 4.0/3*HPLs2[1*2+0]
          - 1.0/3*HPLs1[1]
          - 17.0/6*HPLs2[0*2+1]
          )

       + C_F*pow(u,2)*v * (
          - 8*zeta2
          - 2.0/3*GHPLs1[2]*zeta2
          - 2*GHPLs1[2]*HPLs1[0]
          - 2.0/3*GHPLs1[2]*HPLs2[0*2+0]
          + 2.0/3*GHPLs1[2]*HPLs2[1*2+0]
          + 2*GHPLs2[0*4+2]
          + 2.0/3*GHPLs2[0*4+2]*HPLs1[0]
          + 2.0/3*GHPLs3[2*4*4+1*4+2]
          - 2.0/3*GHPLs2[1*4+2]*HPLs1[0]
          - 2.0/3*GHPLs2[1*4+2]*HPLs1[1]
          + 2.0/3*GHPLs2[2*4+3]*HPLs1[0]
          - 2.0/3*GHPLs3[0*4*4+2*4+3]
          - 2.0/3*GHPLs2[3*4+3]*HPLs1[0]
          + 2.0/3*GHPLs3[0*4*4+3*4+3]
          + 10.0/3*GHPLs1[3]*zeta2
          + 2*GHPLs1[3]*HPLs1[0]
          - 2.0/3*GHPLs1[3]*HPLs2[1*2+0]
          - 2.0/3*GHPLs1[3]*HPLs2[0*2+1]
          - 2.0/3*GHPLs3[2*4*4+0*4+3]
          - 2*GHPLs2[0*4+3]
          + 2.0/3*GHPLs2[0*4+3]*HPLs1[1]
          + 2*GHPLs2[2*4+0]
          - 2.0/3*GHPLs2[2*4+0]*HPLs1[0]
          + 2.0/3*GHPLs2[3*4+0]*HPLs1[0]
          - 2.0/3*GHPLs3[0*4*4+3*4+0]
          - 2*GHPLs1[0]*HPLs1[0]
          + 4.0/3*GHPLs1[0]*HPLs2[0*2+0]
          + 2.0/3*GHPLs1[0]*HPLs2[1*2+0]
          - 2*GHPLs1[0]*HPLs1[1]
          + 2.0/3*GHPLs1[0]*HPLs2[0*2+1]
          - 2*GHPLs2[2*4+1]
          + 2.0/3*GHPLs3[0*4*4+2*4+1]
          - 8.0/3*GHPLs1[1]*zeta2
          + 2*GHPLs1[1]*HPLs1[0]
          - 2.0/3*GHPLs1[1]*HPLs2[0*2+0]
          - 2.0/3*GHPLs1[1]*HPLs2[1*2+0]
          + 2*GHPLs1[1]*HPLs1[1]
          + 2.0/3*GHPLs3[2*4*4+0*4+1]
          - 2.0/3*GHPLs2[0*4+1]*HPLs1[0]
          - 2.0/3*GHPLs2[0*4+1]*HPLs1[1]
          - 2.0/3*GHPLs3[2*4*4+1*4+1]
          + 2.0/3*GHPLs2[1*4+1]*HPLs1[0]
          + 2.0/3*GHPLs2[1*4+1]*HPLs1[1]
          + 10.0/3*HPLs1[0]*zeta2
          + 2*HPLs2[0*2+0]
          + 2.0/3*HPLs3[1*2*2+0*2+0]
          + 2.0/3*HPLs3[0*2*2+1*2+0]
          + 2.0/3*HPLs1[1]*zeta2
          + 2*HPLs2[0*2+1]
          + 2.0/3*HPLs3[0*2*2+0*2+1]
          + 2.0/3*HPLs3[1*2*2+0*2+1]
          + 4.0/3*HPLs3[0*2*2+1*2+1]
          )

       + C_F*pow(u,3) * (
          - 4*zeta2
          - GHPLs1[2]*HPLs1[0]
          + GHPLs2[0*4+2]
          + GHPLs1[3]*HPLs1[0]
          - GHPLs2[0*4+3]
          + GHPLs2[2*4+0]
          - GHPLs1[0]*HPLs1[0]
          - GHPLs1[0]*HPLs1[1]
          - GHPLs2[2*4+1]
          + GHPLs1[1]*HPLs1[0]
          + GHPLs1[1]*HPLs1[1]
          + HPLs2[0*2+0]
          + HPLs2[0*2+1]
          )

       + C_F*double_complex(0,1)*M_PI*pow(u,-2) * (
          - 4*GHPLs3[3*4*4+2*4+2]
          - 4*GHPLs2[2*4+2]*HPLs1[0]
          - 4*GHPLs1[2]*HPLs2[0*2+0]
          + 4*GHPLs3[3*4*4+0*4+2]
          - 2.0/3*GHPLs2[1*4+2]
          - 4*GHPLs3[3*4*4+2*4+1]
          - 2.0/3*GHPLs2[2*4+1]
          - 4*GHPLs2[2*4+1]*HPLs1[0]
          + GHPLs1[1]
          + 8*GHPLs1[1]*zeta2
          + 4*GHPLs1[1]*HPLs2[0*2+0]
          + 2.0/3*GHPLs1[1]*HPLs1[1]
          + 4*GHPLs1[1]*HPLs2[0*2+1]
          - 4*GHPLs3[3*4*4+0*4+1]
          - 2.0/3*GHPLs2[0*4+1]
          + 2.0/3*GHPLs2[1*4+1]
          )

       + C_F*double_complex(0,1)*M_PI*pow(u,-2)*v * (
          + 4*GHPLs3[3*4*4+2*4+2]
          + 4*GHPLs2[2*4+2]*HPLs1[0]
          + 4*GHPLs1[2]*HPLs2[0*2+0]
          - 4*GHPLs3[3*4*4+0*4+2]
          + 2.0/3*GHPLs2[1*4+2]
          + 4*GHPLs3[3*4*4+2*4+1]
          + 2.0/3*GHPLs2[2*4+1]
          + 4*GHPLs2[2*4+1]*HPLs1[0]
          - 2.0/3*GHPLs1[1]
          - 8*GHPLs1[1]*zeta2
          - 4*GHPLs1[1]*HPLs2[0*2+0]
          - 2.0/3*GHPLs1[1]*HPLs1[1]
          - 4*GHPLs1[1]*HPLs2[0*2+1]
          + 4*GHPLs3[3*4*4+0*4+1]
          + 2.0/3*GHPLs2[0*4+1]
          - 2.0/3*GHPLs2[1*4+1]
          )

       + C_F*double_complex(0,1)*M_PI*pow(u,-2)*pow(v,2) * (
          + 1.0/3*GHPLs1[1]
          )

       + C_F*double_complex(0,1)*M_PI*pow(u,-2)*pow(v,3) * (
          + 2.0/3*GHPLs2[1*4+2]
          - 2.0/3*GHPLs2[2*4+3]
          + 2.0/3*GHPLs2[3*4+3]
          + 2.0/3*GHPLs1[3]*HPLs1[0]
          + 2.0/3*GHPLs1[3]*HPLs1[1]
          - 2.0/3*GHPLs2[0*4+3]
          - 2.0/3*GHPLs1[1]
          )

       + C_F*double_complex(0,1)*M_PI*pow(u,-2)*pow(v,4) * (
          - 2.0/3*GHPLs2[1*4+2]
          + 2.0/3*GHPLs2[2*4+3]
          - 2.0/3*GHPLs2[3*4+3]
          - 2.0/3*GHPLs1[3]*HPLs1[0]
          - 2.0/3*GHPLs1[3]*HPLs1[1]
          + 2.0/3*GHPLs2[0*4+3]
          )

       + C_F*double_complex(0,1)*M_PI*pow(u,-1) * (
          + 5.0/3
          + 8*zeta2
          + 6*GHPLs3[3*4*4+2*4+2]
          + 6*GHPLs2[2*4+2]*HPLs1[0]
          - 8*GHPLs2[3*4+2]
          - 2.0/3*GHPLs1[2]
          - 7*GHPLs1[2]*HPLs1[0]
          + 6*GHPLs1[2]*HPLs2[0*2+0]
          - 6*GHPLs3[3*4*4+0*4+2]
          + GHPLs2[1*4+2]
          - 2.0/3*GHPLs1[0]
          + 6*GHPLs3[3*4*4+2*4+1]
          + 2*GHPLs2[2*4+1]
          + 6*GHPLs2[2*4+1]*HPLs1[0]
          - 1.0/2*GHPLs1[1]
          - 12*GHPLs1[1]*zeta2
          - GHPLs1[1]*HPLs1[0]
          - 6*GHPLs1[1]*HPLs2[0*2+0]
          - 2*GHPLs1[1]*HPLs1[1]
          - 6*GHPLs1[1]*HPLs2[0*2+1]
          + 6*GHPLs3[3*4*4+0*4+1]
          + 2*GHPLs2[0*4+1]
          - GHPLs2[1*4+1]
          + 2.0/3*HPLs1[1]
          + 4*HPLs2[0*2+1]
          )

       + C_F*double_complex(0,1)*M_PI*pow(u,-1)*v * (
          - 4.0/3
          - 8*zeta2
          - 4*GHPLs3[3*4*4+2*4+2]
          - 4*GHPLs2[2*4+2]*HPLs1[0]
          + 4*GHPLs2[3*4+2]
          + 2.0/3*GHPLs1[2]
          + 4*GHPLs1[2]*HPLs1[0]
          - 4*GHPLs1[2]*HPLs2[0*2+0]
          + 4*GHPLs3[3*4*4+0*4+2]
          - 2.0/3*GHPLs2[1*4+2]
          - 4*GHPLs1[3]
          + 4*GHPLs2[3*4+0]
          + 2.0/3*GHPLs1[0]
          - 4*GHPLs3[3*4*4+2*4+1]
          - 2.0/3*GHPLs2[2*4+1]
          - 4*GHPLs2[2*4+1]*HPLs1[0]
          - 1.0/6*GHPLs1[1]
          + 8*GHPLs1[1]*zeta2
          + 4*GHPLs1[1]*HPLs2[0*2+0]
          + 2.0/3*GHPLs1[1]*HPLs1[1]
          + 4*GHPLs1[1]*HPLs2[0*2+1]
          - 4*GHPLs3[3*4*4+0*4+1]
          - 2.0/3*GHPLs2[0*4+1]
          + 2.0/3*GHPLs2[1*4+1]
          - 4*HPLs2[0*2+0]
          - 2.0/3*HPLs1[1]
          - 4*HPLs2[0*2+1]
          )

       + C_F*double_complex(0,1)*M_PI*pow(u,-1)*pow(v,2) * (
          - 1.0/3
          + 2.0/3*GHPLs1[2]
          + GHPLs2[1*4+2]
          - GHPLs2[2*4+3]
          + GHPLs2[3*4+3]
          - 2.0/3*GHPLs1[3]
          + GHPLs1[3]*HPLs1[0]
          + GHPLs1[3]*HPLs1[1]
          - GHPLs2[0*4+3]
          + 2.0/3*GHPLs1[0]
          - 5.0/3*GHPLs1[1]
          - 2.0/3*HPLs1[0]
          - 2.0/3*HPLs1[1]
          )

       + C_F*double_complex(0,1)*M_PI*pow(u,-1)*pow(v,3) * (
          - 2.0/3*GHPLs1[2]
          - 2*GHPLs2[1*4+2]
          + 2*GHPLs2[2*4+3]
          - 2*GHPLs2[3*4+3]
          + 2.0/3*GHPLs1[3]
          - 2*GHPLs1[3]*HPLs1[0]
          - 2*GHPLs1[3]*HPLs1[1]
          + 2*GHPLs2[0*4+3]
          - 2.0/3*GHPLs1[0]
          + 4.0/3*GHPLs1[1]
          + 2.0/3*HPLs1[0]
          + 2.0/3*HPLs1[1]
          )

       + C_F*double_complex(0,1)*M_PI*pow(u,-1)*pow(v,4) * (
          + 2.0/3*GHPLs2[1*4+2]
          - 2.0/3*GHPLs2[2*4+3]
          + 2.0/3*GHPLs2[3*4+3]
          + 2.0/3*GHPLs1[3]*HPLs1[0]
          + 2.0/3*GHPLs1[3]*HPLs1[1]
          - 2.0/3*GHPLs2[0*4+3]
          )

       + C_F*double_complex(0,1)*M_PI*pow(1-u,-1) * (
          + 3*GHPLs1[3]
          + 3*HPLs1[0]
          )

       + C_F*double_complex(0,1)*M_PI*pow(1-u-v,-1) * (
          - GHPLs1[3]
          - HPLs1[0]
          )

       + C_F*double_complex(0,1)*M_PI * (
          - 1.0/6
          - 8*zeta2
          - 2*GHPLs3[3*4*4+2*4+2]
          - 2*GHPLs2[2*4+2]*HPLs1[0]
          + 8*GHPLs2[3*4+2]
          + 5.0/3*GHPLs1[2]
          + 7*GHPLs1[2]*HPLs1[0]
          - 2*GHPLs1[2]*HPLs2[0*2+0]
          + 2*GHPLs3[3*4*4+0*4+2]
          - GHPLs2[1*4+2]
          - 6*GHPLs1[3]
          + 5.0/3*GHPLs1[0]
          - 2*GHPLs3[3*4*4+2*4+1]
          - 2*GHPLs2[2*4+1]
          - 2*GHPLs2[2*4+1]*HPLs1[0]
          - 1.0/2*GHPLs1[1]
          + 4*GHPLs1[1]*zeta2
          + GHPLs1[1]*HPLs1[0]
          + 2*GHPLs1[1]*HPLs2[0*2+0]
          + 2*GHPLs1[1]*HPLs1[1]
          + 2*GHPLs1[1]*HPLs2[0*2+1]
          - 2*GHPLs3[3*4*4+0*4+1]
          - 2*GHPLs2[0*4+1]
          + GHPLs2[1*4+1]
          - 6*HPLs1[0]
          - 5.0/3*HPLs1[1]
          - 4*HPLs2[0*2+1]
          )

       + C_F*double_complex(0,1)*M_PI*v*pow(1-u,-2) * (
          - 6*zeta2
          + 3*GHPLs2[3*4+2]
          + 3*GHPLs1[2]*HPLs1[0]
          + 3*GHPLs2[3*4+0]
          - 3*HPLs2[0*2+0]
          - 3*HPLs2[0*2+1]
          )

       + C_F*double_complex(0,1)*M_PI*v*pow(1-u,-1) * (
          + 10*zeta2
          - 5*GHPLs2[3*4+2]
          - 5*GHPLs1[2]*HPLs1[0]
          + 3*GHPLs1[3]
          - 5*GHPLs2[3*4+0]
          + 5*HPLs2[0*2+0]
          + 5*HPLs2[0*2+1]
          )

       + C_F*double_complex(0,1)*M_PI*v * (
          - 1.0/6
          + 1.0/3*GHPLs1[2]
          + GHPLs2[1*4+2]
          - GHPLs2[2*4+3]
          + GHPLs2[3*4+3]
          - 2.0/3*GHPLs1[3]
          + GHPLs1[3]*HPLs1[0]
          + GHPLs1[3]*HPLs1[1]
          - GHPLs2[0*4+3]
          + 1.0/3*GHPLs1[0]
          - 2.0/3*GHPLs1[1]
          - 2.0/3*HPLs1[0]
          - 1.0/3*HPLs1[1]
          )

       + C_F*double_complex(0,1)*M_PI*pow(v,2) * (
          + 1.0/3
          - 5.0/3*GHPLs1[2]
          - 2*GHPLs2[1*4+2]
          + 2*GHPLs2[2*4+3]
          - 2*GHPLs2[3*4+3]
          + 5.0/3*GHPLs1[3]
          - 2*GHPLs1[3]*HPLs1[0]
          - 2*GHPLs1[3]*HPLs1[1]
          + 2*GHPLs2[0*4+3]
          - 5.0/3*GHPLs1[0]
          + 3*GHPLs1[1]
          + 5.0/3*HPLs1[0]
          + 5.0/3*HPLs1[1]
          )

       + C_F*double_complex(0,1)*M_PI*pow(v,3) * (
          + 2.0/3*GHPLs1[2]
          + 2*GHPLs2[1*4+2]
          - 2*GHPLs2[2*4+3]
          + 2*GHPLs2[3*4+3]
          - 2.0/3*GHPLs1[3]
          + 2*GHPLs1[3]*HPLs1[0]
          + 2*GHPLs1[3]*HPLs1[1]
          - 2*GHPLs2[0*4+3]
          + 2.0/3*GHPLs1[0]
          - 2.0/3*GHPLs1[1]
          - 2.0/3*HPLs1[0]
          - 2.0/3*HPLs1[1]
          )

       + C_F*double_complex(0,1)*M_PI*u*pow(1-v,-2) * (
          - 2*zeta2
          - GHPLs1[2]*HPLs1[0]
          - GHPLs1[0]*HPLs1[0]
          + 2*HPLs1[0]
          + HPLs2[1*2+0]
          - HPLs2[0*2+1]
          )

       + C_F*double_complex(0,1)*M_PI*u*pow(1-v,-1) * (
          + 4
          + 2*zeta2
          - GHPLs1[2]
          + GHPLs1[2]*HPLs1[0]
          - GHPLs1[0]
          + GHPLs1[0]*HPLs1[0]
          - 2*HPLs1[0]
          - HPLs2[1*2+0]
          + HPLs1[1]
          + HPLs2[0*2+1]
          )

       + C_F*double_complex(0,1)*M_PI*u*pow(1-u-v,-1) * (
          + 5.0/2*GHPLs1[3]
          + 5.0/2*HPLs1[0]
          )

       + C_F*double_complex(0,1)*M_PI*u * (
          - 1
          - 2.0/3*zeta2
          + 1.0/2*GHPLs1[2]
          + 2.0/3*GHPLs2[1*4+2]
          - 2.0/3*GHPLs2[2*4+3]
          + 2.0/3*GHPLs2[3*4+3]
          - 1.0/2*GHPLs1[3]
          + 2.0/3*GHPLs1[3]*HPLs1[0]
          + 2.0/3*GHPLs1[3]*HPLs1[1]
          - 2.0/3*GHPLs2[0*4+3]
          - 2.0/3*GHPLs2[3*4+0]
          + 1.0/2*GHPLs1[0]
          - 2.0/3*GHPLs1[0]*HPLs1[0]
          + 2.0/3*GHPLs2[2*4+1]
          - 1.0/2*GHPLs1[1]
          - 2.0/3*GHPLs1[1]*HPLs1[1]
          + 2.0/3*GHPLs2[0*4+1]
          - 2.0/3*GHPLs2[1*4+1]
          - 1.0/2*HPLs1[0]
          + 2.0/3*HPLs2[0*2+0]
          + 2.0/3*HPLs2[1*2+0]
          - 1.0/2*HPLs1[1]
          )

       + C_F*double_complex(0,1)*M_PI*u*v * (
          + 1.0/3
          + 2.0/3*zeta2
          - 11.0/6*GHPLs1[2]
          - 2.0/3*GHPLs2[1*4+2]
          + 2.0/3*GHPLs2[2*4+3]
          - 2.0/3*GHPLs2[3*4+3]
          + 5.0/2*GHPLs1[3]
          - 2.0/3*GHPLs1[3]*HPLs1[0]
          - 2.0/3*GHPLs1[3]*HPLs1[1]
          + 2.0/3*GHPLs2[0*4+3]
          + 2.0/3*GHPLs2[3*4+0]
          - 11.0/6*GHPLs1[0]
          + 2.0/3*GHPLs1[0]*HPLs1[0]
          - 2.0/3*GHPLs2[2*4+1]
          + 5.0/2*GHPLs1[1]
          + 2.0/3*GHPLs1[1]*HPLs1[1]
          - 2.0/3*GHPLs2[0*4+1]
          + 2.0/3*GHPLs2[1*4+1]
          + 5.0/2*HPLs1[0]
          - 2.0/3*HPLs2[0*2+0]
          - 2.0/3*HPLs2[1*2+0]
          + 11.0/6*HPLs1[1]
          )

       + C_F*double_complex(0,1)*M_PI*u*pow(v,2) * (
          + 5.0/3*GHPLs1[2]
          + 2*GHPLs2[1*4+2]
          - 2*GHPLs2[2*4+3]
          + 2*GHPLs2[3*4+3]
          - 5.0/3*GHPLs1[3]
          + 2*GHPLs1[3]*HPLs1[0]
          + 2*GHPLs1[3]*HPLs1[1]
          - 2*GHPLs2[0*4+3]
          + 5.0/3*GHPLs1[0]
          - 5.0/3*GHPLs1[1]
          - 5.0/3*HPLs1[0]
          - 5.0/3*HPLs1[1]
          )

       + C_F*double_complex(0,1)*M_PI*pow(u,2) * (
          - 3.0/2*GHPLs1[2]
          + 3.0/2*GHPLs1[3]
          - 3.0/2*GHPLs1[0]
          + 3.0/2*GHPLs1[1]
          + 3.0/2*HPLs1[0]
          + 3.0/2*HPLs1[1]
          )

       + C_F*double_complex(0,1)*M_PI*pow(u,2)*v * (
          - 2.0/3*zeta2
          + 2*GHPLs1[2]
          + 2.0/3*GHPLs2[1*4+2]
          - 2.0/3*GHPLs2[2*4+3]
          + 2.0/3*GHPLs2[3*4+3]
          - 2*GHPLs1[3]
          + 2.0/3*GHPLs1[3]*HPLs1[0]
          + 2.0/3*GHPLs1[3]*HPLs1[1]
          - 2.0/3*GHPLs2[0*4+3]
          - 2.0/3*GHPLs2[3*4+0]
          + 2*GHPLs1[0]
          - 2.0/3*GHPLs1[0]*HPLs1[0]
          + 2.0/3*GHPLs2[2*4+1]
          - 2*GHPLs1[1]
          - 2.0/3*GHPLs1[1]*HPLs1[1]
          + 2.0/3*GHPLs2[0*4+1]
          - 2.0/3*GHPLs2[1*4+1]
          - 2*HPLs1[0]
          + 2.0/3*HPLs2[0*2+0]
          + 2.0/3*HPLs2[1*2+0]
          - 2*HPLs1[1]
          )

       + C_F*double_complex(0,1)*M_PI*pow(u,3) * (
          + GHPLs1[2]
          - GHPLs1[3]
          + GHPLs1[0]
          - GHPLs1[1]
          - HPLs1[0]
          - HPLs1[1]
          );
}

void gamma_2_1(double u, double v, int n_f, double *GHPLs1, double *GHPLs2, double *GHPLs3, double *GHPLs4, double *HPLs1, double *HPLs2, double *HPLs3, double *HPLs4, double_complex &gamma) {
  //  const double zeta2 = M_PI*M_PI/6;
  //  const double zeta3 = 1.20205690315959429;
  //  const double zeta4 = pow(M_PI,4)/90;
  //  const double dN_c=3;
  //  const double C_F=(dN_c*dN_c-1)/(2*dN_c);
  double NF=(double)n_f;

  gamma =
    (dN_c*dN_c-1)*pow(u,-2)*v * (
          - 1.0/4*GHPLs3[3*4*4+2*4+2]*HPLs1[0]
          + 1.0/4*GHPLs4[0*4*4*4+3*4*4+2*4+2]
          + 1.0/4*GHPLs2[2*4+2]*zeta2
          - 1.0/4*GHPLs2[2*4+2]*HPLs2[0*2+0]
          + 1.0/4*GHPLs2[2*4+2]*HPLs2[0*2+1]
          + 1.0/4*GHPLs3[0*4*4+2*4+2]*HPLs1[0]
          + 1.0/4*GHPLs1[2]*zeta3
          + 1.0/4*GHPLs1[2]*HPLs1[0]*zeta2
          - 1.0/4*GHPLs1[2]*HPLs3[0*2*2+0*2+0]
          + 1.0/4*GHPLs1[2]*HPLs3[0*2*2+1*2+0]
          + 1.0/4*GHPLs1[2]*HPLs3[0*2*2+0*2+1]
          + 1.0/4*GHPLs3[3*4*4+0*4+2]*HPLs1[0]
          - 1.0/4*GHPLs4[0*4*4*4+3*4*4+0*4+2]
          + 1.0/4*GHPLs2[0*4+2]*HPLs2[0*2+0]
          - 1.0/4*GHPLs3[3*4*4+2*4+1]*HPLs1[0]
          + 1.0/4*GHPLs4[0*4*4*4+3*4*4+2*4+1]
          + 1.0/4*GHPLs2[2*4+1]*zeta2
          - 1.0/4*GHPLs2[2*4+1]*HPLs2[0*2+0]
          + 1.0/4*GHPLs2[2*4+1]*HPLs2[0*2+1]
          + 1.0/4*GHPLs3[0*4*4+2*4+1]*HPLs1[0]
          + 1.0/4*GHPLs1[1]*zeta3
          - 1.0/4*GHPLs1[1]*HPLs1[0]*zeta2
          + 1.0/4*GHPLs1[1]*HPLs3[0*2*2+0*2+0]
          - 1.0/4*GHPLs1[1]*HPLs3[0*2*2+1*2+0]
          - 1.0/4*GHPLs1[1]*HPLs1[1]*zeta2
          + 1.0/4*GHPLs1[1]*HPLs3[0*2*2+0*2+1]
          - 1.0/4*GHPLs1[1]*HPLs3[0*2*2+1*2+1]
          - 1.0/4*GHPLs3[3*4*4+0*4+1]*HPLs1[0]
          + 1.0/4*GHPLs4[0*4*4*4+3*4*4+0*4+1]
          - 1.0/2*GHPLs2[0*4+1]*zeta2
          - 1.0/4*GHPLs2[0*4+1]*HPLs2[0*2+0]
          - 1.0/4*GHPLs2[0*4+1]*HPLs2[0*2+1]
          )

       + (dN_c*dN_c-1)*pow(u,-2)*pow(v,2) * (
          + 1.0/4*GHPLs3[3*4*4+2*4+2]*HPLs1[0]
          - 1.0/4*GHPLs4[0*4*4*4+3*4*4+2*4+2]
          - 1.0/4*GHPLs2[2*4+2]*zeta2
          + 1.0/4*GHPLs2[2*4+2]*HPLs2[0*2+0]
          - 1.0/4*GHPLs2[2*4+2]*HPLs2[0*2+1]
          - 1.0/4*GHPLs3[0*4*4+2*4+2]*HPLs1[0]
          - 1.0/4*GHPLs1[2]*zeta3
          - 1.0/4*GHPLs1[2]*HPLs1[0]*zeta2
          + 1.0/4*GHPLs1[2]*HPLs3[0*2*2+0*2+0]
          - 1.0/4*GHPLs1[2]*HPLs3[0*2*2+1*2+0]
          - 1.0/4*GHPLs1[2]*HPLs3[0*2*2+0*2+1]
          - 1.0/4*GHPLs3[3*4*4+0*4+2]*HPLs1[0]
          + 1.0/4*GHPLs4[0*4*4*4+3*4*4+0*4+2]
          - 1.0/4*GHPLs2[0*4+2]*HPLs2[0*2+0]
          + 1.0/4*GHPLs3[3*4*4+2*4+1]*HPLs1[0]
          - 1.0/4*GHPLs4[0*4*4*4+3*4*4+2*4+1]
          - 1.0/4*GHPLs2[2*4+1]*zeta2
          + 1.0/4*GHPLs2[2*4+1]*HPLs2[0*2+0]
          - 1.0/4*GHPLs2[2*4+1]*HPLs2[0*2+1]
          - 1.0/4*GHPLs3[0*4*4+2*4+1]*HPLs1[0]
          - 1.0/4*GHPLs1[1]*zeta3
          + 1.0/4*GHPLs1[1]*HPLs1[0]*zeta2
          - 1.0/4*GHPLs1[1]*HPLs3[0*2*2+0*2+0]
          + 1.0/4*GHPLs1[1]*HPLs3[0*2*2+1*2+0]
          + 1.0/4*GHPLs1[1]*HPLs1[1]*zeta2
          - 1.0/4*GHPLs1[1]*HPLs3[0*2*2+0*2+1]
          + 1.0/4*GHPLs1[1]*HPLs3[0*2*2+1*2+1]
          + 1.0/4*GHPLs3[3*4*4+0*4+1]*HPLs1[0]
          - 1.0/4*GHPLs4[0*4*4*4+3*4*4+0*4+1]
          + 1.0/2*GHPLs2[0*4+1]*zeta2
          + 1.0/4*GHPLs2[0*4+1]*HPLs2[0*2+0]
          + 1.0/4*GHPLs2[0*4+1]*HPLs2[0*2+1]
          )

       + (dN_c*dN_c-1)*pow(u,-1)*v * (
          - 1.0/2
          + 1.0/2*zeta2
          + 1.0/2*zeta3
          + 1.0/4*GHPLs3[3*4*4+2*4+2]*HPLs1[0]
          - 1.0/4*GHPLs4[0*4*4*4+3*4*4+2*4+2]
          - 1.0/4*GHPLs2[2*4+2]*zeta2
          + 1.0/4*GHPLs2[2*4+2]*HPLs2[0*2+0]
          - 1.0/4*GHPLs2[2*4+2]*HPLs2[0*2+1]
          - 1.0/4*GHPLs3[0*4*4+2*4+2]*HPLs1[0]
          - 1.0/2*GHPLs2[3*4+2]*HPLs1[0]
          + 1.0/2*GHPLs3[0*4*4+3*4+2]
          + 1.0/2*GHPLs1[2]*zeta2
          - 1.0/4*GHPLs1[2]*zeta3
          - 1.0/4*GHPLs1[2]*HPLs1[0]*zeta2
          - 1.0/2*GHPLs1[2]*HPLs2[0*2+0]
          + 1.0/4*GHPLs1[2]*HPLs3[0*2*2+0*2+0]
          - 1.0/4*GHPLs1[2]*HPLs3[0*2*2+1*2+0]
          + 1.0/2*GHPLs1[2]*HPLs2[0*2+1]
          - 1.0/4*GHPLs1[2]*HPLs3[0*2*2+0*2+1]
          - 1.0/4*GHPLs3[3*4*4+0*4+2]*HPLs1[0]
          + 1.0/4*GHPLs4[0*4*4*4+3*4*4+0*4+2]
          + 1.0/2*GHPLs2[0*4+2]*HPLs1[0]
          - 1.0/4*GHPLs2[0*4+2]*HPLs2[0*2+0]
          - 1.0/2*GHPLs1[0]*zeta2
          - 1.0/4*GHPLs1[0]*HPLs2[0*2+1]
          + 1.0/4*GHPLs3[3*4*4+2*4+1]*HPLs1[0]
          - 1.0/4*GHPLs4[0*4*4*4+3*4*4+2*4+1]
          - 1.0/4*GHPLs2[2*4+1]*zeta2
          + 1.0/4*GHPLs2[2*4+1]*HPLs2[0*2+0]
          - 1.0/4*GHPLs2[2*4+1]*HPLs2[0*2+1]
          - 1.0/4*GHPLs3[0*4*4+2*4+1]*HPLs1[0]
          - 1.0/4*GHPLs1[1]*zeta3
          + 1.0/4*GHPLs1[1]*HPLs1[0]*zeta2
          - 1.0/4*GHPLs1[1]*HPLs3[0*2*2+0*2+0]
          + 1.0/4*GHPLs1[1]*HPLs3[0*2*2+1*2+0]
          + 1.0/4*GHPLs1[1]*HPLs1[1]*zeta2
          - 1.0/4*GHPLs1[1]*HPLs3[0*2*2+0*2+1]
          + 1.0/4*GHPLs1[1]*HPLs3[0*2*2+1*2+1]
          + 1.0/4*GHPLs3[3*4*4+0*4+1]*HPLs1[0]
          - 1.0/4*GHPLs4[0*4*4*4+3*4*4+0*4+1]
          + 1.0/2*GHPLs2[0*4+1]*zeta2
          + 1.0/4*GHPLs2[0*4+1]*HPLs2[0*2+0]
          + 1.0/4*GHPLs2[0*4+1]*HPLs2[0*2+1]
          - 1.0/4*HPLs1[1]*zeta2
          + 1.0/4*HPLs2[0*2+1]
          + 1.0/2*HPLs3[0*2*2+0*2+1]
          - 1.0/4*HPLs3[0*2*2+1*2+1]
          )

       + (dN_c*dN_c-1)*pow(u,-1)*pow(v,2) * (
          - 1.0/2*zeta2
          - 1.0/4*zeta3
          + 1.0/4*GHPLs2[3*4+2]*HPLs1[0]
          - 1.0/4*GHPLs3[0*4*4+3*4+2]
          - 1.0/4*GHPLs1[2]*zeta2
          + 1.0/4*GHPLs1[2]*HPLs2[0*2+0]
          - 1.0/4*GHPLs1[2]*HPLs2[0*2+1]
          - 1.0/4*GHPLs2[0*4+2]*HPLs1[0]
          - 1.0/4*GHPLs1[3]*HPLs1[0]
          + 1.0/4*GHPLs2[0*4+3]
          + 1.0/4*GHPLs2[3*4+0]*HPLs1[0]
          - 1.0/4*GHPLs3[0*4*4+3*4+0]
          + 1.0/2*GHPLs1[0]*zeta2
          + 1.0/4*GHPLs1[0]*HPLs2[0*2+0]
          + 1.0/4*GHPLs1[0]*HPLs2[0*2+1]
          + 1.0/4*HPLs1[0]*zeta2
          - 1.0/4*HPLs2[0*2+0]
          - 1.0/4*HPLs3[0*2*2+0*2+0]
          + 1.0/4*HPLs3[0*2*2+1*2+0]
          + 1.0/4*HPLs1[1]*zeta2
          - 1.0/4*HPLs2[0*2+1]
          - 1.0/4*HPLs3[0*2*2+0*2+1]
          + 1.0/4*HPLs3[0*2*2+1*2+1]
          )

       + (dN_c*dN_c-1)*pow(1-u,-1) * (
          + 1.0/8*zeta2
          - 1.0/8*GHPLs1[3]*HPLs1[0]
          + 1.0/8*GHPLs2[0*4+3]
          + 1.0/8*GHPLs1[0]*HPLs1[0]
          - 1.0/8*HPLs2[0*2+0]
          + 1.0/8*HPLs2[0*2+1]
          )

       + (dN_c*dN_c-1)*pow(1-v,-1) * (
          - 7.0/48*zeta2
          + 1.0/8*zeta3
          - 1.0/8*GHPLs2[3*4+2]*HPLs1[0]
          + 1.0/8*GHPLs3[0*4*4+3*4+2]
          + 1.0/8*GHPLs1[2]*zeta2
          - 1.0/8*GHPLs1[2]*HPLs2[0*2+0]
          + 1.0/8*GHPLs1[2]*HPLs2[0*2+1]
          + 1.0/8*GHPLs2[0*4+2]*HPLs1[0]
          + 1.0/8*GHPLs1[3]*HPLs1[0]
          - 1.0/8*GHPLs2[0*4+3]
          + 1.0/8*GHPLs2[3*4+0]*HPLs1[0]
          - 1.0/8*GHPLs3[0*4*4+3*4+0]
          - 7.0/48*GHPLs1[0]*HPLs1[0]
          + 1.0/8*GHPLs1[0]*HPLs2[0*2+0]
          + 163.0/288*HPLs1[0]
          + 1.0/8*HPLs1[0]*zeta2
          + 25.0/24*HPLs2[0*2+0]
          - 1.0/8*HPLs3[0*2*2+0*2+0]
          + 1.0/8*HPLs3[0*2*2+1*2+0]
          - 7.0/48*HPLs2[0*2+1]
          + 1.0/8*HPLs3[0*2*2+0*2+1]
          )

       + (dN_c*dN_c-1) * (
          + 133.0/288
          + 7.0/48*zeta2
          - 1.0/8*zeta3
          + 1.0/8*GHPLs2[3*4+2]*HPLs1[0]
          - 1.0/8*GHPLs3[0*4*4+3*4+2]
          - 1.0/8*GHPLs1[2]*zeta2
          + 1.0/8*GHPLs1[2]*HPLs2[0*2+0]
          - 1.0/8*GHPLs1[2]*HPLs2[0*2+1]
          - 1.0/8*GHPLs2[0*4+2]*HPLs1[0]
          - 1.0/8*GHPLs1[3]*HPLs1[0]
          + 1.0/8*GHPLs2[0*4+3]
          - 1.0/8*GHPLs2[3*4+0]*HPLs1[0]
          + 1.0/8*GHPLs3[0*4*4+3*4+0]
          - 13.0/48*GHPLs1[0]
          + 7.0/48*GHPLs1[0]*HPLs1[0]
          - 1.0/8*GHPLs1[0]*HPLs2[0*2+0]
          - 31.0/288*HPLs1[0]
          - 1.0/8*HPLs1[0]*zeta2
          - 25.0/24*HPLs2[0*2+0]
          + 1.0/8*HPLs3[0*2*2+0*2+0]
          - 1.0/8*HPLs3[0*2*2+1*2+0]
          + 7.0/48*HPLs2[0*2+1]
          - 1.0/8*HPLs3[0*2*2+0*2+1]
          )

       + (dN_c*dN_c-1)*v*pow(1-u,-2) * (
          - 1.0/4*zeta2
          + 1.0/4*zeta3
          - 1.0/4*GHPLs2[3*4+2]*HPLs1[0]
          + 1.0/4*GHPLs3[0*4*4+3*4+2]
          + 1.0/4*GHPLs1[2]*zeta2
          - 1.0/4*GHPLs1[2]*HPLs2[0*2+0]
          + 1.0/4*GHPLs1[2]*HPLs2[0*2+1]
          + 1.0/4*GHPLs2[0*4+2]*HPLs1[0]
          + 1.0/4*GHPLs1[3]*HPLs1[0]
          - 1.0/4*GHPLs2[0*4+3]
          - 1.0/4*GHPLs2[3*4+0]*HPLs1[0]
          + 1.0/4*GHPLs3[0*4*4+3*4+0]
          - 1.0/2*GHPLs1[0]*zeta2
          - 1.0/4*GHPLs1[0]*HPLs1[0]
          - 1.0/4*GHPLs1[0]*HPLs2[0*2+0]
          - 1.0/4*GHPLs1[0]*HPLs2[0*2+1]
          - 1.0/4*HPLs1[0]*zeta2
          + 1.0/4*HPLs2[0*2+0]
          + 1.0/4*HPLs3[0*2*2+0*2+0]
          - 1.0/4*HPLs3[0*2*2+1*2+0]
          - 1.0/4*HPLs1[1]*zeta2
          - 1.0/4*HPLs2[0*2+1]
          + 1.0/4*HPLs3[0*2*2+0*2+1]
          - 1.0/4*HPLs3[0*2*2+1*2+1]
          )

       + (dN_c*dN_c-1)*v*pow(1-u,-1) * (
          - 1.0/8*zeta2
          - 3.0/8*zeta3
          + 3.0/8*GHPLs2[3*4+2]*HPLs1[0]
          - 3.0/8*GHPLs3[0*4*4+3*4+2]
          - 3.0/8*GHPLs1[2]*zeta2
          + 3.0/8*GHPLs1[2]*HPLs2[0*2+0]
          - 3.0/8*GHPLs1[2]*HPLs2[0*2+1]
          - 3.0/8*GHPLs2[0*4+2]*HPLs1[0]
          - 5.0/8*GHPLs1[3]*HPLs1[0]
          + 5.0/8*GHPLs2[0*4+3]
          + 3.0/8*GHPLs2[3*4+0]*HPLs1[0]
          - 3.0/8*GHPLs3[0*4*4+3*4+0]
          - 1.0/8*GHPLs1[0]
          + 3.0/4*GHPLs1[0]*zeta2
          + 3.0/8*GHPLs1[0]*HPLs1[0]
          + 3.0/8*GHPLs1[0]*HPLs2[0*2+0]
          + 3.0/8*GHPLs1[0]*HPLs2[0*2+1]
          + 3.0/8*HPLs1[0]*zeta2
          - 5.0/8*HPLs2[0*2+0]
          - 3.0/8*HPLs3[0*2*2+0*2+0]
          + 3.0/8*HPLs3[0*2*2+1*2+0]
          + 3.0/8*HPLs1[1]*zeta2
          + 1.0/8*HPLs2[0*2+1]
          - 3.0/8*HPLs3[0*2*2+0*2+1]
          + 3.0/8*HPLs3[0*2*2+1*2+1]
          )

       + (dN_c*dN_c-1)*pow(v,2)*pow(1-u,-3) * (
          - 1.0/4*zeta3
          + 1.0/4*GHPLs2[3*4+2]*HPLs1[0]
          - 1.0/4*GHPLs3[0*4*4+3*4+2]
          - 1.0/4*GHPLs1[2]*zeta2
          + 1.0/4*GHPLs1[2]*HPLs2[0*2+0]
          - 1.0/4*GHPLs1[2]*HPLs2[0*2+1]
          - 1.0/4*GHPLs2[0*4+2]*HPLs1[0]
          + 1.0/4*GHPLs2[3*4+0]*HPLs1[0]
          - 1.0/4*GHPLs3[0*4*4+3*4+0]
          + 1.0/2*GHPLs1[0]*zeta2
          + 1.0/4*GHPLs1[0]*HPLs2[0*2+0]
          + 1.0/4*GHPLs1[0]*HPLs2[0*2+1]
          + 1.0/4*HPLs1[0]*zeta2
          - 1.0/4*HPLs3[0*2*2+0*2+0]
          + 1.0/4*HPLs3[0*2*2+1*2+0]
          + 1.0/4*HPLs1[1]*zeta2
          - 1.0/4*HPLs3[0*2*2+0*2+1]
          + 1.0/4*HPLs3[0*2*2+1*2+1]
          )

       + (dN_c*dN_c-1)*pow(v,2)*pow(1-u,-2) * (
          + 1.0/2*zeta2
          + 3.0/8*zeta3
          - 3.0/8*GHPLs2[3*4+2]*HPLs1[0]
          + 3.0/8*GHPLs3[0*4*4+3*4+2]
          + 3.0/8*GHPLs1[2]*zeta2
          - 3.0/8*GHPLs1[2]*HPLs2[0*2+0]
          + 3.0/8*GHPLs1[2]*HPLs2[0*2+1]
          + 3.0/8*GHPLs2[0*4+2]*HPLs1[0]
          + 1.0/4*GHPLs1[3]*HPLs1[0]
          - 1.0/4*GHPLs2[0*4+3]
          - 3.0/8*GHPLs2[3*4+0]*HPLs1[0]
          + 3.0/8*GHPLs3[0*4*4+3*4+0]
          - 3.0/4*GHPLs1[0]*zeta2
          - 3.0/8*GHPLs1[0]*HPLs2[0*2+0]
          - 3.0/8*GHPLs1[0]*HPLs2[0*2+1]
          - 3.0/8*HPLs1[0]*zeta2
          + 1.0/4*HPLs2[0*2+0]
          + 3.0/8*HPLs3[0*2*2+0*2+0]
          - 3.0/8*HPLs3[0*2*2+1*2+0]
          - 3.0/8*HPLs1[1]*zeta2
          + 1.0/4*HPLs2[0*2+1]
          + 3.0/8*HPLs3[0*2*2+0*2+1]
          - 3.0/8*HPLs3[0*2*2+1*2+1]
          )

       + (dN_c*dN_c-1)*pow(v,2)*pow(1-u,-1) * (
          - 1.0/2*zeta2
          - 1.0/4*zeta3
          + 1.0/4*GHPLs2[3*4+2]*HPLs1[0]
          - 1.0/4*GHPLs3[0*4*4+3*4+2]
          - 1.0/4*GHPLs1[2]*zeta2
          + 1.0/4*GHPLs1[2]*HPLs2[0*2+0]
          - 1.0/4*GHPLs1[2]*HPLs2[0*2+1]
          - 1.0/4*GHPLs2[0*4+2]*HPLs1[0]
          - 1.0/4*GHPLs1[3]*HPLs1[0]
          + 1.0/4*GHPLs2[0*4+3]
          + 1.0/4*GHPLs2[3*4+0]*HPLs1[0]
          - 1.0/4*GHPLs3[0*4*4+3*4+0]
          + 1.0/2*GHPLs1[0]*zeta2
          + 1.0/4*GHPLs1[0]*HPLs2[0*2+0]
          + 1.0/4*GHPLs1[0]*HPLs2[0*2+1]
          + 1.0/4*HPLs1[0]*zeta2
          - 1.0/4*HPLs2[0*2+0]
          - 1.0/4*HPLs3[0*2*2+0*2+0]
          + 1.0/4*HPLs3[0*2*2+1*2+0]
          + 1.0/4*HPLs1[1]*zeta2
          - 1.0/4*HPLs2[0*2+1]
          - 1.0/4*HPLs3[0*2*2+0*2+1]
          + 1.0/4*HPLs3[0*2*2+1*2+1]
          )

       + (dN_c*dN_c-1)*u*pow(1-v,-2) * (
          + 13.0/48*zeta2
          - 1.0/8*zeta3
          + 1.0/8*GHPLs2[3*4+2]*HPLs1[0]
          - 1.0/8*GHPLs3[0*4*4+3*4+2]
          - 1.0/8*GHPLs1[2]*zeta2
          + 1.0/8*GHPLs1[2]*HPLs2[0*2+0]
          - 1.0/8*GHPLs1[2]*HPLs2[0*2+1]
          - 1.0/8*GHPLs2[0*4+2]*HPLs1[0]
          - 1.0/8*GHPLs2[3*4+0]*HPLs1[0]
          + 1.0/8*GHPLs3[0*4*4+3*4+0]
          + 13.0/48*GHPLs1[0]*HPLs1[0]
          - 1.0/8*GHPLs1[0]*HPLs2[0*2+0]
          - 163.0/288*HPLs1[0]
          - 1.0/8*HPLs1[0]*zeta2
          - 11.0/12*HPLs2[0*2+0]
          + 1.0/8*HPLs3[0*2*2+0*2+0]
          - 1.0/8*HPLs3[0*2*2+1*2+0]
          + 13.0/48*HPLs2[0*2+1]
          - 1.0/8*HPLs3[0*2*2+0*2+1]
          )

       + (dN_c*dN_c-1)*u*pow(1-v,-1) * (
          - 277.0/288
          - 19.0/48*zeta2
          + 1.0/8*zeta3
          - 1.0/8*GHPLs2[3*4+2]*HPLs1[0]
          + 1.0/8*GHPLs3[0*4*4+3*4+2]
          + 1.0/8*GHPLs1[2]*zeta2
          - 1.0/8*GHPLs1[2]*HPLs2[0*2+0]
          + 1.0/8*GHPLs1[2]*HPLs2[0*2+1]
          + 1.0/8*GHPLs2[0*4+2]*HPLs1[0]
          + 1.0/8*GHPLs1[3]*HPLs1[0]
          - 1.0/8*GHPLs2[0*4+3]
          + 1.0/8*GHPLs2[3*4+0]*HPLs1[0]
          - 1.0/8*GHPLs3[0*4*4+3*4+0]
          + 19.0/48*GHPLs1[0]
          - 19.0/48*GHPLs1[0]*HPLs1[0]
          + 1.0/8*GHPLs1[0]*HPLs2[0*2+0]
          + 31.0/288*HPLs1[0]
          + 1.0/8*HPLs1[0]*zeta2
          + 25.0/24*HPLs2[0*2+0]
          - 1.0/8*HPLs3[0*2*2+0*2+0]
          + 1.0/8*HPLs3[0*2*2+1*2+0]
          - 19.0/48*HPLs2[0*2+1]
          + 1.0/8*HPLs3[0*2*2+0*2+1]
          )

       + (dN_c*dN_c-1)*double_complex(0,1)*M_PI*pow(u,-2)*v * (
          + 1.0/4*GHPLs3[3*4*4+2*4+2]
          + 1.0/4*GHPLs2[2*4+2]*HPLs1[0]
          + 1.0/4*GHPLs1[2]*HPLs2[0*2+0]
          - 1.0/4*GHPLs3[3*4*4+0*4+2]
          + 1.0/4*GHPLs3[3*4*4+2*4+1]
          + 1.0/4*GHPLs2[2*4+1]*HPLs1[0]
          - 1.0/2*GHPLs1[1]*zeta2
          - 1.0/4*GHPLs1[1]*HPLs2[0*2+0]
          - 1.0/4*GHPLs1[1]*HPLs2[0*2+1]
          + 1.0/4*GHPLs3[3*4*4+0*4+1]
          )

       + (dN_c*dN_c-1)*double_complex(0,1)*M_PI*pow(u,-2)*pow(v,2) * (
          - 1.0/4*GHPLs3[3*4*4+2*4+2]
          - 1.0/4*GHPLs2[2*4+2]*HPLs1[0]
          - 1.0/4*GHPLs1[2]*HPLs2[0*2+0]
          + 1.0/4*GHPLs3[3*4*4+0*4+2]
          - 1.0/4*GHPLs3[3*4*4+2*4+1]
          - 1.0/4*GHPLs2[2*4+1]*HPLs1[0]
          + 1.0/2*GHPLs1[1]*zeta2
          + 1.0/4*GHPLs1[1]*HPLs2[0*2+0]
          + 1.0/4*GHPLs1[1]*HPLs2[0*2+1]
          - 1.0/4*GHPLs3[3*4*4+0*4+1]
          )

       + (dN_c*dN_c-1)*double_complex(0,1)*M_PI*pow(u,-1)*v * (
          - 1.0/2*zeta2
          - 1.0/4*GHPLs3[3*4*4+2*4+2]
          - 1.0/4*GHPLs2[2*4+2]*HPLs1[0]
          + 1.0/2*GHPLs2[3*4+2]
          + 1.0/2*GHPLs1[2]*HPLs1[0]
          - 1.0/4*GHPLs1[2]*HPLs2[0*2+0]
          + 1.0/4*GHPLs3[3*4*4+0*4+2]
          - 1.0/4*GHPLs3[3*4*4+2*4+1]
          - 1.0/4*GHPLs2[2*4+1]*HPLs1[0]
          + 1.0/2*GHPLs1[1]*zeta2
          + 1.0/4*GHPLs1[1]*HPLs2[0*2+0]
          + 1.0/4*GHPLs1[1]*HPLs2[0*2+1]
          - 1.0/4*GHPLs3[3*4*4+0*4+1]
          - 1.0/4*HPLs2[0*2+1]
          )

       + (dN_c*dN_c-1)*double_complex(0,1)*M_PI*pow(u,-1)*pow(v,2) * (
          + 1.0/2*zeta2
          - 1.0/4*GHPLs2[3*4+2]
          - 1.0/4*GHPLs1[2]*HPLs1[0]
          + 1.0/4*GHPLs1[3]
          - 1.0/4*GHPLs2[3*4+0]
          + 1.0/4*HPLs2[0*2+0]
          + 1.0/4*HPLs2[0*2+1]
          )

       + (dN_c*dN_c-1)*double_complex(0,1)*M_PI*pow(1-u,-1) * (
          + 1.0/8*GHPLs1[3]
          + 1.0/8*HPLs1[0]
          )

       + (dN_c*dN_c-1)*double_complex(0,1)*M_PI*pow(1-v,-1) * (
          + 1.0/8*GHPLs2[3*4+2]
          + 1.0/8*GHPLs1[2]*HPLs1[0]
          - 1.0/8*GHPLs1[3]
          - 1.0/8*GHPLs2[3*4+0]
          + 5.0/16*HPLs1[0]
          + 1.0/8*HPLs2[0*2+0]
          )

       + (dN_c*dN_c-1)*double_complex(0,1)*M_PI * (
          + 3.0/16
          - 1.0/8*GHPLs2[3*4+2]
          - 1.0/8*GHPLs1[2]*HPLs1[0]
          + 1.0/8*GHPLs1[3]
          + 1.0/8*GHPLs2[3*4+0]
          - 5.0/16*HPLs1[0]
          - 1.0/8*HPLs2[0*2+0]
          )

       + (dN_c*dN_c-1)*double_complex(0,1)*M_PI*v*pow(1-u,-2) * (
          - 1.0/2*zeta2
          + 1.0/4*GHPLs2[3*4+2]
          + 1.0/4*GHPLs1[2]*HPLs1[0]
          - 1.0/4*GHPLs1[3]
          + 1.0/4*GHPLs2[3*4+0]
          - 1.0/4*HPLs1[0]
          - 1.0/4*HPLs2[0*2+0]
          - 1.0/4*HPLs2[0*2+1]
          )

       + (dN_c*dN_c-1)*double_complex(0,1)*M_PI*v*pow(1-u,-1) * (
          - 1.0/8
          + 3.0/4*zeta2
          - 3.0/8*GHPLs2[3*4+2]
          - 3.0/8*GHPLs1[2]*HPLs1[0]
          + 5.0/8*GHPLs1[3]
          - 3.0/8*GHPLs2[3*4+0]
          + 3.0/8*HPLs1[0]
          + 3.0/8*HPLs2[0*2+0]
          + 3.0/8*HPLs2[0*2+1]
          )

       + (dN_c*dN_c-1)*double_complex(0,1)*M_PI*pow(v,2)*pow(1-u,-3) * (
          + 1.0/2*zeta2
          - 1.0/4*GHPLs2[3*4+2]
          - 1.0/4*GHPLs1[2]*HPLs1[0]
          - 1.0/4*GHPLs2[3*4+0]
          + 1.0/4*HPLs2[0*2+0]
          + 1.0/4*HPLs2[0*2+1]
          )

       + (dN_c*dN_c-1)*double_complex(0,1)*M_PI*pow(v,2)*pow(1-u,-2) * (
          - 3.0/4*zeta2
          + 3.0/8*GHPLs2[3*4+2]
          + 3.0/8*GHPLs1[2]*HPLs1[0]
          - 1.0/4*GHPLs1[3]
          + 3.0/8*GHPLs2[3*4+0]
          - 3.0/8*HPLs2[0*2+0]
          - 3.0/8*HPLs2[0*2+1]
          )

       + (dN_c*dN_c-1)*double_complex(0,1)*M_PI*pow(v,2)*pow(1-u,-1) * (
          + 1.0/2*zeta2
          - 1.0/4*GHPLs2[3*4+2]
          - 1.0/4*GHPLs1[2]*HPLs1[0]
          + 1.0/4*GHPLs1[3]
          - 1.0/4*GHPLs2[3*4+0]
          + 1.0/4*HPLs2[0*2+0]
          + 1.0/4*HPLs2[0*2+1]
          )

       + (dN_c*dN_c-1)*double_complex(0,1)*M_PI*u*pow(1-v,-2) * (
          - 1.0/8*GHPLs2[3*4+2]
          - 1.0/8*GHPLs1[2]*HPLs1[0]
          + 1.0/8*GHPLs2[3*4+0]
          - 3.0/16*HPLs1[0]
          - 1.0/8*HPLs2[0*2+0]
          )

       + (dN_c*dN_c-1)*double_complex(0,1)*M_PI*u*pow(1-v,-1) * (
          - 1.0/16
          + 1.0/8*GHPLs2[3*4+2]
          + 1.0/8*GHPLs1[2]*HPLs1[0]
          - 1.0/8*GHPLs1[3]
          - 1.0/8*GHPLs2[3*4+0]
          + 1.0/16*HPLs1[0]
          + 1.0/8*HPLs2[0*2+0]
          )

       + (dN_c*dN_c-1)/(dN_c*dN_c)*pow(u,-2)*v * (
          + 1.0/4*GHPLs3[3*4*4+2*4+2]*HPLs1[0]
          - 1.0/4*GHPLs4[0*4*4*4+3*4*4+2*4+2]
          - 1.0/4*GHPLs2[2*4+2]*zeta2
          + 1.0/4*GHPLs2[2*4+2]*HPLs2[0*2+0]
          - 1.0/4*GHPLs2[2*4+2]*HPLs2[0*2+1]
          - 1.0/4*GHPLs3[0*4*4+2*4+2]*HPLs1[0]
          + 3.0/8*GHPLs1[2]*zeta2
          - 1.0/4*GHPLs1[2]*zeta3
          + 1.0/4*GHPLs1[2]*HPLs1[0]
          - 1.0/4*GHPLs1[2]*HPLs1[0]*zeta2
          - 1.0/8*GHPLs1[2]*HPLs2[0*2+0]
          + 1.0/4*GHPLs1[2]*HPLs3[0*2*2+0*2+0]
          - 1.0/4*GHPLs1[2]*HPLs2[1*2+0]
          - 1.0/4*GHPLs1[2]*HPLs3[0*2*2+1*2+0]
          + 1.0/8*GHPLs1[2]*HPLs2[0*2+1]
          - 1.0/4*GHPLs1[2]*HPLs3[0*2*2+0*2+1]
          - 1.0/4*GHPLs3[3*4*4+0*4+2]*HPLs1[0]
          + 1.0/4*GHPLs4[0*4*4*4+3*4*4+0*4+2]
          - 1.0/4*GHPLs2[0*4+2]*HPLs2[0*2+0]
          - 1.0/4*GHPLs3[2*4*4+1*4+2]
          + 1.0/4*GHPLs2[1*4+2]*HPLs1[0]
          + 1.0/4*GHPLs2[1*4+2]*HPLs1[1]
          + 1.0/8*GHPLs2[2*4+0]*HPLs1[0]
          + 1.0/8*GHPLs3[2*4*4+1*4+0]
          - 1.0/8*GHPLs2[1*4+0]*HPLs1[0]
          - 1.0/8*GHPLs2[1*4+0]*HPLs1[1]
          + 1.0/4*GHPLs3[3*4*4+2*4+1]*HPLs1[0]
          - 1.0/4*GHPLs4[0*4*4*4+3*4*4+2*4+1]
          + 1.0/4*GHPLs2[2*4+1]
          - 1.0/4*GHPLs2[2*4+1]*zeta2
          + 1.0/4*GHPLs2[2*4+1]*HPLs2[0*2+0]
          - 1.0/4*GHPLs2[2*4+1]*HPLs2[0*2+1]
          - 1.0/4*GHPLs3[0*4*4+2*4+1]*HPLs1[0]
          - 1.0/4*GHPLs1[1]*zeta2
          - 1.0/4*GHPLs1[1]*zeta3
          - 1.0/4*GHPLs1[1]*HPLs1[0]
          + 1.0/4*GHPLs1[1]*HPLs1[0]*zeta2
          + 1.0/8*GHPLs1[1]*HPLs2[0*2+0]
          - 1.0/4*GHPLs1[1]*HPLs3[0*2*2+0*2+0]
          + 1.0/8*GHPLs1[1]*HPLs2[1*2+0]
          + 1.0/4*GHPLs1[1]*HPLs3[0*2*2+1*2+0]
          - 1.0/4*GHPLs1[1]*HPLs1[1]
          + 1.0/4*GHPLs1[1]*HPLs1[1]*zeta2
          - 1.0/4*GHPLs1[1]*HPLs3[0*2*2+0*2+1]
          + 1.0/4*GHPLs1[1]*HPLs3[0*2*2+1*2+1]
          + 1.0/4*GHPLs3[3*4*4+0*4+1]*HPLs1[0]
          - 1.0/4*GHPLs4[0*4*4*4+3*4*4+0*4+1]
          + 1.0/2*GHPLs2[0*4+1]*zeta2
          + 1.0/4*GHPLs2[0*4+1]*HPLs2[0*2+0]
          + 1.0/4*GHPLs2[0*4+1]*HPLs2[0*2+1]
          + 1.0/8*GHPLs3[2*4*4+1*4+1]
          - 1.0/8*GHPLs2[1*4+1]*HPLs1[0]
          - 1.0/8*GHPLs2[1*4+1]*HPLs1[1]
          )

       + (dN_c*dN_c-1)/(dN_c*dN_c)*pow(u,-2)*pow(v,2) * (
          - 1.0/4*GHPLs3[3*4*4+2*4+2]*HPLs1[0]
          + 1.0/4*GHPLs4[0*4*4*4+3*4*4+2*4+2]
          + 1.0/4*GHPLs2[2*4+2]*zeta2
          - 1.0/4*GHPLs2[2*4+2]*HPLs2[0*2+0]
          + 1.0/4*GHPLs2[2*4+2]*HPLs2[0*2+1]
          + 1.0/4*GHPLs3[0*4*4+2*4+2]*HPLs1[0]
          - 3.0/8*GHPLs1[2]*zeta2
          + 1.0/4*GHPLs1[2]*zeta3
          - 1.0/8*GHPLs1[2]*HPLs1[0]
          + 1.0/4*GHPLs1[2]*HPLs1[0]*zeta2
          + 1.0/8*GHPLs1[2]*HPLs2[0*2+0]
          - 1.0/4*GHPLs1[2]*HPLs3[0*2*2+0*2+0]
          + 1.0/4*GHPLs1[2]*HPLs2[1*2+0]
          + 1.0/4*GHPLs1[2]*HPLs3[0*2*2+1*2+0]
          - 1.0/8*GHPLs1[2]*HPLs2[0*2+1]
          + 1.0/4*GHPLs1[2]*HPLs3[0*2*2+0*2+1]
          + 1.0/4*GHPLs3[3*4*4+0*4+2]*HPLs1[0]
          - 1.0/4*GHPLs4[0*4*4*4+3*4*4+0*4+2]
          + 1.0/4*GHPLs2[0*4+2]*HPLs2[0*2+0]
          + 1.0/4*GHPLs3[2*4*4+1*4+2]
          - 1.0/4*GHPLs2[1*4+2]*HPLs1[0]
          - 1.0/4*GHPLs2[1*4+2]*HPLs1[1]
          - 1.0/8*GHPLs2[2*4+0]*HPLs1[0]
          - 1.0/8*GHPLs3[2*4*4+1*4+0]
          + 1.0/8*GHPLs2[1*4+0]*HPLs1[0]
          + 1.0/8*GHPLs2[1*4+0]*HPLs1[1]
          - 1.0/4*GHPLs3[3*4*4+2*4+1]*HPLs1[0]
          + 1.0/4*GHPLs4[0*4*4*4+3*4*4+2*4+1]
          - 1.0/8*GHPLs2[2*4+1]
          + 1.0/4*GHPLs2[2*4+1]*zeta2
          - 1.0/4*GHPLs2[2*4+1]*HPLs2[0*2+0]
          + 1.0/4*GHPLs2[2*4+1]*HPLs2[0*2+1]
          + 1.0/4*GHPLs3[0*4*4+2*4+1]*HPLs1[0]
          + 1.0/4*GHPLs1[1]*zeta2
          + 1.0/4*GHPLs1[1]*zeta3
          + 1.0/8*GHPLs1[1]*HPLs1[0]
          - 1.0/4*GHPLs1[1]*HPLs1[0]*zeta2
          - 1.0/8*GHPLs1[1]*HPLs2[0*2+0]
          + 1.0/4*GHPLs1[1]*HPLs3[0*2*2+0*2+0]
          - 1.0/8*GHPLs1[1]*HPLs2[1*2+0]
          - 1.0/4*GHPLs1[1]*HPLs3[0*2*2+1*2+0]
          + 1.0/8*GHPLs1[1]*HPLs1[1]
          - 1.0/4*GHPLs1[1]*HPLs1[1]*zeta2
          + 1.0/4*GHPLs1[1]*HPLs3[0*2*2+0*2+1]
          - 1.0/4*GHPLs1[1]*HPLs3[0*2*2+1*2+1]
          - 1.0/4*GHPLs3[3*4*4+0*4+1]*HPLs1[0]
          + 1.0/4*GHPLs4[0*4*4*4+3*4*4+0*4+1]
          - 1.0/2*GHPLs2[0*4+1]*zeta2
          - 1.0/4*GHPLs2[0*4+1]*HPLs2[0*2+0]
          - 1.0/4*GHPLs2[0*4+1]*HPLs2[0*2+1]
          - 1.0/8*GHPLs3[2*4*4+1*4+1]
          + 1.0/8*GHPLs2[1*4+1]*HPLs1[0]
          + 1.0/8*GHPLs2[1*4+1]*HPLs1[1]
          )

       + (dN_c*dN_c-1)/(dN_c*dN_c)*pow(u,-2)*pow(v,3) * (
          - 1.0/8*GHPLs1[2]*zeta2
          - 1.0/8*GHPLs1[2]*HPLs1[0]
          - 1.0/8*GHPLs1[2]*HPLs2[0*2+0]
          + 1.0/8*GHPLs1[2]*HPLs2[1*2+0]
          + 1.0/8*GHPLs2[0*4+2]*HPLs1[0]
          + 1.0/8*GHPLs3[2*4*4+1*4+2]
          - 1.0/8*GHPLs2[1*4+2]*HPLs1[0]
          - 1.0/8*GHPLs2[1*4+2]*HPLs1[1]
          + 1.0/8*GHPLs2[2*4+3]*HPLs1[0]
          - 1.0/8*GHPLs3[0*4*4+2*4+3]
          - 1.0/8*GHPLs2[3*4+3]*HPLs1[0]
          + 1.0/8*GHPLs3[0*4*4+3*4+3]
          + 5.0/8*GHPLs1[3]*zeta2
          - 1.0/8*GHPLs1[3]*HPLs2[1*2+0]
          - 1.0/8*GHPLs1[3]*HPLs2[0*2+1]
          - 1.0/8*GHPLs3[2*4*4+0*4+3]
          + 1.0/8*GHPLs2[0*4+3]*HPLs1[1]
          - 1.0/8*GHPLs2[2*4+1]
          + 1.0/8*GHPLs1[1]*HPLs1[0]
          + 1.0/8*GHPLs1[1]*HPLs1[1]
          )

       + (dN_c*dN_c-1)/(dN_c*dN_c)*pow(u,-2)*pow(v,4) * (
          + 1.0/8*GHPLs1[2]*zeta2
          + 1.0/8*GHPLs1[2]*HPLs2[0*2+0]
          - 1.0/8*GHPLs1[2]*HPLs2[1*2+0]
          - 1.0/8*GHPLs2[0*4+2]*HPLs1[0]
          - 1.0/8*GHPLs3[2*4*4+1*4+2]
          + 1.0/8*GHPLs2[1*4+2]*HPLs1[0]
          + 1.0/8*GHPLs2[1*4+2]*HPLs1[1]
          - 1.0/8*GHPLs2[2*4+3]*HPLs1[0]
          + 1.0/8*GHPLs3[0*4*4+2*4+3]
          + 1.0/8*GHPLs2[3*4+3]*HPLs1[0]
          - 1.0/8*GHPLs3[0*4*4+3*4+3]
          - 5.0/8*GHPLs1[3]*zeta2
          + 1.0/8*GHPLs1[3]*HPLs2[1*2+0]
          + 1.0/8*GHPLs1[3]*HPLs2[0*2+1]
          + 1.0/8*GHPLs3[2*4*4+0*4+3]
          - 1.0/8*GHPLs2[0*4+3]*HPLs1[1]
          )

       + (dN_c*dN_c-1)/(dN_c*dN_c)*pow(u,-1) * (
          + 1.0/8*GHPLs1[2]*HPLs1[0]
          + 1.0/8*GHPLs2[2*4+1]
          - 1.0/8*GHPLs1[1]*HPLs1[0]
          - 1.0/8*GHPLs1[1]*HPLs1[1]
          )

       + (dN_c*dN_c-1)/(dN_c*dN_c)*pow(u,-1)*v * (
          + 1.0/2
          - 3.0/8*zeta2
          - 1.0/2*zeta3
          - 1.0/4*GHPLs3[3*4*4+2*4+2]*HPLs1[0]
          + 1.0/4*GHPLs4[0*4*4*4+3*4*4+2*4+2]
          + 1.0/4*GHPLs2[2*4+2]*zeta2
          - 1.0/4*GHPLs2[2*4+2]*HPLs2[0*2+0]
          + 1.0/4*GHPLs2[2*4+2]*HPLs2[0*2+1]
          + 1.0/4*GHPLs3[0*4*4+2*4+2]*HPLs1[0]
          + 1.0/2*GHPLs2[3*4+2]*HPLs1[0]
          - 1.0/2*GHPLs3[0*4*4+3*4+2]
          + 3.0/8*GHPLs1[2]
          - 7.0/8*GHPLs1[2]*zeta2
          + 1.0/4*GHPLs1[2]*zeta3
          + 3.0/8*GHPLs1[2]*HPLs1[0]
          + 1.0/4*GHPLs1[2]*HPLs1[0]*zeta2
          + 5.0/8*GHPLs1[2]*HPLs2[0*2+0]
          - 1.0/4*GHPLs1[2]*HPLs3[0*2*2+0*2+0]
          + 1.0/4*GHPLs1[2]*HPLs2[1*2+0]
          + 1.0/4*GHPLs1[2]*HPLs3[0*2*2+1*2+0]
          - 5.0/8*GHPLs1[2]*HPLs2[0*2+1]
          + 1.0/4*GHPLs1[2]*HPLs3[0*2*2+0*2+1]
          + 1.0/4*GHPLs3[3*4*4+0*4+2]*HPLs1[0]
          - 1.0/4*GHPLs4[0*4*4*4+3*4*4+0*4+2]
          - 1.0/2*GHPLs2[0*4+2]*HPLs1[0]
          + 1.0/4*GHPLs2[0*4+2]*HPLs2[0*2+0]
          + 1.0/4*GHPLs3[2*4*4+1*4+2]
          - 1.0/4*GHPLs2[1*4+2]*HPLs1[0]
          - 1.0/4*GHPLs2[1*4+2]*HPLs1[1]
          - 1.0/8*GHPLs2[2*4+0]*HPLs1[0]
          + 1.0/2*GHPLs1[0]*zeta2
          + 1.0/4*GHPLs1[0]*HPLs2[0*2+1]
          - 1.0/8*GHPLs3[2*4*4+1*4+0]
          + 1.0/8*GHPLs2[1*4+0]*HPLs1[0]
          + 1.0/8*GHPLs2[1*4+0]*HPLs1[1]
          - 1.0/4*GHPLs3[3*4*4+2*4+1]*HPLs1[0]
          + 1.0/4*GHPLs4[0*4*4*4+3*4*4+2*4+1]
          + 1.0/4*GHPLs2[2*4+1]
          + 1.0/4*GHPLs2[2*4+1]*zeta2
          - 1.0/4*GHPLs2[2*4+1]*HPLs2[0*2+0]
          + 1.0/4*GHPLs2[2*4+1]*HPLs2[0*2+1]
          + 1.0/4*GHPLs3[0*4*4+2*4+1]*HPLs1[0]
          + 1.0/4*GHPLs1[1]*zeta2
          + 1.0/4*GHPLs1[1]*zeta3
          - 1.0/4*GHPLs1[1]*HPLs1[0]
          - 1.0/4*GHPLs1[1]*HPLs1[0]*zeta2
          - 1.0/8*GHPLs1[1]*HPLs2[0*2+0]
          + 1.0/4*GHPLs1[1]*HPLs3[0*2*2+0*2+0]
          - 1.0/8*GHPLs1[1]*HPLs2[1*2+0]
          - 1.0/4*GHPLs1[1]*HPLs3[0*2*2+1*2+0]
          - 1.0/4*GHPLs1[1]*HPLs1[1]
          - 1.0/4*GHPLs1[1]*HPLs1[1]*zeta2
          + 1.0/4*GHPLs1[1]*HPLs3[0*2*2+0*2+1]
          - 1.0/4*GHPLs1[1]*HPLs3[0*2*2+1*2+1]
          - 1.0/4*GHPLs3[3*4*4+0*4+1]*HPLs1[0]
          + 1.0/4*GHPLs4[0*4*4*4+3*4*4+0*4+1]
          - 1.0/2*GHPLs2[0*4+1]*zeta2
          - 1.0/4*GHPLs2[0*4+1]*HPLs2[0*2+0]
          - 1.0/4*GHPLs2[0*4+1]*HPLs2[0*2+1]
          - 1.0/8*GHPLs3[2*4*4+1*4+1]
          + 1.0/8*GHPLs2[1*4+1]*HPLs1[0]
          + 1.0/8*GHPLs2[1*4+1]*HPLs1[1]
          - 1.0/8*HPLs2[1*2+0]
          - 3.0/8*HPLs1[1]
          + 1.0/4*HPLs1[1]*zeta2
          - 1.0/8*HPLs2[0*2+1]
          - 1.0/2*HPLs3[0*2*2+0*2+1]
          + 1.0/4*HPLs3[0*2*2+1*2+1]
          )

       + (dN_c*dN_c-1)/(dN_c*dN_c)*pow(u,-1)*pow(v,2) * (
          + 1.0/8*zeta2
          + 1.0/4*zeta3
          - 1.0/4*GHPLs2[3*4+2]*HPLs1[0]
          + 1.0/4*GHPLs3[0*4*4+3*4+2]
          - 3.0/8*GHPLs1[2]
          - 3.0/4*GHPLs1[2]*HPLs1[0]
          - 1.0/2*GHPLs1[2]*HPLs2[0*2+0]
          + 1.0/4*GHPLs1[2]*HPLs2[1*2+0]
          + 1.0/4*GHPLs1[2]*HPLs2[0*2+1]
          + 1.0/8*GHPLs2[0*4+2]
          + 1.0/2*GHPLs2[0*4+2]*HPLs1[0]
          + 1.0/4*GHPLs3[2*4*4+1*4+2]
          - 1.0/4*GHPLs2[1*4+2]*HPLs1[0]
          - 1.0/4*GHPLs2[1*4+2]*HPLs1[1]
          + 1.0/4*GHPLs2[2*4+3]*HPLs1[0]
          - 1.0/4*GHPLs3[0*4*4+2*4+3]
          - 1.0/4*GHPLs2[3*4+3]*HPLs1[0]
          + 1.0/4*GHPLs3[0*4*4+3*4+3]
          + 5.0/4*GHPLs1[3]*zeta2
          + 3.0/8*GHPLs1[3]*HPLs1[0]
          - 1.0/4*GHPLs1[3]*HPLs2[1*2+0]
          - 1.0/4*GHPLs1[3]*HPLs2[0*2+1]
          - 1.0/4*GHPLs3[2*4*4+0*4+3]
          - 3.0/8*GHPLs2[0*4+3]
          + 1.0/4*GHPLs2[0*4+3]*HPLs1[1]
          + 1.0/8*GHPLs2[2*4+0]
          - 1.0/4*GHPLs2[3*4+0]*HPLs1[0]
          + 1.0/4*GHPLs3[0*4*4+3*4+0]
          - 1.0/2*GHPLs1[0]*zeta2
          - 1.0/4*GHPLs1[0]*HPLs2[0*2+0]
          - 1.0/8*GHPLs1[0]*HPLs1[1]
          - 1.0/4*GHPLs1[0]*HPLs2[0*2+1]
          - 3.0/4*GHPLs2[2*4+1]
          + 3.0/4*GHPLs1[1]*HPLs1[0]
          + 3.0/4*GHPLs1[1]*HPLs1[1]
          + 3.0/8*HPLs1[0]
          - 1.0/4*HPLs1[0]*zeta2
          + 1.0/8*HPLs2[0*2+0]
          + 1.0/4*HPLs3[0*2*2+0*2+0]
          - 1.0/4*HPLs3[0*2*2+1*2+0]
          + 3.0/8*HPLs1[1]
          - 1.0/4*HPLs1[1]*zeta2
          + 3.0/8*HPLs2[0*2+1]
          + 1.0/4*HPLs3[0*2*2+0*2+1]
          - 1.0/4*HPLs3[0*2*2+1*2+1]
          )

       + (dN_c*dN_c-1)/(dN_c*dN_c)*pow(u,-1)*pow(v,3) * (
          + 1.0/2*zeta2
          + 3.0/8*GHPLs1[2]*zeta2
          + 1.0/8*GHPLs1[2]*HPLs1[0]
          + 3.0/8*GHPLs1[2]*HPLs2[0*2+0]
          - 3.0/8*GHPLs1[2]*HPLs2[1*2+0]
          - 1.0/8*GHPLs2[0*4+2]
          - 3.0/8*GHPLs2[0*4+2]*HPLs1[0]
          - 3.0/8*GHPLs3[2*4*4+1*4+2]
          + 3.0/8*GHPLs2[1*4+2]*HPLs1[0]
          + 3.0/8*GHPLs2[1*4+2]*HPLs1[1]
          - 3.0/8*GHPLs2[2*4+3]*HPLs1[0]
          + 3.0/8*GHPLs3[0*4*4+2*4+3]
          + 3.0/8*GHPLs2[3*4+3]*HPLs1[0]
          - 3.0/8*GHPLs3[0*4*4+3*4+3]
          - 15.0/8*GHPLs1[3]*zeta2
          - 1.0/8*GHPLs1[3]*HPLs1[0]
          + 3.0/8*GHPLs1[3]*HPLs2[1*2+0]
          + 3.0/8*GHPLs1[3]*HPLs2[0*2+1]
          + 3.0/8*GHPLs3[2*4*4+0*4+3]
          + 1.0/8*GHPLs2[0*4+3]
          - 3.0/8*GHPLs2[0*4+3]*HPLs1[1]
          - 1.0/8*GHPLs2[2*4+0]
          + 1.0/8*GHPLs1[0]*HPLs1[0]
          + 1.0/8*GHPLs1[0]*HPLs1[1]
          + 1.0/8*GHPLs2[2*4+1]
          - 1.0/8*GHPLs1[1]*HPLs1[0]
          - 1.0/8*GHPLs1[1]*HPLs1[1]
          - 1.0/8*HPLs2[0*2+0]
          - 1.0/8*HPLs2[0*2+1]
          )

       + (dN_c*dN_c-1)/(dN_c*dN_c)*pow(1-u,-1) * (
          + 1.0/4*zeta2
          - 1.0/4*GHPLs1[3]*HPLs1[0]
          + 1.0/4*GHPLs2[0*4+3]
          + 1.0/4*GHPLs1[0]*HPLs1[0]
          - 1.0/4*HPLs2[0*2+0]
          + 1.0/4*HPLs2[0*2+1]
          )

       + (dN_c*dN_c-1)/(dN_c*dN_c)*pow(1-v,-1) * (
          + 15.0/16*zeta2
          + 3.0/4*zeta3
          + 1.0/2*GHPLs2[3*4+2]*HPLs1[0]
          - 1.0/2*GHPLs3[0*4*4+3*4+2]
          - 3.0/4*GHPLs1[2]*zeta2
          - 7.0/8*GHPLs1[2]*HPLs1[0]
          + 3.0/4*GHPLs1[2]*HPLs2[0*2+0]
          + 7.0/8*GHPLs1[2]*HPLs2[1*2+0]
          + 1.0/8*GHPLs1[2]*HPLs2[0*2+1]
          + 1.0/8*GHPLs2[0*4+2]*HPLs1[0]
          + 7.0/8*GHPLs3[2*4*4+1*4+2]
          - 7.0/8*GHPLs2[1*4+2]*HPLs1[0]
          - 7.0/8*GHPLs2[1*4+2]*HPLs1[1]
          - 13.0/8*GHPLs1[3]*HPLs1[0]
          + 13.0/8*GHPLs2[0*4+3]
          - 1.0/4*GHPLs2[2*4+0]*HPLs1[0]
          - 1.0/2*GHPLs2[3*4+0]*HPLs1[0]
          + 1.0/2*GHPLs3[0*4*4+3*4+0]
          + 5.0/8*GHPLs1[0]*zeta2
          - 3.0/16*GHPLs1[0]*HPLs1[0]
          - 3.0/4*GHPLs1[0]*HPLs2[0*2+0]
          - 5.0/8*GHPLs1[0]*HPLs2[1*2+0]
          - 7.0/8*GHPLs3[2*4*4+1*4+0]
          + 7.0/8*GHPLs2[1*4+0]*HPLs1[0]
          + 7.0/8*GHPLs2[1*4+0]*HPLs1[1]
          - 2*GHPLs2[2*4+1]
          + 2*GHPLs1[1]*HPLs1[0]
          + 2*GHPLs1[1]*HPLs1[1]
          + 15.0/32*HPLs1[0]
          - 19.0/8*HPLs1[0]*zeta2
          - 11.0/8*HPLs2[0*2+0]
          + 1.0/2*HPLs3[0*2*2+0*2+0]
          - 1.0/4*HPLs3[1*2*2+0*2+0]
          - 9.0/8*HPLs2[1*2+0]
          + 1.0/2*HPLs3[0*2*2+1*2+0]
          + 5.0/8*HPLs1[1]*zeta2
          - 3.0/16*HPLs2[0*2+1]
          - 3.0/4*HPLs3[0*2*2+0*2+1]
          - 5.0/8*HPLs3[1*2*2+0*2+1]
          )

       + (dN_c*dN_c-1)/(dN_c*dN_c) * (
          + 33.0/32
          - 21.0/16*zeta2
          - 3.0/4*zeta3
          - 1.0/2*GHPLs2[3*4+2]*HPLs1[0]
          + 1.0/2*GHPLs3[0*4*4+3*4+2]
          + 3.0/8*GHPLs1[2]
          + 3.0/4*GHPLs1[2]*zeta2
          + 1.0/2*GHPLs1[2]*HPLs1[0]
          - 3.0/4*GHPLs1[2]*HPLs2[0*2+0]
          - 7.0/8*GHPLs1[2]*HPLs2[1*2+0]
          - 1.0/8*GHPLs1[2]*HPLs2[0*2+1]
          - 1.0/8*GHPLs2[0*4+2]*HPLs1[0]
          - 7.0/8*GHPLs3[2*4*4+1*4+2]
          + 7.0/8*GHPLs2[1*4+2]*HPLs1[0]
          + 7.0/8*GHPLs2[1*4+2]*HPLs1[1]
          + 2*GHPLs1[3]*HPLs1[0]
          - 2*GHPLs2[0*4+3]
          + 1.0/4*GHPLs2[2*4+0]*HPLs1[0]
          + 1.0/2*GHPLs2[3*4+0]*HPLs1[0]
          - 1.0/2*GHPLs3[0*4*4+3*4+0]
          - 3.0/16*GHPLs1[0]
          - 5.0/8*GHPLs1[0]*zeta2
          - 3.0/16*GHPLs1[0]*HPLs1[0]
          + 3.0/4*GHPLs1[0]*HPLs2[0*2+0]
          + 5.0/8*GHPLs1[0]*HPLs2[1*2+0]
          + 7.0/8*GHPLs3[2*4*4+1*4+0]
          - 7.0/8*GHPLs2[1*4+0]*HPLs1[0]
          - 7.0/8*GHPLs2[1*4+0]*HPLs1[1]
          + 13.0/8*GHPLs2[2*4+1]
          - 13.0/8*GHPLs1[1]*HPLs1[0]
          - 13.0/8*GHPLs1[1]*HPLs1[1]
          - 15.0/32*HPLs1[0]
          + 19.0/8*HPLs1[0]*zeta2
          + 7.0/4*HPLs2[0*2+0]
          - 1.0/2*HPLs3[0*2*2+0*2+0]
          + 1.0/4*HPLs3[1*2*2+0*2+0]
          + 9.0/8*HPLs2[1*2+0]
          - 1.0/2*HPLs3[0*2*2+1*2+0]
          - 3.0/8*HPLs1[1]
          - 5.0/8*HPLs1[1]*zeta2
          - 3.0/16*HPLs2[0*2+1]
          + 3.0/4*HPLs3[0*2*2+0*2+1]
          + 5.0/8*HPLs3[1*2*2+0*2+1]
          )

       + (dN_c*dN_c-1)/(dN_c*dN_c)*v*pow(1-u,-2) * (
          - 1.0/2*zeta2
          + 1.0/2*zeta3
          - 1.0/2*GHPLs2[3*4+2]*HPLs1[0]
          + 1.0/2*GHPLs3[0*4*4+3*4+2]
          + 1.0/2*GHPLs1[2]*zeta2
          - 1.0/2*GHPLs1[2]*HPLs2[0*2+0]
          + 1.0/2*GHPLs1[2]*HPLs2[0*2+1]
          + 1.0/2*GHPLs2[0*4+2]*HPLs1[0]
          + 1.0/2*GHPLs1[3]*HPLs1[0]
          - 1.0/2*GHPLs2[0*4+3]
          - 1.0/2*GHPLs2[3*4+0]*HPLs1[0]
          + 1.0/2*GHPLs3[0*4*4+3*4+0]
          - GHPLs1[0]*zeta2
          - 1.0/2*GHPLs1[0]*HPLs1[0]
          - 1.0/2*GHPLs1[0]*HPLs2[0*2+0]
          - 1.0/2*GHPLs1[0]*HPLs2[0*2+1]
          - 1.0/2*HPLs1[0]*zeta2
          + 1.0/2*HPLs2[0*2+0]
          + 1.0/2*HPLs3[0*2*2+0*2+0]
          - 1.0/2*HPLs3[0*2*2+1*2+0]
          - 1.0/2*HPLs1[1]*zeta2
          - 1.0/2*HPLs2[0*2+1]
          + 1.0/2*HPLs3[0*2*2+0*2+1]
          - 1.0/2*HPLs3[0*2*2+1*2+1]
          )

       + (dN_c*dN_c-1)/(dN_c*dN_c)*v*pow(1-u,-1) * (
          - 3.0/4*zeta2
          - 1.0/4*zeta3
          + 1.0/4*GHPLs2[3*4+2]*HPLs1[0]
          - 1.0/4*GHPLs3[0*4*4+3*4+2]
          - 1.0/4*GHPLs1[2]*zeta2
          + 1.0/4*GHPLs1[2]*HPLs2[0*2+0]
          - 1.0/4*GHPLs1[2]*HPLs2[0*2+1]
          - 1.0/4*GHPLs2[0*4+2]*HPLs1[0]
          - 3.0/4*GHPLs1[3]*HPLs1[0]
          + 3.0/4*GHPLs2[0*4+3]
          + 1.0/4*GHPLs2[3*4+0]*HPLs1[0]
          - 1.0/4*GHPLs3[0*4*4+3*4+0]
          - 1.0/4*GHPLs1[0]
          + 1.0/2*GHPLs1[0]*zeta2
          + 1.0/4*GHPLs1[0]*HPLs1[0]
          + 1.0/4*GHPLs1[0]*HPLs2[0*2+0]
          + 1.0/4*GHPLs1[0]*HPLs2[0*2+1]
          + 1.0/4*HPLs1[0]*zeta2
          - 3.0/4*HPLs2[0*2+0]
          - 1.0/4*HPLs3[0*2*2+0*2+0]
          + 1.0/4*HPLs3[0*2*2+1*2+0]
          + 1.0/4*HPLs1[1]*zeta2
          - 1.0/4*HPLs2[0*2+1]
          - 1.0/4*HPLs3[0*2*2+0*2+1]
          + 1.0/4*HPLs3[0*2*2+1*2+1]
          )

       + (dN_c*dN_c-1)/(dN_c*dN_c)*v * (
          - 37.0/8*zeta2
          + 3.0/8*GHPLs1[2]
          - 1.0/8*GHPLs1[2]*zeta2
          - 7.0/4*GHPLs1[2]*HPLs1[0]
          - 1.0/8*GHPLs1[2]*HPLs2[0*2+0]
          + 1.0/8*GHPLs1[2]*HPLs2[1*2+0]
          + 9.0/8*GHPLs2[0*4+2]
          + 1.0/8*GHPLs2[0*4+2]*HPLs1[0]
          + 1.0/8*GHPLs3[2*4*4+1*4+2]
          - 1.0/8*GHPLs2[1*4+2]*HPLs1[0]
          - 1.0/8*GHPLs2[1*4+2]*HPLs1[1]
          + 1.0/8*GHPLs2[2*4+3]*HPLs1[0]
          - 1.0/8*GHPLs3[0*4*4+2*4+3]
          - 1.0/8*GHPLs2[3*4+3]*HPLs1[0]
          + 1.0/8*GHPLs3[0*4*4+3*4+3]
          + 5.0/8*GHPLs1[3]*zeta2
          + 5.0/4*GHPLs1[3]*HPLs1[0]
          - 1.0/8*GHPLs1[3]*HPLs2[1*2+0]
          - 1.0/8*GHPLs1[3]*HPLs2[0*2+1]
          - 1.0/8*GHPLs3[2*4*4+0*4+3]
          - 5.0/4*GHPLs2[0*4+3]
          + 1.0/8*GHPLs2[0*4+3]*HPLs1[1]
          + 9.0/8*GHPLs2[2*4+0]
          - 1.0/8*GHPLs2[2*4+0]*HPLs1[0]
          + 1.0/8*GHPLs2[3*4+0]*HPLs1[0]
          - 1.0/8*GHPLs3[0*4*4+3*4+0]
          - 3.0/4*GHPLs1[0]*HPLs1[0]
          + 1.0/4*GHPLs1[0]*HPLs2[0*2+0]
          + 1.0/8*GHPLs1[0]*HPLs2[1*2+0]
          - 9.0/8*GHPLs1[0]*HPLs1[1]
          + 1.0/8*GHPLs1[0]*HPLs2[0*2+1]
          - 5.0/4*GHPLs2[2*4+1]
          + 1.0/8*GHPLs3[0*4*4+2*4+1]
          - 1.0/2*GHPLs1[1]*zeta2
          + 5.0/4*GHPLs1[1]*HPLs1[0]
          - 1.0/8*GHPLs1[1]*HPLs2[0*2+0]
          - 1.0/8*GHPLs1[1]*HPLs2[1*2+0]
          + 5.0/4*GHPLs1[1]*HPLs1[1]
          + 1.0/8*GHPLs3[2*4*4+0*4+1]
          - 1.0/8*GHPLs2[0*4+1]*HPLs1[0]
          - 1.0/8*GHPLs2[0*4+1]*HPLs1[1]
          - 1.0/8*GHPLs3[2*4*4+1*4+1]
          + 1.0/8*GHPLs2[1*4+1]*HPLs1[0]
          + 1.0/8*GHPLs2[1*4+1]*HPLs1[1]
          - 3.0/8*HPLs1[0]
          + 5.0/8*HPLs1[0]*zeta2
          + 5.0/4*HPLs2[0*2+0]
          + 1.0/8*HPLs3[1*2*2+0*2+0]
          + 1.0/2*HPLs2[1*2+0]
          + 1.0/8*HPLs3[0*2*2+1*2+0]
          - 3.0/8*HPLs1[1]
          + 1.0/8*HPLs1[1]*zeta2
          + 3.0/2*HPLs2[0*2+1]
          + 1.0/8*HPLs3[0*2*2+0*2+1]
          + 1.0/8*HPLs3[1*2*2+0*2+1]
          + 1.0/4*HPLs3[0*2*2+1*2+1]
          )

       + (dN_c*dN_c-1)/(dN_c*dN_c)*pow(v,2)*pow(1-u,-3) * (
          - 1.0/2*zeta3
          + 1.0/2*GHPLs2[3*4+2]*HPLs1[0]
          - 1.0/2*GHPLs3[0*4*4+3*4+2]
          - 1.0/2*GHPLs1[2]*zeta2
          + 1.0/2*GHPLs1[2]*HPLs2[0*2+0]
          - 1.0/2*GHPLs1[2]*HPLs2[0*2+1]
          - 1.0/2*GHPLs2[0*4+2]*HPLs1[0]
          + 1.0/2*GHPLs2[3*4+0]*HPLs1[0]
          - 1.0/2*GHPLs3[0*4*4+3*4+0]
          + GHPLs1[0]*zeta2
          + 1.0/2*GHPLs1[0]*HPLs2[0*2+0]
          + 1.0/2*GHPLs1[0]*HPLs2[0*2+1]
          + 1.0/2*HPLs1[0]*zeta2
          - 1.0/2*HPLs3[0*2*2+0*2+0]
          + 1.0/2*HPLs3[0*2*2+1*2+0]
          + 1.0/2*HPLs1[1]*zeta2
          - 1.0/2*HPLs3[0*2*2+0*2+1]
          + 1.0/2*HPLs3[0*2*2+1*2+1]
          )

       + (dN_c*dN_c-1)/(dN_c*dN_c)*pow(v,2)*pow(1-u,-2) * (
          + zeta2
          + 1.0/4*zeta3
          - 1.0/4*GHPLs2[3*4+2]*HPLs1[0]
          + 1.0/4*GHPLs3[0*4*4+3*4+2]
          + 1.0/4*GHPLs1[2]*zeta2
          - 1.0/4*GHPLs1[2]*HPLs2[0*2+0]
          + 1.0/4*GHPLs1[2]*HPLs2[0*2+1]
          + 1.0/4*GHPLs2[0*4+2]*HPLs1[0]
          + 1.0/2*GHPLs1[3]*HPLs1[0]
          - 1.0/2*GHPLs2[0*4+3]
          - 1.0/4*GHPLs2[3*4+0]*HPLs1[0]
          + 1.0/4*GHPLs3[0*4*4+3*4+0]
          - 1.0/2*GHPLs1[0]*zeta2
          - 1.0/4*GHPLs1[0]*HPLs2[0*2+0]
          - 1.0/4*GHPLs1[0]*HPLs2[0*2+1]
          - 1.0/4*HPLs1[0]*zeta2
          + 1.0/2*HPLs2[0*2+0]
          + 1.0/4*HPLs3[0*2*2+0*2+0]
          - 1.0/4*HPLs3[0*2*2+1*2+0]
          - 1.0/4*HPLs1[1]*zeta2
          + 1.0/2*HPLs2[0*2+1]
          + 1.0/4*HPLs3[0*2*2+0*2+1]
          - 1.0/4*HPLs3[0*2*2+1*2+1]
          )

       + (dN_c*dN_c-1)/(dN_c*dN_c)*pow(v,2)*pow(1-u,-1) * (
          + 5.0/4*zeta2
          + 1.0/4*zeta3
          - 1.0/4*GHPLs2[3*4+2]*HPLs1[0]
          + 1.0/4*GHPLs3[0*4*4+3*4+2]
          - 3.0/8*GHPLs1[2]
          + 1.0/4*GHPLs1[2]*zeta2
          - 1.0/4*GHPLs1[2]*HPLs2[0*2+0]
          + 1.0/4*GHPLs1[2]*HPLs2[0*2+1]
          - 1.0/8*GHPLs2[0*4+2]
          + 1.0/4*GHPLs2[0*4+2]*HPLs1[0]
          - 1.0/8*GHPLs2[2*4+0]
          - 1.0/4*GHPLs2[3*4+0]*HPLs1[0]
          + 1.0/4*GHPLs3[0*4*4+3*4+0]
          - 1.0/2*GHPLs1[0]*zeta2
          + 1.0/8*GHPLs1[0]*HPLs1[0]
          - 1.0/4*GHPLs1[0]*HPLs2[0*2+0]
          + 1.0/8*GHPLs1[0]*HPLs1[1]
          - 1.0/4*GHPLs1[0]*HPLs2[0*2+1]
          - 1.0/4*GHPLs2[2*4+1]
          + 1.0/4*GHPLs1[1]*HPLs1[0]
          + 1.0/4*GHPLs1[1]*HPLs1[1]
          + 3.0/8*HPLs1[0]
          - 1.0/4*HPLs1[0]*zeta2
          - 1.0/4*HPLs2[0*2+0]
          + 1.0/4*HPLs3[0*2*2+0*2+0]
          - 1.0/4*HPLs2[1*2+0]
          - 1.0/4*HPLs3[0*2*2+1*2+0]
          + 3.0/8*HPLs1[1]
          - 1.0/4*HPLs1[1]*zeta2
          + 1.0/4*HPLs3[0*2*2+0*2+1]
          - 1.0/4*HPLs3[0*2*2+1*2+1]
          )

       + (dN_c*dN_c-1)/(dN_c*dN_c)*pow(v,2) * (
          + 2*zeta2
          + 3.0/8*GHPLs1[2]*zeta2
          + 1.0/2*GHPLs1[2]*HPLs1[0]
          + 3.0/8*GHPLs1[2]*HPLs2[0*2+0]
          - 3.0/8*GHPLs1[2]*HPLs2[1*2+0]
          - 1.0/2*GHPLs2[0*4+2]
          - 3.0/8*GHPLs2[0*4+2]*HPLs1[0]
          - 3.0/8*GHPLs3[2*4*4+1*4+2]
          + 3.0/8*GHPLs2[1*4+2]*HPLs1[0]
          + 3.0/8*GHPLs2[1*4+2]*HPLs1[1]
          - 3.0/8*GHPLs2[2*4+3]*HPLs1[0]
          + 3.0/8*GHPLs3[0*4*4+2*4+3]
          + 3.0/8*GHPLs2[3*4+3]*HPLs1[0]
          - 3.0/8*GHPLs3[0*4*4+3*4+3]
          - 15.0/8*GHPLs1[3]*zeta2
          - 1.0/2*GHPLs1[3]*HPLs1[0]
          + 3.0/8*GHPLs1[3]*HPLs2[1*2+0]
          + 3.0/8*GHPLs1[3]*HPLs2[0*2+1]
          + 3.0/8*GHPLs3[2*4*4+0*4+3]
          + 1.0/2*GHPLs2[0*4+3]
          - 3.0/8*GHPLs2[0*4+3]*HPLs1[1]
          - 1.0/2*GHPLs2[2*4+0]
          + 1.0/8*GHPLs2[2*4+0]*HPLs1[0]
          - 1.0/8*GHPLs2[3*4+0]*HPLs1[0]
          + 1.0/8*GHPLs3[0*4*4+3*4+0]
          + 1.0/2*GHPLs1[0]*HPLs1[0]
          - 1.0/4*GHPLs1[0]*HPLs2[0*2+0]
          - 1.0/8*GHPLs1[0]*HPLs2[1*2+0]
          + 1.0/2*GHPLs1[0]*HPLs1[1]
          - 1.0/8*GHPLs1[0]*HPLs2[0*2+1]
          + 1.0/2*GHPLs2[2*4+1]
          - 1.0/8*GHPLs3[0*4*4+2*4+1]
          + 1.0/2*GHPLs1[1]*zeta2
          - 1.0/2*GHPLs1[1]*HPLs1[0]
          + 1.0/8*GHPLs1[1]*HPLs2[0*2+0]
          + 1.0/8*GHPLs1[1]*HPLs2[1*2+0]
          - 1.0/2*GHPLs1[1]*HPLs1[1]
          - 1.0/8*GHPLs3[2*4*4+0*4+1]
          + 1.0/8*GHPLs2[0*4+1]*HPLs1[0]
          + 1.0/8*GHPLs2[0*4+1]*HPLs1[1]
          + 1.0/8*GHPLs3[2*4*4+1*4+1]
          - 1.0/8*GHPLs2[1*4+1]*HPLs1[0]
          - 1.0/8*GHPLs2[1*4+1]*HPLs1[1]
          - 5.0/8*HPLs1[0]*zeta2
          - 1.0/2*HPLs2[0*2+0]
          - 1.0/8*HPLs3[1*2*2+0*2+0]
          - 1.0/8*HPLs3[0*2*2+1*2+0]
          - 1.0/8*HPLs1[1]*zeta2
          - 1.0/2*HPLs2[0*2+1]
          - 1.0/8*HPLs3[0*2*2+0*2+1]
          - 1.0/8*HPLs3[1*2*2+0*2+1]
          - 1.0/4*HPLs3[0*2*2+1*2+1]
          )

       + (dN_c*dN_c-1)/(dN_c*dN_c)*u*pow(1-v,-2) * (
          - 63.0/16*zeta2
          - 15.0/4*zeta3
          - 7.0/2*GHPLs2[3*4+2]*HPLs1[0]
          + 7.0/2*GHPLs3[0*4*4+3*4+2]
          + 15.0/4*GHPLs1[2]*zeta2
          + 5.0/8*GHPLs1[2]*HPLs1[0]
          - 15.0/4*GHPLs1[2]*HPLs2[0*2+0]
          - 31.0/8*GHPLs1[2]*HPLs2[1*2+0]
          - 1.0/8*GHPLs1[2]*HPLs2[0*2+1]
          - 1.0/8*GHPLs2[0*4+2]*HPLs1[0]
          - 31.0/8*GHPLs3[2*4*4+1*4+2]
          + 31.0/8*GHPLs2[1*4+2]*HPLs1[0]
          + 31.0/8*GHPLs2[1*4+2]*HPLs1[1]
          + 33.0/8*GHPLs1[3]*HPLs1[0]
          - 33.0/8*GHPLs2[0*4+3]
          + 1.0/4*GHPLs2[2*4+0]*HPLs1[0]
          + 7.0/2*GHPLs2[3*4+0]*HPLs1[0]
          - 7.0/2*GHPLs3[0*4*4+3*4+0]
          - 29.0/8*GHPLs1[0]*zeta2
          - 7.0/16*GHPLs1[0]*HPLs1[0]
          + 15.0/4*GHPLs1[0]*HPLs2[0*2+0]
          + 29.0/8*GHPLs1[0]*HPLs2[1*2+0]
          + 31.0/8*GHPLs3[2*4*4+1*4+0]
          - 31.0/8*GHPLs2[1*4+0]*HPLs1[0]
          - 31.0/8*GHPLs2[1*4+0]*HPLs1[1]
          + 33.0/8*GHPLs2[2*4+1]
          - 33.0/8*GHPLs1[1]*HPLs1[0]
          - 33.0/8*GHPLs1[1]*HPLs1[1]
          - 27.0/32*HPLs1[0]
          + 115.0/8*HPLs1[0]*zeta2
          + 33.0/8*HPLs2[0*2+0]
          - 7.0/2*HPLs3[0*2*2+0*2+0]
          + 1.0/4*HPLs3[1*2*2+0*2+0]
          + 7.0/2*HPLs2[1*2+0]
          - 7.0/2*HPLs3[0*2*2+1*2+0]
          - 29.0/8*HPLs1[1]*zeta2
          - 7.0/16*HPLs2[0*2+1]
          + 15.0/4*HPLs3[0*2*2+0*2+1]
          + 29.0/8*HPLs3[1*2*2+0*2+1]
          )

       + (dN_c*dN_c-1)/(dN_c*dN_c)*u*pow(1-v,-1) * (
          - 17.0/32
          + 293.0/16*zeta2
          + 15.0/4*zeta3
          + 7.0/2*GHPLs2[3*4+2]*HPLs1[0]
          - 7.0/2*GHPLs3[0*4*4+3*4+2]
          - 15.0/8*GHPLs1[2]
          - 15.0/4*GHPLs1[2]*zeta2
          + 7.0/2*GHPLs1[2]*HPLs1[0]
          + 15.0/4*GHPLs1[2]*HPLs2[0*2+0]
          + 31.0/8*GHPLs1[2]*HPLs2[1*2+0]
          + 1.0/8*GHPLs1[2]*HPLs2[0*2+1]
          - 29.0/8*GHPLs2[0*4+2]
          + 1.0/8*GHPLs2[0*4+2]*HPLs1[0]
          + 31.0/8*GHPLs3[2*4*4+1*4+2]
          - 31.0/8*GHPLs2[1*4+2]*HPLs1[0]
          - 31.0/8*GHPLs2[1*4+2]*HPLs1[1]
          - 61.0/8*GHPLs1[3]*HPLs1[0]
          + 61.0/8*GHPLs2[0*4+3]
          - 29.0/8*GHPLs2[2*4+0]
          - 1.0/4*GHPLs2[2*4+0]*HPLs1[0]
          - 7.0/2*GHPLs2[3*4+0]*HPLs1[0]
          + 7.0/2*GHPLs3[0*4*4+3*4+0]
          + 25.0/16*GHPLs1[0]
          + 29.0/8*GHPLs1[0]*zeta2
          + 59.0/16*GHPLs1[0]*HPLs1[0]
          - 15.0/4*GHPLs1[0]*HPLs2[0*2+0]
          - 29.0/8*GHPLs1[0]*HPLs2[1*2+0]
          + 29.0/8*GHPLs1[0]*HPLs1[1]
          - 31.0/8*GHPLs3[2*4*4+1*4+0]
          + 31.0/8*GHPLs2[1*4+0]*HPLs1[0]
          + 31.0/8*GHPLs2[1*4+0]*HPLs1[1]
          - 1.0/4*GHPLs2[2*4+1]
          + 1.0/4*GHPLs1[1]*HPLs1[0]
          + 1.0/4*GHPLs1[1]*HPLs1[1]
          + 39.0/32*HPLs1[0]
          - 115.0/8*HPLs1[0]*zeta2
          - 61.0/8*HPLs2[0*2+0]
          + 7.0/2*HPLs3[0*2*2+0*2+0]
          - 1.0/4*HPLs3[1*2*2+0*2+0]
          - 15.0/4*HPLs2[1*2+0]
          + 7.0/2*HPLs3[0*2*2+1*2+0]
          + 15.0/8*HPLs1[1]
          + 29.0/8*HPLs1[1]*zeta2
          - 57.0/16*HPLs2[0*2+1]
          - 15.0/4*HPLs3[0*2*2+0*2+1]
          - 29.0/8*HPLs3[1*2*2+0*2+1]
          )

       + (dN_c*dN_c-1)/(dN_c*dN_c)*u * (
          - 11*zeta2
          + 3.0/4*GHPLs1[2]
          - 3*GHPLs1[2]*HPLs1[0]
          + 11.0/4*GHPLs2[0*4+2]
          + 11.0/4*GHPLs1[3]*HPLs1[0]
          - 11.0/4*GHPLs2[0*4+3]
          + 11.0/4*GHPLs2[2*4+0]
          - 3.0/8*GHPLs1[0]
          - 5.0/2*GHPLs1[0]*HPLs1[0]
          - 11.0/4*GHPLs1[0]*HPLs1[1]
          - 11.0/4*GHPLs2[2*4+1]
          + 11.0/4*GHPLs1[1]*HPLs1[0]
          + 11.0/4*GHPLs1[1]*HPLs1[1]
          - 3.0/8*HPLs1[0]
          + 11.0/4*HPLs2[0*2+0]
          + 1.0/4*HPLs2[1*2+0]
          - 3.0/4*HPLs1[1]
          + 3*HPLs2[0*2+1]
          )

       + (dN_c*dN_c-1)/(dN_c*dN_c)*u*v * (
          + 4*zeta2
          + 1.0/8*GHPLs1[2]*zeta2
          + GHPLs1[2]*HPLs1[0]
          + 1.0/8*GHPLs1[2]*HPLs2[0*2+0]
          - 1.0/8*GHPLs1[2]*HPLs2[1*2+0]
          - GHPLs2[0*4+2]
          - 1.0/8*GHPLs2[0*4+2]*HPLs1[0]
          - 1.0/8*GHPLs3[2*4*4+1*4+2]
          + 1.0/8*GHPLs2[1*4+2]*HPLs1[0]
          + 1.0/8*GHPLs2[1*4+2]*HPLs1[1]
          - 1.0/8*GHPLs2[2*4+3]*HPLs1[0]
          + 1.0/8*GHPLs3[0*4*4+2*4+3]
          + 1.0/8*GHPLs2[3*4+3]*HPLs1[0]
          - 1.0/8*GHPLs3[0*4*4+3*4+3]
          - 5.0/8*GHPLs1[3]*zeta2
          - GHPLs1[3]*HPLs1[0]
          + 1.0/8*GHPLs1[3]*HPLs2[1*2+0]
          + 1.0/8*GHPLs1[3]*HPLs2[0*2+1]
          + 1.0/8*GHPLs3[2*4*4+0*4+3]
          + GHPLs2[0*4+3]
          - 1.0/8*GHPLs2[0*4+3]*HPLs1[1]
          - GHPLs2[2*4+0]
          + 1.0/8*GHPLs2[2*4+0]*HPLs1[0]
          - 1.0/8*GHPLs2[3*4+0]*HPLs1[0]
          + 1.0/8*GHPLs3[0*4*4+3*4+0]
          + GHPLs1[0]*HPLs1[0]
          - 1.0/4*GHPLs1[0]*HPLs2[0*2+0]
          - 1.0/8*GHPLs1[0]*HPLs2[1*2+0]
          + GHPLs1[0]*HPLs1[1]
          - 1.0/8*GHPLs1[0]*HPLs2[0*2+1]
          + GHPLs2[2*4+1]
          - 1.0/8*GHPLs3[0*4*4+2*4+1]
          + 1.0/2*GHPLs1[1]*zeta2
          - GHPLs1[1]*HPLs1[0]
          + 1.0/8*GHPLs1[1]*HPLs2[0*2+0]
          + 1.0/8*GHPLs1[1]*HPLs2[1*2+0]
          - GHPLs1[1]*HPLs1[1]
          - 1.0/8*GHPLs3[2*4*4+0*4+1]
          + 1.0/8*GHPLs2[0*4+1]*HPLs1[0]
          + 1.0/8*GHPLs2[0*4+1]*HPLs1[1]
          + 1.0/8*GHPLs3[2*4*4+1*4+1]
          - 1.0/8*GHPLs2[1*4+1]*HPLs1[0]
          - 1.0/8*GHPLs2[1*4+1]*HPLs1[1]
          - 5.0/8*HPLs1[0]*zeta2
          - HPLs2[0*2+0]
          - 1.0/8*HPLs3[1*2*2+0*2+0]
          - 1.0/8*HPLs3[0*2*2+1*2+0]
          - 1.0/8*HPLs1[1]*zeta2
          - HPLs2[0*2+1]
          - 1.0/8*HPLs3[0*2*2+0*2+1]
          - 1.0/8*HPLs3[1*2*2+0*2+1]
          - 1.0/4*HPLs3[0*2*2+1*2+1]
          )

       + (dN_c*dN_c-1)/(dN_c*dN_c)*pow(u,2)*pow(1-v,-3) * (
          + 9.0/4*zeta2
          + 21.0/4*zeta3
          + 21.0/4*GHPLs2[3*4+2]*HPLs1[0]
          - 21.0/4*GHPLs3[0*4*4+3*4+2]
          - 21.0/4*GHPLs1[2]*zeta2
          + 21.0/4*GHPLs1[2]*HPLs2[0*2+0]
          + 21.0/4*GHPLs1[2]*HPLs2[1*2+0]
          + 21.0/4*GHPLs3[2*4*4+1*4+2]
          - 21.0/4*GHPLs2[1*4+2]*HPLs1[0]
          - 21.0/4*GHPLs2[1*4+2]*HPLs1[1]
          - 9.0/4*GHPLs1[3]*HPLs1[0]
          + 9.0/4*GHPLs2[0*4+3]
          - 21.0/4*GHPLs2[3*4+0]*HPLs1[0]
          + 21.0/4*GHPLs3[0*4*4+3*4+0]
          + 21.0/4*GHPLs1[0]*zeta2
          - 21.0/4*GHPLs1[0]*HPLs2[0*2+0]
          - 21.0/4*GHPLs1[0]*HPLs2[1*2+0]
          - 21.0/4*GHPLs3[2*4*4+1*4+0]
          + 21.0/4*GHPLs2[1*4+0]*HPLs1[0]
          + 21.0/4*GHPLs2[1*4+0]*HPLs1[1]
          - 9.0/4*GHPLs2[2*4+1]
          + 9.0/4*GHPLs1[1]*HPLs1[0]
          + 9.0/4*GHPLs1[1]*HPLs1[1]
          - 21*HPLs1[0]*zeta2
          - 9.0/4*HPLs2[0*2+0]
          + 21.0/4*HPLs3[0*2*2+0*2+0]
          - 9.0/4*HPLs2[1*2+0]
          + 21.0/4*HPLs3[0*2*2+1*2+0]
          + 21.0/4*HPLs1[1]*zeta2
          - 21.0/4*HPLs3[0*2*2+0*2+1]
          - 21.0/4*HPLs3[1*2*2+0*2+1]
          )

       + (dN_c*dN_c-1)/(dN_c*dN_c)*pow(u,2)*pow(1-v,-2) * (
          - 93.0/4*zeta2
          - 21.0/4*zeta3
          - 21.0/4*GHPLs2[3*4+2]*HPLs1[0]
          + 21.0/4*GHPLs3[0*4*4+3*4+2]
          + 9.0/8*GHPLs1[2]
          + 21.0/4*GHPLs1[2]*zeta2
          - 21.0/4*GHPLs1[2]*HPLs1[0]
          - 21.0/4*GHPLs1[2]*HPLs2[0*2+0]
          - 21.0/4*GHPLs1[2]*HPLs2[1*2+0]
          + 21.0/4*GHPLs2[0*4+2]
          - 21.0/4*GHPLs3[2*4*4+1*4+2]
          + 21.0/4*GHPLs2[1*4+2]*HPLs1[0]
          + 21.0/4*GHPLs2[1*4+2]*HPLs1[1]
          + 15.0/2*GHPLs1[3]*HPLs1[0]
          - 15.0/2*GHPLs2[0*4+3]
          + 21.0/4*GHPLs2[2*4+0]
          + 21.0/4*GHPLs2[3*4+0]*HPLs1[0]
          - 21.0/4*GHPLs3[0*4*4+3*4+0]
          - 9.0/8*GHPLs1[0]
          - 21.0/4*GHPLs1[0]*zeta2
          - 21.0/4*GHPLs1[0]*HPLs1[0]
          + 21.0/4*GHPLs1[0]*HPLs2[0*2+0]
          + 21.0/4*GHPLs1[0]*HPLs2[1*2+0]
          - 21.0/4*GHPLs1[0]*HPLs1[1]
          + 21.0/4*GHPLs3[2*4*4+1*4+0]
          - 21.0/4*GHPLs2[1*4+0]*HPLs1[0]
          - 21.0/4*GHPLs2[1*4+0]*HPLs1[1]
          - 3*GHPLs2[2*4+1]
          + 3*GHPLs1[1]*HPLs1[0]
          + 3*GHPLs1[1]*HPLs1[1]
          + 21*HPLs1[0]*zeta2
          + 15.0/2*HPLs2[0*2+0]
          - 21.0/4*HPLs3[0*2*2+0*2+0]
          + 9.0/4*HPLs2[1*2+0]
          - 21.0/4*HPLs3[0*2*2+1*2+0]
          - 9.0/8*HPLs1[1]
          - 21.0/4*HPLs1[1]*zeta2
          + 21.0/4*HPLs2[0*2+1]
          + 21.0/4*HPLs3[0*2*2+0*2+1]
          + 21.0/4*HPLs3[1*2*2+0*2+1]
          )

       + (dN_c*dN_c-1)/(dN_c*dN_c)*pow(u,2)*pow(1-v,-1) * (
          + 21.0/2*zeta2
          - 3.0/8*GHPLs1[2]
          + 21.0/8*GHPLs1[2]*HPLs1[0]
          - 21.0/8*GHPLs2[0*4+2]
          - 21.0/8*GHPLs1[3]*HPLs1[0]
          + 21.0/8*GHPLs2[0*4+3]
          - 21.0/8*GHPLs2[2*4+0]
          + 3.0/8*GHPLs1[0]
          + 21.0/8*GHPLs1[0]*HPLs1[0]
          + 21.0/8*GHPLs1[0]*HPLs1[1]
          + 21.0/8*GHPLs2[2*4+1]
          - 21.0/8*GHPLs1[1]*HPLs1[0]
          - 21.0/8*GHPLs1[1]*HPLs1[1]
          - 21.0/8*HPLs2[0*2+0]
          + 3.0/8*HPLs1[1]
          - 21.0/8*HPLs2[0*2+1]
          )

       + (dN_c*dN_c-1)/(dN_c*dN_c)*pow(u,2) * (
          + 4*zeta2
          + GHPLs1[2]*HPLs1[0]
          - GHPLs2[0*4+2]
          - GHPLs1[3]*HPLs1[0]
          + GHPLs2[0*4+3]
          - GHPLs2[2*4+0]
          + GHPLs1[0]*HPLs1[0]
          + GHPLs1[0]*HPLs1[1]
          + GHPLs2[2*4+1]
          - GHPLs1[1]*HPLs1[0]
          - GHPLs1[1]*HPLs1[1]
          - HPLs2[0*2+0]
          - HPLs2[0*2+1]
          )

       + (dN_c*dN_c-1)/(dN_c*dN_c)*pow(u,3)*pow(1-v,-4) * (
          - 9.0/4*zeta3
          - 9.0/4*GHPLs2[3*4+2]*HPLs1[0]
          + 9.0/4*GHPLs3[0*4*4+3*4+2]
          + 9.0/4*GHPLs1[2]*zeta2
          - 9.0/4*GHPLs1[2]*HPLs2[0*2+0]
          - 9.0/4*GHPLs1[2]*HPLs2[1*2+0]
          - 9.0/4*GHPLs3[2*4*4+1*4+2]
          + 9.0/4*GHPLs2[1*4+2]*HPLs1[0]
          + 9.0/4*GHPLs2[1*4+2]*HPLs1[1]
          + 9.0/4*GHPLs2[3*4+0]*HPLs1[0]
          - 9.0/4*GHPLs3[0*4*4+3*4+0]
          - 9.0/4*GHPLs1[0]*zeta2
          + 9.0/4*GHPLs1[0]*HPLs2[0*2+0]
          + 9.0/4*GHPLs1[0]*HPLs2[1*2+0]
          + 9.0/4*GHPLs3[2*4*4+1*4+0]
          - 9.0/4*GHPLs2[1*4+0]*HPLs1[0]
          - 9.0/4*GHPLs2[1*4+0]*HPLs1[1]
          + 9*HPLs1[0]*zeta2
          - 9.0/4*HPLs3[0*2*2+0*2+0]
          - 9.0/4*HPLs3[0*2*2+1*2+0]
          - 9.0/4*HPLs1[1]*zeta2
          + 9.0/4*HPLs3[0*2*2+0*2+1]
          + 9.0/4*HPLs3[1*2*2+0*2+1]
          )

       + (dN_c*dN_c-1)/(dN_c*dN_c)*pow(u,3)*pow(1-v,-3) * (
          + 9*zeta2
          + 9.0/4*zeta3
          + 9.0/4*GHPLs2[3*4+2]*HPLs1[0]
          - 9.0/4*GHPLs3[0*4*4+3*4+2]
          - 9.0/4*GHPLs1[2]*zeta2
          + 9.0/4*GHPLs1[2]*HPLs1[0]
          + 9.0/4*GHPLs1[2]*HPLs2[0*2+0]
          + 9.0/4*GHPLs1[2]*HPLs2[1*2+0]
          - 9.0/4*GHPLs2[0*4+2]
          + 9.0/4*GHPLs3[2*4*4+1*4+2]
          - 9.0/4*GHPLs2[1*4+2]*HPLs1[0]
          - 9.0/4*GHPLs2[1*4+2]*HPLs1[1]
          - 9.0/4*GHPLs1[3]*HPLs1[0]
          + 9.0/4*GHPLs2[0*4+3]
          - 9.0/4*GHPLs2[2*4+0]
          - 9.0/4*GHPLs2[3*4+0]*HPLs1[0]
          + 9.0/4*GHPLs3[0*4*4+3*4+0]
          + 9.0/4*GHPLs1[0]*zeta2
          + 9.0/4*GHPLs1[0]*HPLs1[0]
          - 9.0/4*GHPLs1[0]*HPLs2[0*2+0]
          - 9.0/4*GHPLs1[0]*HPLs2[1*2+0]
          + 9.0/4*GHPLs1[0]*HPLs1[1]
          - 9.0/4*GHPLs3[2*4*4+1*4+0]
          + 9.0/4*GHPLs2[1*4+0]*HPLs1[0]
          + 9.0/4*GHPLs2[1*4+0]*HPLs1[1]
          + 9.0/4*GHPLs2[2*4+1]
          - 9.0/4*GHPLs1[1]*HPLs1[0]
          - 9.0/4*GHPLs1[1]*HPLs1[1]
          - 9*HPLs1[0]*zeta2
          - 9.0/4*HPLs2[0*2+0]
          + 9.0/4*HPLs3[0*2*2+0*2+0]
          + 9.0/4*HPLs3[0*2*2+1*2+0]
          + 9.0/4*HPLs1[1]*zeta2
          - 9.0/4*HPLs2[0*2+1]
          - 9.0/4*HPLs3[0*2*2+0*2+1]
          - 9.0/4*HPLs3[1*2*2+0*2+1]
          )

       + (dN_c*dN_c-1)/(dN_c*dN_c)*pow(u,3)*pow(1-v,-2) * (
          - 9.0/2*zeta2
          - 9.0/8*GHPLs1[2]*HPLs1[0]
          + 9.0/8*GHPLs2[0*4+2]
          + 9.0/8*GHPLs1[3]*HPLs1[0]
          - 9.0/8*GHPLs2[0*4+3]
          + 9.0/8*GHPLs2[2*4+0]
          - 9.0/8*GHPLs1[0]*HPLs1[0]
          - 9.0/8*GHPLs1[0]*HPLs1[1]
          - 9.0/8*GHPLs2[2*4+1]
          + 9.0/8*GHPLs1[1]*HPLs1[0]
          + 9.0/8*GHPLs1[1]*HPLs1[1]
          + 9.0/8*HPLs2[0*2+0]
          + 9.0/8*HPLs2[0*2+1]
          )

       + (dN_c*dN_c-1)/(dN_c*dN_c)*pow(u,3)*pow(1-v,-1) * (
          - 3.0/2*zeta2
          - 3.0/8*GHPLs1[2]*HPLs1[0]
          + 3.0/8*GHPLs2[0*4+2]
          + 3.0/8*GHPLs1[3]*HPLs1[0]
          - 3.0/8*GHPLs2[0*4+3]
          + 3.0/8*GHPLs2[2*4+0]
          - 3.0/8*GHPLs1[0]*HPLs1[0]
          - 3.0/8*GHPLs1[0]*HPLs1[1]
          - 3.0/8*GHPLs2[2*4+1]
          + 3.0/8*GHPLs1[1]*HPLs1[0]
          + 3.0/8*GHPLs1[1]*HPLs1[1]
          + 3.0/8*HPLs2[0*2+0]
          + 3.0/8*HPLs2[0*2+1]
          )

       + (dN_c*dN_c-1)/(dN_c*dN_c)*double_complex(0,1)*M_PI*pow(u,-2)*v * (
          - 1.0/4*GHPLs3[3*4*4+2*4+2]
          - 1.0/4*GHPLs2[2*4+2]*HPLs1[0]
          + 1.0/4*GHPLs1[2]*HPLs1[0]
          - 1.0/4*GHPLs1[2]*HPLs2[0*2+0]
          + 1.0/4*GHPLs3[3*4*4+0*4+2]
          - 1.0/4*GHPLs2[1*4+2]
          + 1.0/8*GHPLs2[1*4+0]
          - 1.0/4*GHPLs3[3*4*4+2*4+1]
          - 1.0/4*GHPLs2[2*4+1]*HPLs1[0]
          + 1.0/4*GHPLs1[1]
          + 1.0/2*GHPLs1[1]*zeta2
          - 1.0/8*GHPLs1[1]*HPLs1[0]
          + 1.0/4*GHPLs1[1]*HPLs2[0*2+0]
          + 1.0/4*GHPLs1[1]*HPLs2[0*2+1]
          - 1.0/4*GHPLs3[3*4*4+0*4+1]
          + 1.0/8*GHPLs2[1*4+1]
          )

       + (dN_c*dN_c-1)/(dN_c*dN_c)*double_complex(0,1)*M_PI*pow(u,-2)*pow(v,2) * (
          + 1.0/4*GHPLs3[3*4*4+2*4+2]
          + 1.0/4*GHPLs2[2*4+2]*HPLs1[0]
          - 1.0/4*GHPLs1[2]*HPLs1[0]
          + 1.0/4*GHPLs1[2]*HPLs2[0*2+0]
          - 1.0/4*GHPLs3[3*4*4+0*4+2]
          + 1.0/4*GHPLs2[1*4+2]
          - 1.0/8*GHPLs2[1*4+0]
          + 1.0/4*GHPLs3[3*4*4+2*4+1]
          + 1.0/4*GHPLs2[2*4+1]*HPLs1[0]
          - 1.0/8*GHPLs1[1]
          - 1.0/2*GHPLs1[1]*zeta2
          + 1.0/8*GHPLs1[1]*HPLs1[0]
          - 1.0/4*GHPLs1[1]*HPLs2[0*2+0]
          - 1.0/4*GHPLs1[1]*HPLs2[0*2+1]
          + 1.0/4*GHPLs3[3*4*4+0*4+1]
          - 1.0/8*GHPLs2[1*4+1]
          )

       + (dN_c*dN_c-1)/(dN_c*dN_c)*double_complex(0,1)*M_PI*pow(u,-2)*pow(v,3) * (
          + 1.0/8*GHPLs2[1*4+2]
          - 1.0/8*GHPLs2[2*4+3]
          + 1.0/8*GHPLs2[3*4+3]
          + 1.0/8*GHPLs1[3]*HPLs1[0]
          + 1.0/8*GHPLs1[3]*HPLs1[1]
          - 1.0/8*GHPLs2[0*4+3]
          - 1.0/8*GHPLs1[1]
          )

       + (dN_c*dN_c-1)/(dN_c*dN_c)*double_complex(0,1)*M_PI*pow(u,-2)*pow(v,4) * (
          - 1.0/8*GHPLs2[1*4+2]
          + 1.0/8*GHPLs2[2*4+3]
          - 1.0/8*GHPLs2[3*4+3]
          - 1.0/8*GHPLs1[3]*HPLs1[0]
          - 1.0/8*GHPLs1[3]*HPLs1[1]
          + 1.0/8*GHPLs2[0*4+3]
          )

       + (dN_c*dN_c-1)/(dN_c*dN_c)*double_complex(0,1)*M_PI*pow(u,-1) * (
          + 1.0/8*GHPLs1[1]
          )

       + (dN_c*dN_c-1)/(dN_c*dN_c)*double_complex(0,1)*M_PI*pow(u,-1)*v * (
          + 3.0/8
          + 1.0/2*zeta2
          + 1.0/4*GHPLs3[3*4*4+2*4+2]
          + 1.0/4*GHPLs2[2*4+2]*HPLs1[0]
          - 1.0/2*GHPLs2[3*4+2]
          - 3.0/4*GHPLs1[2]*HPLs1[0]
          + 1.0/4*GHPLs1[2]*HPLs2[0*2+0]
          - 1.0/4*GHPLs3[3*4*4+0*4+2]
          + 1.0/4*GHPLs2[1*4+2]
          - 1.0/8*GHPLs2[1*4+0]
          + 1.0/4*GHPLs3[3*4*4+2*4+1]
          + 1.0/4*GHPLs2[2*4+1]*HPLs1[0]
          + 1.0/4*GHPLs1[1]
          - 1.0/2*GHPLs1[1]*zeta2
          + 1.0/8*GHPLs1[1]*HPLs1[0]
          - 1.0/4*GHPLs1[1]*HPLs2[0*2+0]
          - 1.0/4*GHPLs1[1]*HPLs2[0*2+1]
          + 1.0/4*GHPLs3[3*4*4+0*4+1]
          - 1.0/8*GHPLs2[1*4+1]
          + 1.0/8*HPLs1[0]
          + 1.0/4*HPLs2[0*2+1]
          )

       + (dN_c*dN_c-1)/(dN_c*dN_c)*double_complex(0,1)*M_PI*pow(u,-1)*pow(v,2) * (
          - 3.0/8
          - 1.0/2*zeta2
          + 1.0/4*GHPLs2[3*4+2]
          + 1.0/8*GHPLs1[2]
          + 1.0/4*GHPLs1[2]*HPLs1[0]
          + 1.0/4*GHPLs2[1*4+2]
          - 1.0/4*GHPLs2[2*4+3]
          + 1.0/4*GHPLs2[3*4+3]
          - 3.0/8*GHPLs1[3]
          + 1.0/4*GHPLs1[3]*HPLs1[0]
          + 1.0/4*GHPLs1[3]*HPLs1[1]
          - 1.0/4*GHPLs2[0*4+3]
          + 1.0/4*GHPLs2[3*4+0]
          + 1.0/8*GHPLs1[0]
          - 3.0/4*GHPLs1[1]
          - 1.0/4*HPLs2[0*2+0]
          - 1.0/8*HPLs1[1]
          - 1.0/4*HPLs2[0*2+1]
          )

       + (dN_c*dN_c-1)/(dN_c*dN_c)*double_complex(0,1)*M_PI*pow(u,-1)*pow(v,3) * (
          - 1.0/8*GHPLs1[2]
          - 3.0/8*GHPLs2[1*4+2]
          + 3.0/8*GHPLs2[2*4+3]
          - 3.0/8*GHPLs2[3*4+3]
          + 1.0/8*GHPLs1[3]
          - 3.0/8*GHPLs1[3]*HPLs1[0]
          - 3.0/8*GHPLs1[3]*HPLs1[1]
          + 3.0/8*GHPLs2[0*4+3]
          - 1.0/8*GHPLs1[0]
          + 1.0/8*GHPLs1[1]
          + 1.0/8*HPLs1[0]
          + 1.0/8*HPLs1[1]
          )

       + (dN_c*dN_c-1)/(dN_c*dN_c)*double_complex(0,1)*M_PI*pow(1-u,-1) * (
          + 1.0/4*GHPLs1[3]
          + 1.0/4*HPLs1[0]
          )

       + (dN_c*dN_c-1)/(dN_c*dN_c)*double_complex(0,1)*M_PI*pow(1-v,-1) * (
          + 5.0/4*zeta2
          - 1.0/2*GHPLs2[3*4+2]
          - 3.0/4*GHPLs1[2]*HPLs1[0]
          + 7.0/8*GHPLs2[1*4+2]
          + 13.0/8*GHPLs1[3]
          + 1.0/2*GHPLs2[3*4+0]
          + 5.0/8*GHPLs1[0]*HPLs1[0]
          - 7.0/8*GHPLs2[1*4+0]
          - 2*GHPLs1[1]
          + 15.0/16*HPLs1[0]
          - 1.0/2*HPLs2[0*2+0]
          - 5.0/8*HPLs2[1*2+0]
          + 5.0/8*HPLs2[0*2+1]
          )

       + (dN_c*dN_c-1)/(dN_c*dN_c)*double_complex(0,1)*M_PI * (
          + 3.0/16
          - 5.0/4*zeta2
          + 1.0/2*GHPLs2[3*4+2]
          + 3.0/4*GHPLs1[2]*HPLs1[0]
          - 7.0/8*GHPLs2[1*4+2]
          - 2*GHPLs1[3]
          - 1.0/2*GHPLs2[3*4+0]
          - 5.0/8*GHPLs1[0]*HPLs1[0]
          + 7.0/8*GHPLs2[1*4+0]
          + 13.0/8*GHPLs1[1]
          - 21.0/16*HPLs1[0]
          + 1.0/2*HPLs2[0*2+0]
          + 5.0/8*HPLs2[1*2+0]
          - 5.0/8*HPLs2[0*2+1]
          )

       + (dN_c*dN_c-1)/(dN_c*dN_c)*double_complex(0,1)*M_PI*v*pow(1-u,-2) * (
          - zeta2
          + 1.0/2*GHPLs2[3*4+2]
          + 1.0/2*GHPLs1[2]*HPLs1[0]
          - 1.0/2*GHPLs1[3]
          + 1.0/2*GHPLs2[3*4+0]
          - 1.0/2*HPLs1[0]
          - 1.0/2*HPLs2[0*2+0]
          - 1.0/2*HPLs2[0*2+1]
          )

       + (dN_c*dN_c-1)/(dN_c*dN_c)*double_complex(0,1)*M_PI*v*pow(1-u,-1) * (
          - 1.0/4
          + 1.0/2*zeta2
          - 1.0/4*GHPLs2[3*4+2]
          - 1.0/4*GHPLs1[2]*HPLs1[0]
          + 3.0/4*GHPLs1[3]
          - 1.0/4*GHPLs2[3*4+0]
          + 1.0/4*HPLs1[0]
          + 1.0/4*HPLs2[0*2+0]
          + 1.0/4*HPLs2[0*2+1]
          )

       + (dN_c*dN_c-1)/(dN_c*dN_c)*double_complex(0,1)*M_PI*v * (
          + 3.0/8
          - 1.0/8*zeta2
          + 9.0/8*GHPLs1[2]
          + 1.0/8*GHPLs2[1*4+2]
          - 1.0/8*GHPLs2[2*4+3]
          + 1.0/8*GHPLs2[3*4+3]
          - 5.0/4*GHPLs1[3]
          + 1.0/8*GHPLs1[3]*HPLs1[0]
          + 1.0/8*GHPLs1[3]*HPLs1[1]
          - 1.0/8*GHPLs2[0*4+3]
          - 1.0/8*GHPLs2[3*4+0]
          + 9.0/8*GHPLs1[0]
          - 1.0/8*GHPLs1[0]*HPLs1[0]
          + 1.0/8*GHPLs2[2*4+1]
          - 5.0/4*GHPLs1[1]
          - 1.0/8*GHPLs1[1]*HPLs1[1]
          + 1.0/8*GHPLs2[0*4+1]
          - 1.0/8*GHPLs2[1*4+1]
          - 5.0/4*HPLs1[0]
          + 1.0/8*HPLs2[0*2+0]
          + 1.0/8*HPLs2[1*2+0]
          - 9.0/8*HPLs1[1]
          )

       + (dN_c*dN_c-1)/(dN_c*dN_c)*double_complex(0,1)*M_PI*pow(v,2)*pow(1-u,-3) * (
          + zeta2
          - 1.0/2*GHPLs2[3*4+2]
          - 1.0/2*GHPLs1[2]*HPLs1[0]
          - 1.0/2*GHPLs2[3*4+0]
          + 1.0/2*HPLs2[0*2+0]
          + 1.0/2*HPLs2[0*2+1]
          )

       + (dN_c*dN_c-1)/(dN_c*dN_c)*double_complex(0,1)*M_PI*pow(v,2)*pow(1-u,-2) * (
          - 1.0/2*zeta2
          + 1.0/4*GHPLs2[3*4+2]
          + 1.0/4*GHPLs1[2]*HPLs1[0]
          - 1.0/2*GHPLs1[3]
          + 1.0/4*GHPLs2[3*4+0]
          - 1.0/4*HPLs2[0*2+0]
          - 1.0/4*HPLs2[0*2+1]
          )

       + (dN_c*dN_c-1)/(dN_c*dN_c)*double_complex(0,1)*M_PI*pow(v,2)*pow(1-u,-1) * (
          - 3.0/8
          - 1.0/2*zeta2
          + 1.0/4*GHPLs2[3*4+2]
          - 1.0/8*GHPLs1[2]
          + 1.0/4*GHPLs1[2]*HPLs1[0]
          + 1.0/4*GHPLs2[3*4+0]
          - 1.0/8*GHPLs1[0]
          - 1.0/4*GHPLs1[1]
          + 3.0/8*HPLs1[0]
          - 1.0/4*HPLs2[0*2+0]
          + 1.0/8*HPLs1[1]
          - 1.0/4*HPLs2[0*2+1]
          )

       + (dN_c*dN_c-1)/(dN_c*dN_c)*double_complex(0,1)*M_PI*pow(v,2) * (
          + 1.0/8*zeta2
          - 1.0/2*GHPLs1[2]
          - 3.0/8*GHPLs2[1*4+2]
          + 3.0/8*GHPLs2[2*4+3]
          - 3.0/8*GHPLs2[3*4+3]
          + 1.0/2*GHPLs1[3]
          - 3.0/8*GHPLs1[3]*HPLs1[0]
          - 3.0/8*GHPLs1[3]*HPLs1[1]
          + 3.0/8*GHPLs2[0*4+3]
          + 1.0/8*GHPLs2[3*4+0]
          - 1.0/2*GHPLs1[0]
          + 1.0/8*GHPLs1[0]*HPLs1[0]
          - 1.0/8*GHPLs2[2*4+1]
          + 1.0/2*GHPLs1[1]
          + 1.0/8*GHPLs1[1]*HPLs1[1]
          - 1.0/8*GHPLs2[0*4+1]
          + 1.0/8*GHPLs2[1*4+1]
          + 1.0/2*HPLs1[0]
          - 1.0/8*HPLs2[0*2+0]
          - 1.0/8*HPLs2[1*2+0]
          + 1.0/2*HPLs1[1]
          )

       + (dN_c*dN_c-1)/(dN_c*dN_c)*double_complex(0,1)*M_PI*u*pow(1-v,-2) * (
          - 29.0/4*zeta2
          + 7.0/2*GHPLs2[3*4+2]
          + 15.0/4*GHPLs1[2]*HPLs1[0]
          - 31.0/8*GHPLs2[1*4+2]
          - 33.0/8*GHPLs1[3]
          - 7.0/2*GHPLs2[3*4+0]
          - 29.0/8*GHPLs1[0]*HPLs1[0]
          + 31.0/8*GHPLs2[1*4+0]
          + 33.0/8*GHPLs1[1]
          - 63.0/16*HPLs1[0]
          + 7.0/2*HPLs2[0*2+0]
          + 29.0/8*HPLs2[1*2+0]
          - 29.0/8*HPLs2[0*2+1]
          )

       + (dN_c*dN_c-1)/(dN_c*dN_c)*double_complex(0,1)*M_PI*u*pow(1-v,-1) * (
          - 5.0/16
          + 29.0/4*zeta2
          - 7.0/2*GHPLs2[3*4+2]
          - 29.0/8*GHPLs1[2]
          - 15.0/4*GHPLs1[2]*HPLs1[0]
          + 31.0/8*GHPLs2[1*4+2]
          + 61.0/8*GHPLs1[3]
          + 7.0/2*GHPLs2[3*4+0]
          - 29.0/8*GHPLs1[0]
          + 29.0/8*GHPLs1[0]*HPLs1[0]
          - 31.0/8*GHPLs2[1*4+0]
          - 1.0/4*GHPLs1[1]
          + 119.0/16*HPLs1[0]
          - 7.0/2*HPLs2[0*2+0]
          - 29.0/8*HPLs2[1*2+0]
          + 29.0/8*HPLs1[1]
          + 29.0/8*HPLs2[0*2+1]
          )

       + (dN_c*dN_c-1)/(dN_c*dN_c)*double_complex(0,1)*M_PI*u * (
          + 3.0/8
          + 11.0/4*GHPLs1[2]
          - 11.0/4*GHPLs1[3]
          + 11.0/4*GHPLs1[0]
          - 11.0/4*GHPLs1[1]
          - 11.0/4*HPLs1[0]
          - 11.0/4*HPLs1[1]
          )

       + (dN_c*dN_c-1)/(dN_c*dN_c)*double_complex(0,1)*M_PI*u*v * (
          + 1.0/8*zeta2
          - GHPLs1[2]
          - 1.0/8*GHPLs2[1*4+2]
          + 1.0/8*GHPLs2[2*4+3]
          - 1.0/8*GHPLs2[3*4+3]
          + GHPLs1[3]
          - 1.0/8*GHPLs1[3]*HPLs1[0]
          - 1.0/8*GHPLs1[3]*HPLs1[1]
          + 1.0/8*GHPLs2[0*4+3]
          + 1.0/8*GHPLs2[3*4+0]
          - GHPLs1[0]
          + 1.0/8*GHPLs1[0]*HPLs1[0]
          - 1.0/8*GHPLs2[2*4+1]
          + GHPLs1[1]
          + 1.0/8*GHPLs1[1]*HPLs1[1]
          - 1.0/8*GHPLs2[0*4+1]
          + 1.0/8*GHPLs2[1*4+1]
          + HPLs1[0]
          - 1.0/8*HPLs2[0*2+0]
          - 1.0/8*HPLs2[1*2+0]
          + HPLs1[1]
          )

       + (dN_c*dN_c-1)/(dN_c*dN_c)*double_complex(0,1)*M_PI*pow(u,2)*pow(1-v,-3) * (
          + 21.0/2*zeta2
          - 21.0/4*GHPLs2[3*4+2]
          - 21.0/4*GHPLs1[2]*HPLs1[0]
          + 21.0/4*GHPLs2[1*4+2]
          + 9.0/4*GHPLs1[3]
          + 21.0/4*GHPLs2[3*4+0]
          + 21.0/4*GHPLs1[0]*HPLs1[0]
          - 21.0/4*GHPLs2[1*4+0]
          - 9.0/4*GHPLs1[1]
          + 9.0/4*HPLs1[0]
          - 21.0/4*HPLs2[0*2+0]
          - 21.0/4*HPLs2[1*2+0]
          + 21.0/4*HPLs2[0*2+1]
          )

       + (dN_c*dN_c-1)/(dN_c*dN_c)*double_complex(0,1)*M_PI*pow(u,2)*pow(1-v,-2) * (
          - 21.0/2*zeta2
          + 21.0/4*GHPLs2[3*4+2]
          + 21.0/4*GHPLs1[2]
          + 21.0/4*GHPLs1[2]*HPLs1[0]
          - 21.0/4*GHPLs2[1*4+2]
          - 15.0/2*GHPLs1[3]
          - 21.0/4*GHPLs2[3*4+0]
          + 21.0/4*GHPLs1[0]
          - 21.0/4*GHPLs1[0]*HPLs1[0]
          + 21.0/4*GHPLs2[1*4+0]
          - 3*GHPLs1[1]
          - 15.0/2*HPLs1[0]
          + 21.0/4*HPLs2[0*2+0]
          + 21.0/4*HPLs2[1*2+0]
          - 21.0/4*HPLs1[1]
          - 21.0/4*HPLs2[0*2+1]
          )

       + (dN_c*dN_c-1)/(dN_c*dN_c)*double_complex(0,1)*M_PI*pow(u,2)*pow(1-v,-1) * (
          - 21.0/8*GHPLs1[2]
          + 21.0/8*GHPLs1[3]
          - 21.0/8*GHPLs1[0]
          + 21.0/8*GHPLs1[1]
          + 21.0/8*HPLs1[0]
          + 21.0/8*HPLs1[1]
          )

       + (dN_c*dN_c-1)/(dN_c*dN_c)*double_complex(0,1)*M_PI*pow(u,2) * (
          - GHPLs1[2]
          + GHPLs1[3]
          - GHPLs1[0]
          + GHPLs1[1]
          + HPLs1[0]
          + HPLs1[1]
          )

       + (dN_c*dN_c-1)/(dN_c*dN_c)*double_complex(0,1)*M_PI*pow(u,3)*pow(1-v,-4) * (
          - 9.0/2*zeta2
          + 9.0/4*GHPLs2[3*4+2]
          + 9.0/4*GHPLs1[2]*HPLs1[0]
          - 9.0/4*GHPLs2[1*4+2]
          - 9.0/4*GHPLs2[3*4+0]
          - 9.0/4*GHPLs1[0]*HPLs1[0]
          + 9.0/4*GHPLs2[1*4+0]
          + 9.0/4*HPLs2[0*2+0]
          + 9.0/4*HPLs2[1*2+0]
          - 9.0/4*HPLs2[0*2+1]
          )

       + (dN_c*dN_c-1)/(dN_c*dN_c)*double_complex(0,1)*M_PI*pow(u,3)*pow(1-v,-3) * (
          + 9.0/2*zeta2
          - 9.0/4*GHPLs2[3*4+2]
          - 9.0/4*GHPLs1[2]
          - 9.0/4*GHPLs1[2]*HPLs1[0]
          + 9.0/4*GHPLs2[1*4+2]
          + 9.0/4*GHPLs1[3]
          + 9.0/4*GHPLs2[3*4+0]
          - 9.0/4*GHPLs1[0]
          + 9.0/4*GHPLs1[0]*HPLs1[0]
          - 9.0/4*GHPLs2[1*4+0]
          + 9.0/4*GHPLs1[1]
          + 9.0/4*HPLs1[0]
          - 9.0/4*HPLs2[0*2+0]
          - 9.0/4*HPLs2[1*2+0]
          + 9.0/4*HPLs1[1]
          + 9.0/4*HPLs2[0*2+1]
          )

       + (dN_c*dN_c-1)/(dN_c*dN_c)*double_complex(0,1)*M_PI*pow(u,3)*pow(1-v,-2) * (
          + 9.0/8*GHPLs1[2]
          - 9.0/8*GHPLs1[3]
          + 9.0/8*GHPLs1[0]
          - 9.0/8*GHPLs1[1]
          - 9.0/8*HPLs1[0]
          - 9.0/8*HPLs1[1]
          )

       + (dN_c*dN_c-1)/(dN_c*dN_c)*double_complex(0,1)*M_PI*pow(u,3)*pow(1-v,-1) * (
          + 3.0/8*GHPLs1[2]
          - 3.0/8*GHPLs1[3]
          + 3.0/8*GHPLs1[0]
          - 3.0/8*GHPLs1[1]
          - 3.0/8*HPLs1[0]
          - 3.0/8*HPLs1[1]
          )

       + C_F*NF*pow(1-v,-1) * (
          + 1.0/6*zeta2
          + 1.0/6*GHPLs1[0]*HPLs1[0]
          - 13.0/36*HPLs1[0]
          - 1.0/3*HPLs2[0*2+0]
          + 1.0/6*HPLs2[0*2+1]
          )

       + C_F*NF * (
          - 19.0/36
          - 1.0/6*zeta2
          + 1.0/6*GHPLs1[0]
          - 1.0/6*GHPLs1[0]*HPLs1[0]
          + 7.0/36*HPLs1[0]
          + 1.0/3*HPLs2[0*2+0]
          - 1.0/6*HPLs2[0*2+1]
          )

       + C_F*NF*u*pow(1-v,-2) * (
          - 1.0/6*zeta2
          - 1.0/6*GHPLs1[0]*HPLs1[0]
          + 13.0/36*HPLs1[0]
          + 1.0/3*HPLs2[0*2+0]
          - 1.0/6*HPLs2[0*2+1]
          )

       + C_F*NF*u*pow(1-v,-1) * (
          + 19.0/36
          + 1.0/6*zeta2
          - 1.0/6*GHPLs1[0]
          + 1.0/6*GHPLs1[0]*HPLs1[0]
          - 7.0/36*HPLs1[0]
          - 1.0/3*HPLs2[0*2+0]
          + 1.0/6*HPLs2[0*2+1]
          );
}

void gamma_2_2(double u, double v, int n_f, double *GHPLs1, double *GHPLs2, double *GHPLs3, double *GHPLs4, double *HPLs1, double *HPLs2, double *HPLs3, double *HPLs4, double_complex &gamma) {
  //  const double zeta2 = M_PI*M_PI/6;
  //  const double zeta3 = 1.20205690315959429;
  //  const double zeta4 = pow(M_PI,4)/90;
  //  const double dN_c=3;
  //  const double C_F=(dN_c*dN_c-1)/(2*dN_c);
  double NF=(double)n_f;

  gamma =
    (dN_c*dN_c-1)*pow(u,-2)*v * (
          + 1.0/2*GHPLs2[2*4+2]*zeta2
          - 13.0/24*GHPLs2[2*4+2]*HPLs1[0]
          - 1.0/2*GHPLs2[2*4+2]*HPLs2[1*2+0]
          - 1.0/2*GHPLs4[2*4*4*4+1*4*4+2*4+2]
          + 1.0/2*GHPLs3[1*4*4+2*4+2]*HPLs1[0]
          + 1.0/2*GHPLs3[1*4*4+2*4+2]*HPLs1[1]
          - 13.0/24*GHPLs1[2]*zeta2
          + 277.0/144*GHPLs1[2]*HPLs1[0]
          + 11.0/6*GHPLs1[2]*HPLs2[0*2+0]
          + 13.0/24*GHPLs1[2]*HPLs2[1*2+0]
          + 1.0/2*GHPLs3[2*4*4+0*4+2]*HPLs1[0]
          + 1.0/2*GHPLs4[2*4*4*4+1*4*4+0*4+2]
          - 1.0/2*GHPLs3[1*4*4+0*4+2]*HPLs1[0]
          - 1.0/2*GHPLs3[1*4*4+0*4+2]*HPLs1[1]
          + 1.0/4*GHPLs3[2*4*4+1*4+2]*HPLs1[0]
          - GHPLs2[1*4+2]*zeta2
          + 1.0/4*GHPLs2[1*4+2]*HPLs2[1*2+0]
          - 1.0/4*GHPLs2[1*4+2]*HPLs2[0*2+1]
          + 1.0/2*GHPLs4[2*4*4*4+1*4*4+1*4+2]
          - 1.0/2*GHPLs3[1*4*4+1*4+2]*HPLs1[0]
          - 1.0/2*GHPLs3[1*4*4+1*4+2]*HPLs1[1]
          - 13.0/24*GHPLs3[2*4*4+2*4+1]
          + 1.0/2*GHPLs3[2*4*4+2*4+1]*HPLs1[0]
          + 277.0/144*GHPLs2[2*4+1]
          - GHPLs2[2*4+1]*zeta2
          + 11.0/12*GHPLs2[2*4+1]*HPLs1[0]
          + 1.0/4*GHPLs2[2*4+1]*HPLs2[1*2+0]
          + 13.0/24*GHPLs2[2*4+1]*HPLs1[1]
          - 1.0/4*GHPLs2[2*4+1]*HPLs2[0*2+1]
          + 3.0/4*GHPLs4[2*4*4*4+1*4*4+2*4+1]
          - 3.0/4*GHPLs3[1*4*4+2*4+1]*HPLs1[0]
          - 3.0/4*GHPLs3[1*4*4+2*4+1]*HPLs1[1]
          - 67.0/24*GHPLs1[1]*zeta2
          - 3.0/4*GHPLs1[1]*zeta3
          - 277.0/144*GHPLs1[1]*HPLs1[0]
          - 11.0/6*GHPLs1[1]*HPLs2[0*2+0]
          - 35.0/24*GHPLs1[1]*HPLs2[1*2+0]
          - 277.0/144*GHPLs1[1]*HPLs1[1]
          + GHPLs1[1]*HPLs1[1]*zeta2
          - 11.0/12*GHPLs1[1]*HPLs2[0*2+1]
          - 1.0/4*GHPLs1[1]*HPLs3[1*2*2+0*2+1]
          - 13.0/24*GHPLs1[1]*HPLs2[1*2+1]
          + 1.0/4*GHPLs1[1]*HPLs3[0*2*2+1*2+1]
          - 1.0/4*GHPLs3[2*4*4+0*4+1]*HPLs1[0]
          - 1.0/4*GHPLs4[2*4*4*4+1*4*4+0*4+1]
          + 1.0/4*GHPLs3[1*4*4+0*4+1]*HPLs1[0]
          + 1.0/4*GHPLs3[1*4*4+0*4+1]*HPLs1[1]
          + 1.0/2*GHPLs4[2*4*4*4+2*4*4+1*4+1]
          - 13.0/24*GHPLs3[2*4*4+1*4+1]
          - 1.0/2*GHPLs3[2*4*4+1*4+1]*HPLs1[0]
          - 1.0/2*GHPLs3[2*4*4+1*4+1]*HPLs1[1]
          - 1.0/2*GHPLs2[1*4+1]*zeta2
          + 13.0/24*GHPLs2[1*4+1]*HPLs1[0]
          + 13.0/24*GHPLs2[1*4+1]*HPLs1[1]
          + 1.0/2*GHPLs2[1*4+1]*HPLs2[0*2+1]
          + 1.0/2*GHPLs2[1*4+1]*HPLs2[1*2+1]
          - 1.0/2*GHPLs4[2*4*4*4+1*4*4+1*4+1]
          + 1.0/2*GHPLs3[1*4*4+1*4+1]*HPLs1[0]
          + 1.0/2*GHPLs3[1*4*4+1*4+1]*HPLs1[1]
          )

       + (dN_c*dN_c-1)*pow(u,-2)*pow(v,2) * (
          - 1.0/2*GHPLs2[2*4+2]*zeta2
          + 13.0/24*GHPLs2[2*4+2]*HPLs1[0]
          + 1.0/2*GHPLs2[2*4+2]*HPLs2[1*2+0]
          + 1.0/2*GHPLs4[2*4*4*4+1*4*4+2*4+2]
          - 1.0/2*GHPLs3[1*4*4+2*4+2]*HPLs1[0]
          - 1.0/2*GHPLs3[1*4*4+2*4+2]*HPLs1[1]
          + 13.0/24*GHPLs1[2]*zeta2
          - 277.0/144*GHPLs1[2]*HPLs1[0]
          - 11.0/6*GHPLs1[2]*HPLs2[0*2+0]
          - 13.0/24*GHPLs1[2]*HPLs2[1*2+0]
          - 1.0/2*GHPLs3[2*4*4+0*4+2]*HPLs1[0]
          - 1.0/2*GHPLs4[2*4*4*4+1*4*4+0*4+2]
          + 1.0/2*GHPLs3[1*4*4+0*4+2]*HPLs1[0]
          + 1.0/2*GHPLs3[1*4*4+0*4+2]*HPLs1[1]
          - 1.0/4*GHPLs3[2*4*4+1*4+2]*HPLs1[0]
          + GHPLs2[1*4+2]*zeta2
          - 1.0/4*GHPLs2[1*4+2]*HPLs2[1*2+0]
          + 1.0/4*GHPLs2[1*4+2]*HPLs2[0*2+1]
          - 1.0/2*GHPLs4[2*4*4*4+1*4*4+1*4+2]
          + 1.0/2*GHPLs3[1*4*4+1*4+2]*HPLs1[0]
          + 1.0/2*GHPLs3[1*4*4+1*4+2]*HPLs1[1]
          + 13.0/24*GHPLs3[2*4*4+2*4+1]
          - 1.0/2*GHPLs3[2*4*4+2*4+1]*HPLs1[0]
          - 277.0/144*GHPLs2[2*4+1]
          + GHPLs2[2*4+1]*zeta2
          - 11.0/12*GHPLs2[2*4+1]*HPLs1[0]
          - 1.0/4*GHPLs2[2*4+1]*HPLs2[1*2+0]
          - 13.0/24*GHPLs2[2*4+1]*HPLs1[1]
          + 1.0/4*GHPLs2[2*4+1]*HPLs2[0*2+1]
          - 3.0/4*GHPLs4[2*4*4*4+1*4*4+2*4+1]
          + 3.0/4*GHPLs3[1*4*4+2*4+1]*HPLs1[0]
          + 3.0/4*GHPLs3[1*4*4+2*4+1]*HPLs1[1]
          + 67.0/24*GHPLs1[1]*zeta2
          + 3.0/4*GHPLs1[1]*zeta3
          + 277.0/144*GHPLs1[1]*HPLs1[0]
          + 11.0/6*GHPLs1[1]*HPLs2[0*2+0]
          + 35.0/24*GHPLs1[1]*HPLs2[1*2+0]
          + 277.0/144*GHPLs1[1]*HPLs1[1]
          - GHPLs1[1]*HPLs1[1]*zeta2
          + 11.0/12*GHPLs1[1]*HPLs2[0*2+1]
          + 1.0/4*GHPLs1[1]*HPLs3[1*2*2+0*2+1]
          + 13.0/24*GHPLs1[1]*HPLs2[1*2+1]
          - 1.0/4*GHPLs1[1]*HPLs3[0*2*2+1*2+1]
          + 1.0/4*GHPLs3[2*4*4+0*4+1]*HPLs1[0]
          + 1.0/4*GHPLs4[2*4*4*4+1*4*4+0*4+1]
          - 1.0/4*GHPLs3[1*4*4+0*4+1]*HPLs1[0]
          - 1.0/4*GHPLs3[1*4*4+0*4+1]*HPLs1[1]
          - 1.0/2*GHPLs4[2*4*4*4+2*4*4+1*4+1]
          + 13.0/24*GHPLs3[2*4*4+1*4+1]
          + 1.0/2*GHPLs3[2*4*4+1*4+1]*HPLs1[0]
          + 1.0/2*GHPLs3[2*4*4+1*4+1]*HPLs1[1]
          + 1.0/2*GHPLs2[1*4+1]*zeta2
          - 13.0/24*GHPLs2[1*4+1]*HPLs1[0]
          - 13.0/24*GHPLs2[1*4+1]*HPLs1[1]
          - 1.0/2*GHPLs2[1*4+1]*HPLs2[0*2+1]
          - 1.0/2*GHPLs2[1*4+1]*HPLs2[1*2+1]
          + 1.0/2*GHPLs4[2*4*4*4+1*4*4+1*4+1]
          - 1.0/2*GHPLs3[1*4*4+1*4+1]*HPLs1[0]
          - 1.0/2*GHPLs3[1*4*4+1*4+1]*HPLs1[1]
          )

       + (dN_c*dN_c-1)*pow(u,-1) * (
          - 1.0/8*GHPLs1[2]*HPLs1[0]
          - 1.0/8*GHPLs2[2*4+1]
          + 1.0/8*GHPLs1[1]*HPLs1[0]
          + 1.0/8*GHPLs1[1]*HPLs1[1]
          )

       + (dN_c*dN_c-1)*pow(u,-1)*v * (
          + 1.0/2
          - 10.0/3*zeta2
          - 3.0/4*zeta3
          - 13.0/24*GHPLs2[2*4+2]
          - 1.0/2*GHPLs2[2*4+2]*zeta2
          + 25.0/24*GHPLs2[2*4+2]*HPLs1[0]
          + 1.0/2*GHPLs2[2*4+2]*HPLs2[1*2+0]
          + 1.0/2*GHPLs4[2*4*4*4+1*4*4+2*4+2]
          - 1.0/2*GHPLs3[1*4*4+2*4+2]*HPLs1[0]
          - 1.0/2*GHPLs3[1*4*4+2*4+2]*HPLs1[1]
          + 277.0/144*GHPLs1[2]
          - 5.0/24*GHPLs1[2]*zeta2
          - 205.0/144*GHPLs1[2]*HPLs1[0]
          - 11.0/6*GHPLs1[2]*HPLs2[0*2+0]
          - 13.0/24*GHPLs1[2]*HPLs2[1*2+0]
          + 13.0/24*GHPLs1[2]*HPLs1[1]
          - 1.0/4*GHPLs1[2]*HPLs2[0*2+1]
          - 1.0/2*GHPLs3[2*4*4+0*4+2]*HPLs1[0]
          - 1.0/2*GHPLs4[2*4*4*4+1*4*4+0*4+2]
          + 1.0/2*GHPLs3[1*4*4+0*4+2]*HPLs1[0]
          + 1.0/2*GHPLs3[1*4*4+0*4+2]*HPLs1[1]
          + 1.0/2*GHPLs3[2*4*4+1*4+2]
          - 1.0/4*GHPLs3[2*4*4+1*4+2]*HPLs1[0]
          + GHPLs2[1*4+2]*zeta2
          - 1.0/2*GHPLs2[1*4+2]*HPLs1[0]
          - 1.0/4*GHPLs2[1*4+2]*HPLs2[1*2+0]
          - 1.0/2*GHPLs2[1*4+2]*HPLs1[1]
          + 1.0/4*GHPLs2[1*4+2]*HPLs2[0*2+1]
          - 1.0/2*GHPLs4[2*4*4*4+1*4*4+1*4+2]
          + 1.0/2*GHPLs3[1*4*4+1*4+2]*HPLs1[0]
          + 1.0/2*GHPLs3[1*4*4+1*4+2]*HPLs1[1]
          + 25.0/24*GHPLs3[2*4*4+2*4+1]
          - 1.0/2*GHPLs3[2*4*4+2*4+1]*HPLs1[0]
          - 337.0/144*GHPLs2[2*4+1]
          + GHPLs2[2*4+1]*zeta2
          - 17.0/12*GHPLs2[2*4+1]*HPLs1[0]
          - 1.0/4*GHPLs2[2*4+1]*HPLs2[1*2+0]
          - 25.0/24*GHPLs2[2*4+1]*HPLs1[1]
          + 1.0/4*GHPLs2[2*4+1]*HPLs2[0*2+1]
          - 3.0/4*GHPLs4[2*4*4*4+1*4*4+2*4+1]
          + 3.0/4*GHPLs3[1*4*4+2*4+1]*HPLs1[0]
          + 3.0/4*GHPLs3[1*4*4+2*4+1]*HPLs1[1]
          + 55.0/24*GHPLs1[1]*zeta2
          + 3.0/4*GHPLs1[1]*zeta3
          + 337.0/144*GHPLs1[1]*HPLs1[0]
          + 11.0/6*GHPLs1[1]*HPLs2[0*2+0]
          + 35.0/24*GHPLs1[1]*HPLs2[1*2+0]
          + 337.0/144*GHPLs1[1]*HPLs1[1]
          - GHPLs1[1]*HPLs1[1]*zeta2
          + 17.0/12*GHPLs1[1]*HPLs2[0*2+1]
          + 1.0/4*GHPLs1[1]*HPLs3[1*2*2+0*2+1]
          + 25.0/24*GHPLs1[1]*HPLs2[1*2+1]
          - 1.0/4*GHPLs1[1]*HPLs3[0*2*2+1*2+1]
          + 1.0/4*GHPLs3[2*4*4+0*4+1]*HPLs1[0]
          + 1.0/4*GHPLs4[2*4*4*4+1*4*4+0*4+1]
          - 1.0/4*GHPLs3[1*4*4+0*4+1]*HPLs1[0]
          - 1.0/4*GHPLs3[1*4*4+0*4+1]*HPLs1[1]
          - 1.0/2*GHPLs4[2*4*4*4+2*4*4+1*4+1]
          + 1.0/24*GHPLs3[2*4*4+1*4+1]
          + 1.0/2*GHPLs3[2*4*4+1*4+1]*HPLs1[0]
          + 1.0/2*GHPLs3[2*4*4+1*4+1]*HPLs1[1]
          + 1.0/2*GHPLs2[1*4+1]*zeta2
          - 1.0/24*GHPLs2[1*4+1]*HPLs1[0]
          - 1.0/24*GHPLs2[1*4+1]*HPLs1[1]
          - 1.0/2*GHPLs2[1*4+1]*HPLs2[0*2+1]
          - 1.0/2*GHPLs2[1*4+1]*HPLs2[1*2+1]
          + 1.0/2*GHPLs4[2*4*4*4+1*4*4+1*4+1]
          - 1.0/2*GHPLs3[1*4*4+1*4+1]*HPLs1[0]
          - 1.0/2*GHPLs3[1*4*4+1*4+1]*HPLs1[1]
          - 11.0/12*HPLs2[1*2+0]
          - 277.0/144*HPLs1[1]
          + HPLs1[1]*zeta2
          - 11.0/12*HPLs2[0*2+1]
          - 1.0/4*HPLs3[1*2*2+0*2+1]
          - 13.0/24*HPLs2[1*2+1]
          + 1.0/4*HPLs3[0*2*2+1*2+1]
          )

       + (dN_c*dN_c-1)*pow(u,-1)*pow(v,2) * (
          + 67.0/24*zeta2
          + 3.0/4*zeta3
          + 13.0/24*GHPLs2[2*4+2]
          - 1.0/2*GHPLs2[2*4+2]*HPLs1[0]
          - 277.0/144*GHPLs1[2]
          + GHPLs1[2]*zeta2
          - 25.0/24*GHPLs1[2]*HPLs1[0]
          - 1.0/4*GHPLs1[2]*HPLs2[1*2+0]
          - 13.0/24*GHPLs1[2]*HPLs1[1]
          + 1.0/4*GHPLs1[2]*HPLs2[0*2+1]
          - 3.0/4*GHPLs3[2*4*4+1*4+2]
          + 3.0/4*GHPLs2[1*4+2]*HPLs1[0]
          + 3.0/4*GHPLs2[1*4+2]*HPLs1[1]
          + 1.0/4*GHPLs2[2*4+0]*HPLs1[0]
          + 1.0/4*GHPLs3[2*4*4+1*4+0]
          - 1.0/4*GHPLs2[1*4+0]*HPLs1[0]
          - 1.0/4*GHPLs2[1*4+0]*HPLs1[1]
          - 1.0/2*GHPLs3[2*4*4+2*4+1]
          + 5.0/12*GHPLs2[2*4+1]
          + 1.0/2*GHPLs2[2*4+1]*HPLs1[0]
          + 1.0/2*GHPLs2[2*4+1]*HPLs1[1]
          + 1.0/2*GHPLs1[1]*zeta2
          - 5.0/12*GHPLs1[1]*HPLs1[0]
          - 5.0/12*GHPLs1[1]*HPLs1[1]
          - 1.0/2*GHPLs1[1]*HPLs2[0*2+1]
          - 1.0/2*GHPLs1[1]*HPLs2[1*2+1]
          + 1.0/2*GHPLs3[2*4*4+1*4+1]
          - 1.0/2*GHPLs2[1*4+1]*HPLs1[0]
          - 1.0/2*GHPLs2[1*4+1]*HPLs1[1]
          + 277.0/144*HPLs1[0]
          + 11.0/6*HPLs2[0*2+0]
          + 35.0/24*HPLs2[1*2+0]
          + 277.0/144*HPLs1[1]
          - HPLs1[1]*zeta2
          + 11.0/12*HPLs2[0*2+1]
          + 1.0/4*HPLs3[1*2*2+0*2+1]
          + 13.0/24*HPLs2[1*2+1]
          - 1.0/4*HPLs3[0*2*2+1*2+1]
          )

       + (dN_c*dN_c-1)*pow(1-v,-1) * (
          + 13.0/48*zeta2
          - 1.0/8*GHPLs1[2]*zeta2
          + 19.0/48*GHPLs1[2]*HPLs1[0]
          + 1.0/8*GHPLs1[2]*HPLs2[1*2+0]
          + 1.0/8*GHPLs3[2*4*4+1*4+2]
          - 1.0/8*GHPLs2[1*4+2]*HPLs1[0]
          - 1.0/8*GHPLs2[1*4+2]*HPLs1[1]
          - 1.0/8*GHPLs2[2*4+0]*HPLs1[0]
          - 1.0/8*GHPLs3[2*4*4+1*4+0]
          + 1.0/8*GHPLs2[1*4+0]*HPLs1[0]
          + 1.0/8*GHPLs2[1*4+0]*HPLs1[1]
          + 1.0/8*GHPLs2[2*4+1]
          - 1.0/8*GHPLs1[1]*HPLs1[0]
          - 1.0/8*GHPLs1[1]*HPLs1[1]
          - 391.0/288*HPLs1[0]
          - 11.0/12*HPLs2[0*2+0]
          - 13.0/48*HPLs2[1*2+0]
          )

       + (dN_c*dN_c-1) * (
          + 1.0/2
          - 13.0/48*zeta2
          - 1.0/8*GHPLs1[2]
          + 1.0/8*GHPLs1[2]*zeta2
          - 13.0/48*GHPLs1[2]*HPLs1[0]
          - 1.0/8*GHPLs1[2]*HPLs2[1*2+0]
          - 1.0/8*GHPLs3[2*4*4+1*4+2]
          + 1.0/8*GHPLs2[1*4+2]*HPLs1[0]
          + 1.0/8*GHPLs2[1*4+2]*HPLs1[1]
          + 1.0/8*GHPLs2[2*4+0]*HPLs1[0]
          + 1.0/8*GHPLs3[2*4*4+1*4+0]
          - 1.0/8*GHPLs2[1*4+0]*HPLs1[0]
          - 1.0/8*GHPLs2[1*4+0]*HPLs1[1]
          + 391.0/288*HPLs1[0]
          + 11.0/12*HPLs2[0*2+0]
          + 13.0/48*HPLs2[1*2+0]
          + 1.0/8*HPLs1[1]
          )

       + (dN_c*dN_c-1)*v*pow(1-u,-1) * (
          + 277.0/288
          + 55.0/48*zeta2
          + 3.0/8*zeta3
          + 25.0/48*GHPLs2[2*4+2]
          - 1.0/4*GHPLs2[2*4+2]*HPLs1[0]
          - 433.0/288*GHPLs1[2]
          + 1.0/2*GHPLs1[2]*zeta2
          - 7.0/12*GHPLs1[2]*HPLs1[0]
          - 1.0/8*GHPLs1[2]*HPLs2[1*2+0]
          - 25.0/48*GHPLs1[2]*HPLs1[1]
          + 1.0/8*GHPLs1[2]*HPLs2[0*2+1]
          - 3.0/8*GHPLs3[2*4*4+1*4+2]
          + 3.0/8*GHPLs2[1*4+2]*HPLs1[0]
          + 3.0/8*GHPLs2[1*4+2]*HPLs1[1]
          + 1.0/8*GHPLs2[2*4+0]*HPLs1[0]
          + 1.0/8*GHPLs3[2*4*4+1*4+0]
          - 1.0/8*GHPLs2[1*4+0]*HPLs1[0]
          - 1.0/8*GHPLs2[1*4+0]*HPLs1[1]
          - 1.0/4*GHPLs3[2*4*4+2*4+1]
          + 7.0/48*GHPLs2[2*4+1]
          + 1.0/4*GHPLs2[2*4+1]*HPLs1[0]
          + 1.0/4*GHPLs2[2*4+1]*HPLs1[1]
          + 1.0/4*GHPLs1[1]*zeta2
          - 7.0/48*GHPLs1[1]*HPLs1[0]
          - 7.0/48*GHPLs1[1]*HPLs1[1]
          - 1.0/4*GHPLs1[1]*HPLs2[0*2+1]
          - 1.0/4*GHPLs1[1]*HPLs2[1*2+1]
          + 1.0/4*GHPLs3[2*4*4+1*4+1]
          - 1.0/4*GHPLs2[1*4+1]*HPLs1[0]
          - 1.0/4*GHPLs2[1*4+1]*HPLs1[1]
          + 487.0/288*HPLs1[0]
          + 11.0/12*HPLs2[0*2+0]
          + 35.0/48*HPLs2[1*2+0]
          + 433.0/288*HPLs1[1]
          - 1.0/2*HPLs1[1]*zeta2
          + 17.0/24*HPLs2[0*2+1]
          + 1.0/8*HPLs3[1*2*2+0*2+1]
          + 25.0/48*HPLs2[1*2+1]
          - 1.0/8*HPLs3[0*2*2+1*2+1]
          )

       + (dN_c*dN_c-1)*pow(v,2)*pow(1-u,-2) * (
          - 55.0/48*zeta2
          - 3.0/8*zeta3
          - 25.0/48*GHPLs2[2*4+2]
          + 1.0/4*GHPLs2[2*4+2]*HPLs1[0]
          + 355.0/288*GHPLs1[2]
          - 1.0/2*GHPLs1[2]*zeta2
          + 17.0/24*GHPLs1[2]*HPLs1[0]
          + 1.0/8*GHPLs1[2]*HPLs2[1*2+0]
          + 25.0/48*GHPLs1[2]*HPLs1[1]
          - 1.0/8*GHPLs1[2]*HPLs2[0*2+1]
          + 3.0/8*GHPLs3[2*4*4+1*4+2]
          - 3.0/8*GHPLs2[1*4+2]*HPLs1[0]
          - 3.0/8*GHPLs2[1*4+2]*HPLs1[1]
          - 1.0/8*GHPLs2[2*4+0]*HPLs1[0]
          - 1.0/8*GHPLs3[2*4*4+1*4+0]
          + 1.0/8*GHPLs2[1*4+0]*HPLs1[0]
          + 1.0/8*GHPLs2[1*4+0]*HPLs1[1]
          + 1.0/4*GHPLs3[2*4*4+2*4+1]
          - 1.0/48*GHPLs2[2*4+1]
          - 1.0/4*GHPLs2[2*4+1]*HPLs1[0]
          - 1.0/4*GHPLs2[2*4+1]*HPLs1[1]
          - 1.0/4*GHPLs1[1]*zeta2
          + 1.0/48*GHPLs1[1]*HPLs1[0]
          + 1.0/48*GHPLs1[1]*HPLs1[1]
          + 1.0/4*GHPLs1[1]*HPLs2[0*2+1]
          + 1.0/4*GHPLs1[1]*HPLs2[1*2+1]
          - 1.0/4*GHPLs3[2*4*4+1*4+1]
          + 1.0/4*GHPLs2[1*4+1]*HPLs1[0]
          + 1.0/4*GHPLs2[1*4+1]*HPLs1[1]
          - 355.0/288*HPLs1[0]
          - 11.0/12*HPLs2[0*2+0]
          - 35.0/48*HPLs2[1*2+0]
          - 355.0/288*HPLs1[1]
          + 1.0/2*HPLs1[1]*zeta2
          - 17.0/24*HPLs2[0*2+1]
          - 1.0/8*HPLs3[1*2*2+0*2+1]
          - 25.0/48*HPLs2[1*2+1]
          + 1.0/8*HPLs3[0*2*2+1*2+1]
          )

       + (dN_c*dN_c-1)*pow(v,2)*pow(1-u,-1) * (
          + 67.0/24*zeta2
          + 3.0/4*zeta3
          + 13.0/24*GHPLs2[2*4+2]
          - 1.0/2*GHPLs2[2*4+2]*HPLs1[0]
          - 277.0/144*GHPLs1[2]
          + GHPLs1[2]*zeta2
          - 25.0/24*GHPLs1[2]*HPLs1[0]
          - 1.0/4*GHPLs1[2]*HPLs2[1*2+0]
          - 13.0/24*GHPLs1[2]*HPLs1[1]
          + 1.0/4*GHPLs1[2]*HPLs2[0*2+1]
          - 3.0/4*GHPLs3[2*4*4+1*4+2]
          + 3.0/4*GHPLs2[1*4+2]*HPLs1[0]
          + 3.0/4*GHPLs2[1*4+2]*HPLs1[1]
          + 1.0/4*GHPLs2[2*4+0]*HPLs1[0]
          + 1.0/4*GHPLs3[2*4*4+1*4+0]
          - 1.0/4*GHPLs2[1*4+0]*HPLs1[0]
          - 1.0/4*GHPLs2[1*4+0]*HPLs1[1]
          - 1.0/2*GHPLs3[2*4*4+2*4+1]
          + 5.0/12*GHPLs2[2*4+1]
          + 1.0/2*GHPLs2[2*4+1]*HPLs1[0]
          + 1.0/2*GHPLs2[2*4+1]*HPLs1[1]
          + 1.0/2*GHPLs1[1]*zeta2
          - 5.0/12*GHPLs1[1]*HPLs1[0]
          - 5.0/12*GHPLs1[1]*HPLs1[1]
          - 1.0/2*GHPLs1[1]*HPLs2[0*2+1]
          - 1.0/2*GHPLs1[1]*HPLs2[1*2+1]
          + 1.0/2*GHPLs3[2*4*4+1*4+1]
          - 1.0/2*GHPLs2[1*4+1]*HPLs1[0]
          - 1.0/2*GHPLs2[1*4+1]*HPLs1[1]
          + 277.0/144*HPLs1[0]
          + 11.0/6*HPLs2[0*2+0]
          + 35.0/24*HPLs2[1*2+0]
          + 277.0/144*HPLs1[1]
          - HPLs1[1]*zeta2
          + 11.0/12*HPLs2[0*2+1]
          + 1.0/4*HPLs3[1*2*2+0*2+1]
          + 13.0/24*HPLs2[1*2+1]
          - 1.0/4*HPLs3[0*2*2+1*2+1]
          )

       + (dN_c*dN_c-1)*u*pow(1-v,-2) * (
          + 13.0/48*zeta2
          - 1.0/8*GHPLs1[2]*zeta2
          + 13.0/48*GHPLs1[2]*HPLs1[0]
          + 1.0/8*GHPLs1[2]*HPLs2[1*2+0]
          + 1.0/8*GHPLs3[2*4*4+1*4+2]
          - 1.0/8*GHPLs2[1*4+2]*HPLs1[0]
          - 1.0/8*GHPLs2[1*4+2]*HPLs1[1]
          - 1.0/8*GHPLs2[2*4+0]*HPLs1[0]
          - 1.0/8*GHPLs3[2*4*4+1*4+0]
          + 1.0/8*GHPLs2[1*4+0]*HPLs1[0]
          + 1.0/8*GHPLs2[1*4+0]*HPLs1[1]
          - 163.0/288*HPLs1[0]
          - 11.0/12*HPLs2[0*2+0]
          - 13.0/48*HPLs2[1*2+0]
          )

       + (dN_c*dN_c-1)*u*pow(1-v,-1) * (
          - 277.0/288
          - 13.0/48*zeta2
          + 19.0/48*GHPLs1[2]
          + 1.0/8*GHPLs1[2]*zeta2
          - 19.0/48*GHPLs1[2]*HPLs1[0]
          - 1.0/8*GHPLs1[2]*HPLs2[1*2+0]
          - 1.0/8*GHPLs3[2*4*4+1*4+2]
          + 1.0/8*GHPLs2[1*4+2]*HPLs1[0]
          + 1.0/8*GHPLs2[1*4+2]*HPLs1[1]
          + 1.0/8*GHPLs2[2*4+0]*HPLs1[0]
          + 1.0/8*GHPLs3[2*4*4+1*4+0]
          - 1.0/8*GHPLs2[1*4+0]*HPLs1[0]
          - 1.0/8*GHPLs2[1*4+0]*HPLs1[1]
          - 1.0/8*GHPLs2[2*4+1]
          + 1.0/8*GHPLs1[1]*HPLs1[0]
          + 1.0/8*GHPLs1[1]*HPLs1[1]
          + 31.0/288*HPLs1[0]
          + 11.0/12*HPLs2[0*2+0]
          + 13.0/48*HPLs2[1*2+0]
          - 19.0/48*HPLs1[1]
          )

       + (dN_c*dN_c-1)*double_complex(0,1)*M_PI*pow(u,-2)*v * (
          + 1.0/2*GHPLs2[2*4+2]*HPLs1[0]
          - 1.0/2*GHPLs3[1*4*4+2*4+2]
          + 3.0/8*GHPLs1[2]*HPLs1[0]
          + 1.0/2*GHPLs3[1*4*4+0*4+2]
          - 1.0/4*GHPLs2[1*4+2]*HPLs1[0]
          + 1.0/2*GHPLs3[1*4*4+1*4+2]
          + 3.0/8*GHPLs2[2*4+1]
          - 1.0/4*GHPLs2[2*4+1]*HPLs1[0]
          + 3.0/4*GHPLs3[1*4*4+2*4+1]
          + 277.0/144*GHPLs1[1]
          - 1.0/4*GHPLs1[1]*zeta2
          + 13.0/24*GHPLs1[1]*HPLs1[0]
          - 3.0/8*GHPLs1[1]*HPLs1[1]
          + 1.0/4*GHPLs1[1]*HPLs2[0*2+1]
          - 1.0/4*GHPLs3[1*4*4+0*4+1]
          + 1.0/2*GHPLs3[2*4*4+1*4+1]
          - 13.0/24*GHPLs2[1*4+1]
          - 1.0/2*GHPLs2[1*4+1]*HPLs1[1]
          - 1.0/2*GHPLs3[1*4*4+1*4+1]
          )

       + (dN_c*dN_c-1)*double_complex(0,1)*M_PI*pow(u,-2)*pow(v,2) * (
          - 1.0/2*GHPLs2[2*4+2]*HPLs1[0]
          + 1.0/2*GHPLs3[1*4*4+2*4+2]
          - 3.0/8*GHPLs1[2]*HPLs1[0]
          - 1.0/2*GHPLs3[1*4*4+0*4+2]
          + 1.0/4*GHPLs2[1*4+2]*HPLs1[0]
          - 1.0/2*GHPLs3[1*4*4+1*4+2]
          - 3.0/8*GHPLs2[2*4+1]
          + 1.0/4*GHPLs2[2*4+1]*HPLs1[0]
          - 3.0/4*GHPLs3[1*4*4+2*4+1]
          - 277.0/144*GHPLs1[1]
          + 1.0/4*GHPLs1[1]*zeta2
          - 13.0/24*GHPLs1[1]*HPLs1[0]
          + 3.0/8*GHPLs1[1]*HPLs1[1]
          - 1.0/4*GHPLs1[1]*HPLs2[0*2+1]
          + 1.0/4*GHPLs3[1*4*4+0*4+1]
          - 1.0/2*GHPLs3[2*4*4+1*4+1]
          + 13.0/24*GHPLs2[1*4+1]
          + 1.0/2*GHPLs2[1*4+1]*HPLs1[1]
          + 1.0/2*GHPLs3[1*4*4+1*4+1]
          )

       + (dN_c*dN_c-1)*double_complex(0,1)*M_PI*pow(u,-1) * (
          - 1.0/8*GHPLs1[1]
          )

       + (dN_c*dN_c-1)*double_complex(0,1)*M_PI*pow(u,-1)*v * (
          + 277.0/144
          - 1.0/4*zeta2
          - 1.0/2*GHPLs2[2*4+2]*HPLs1[0]
          + 1.0/2*GHPLs3[1*4*4+2*4+2]
          + 3.0/8*GHPLs1[2]
          - 3.0/8*GHPLs1[2]*HPLs1[0]
          - 1.0/2*GHPLs3[1*4*4+0*4+2]
          + 1.0/2*GHPLs2[1*4+2]
          + 1.0/4*GHPLs2[1*4+2]*HPLs1[0]
          - 1.0/2*GHPLs3[1*4*4+1*4+2]
          + 1.0/8*GHPLs2[2*4+1]
          + 1.0/4*GHPLs2[2*4+1]*HPLs1[0]
          - 3.0/4*GHPLs3[1*4*4+2*4+1]
          - 337.0/144*GHPLs1[1]
          + 1.0/4*GHPLs1[1]*zeta2
          - 13.0/24*GHPLs1[1]*HPLs1[0]
          - 1.0/8*GHPLs1[1]*HPLs1[1]
          - 1.0/4*GHPLs1[1]*HPLs2[0*2+1]
          + 1.0/4*GHPLs3[1*4*4+0*4+1]
          - 1.0/2*GHPLs3[2*4*4+1*4+1]
          + 1.0/24*GHPLs2[1*4+1]
          + 1.0/2*GHPLs2[1*4+1]*HPLs1[1]
          + 1.0/2*GHPLs3[1*4*4+1*4+1]
          + 11.0/12*HPLs1[0]
          - 3.0/8*HPLs1[1]
          + 1.0/4*HPLs2[0*2+1]
          )

       + (dN_c*dN_c-1)*double_complex(0,1)*M_PI*pow(u,-1)*pow(v,2) * (
          - 277.0/144
          + 1.0/4*zeta2
          - 3.0/8*GHPLs1[2]
          + 1.0/4*GHPLs1[2]*HPLs1[0]
          - 3.0/4*GHPLs2[1*4+2]
          + 1.0/4*GHPLs2[1*4+0]
          - 1.0/2*GHPLs2[2*4+1]
          + 5.0/12*GHPLs1[1]
          + 1.0/2*GHPLs1[1]*HPLs1[1]
          + 1.0/2*GHPLs2[1*4+1]
          - 13.0/24*HPLs1[0]
          + 3.0/8*HPLs1[1]
          - 1.0/4*HPLs2[0*2+1]
          )

       + (dN_c*dN_c-1)*double_complex(0,1)*M_PI*pow(1-v,-1) * (
          - 1.0/8*GHPLs1[2]*HPLs1[0]
          + 1.0/8*GHPLs2[1*4+2]
          - 1.0/8*GHPLs2[1*4+0]
          + 1.0/8*GHPLs1[1]
          - 3.0/16*HPLs1[0]
          )

       + (dN_c*dN_c-1)*double_complex(0,1)*M_PI * (
          - 1.0/8
          + 1.0/8*GHPLs1[2]*HPLs1[0]
          - 1.0/8*GHPLs2[1*4+2]
          + 1.0/8*GHPLs2[1*4+0]
          + 3.0/16*HPLs1[0]
          )

       + (dN_c*dN_c-1)*double_complex(0,1)*M_PI*v*pow(1-u,-1) * (
          - 301.0/288
          + 1.0/8*zeta2
          + 1.0/16*GHPLs1[2]
          + 1.0/8*GHPLs1[2]*HPLs1[0]
          - 3.0/8*GHPLs2[1*4+2]
          + 1.0/8*GHPLs2[1*4+0]
          - 1.0/4*GHPLs2[2*4+1]
          + 7.0/48*GHPLs1[1]
          + 1.0/4*GHPLs1[1]*HPLs1[1]
          + 1.0/4*GHPLs2[1*4+1]
          - 13.0/48*HPLs1[0]
          - 1.0/16*HPLs1[1]
          - 1.0/8*HPLs2[0*2+1]
          )

       + (dN_c*dN_c-1)*double_complex(0,1)*M_PI*pow(v,2)*pow(1-u,-2) * (
          + 355.0/288
          - 1.0/8*zeta2
          - 1.0/16*GHPLs1[2]
          - 1.0/8*GHPLs1[2]*HPLs1[0]
          + 3.0/8*GHPLs2[1*4+2]
          - 1.0/8*GHPLs2[1*4+0]
          + 1.0/4*GHPLs2[2*4+1]
          - 1.0/48*GHPLs1[1]
          - 1.0/4*GHPLs1[1]*HPLs1[1]
          - 1.0/4*GHPLs2[1*4+1]
          + 13.0/48*HPLs1[0]
          + 1.0/16*HPLs1[1]
          + 1.0/8*HPLs2[0*2+1]
          )

       + (dN_c*dN_c-1)*double_complex(0,1)*M_PI*pow(v,2)*pow(1-u,-1) * (
          - 277.0/144
          + 1.0/4*zeta2
          - 3.0/8*GHPLs1[2]
          + 1.0/4*GHPLs1[2]*HPLs1[0]
          - 3.0/4*GHPLs2[1*4+2]
          + 1.0/4*GHPLs2[1*4+0]
          - 1.0/2*GHPLs2[2*4+1]
          + 5.0/12*GHPLs1[1]
          + 1.0/2*GHPLs1[1]*HPLs1[1]
          + 1.0/2*GHPLs2[1*4+1]
          - 13.0/24*HPLs1[0]
          + 3.0/8*HPLs1[1]
          - 1.0/4*HPLs2[0*2+1]
          )

       + (dN_c*dN_c-1)*double_complex(0,1)*M_PI*u*pow(1-v,-2) * (
          - 1.0/8*GHPLs1[2]*HPLs1[0]
          + 1.0/8*GHPLs2[1*4+2]
          - 1.0/8*GHPLs2[1*4+0]
          - 3.0/16*HPLs1[0]
          )

       + (dN_c*dN_c-1)*double_complex(0,1)*M_PI*u*pow(1-v,-1) * (
          - 1.0/16
          + 1.0/8*GHPLs1[2]*HPLs1[0]
          - 1.0/8*GHPLs2[1*4+2]
          + 1.0/8*GHPLs2[1*4+0]
          - 1.0/8*GHPLs1[1]
          + 3.0/16*HPLs1[0]
          )

       + (dN_c*dN_c-1)/(dN_c*dN_c)*pow(u,-2)*pow(1-u-v,-1) * (
          - 1.0/8*GHPLs2[2*4+3]*HPLs1[0]
          + 1.0/8*GHPLs3[0*4*4+2*4+3]
          - 1.0/8*GHPLs2[3*4+3]*HPLs1[0]
          + 1.0/8*GHPLs3[0*4*4+3*4+3]
          - 7.0/8*GHPLs1[3]*zeta2
          + 1.0/8*GHPLs1[3]*HPLs2[1*2+0]
          + 1.0/8*GHPLs1[3]*HPLs2[0*2+1]
          + 1.0/8*GHPLs3[2*4*4+0*4+3]
          - 1.0/8*GHPLs2[0*4+3]*HPLs1[1]
          + 1.0/8*GHPLs3[0*4*4+2*4+1]
          - GHPLs1[1]*zeta2
          + 1.0/8*GHPLs1[1]*HPLs2[0*2+0]
          + 1.0/8*GHPLs1[1]*HPLs2[1*2+0]
          + 1.0/8*GHPLs3[2*4*4+0*4+1]
          - 1.0/8*GHPLs2[0*4+1]*HPLs1[0]
          - 1.0/8*GHPLs2[0*4+1]*HPLs1[1]
          + 1.0/8*GHPLs3[2*4*4+1*4+1]
          - 1.0/8*GHPLs2[1*4+1]*HPLs1[0]
          - 1.0/8*GHPLs2[1*4+1]*HPLs1[1]
          )

       + (dN_c*dN_c-1)/(dN_c*dN_c)*pow(u,-2) * (
          + 1.0/8*GHPLs2[2*4+3]*HPLs1[0]
          - 1.0/8*GHPLs3[0*4*4+2*4+3]
          + 1.0/8*GHPLs2[3*4+3]*HPLs1[0]
          - 1.0/8*GHPLs3[0*4*4+3*4+3]
          + 7.0/8*GHPLs1[3]*zeta2
          - 1.0/8*GHPLs1[3]*HPLs2[1*2+0]
          - 1.0/8*GHPLs1[3]*HPLs2[0*2+1]
          - 1.0/8*GHPLs3[2*4*4+0*4+3]
          + 1.0/8*GHPLs2[0*4+3]*HPLs1[1]
          - 1.0/8*GHPLs3[0*4*4+2*4+1]
          + GHPLs1[1]*zeta2
          - 1.0/8*GHPLs1[1]*HPLs2[0*2+0]
          - 1.0/8*GHPLs1[1]*HPLs2[1*2+0]
          - 1.0/8*GHPLs3[2*4*4+0*4+1]
          + 1.0/8*GHPLs2[0*4+1]*HPLs1[0]
          + 1.0/8*GHPLs2[0*4+1]*HPLs1[1]
          - 1.0/8*GHPLs3[2*4*4+1*4+1]
          + 1.0/8*GHPLs2[1*4+1]*HPLs1[0]
          + 1.0/8*GHPLs2[1*4+1]*HPLs1[1]
          )

       + (dN_c*dN_c-1)/(dN_c*dN_c)*pow(u,-2)*v * (
          + 7.0/4*GHPLs3[3*4*4+2*4+2]*HPLs1[0]
          - 7.0/4*GHPLs4[0*4*4*4+3*4*4+2*4+2]
          - 7.0/4*GHPLs2[2*4+2]*zeta2
          + 5.0/4*GHPLs2[2*4+2]*HPLs2[0*2+0]
          + 5.0/4*GHPLs2[2*4+2]*HPLs2[1*2+0]
          - 1.0/2*GHPLs2[2*4+2]*HPLs2[0*2+1]
          - 1.0/2*GHPLs3[0*4*4+2*4+2]*HPLs1[0]
          + 5.0/4*GHPLs4[2*4*4*4+1*4*4+2*4+2]
          - 5.0/4*GHPLs3[1*4*4+2*4+2]*HPLs1[0]
          - 5.0/4*GHPLs3[1*4*4+2*4+2]*HPLs1[1]
          + 1.0/2*GHPLs3[3*4*4+3*4+2]*HPLs1[0]
          - 1.0/2*GHPLs4[0*4*4*4+3*4*4+3*4+2]
          + 1.0/2*GHPLs2[3*4+2]*zeta2
          - 3.0/2*GHPLs1[2]*zeta2
          + 3.0/4*GHPLs1[2]*zeta3
          + 11.0/16*GHPLs1[2]*HPLs1[0]
          - 11.0/2*GHPLs1[2]*HPLs1[0]*zeta2
          + 3.0/8*GHPLs1[2]*HPLs2[0*2+0]
          + 7.0/4*GHPLs1[2]*HPLs3[0*2*2+0*2+0]
          + 1.0/2*GHPLs1[2]*HPLs3[1*2*2+0*2+0]
          + 3.0/8*GHPLs1[2]*HPLs2[1*2+0]
          + 5.0/4*GHPLs1[2]*HPLs3[0*2*2+1*2+0]
          + 5.0/4*GHPLs1[2]*HPLs1[1]*zeta2
          - 9.0/8*GHPLs1[2]*HPLs2[0*2+1]
          - 5.0/4*GHPLs1[2]*HPLs3[0*2*2+0*2+1]
          - 5.0/4*GHPLs1[2]*HPLs3[1*2*2+0*2+1]
          - 7.0/4*GHPLs3[3*4*4+0*4+2]*HPLs1[0]
          + 7.0/4*GHPLs4[0*4*4*4+3*4*4+0*4+2]
          + 5.0/4*GHPLs2[0*4+2]*zeta2
          - 3.0/4*GHPLs2[0*4+2]*HPLs1[0]
          - 5.0/4*GHPLs2[0*4+2]*HPLs2[0*2+0]
          - 5.0/4*GHPLs2[0*4+2]*HPLs2[1*2+0]
          - 5.0/4*GHPLs4[2*4*4*4+1*4*4+0*4+2]
          + 5.0/4*GHPLs3[1*4*4+0*4+2]*HPLs1[0]
          + 5.0/4*GHPLs3[1*4*4+0*4+2]*HPLs1[1]
          + 3.0/8*GHPLs3[2*4*4+1*4+2]
          - 1.0/4*GHPLs3[2*4*4+1*4+2]*HPLs1[0]
          + GHPLs2[1*4+2]*zeta2
          - 3.0/8*GHPLs2[1*4+2]*HPLs1[0]
          - 1.0/4*GHPLs2[1*4+2]*HPLs2[1*2+0]
          - 3.0/8*GHPLs2[1*4+2]*HPLs1[1]
          + 1.0/4*GHPLs2[1*4+2]*HPLs2[0*2+1]
          - 1.0/2*GHPLs4[2*4*4*4+1*4*4+1*4+2]
          + 1.0/2*GHPLs3[1*4*4+1*4+2]*HPLs1[0]
          + 1.0/2*GHPLs3[1*4*4+1*4+2]*HPLs1[1]
          + 1.0/8*GHPLs2[2*4+3]*HPLs1[0]
          - 1.0/8*GHPLs3[0*4*4+2*4+3]
          + 1.0/8*GHPLs2[3*4+3]*HPLs1[0]
          - 1.0/8*GHPLs3[0*4*4+3*4+3]
          + 7.0/8*GHPLs1[3]*zeta2
          - 1.0/8*GHPLs1[3]*HPLs2[1*2+0]
          - 1.0/8*GHPLs1[3]*HPLs2[0*2+1]
          - 1.0/8*GHPLs3[2*4*4+0*4+3]
          + 1.0/8*GHPLs2[0*4+3]*HPLs1[1]
          - 7.0/4*GHPLs3[2*4*4+2*4+1]*HPLs1[0]
          + 5.0/4*GHPLs4[0*4*4*4+2*4*4+2*4+1]
          + 5.0/4*GHPLs3[3*4*4+2*4+1]*HPLs1[0]
          - 5.0/4*GHPLs4[0*4*4*4+3*4*4+2*4+1]
          + 11.0/16*GHPLs2[2*4+1]
          - 5*GHPLs2[2*4+1]*zeta2
          + 7.0/4*GHPLs2[2*4+1]*HPLs2[0*2+0]
          + 1.0/4*GHPLs2[2*4+1]*HPLs2[1*2+0]
          + 3.0/2*GHPLs2[2*4+1]*HPLs2[0*2+1]
          + 5.0/4*GHPLs4[2*4*4*4+0*4*4+2*4+1]
          - 7.0/8*GHPLs3[0*4*4+2*4+1]
          - 5.0/4*GHPLs3[0*4*4+2*4+1]*HPLs1[0]
          - 5.0/4*GHPLs3[0*4*4+2*4+1]*HPLs1[1]
          - 3.0/2*GHPLs4[2*4*4*4+1*4*4+2*4+1]
          + 3.0/2*GHPLs3[1*4*4+2*4+1]*HPLs1[0]
          + 3.0/2*GHPLs3[1*4*4+2*4+1]*HPLs1[1]
          + 25.0/4*GHPLs1[1]*zeta2
          + GHPLs1[1]*zeta3
          - 11.0/16*GHPLs1[1]*HPLs1[0]
          + 6*GHPLs1[1]*HPLs1[0]*zeta2
          - 1.0/2*GHPLs1[1]*HPLs2[0*2+0]
          - 7.0/4*GHPLs1[1]*HPLs3[0*2*2+0*2+0]
          - 1.0/2*GHPLs1[1]*HPLs3[1*2*2+0*2+0]
          - 1.0/2*GHPLs1[1]*HPLs2[1*2+0]
          - 5.0/4*GHPLs1[1]*HPLs3[0*2*2+1*2+0]
          - 11.0/16*GHPLs1[1]*HPLs1[1]
          + 5*GHPLs1[1]*HPLs1[1]*zeta2
          - 7.0/4*GHPLs1[1]*HPLs3[0*2*2+0*2+1]
          - 1.0/4*GHPLs1[1]*HPLs3[1*2*2+0*2+1]
          - 3.0/2*GHPLs1[1]*HPLs3[0*2*2+1*2+1]
          + 5.0/4*GHPLs4[2*4*4*4+2*4*4+0*4+1]
          - 7.0/8*GHPLs3[2*4*4+0*4+1]
          - GHPLs3[2*4*4+0*4+1]*HPLs1[0]
          - 5.0/4*GHPLs3[2*4*4+0*4+1]*HPLs1[1]
          + 5.0/4*GHPLs3[3*4*4+0*4+1]*HPLs1[0]
          - 5.0/4*GHPLs4[0*4*4*4+3*4*4+0*4+1]
          - 15.0/4*GHPLs2[0*4+1]*zeta2
          + 7.0/8*GHPLs2[0*4+1]*HPLs1[0]
          + 5.0/4*GHPLs2[0*4+1]*HPLs2[0*2+0]
          + 5.0/4*GHPLs2[0*4+1]*HPLs2[1*2+0]
          + 7.0/8*GHPLs2[0*4+1]*HPLs1[1]
          + 5.0/4*GHPLs2[0*4+1]*HPLs2[0*2+1]
          + 5.0/4*GHPLs2[0*4+1]*HPLs2[1*2+1]
          + 1.0/4*GHPLs4[2*4*4*4+1*4*4+0*4+1]
          - 1.0/4*GHPLs3[1*4*4+0*4+1]*HPLs1[0]
          - 1.0/4*GHPLs3[1*4*4+0*4+1]*HPLs1[1]
          - 7.0/4*GHPLs4[2*4*4*4+2*4*4+1*4+1]
          - 1.0/2*GHPLs3[2*4*4+1*4+1]
          + 1.0/2*GHPLs3[2*4*4+1*4+1]*HPLs1[0]
          + 7.0/4*GHPLs3[2*4*4+1*4+1]*HPLs1[1]
          + 5.0/4*GHPLs4[0*4*4*4+2*4*4+1*4+1]
          - 3.0/4*GHPLs2[1*4+1]*zeta2
          + 1.0/2*GHPLs2[1*4+1]*HPLs1[0]
          - 5.0/4*GHPLs2[1*4+1]*HPLs2[1*2+0]
          + 1.0/2*GHPLs2[1*4+1]*HPLs1[1]
          - 1.0/2*GHPLs2[1*4+1]*HPLs2[0*2+1]
          - 7.0/4*GHPLs2[1*4+1]*HPLs2[1*2+1]
          + 5.0/4*GHPLs4[2*4*4*4+0*4*4+1*4+1]
          - 5.0/4*GHPLs3[0*4*4+1*4+1]*HPLs1[0]
          - 5.0/4*GHPLs3[0*4*4+1*4+1]*HPLs1[1]
          - 3.0/4*GHPLs4[2*4*4*4+1*4*4+1*4+1]
          + 3.0/4*GHPLs3[1*4*4+1*4+1]*HPLs1[0]
          + 3.0/4*GHPLs3[1*4*4+1*4+1]*HPLs1[1]
          )

       + (dN_c*dN_c-1)/(dN_c*dN_c)*pow(u,-2)*pow(v,2) * (
          - 7.0/4*GHPLs3[3*4*4+2*4+2]*HPLs1[0]
          + 7.0/4*GHPLs4[0*4*4*4+3*4*4+2*4+2]
          + 7.0/4*GHPLs2[2*4+2]*zeta2
          - 5.0/4*GHPLs2[2*4+2]*HPLs2[0*2+0]
          - 5.0/4*GHPLs2[2*4+2]*HPLs2[1*2+0]
          + 1.0/2*GHPLs2[2*4+2]*HPLs2[0*2+1]
          + 1.0/2*GHPLs3[0*4*4+2*4+2]*HPLs1[0]
          - 5.0/4*GHPLs4[2*4*4*4+1*4*4+2*4+2]
          + 5.0/4*GHPLs3[1*4*4+2*4+2]*HPLs1[0]
          + 5.0/4*GHPLs3[1*4*4+2*4+2]*HPLs1[1]
          - 1.0/2*GHPLs3[3*4*4+3*4+2]*HPLs1[0]
          + 1.0/2*GHPLs4[0*4*4*4+3*4*4+3*4+2]
          - 1.0/2*GHPLs2[3*4+2]*zeta2
          + 7.0/4*GHPLs1[2]*zeta2
          - 3.0/4*GHPLs1[2]*zeta3
          - 15.0/16*GHPLs1[2]*HPLs1[0]
          + 11.0/2*GHPLs1[2]*HPLs1[0]*zeta2
          - 1.0/8*GHPLs1[2]*HPLs2[0*2+0]
          - 7.0/4*GHPLs1[2]*HPLs3[0*2*2+0*2+0]
          - 1.0/2*GHPLs1[2]*HPLs3[1*2*2+0*2+0]
          - 5.0/8*GHPLs1[2]*HPLs2[1*2+0]
          - 5.0/4*GHPLs1[2]*HPLs3[0*2*2+1*2+0]
          - 5.0/4*GHPLs1[2]*HPLs1[1]*zeta2
          + 9.0/8*GHPLs1[2]*HPLs2[0*2+1]
          + 5.0/4*GHPLs1[2]*HPLs3[0*2*2+0*2+1]
          + 5.0/4*GHPLs1[2]*HPLs3[1*2*2+0*2+1]
          + 7.0/4*GHPLs3[3*4*4+0*4+2]*HPLs1[0]
          - 7.0/4*GHPLs4[0*4*4*4+3*4*4+0*4+2]
          - 5.0/4*GHPLs2[0*4+2]*zeta2
          + 1.0/2*GHPLs2[0*4+2]*HPLs1[0]
          + 5.0/4*GHPLs2[0*4+2]*HPLs2[0*2+0]
          + 5.0/4*GHPLs2[0*4+2]*HPLs2[1*2+0]
          + 5.0/4*GHPLs4[2*4*4*4+1*4*4+0*4+2]
          - 5.0/4*GHPLs3[1*4*4+0*4+2]*HPLs1[0]
          - 5.0/4*GHPLs3[1*4*4+0*4+2]*HPLs1[1]
          - 5.0/8*GHPLs3[2*4*4+1*4+2]
          + 1.0/4*GHPLs3[2*4*4+1*4+2]*HPLs1[0]
          - GHPLs2[1*4+2]*zeta2
          + 5.0/8*GHPLs2[1*4+2]*HPLs1[0]
          + 1.0/4*GHPLs2[1*4+2]*HPLs2[1*2+0]
          + 5.0/8*GHPLs2[1*4+2]*HPLs1[1]
          - 1.0/4*GHPLs2[1*4+2]*HPLs2[0*2+1]
          + 1.0/2*GHPLs4[2*4*4*4+1*4*4+1*4+2]
          - 1.0/2*GHPLs3[1*4*4+1*4+2]*HPLs1[0]
          - 1.0/2*GHPLs3[1*4*4+1*4+2]*HPLs1[1]
          + 1.0/8*GHPLs2[2*4+3]*HPLs1[0]
          - 1.0/8*GHPLs3[0*4*4+2*4+3]
          + 5.0/8*GHPLs2[3*4+3]*HPLs1[0]
          - 5.0/8*GHPLs3[0*4*4+3*4+3]
          + 11.0/8*GHPLs1[3]*zeta2
          - 1.0/8*GHPLs1[3]*HPLs2[1*2+0]
          - 1.0/8*GHPLs1[3]*HPLs2[0*2+1]
          - 1.0/8*GHPLs3[2*4*4+0*4+3]
          + 1.0/8*GHPLs2[0*4+3]*HPLs1[1]
          + 7.0/4*GHPLs3[2*4*4+2*4+1]*HPLs1[0]
          - 5.0/4*GHPLs4[0*4*4*4+2*4*4+2*4+1]
          - 5.0/4*GHPLs3[3*4*4+2*4+1]*HPLs1[0]
          + 5.0/4*GHPLs4[0*4*4*4+3*4*4+2*4+1]
          - 15.0/16*GHPLs2[2*4+1]
          + 5*GHPLs2[2*4+1]*zeta2
          - 7.0/4*GHPLs2[2*4+1]*HPLs2[0*2+0]
          - 1.0/4*GHPLs2[2*4+1]*HPLs2[1*2+0]
          - 3.0/2*GHPLs2[2*4+1]*HPLs2[0*2+1]
          - 5.0/4*GHPLs4[2*4*4*4+0*4*4+2*4+1]
          + 3.0/8*GHPLs3[0*4*4+2*4+1]
          + 5.0/4*GHPLs3[0*4*4+2*4+1]*HPLs1[0]
          + 5.0/4*GHPLs3[0*4*4+2*4+1]*HPLs1[1]
          + 3.0/2*GHPLs4[2*4*4*4+1*4*4+2*4+1]
          - 3.0/2*GHPLs3[1*4*4+2*4+1]*HPLs1[0]
          - 3.0/2*GHPLs3[1*4*4+2*4+1]*HPLs1[1]
          - 9.0/4*GHPLs1[1]*zeta2
          - GHPLs1[1]*zeta3
          + 15.0/16*GHPLs1[1]*HPLs1[0]
          - 6*GHPLs1[1]*HPLs1[0]*zeta2
          + 7.0/4*GHPLs1[1]*HPLs3[0*2*2+0*2+0]
          + 1.0/2*GHPLs1[1]*HPLs3[1*2*2+0*2+0]
          + 5.0/4*GHPLs1[1]*HPLs3[0*2*2+1*2+0]
          + 15.0/16*GHPLs1[1]*HPLs1[1]
          - 5*GHPLs1[1]*HPLs1[1]*zeta2
          + 7.0/4*GHPLs1[1]*HPLs3[0*2*2+0*2+1]
          + 1.0/4*GHPLs1[1]*HPLs3[1*2*2+0*2+1]
          + 3.0/2*GHPLs1[1]*HPLs3[0*2*2+1*2+1]
          - 5.0/4*GHPLs4[2*4*4*4+2*4*4+0*4+1]
          + 3.0/8*GHPLs3[2*4*4+0*4+1]
          + GHPLs3[2*4*4+0*4+1]*HPLs1[0]
          + 5.0/4*GHPLs3[2*4*4+0*4+1]*HPLs1[1]
          - 5.0/4*GHPLs3[3*4*4+0*4+1]*HPLs1[0]
          + 5.0/4*GHPLs4[0*4*4*4+3*4*4+0*4+1]
          + 15.0/4*GHPLs2[0*4+1]*zeta2
          - 3.0/8*GHPLs2[0*4+1]*HPLs1[0]
          - 5.0/4*GHPLs2[0*4+1]*HPLs2[0*2+0]
          - 5.0/4*GHPLs2[0*4+1]*HPLs2[1*2+0]
          - 3.0/8*GHPLs2[0*4+1]*HPLs1[1]
          - 5.0/4*GHPLs2[0*4+1]*HPLs2[0*2+1]
          - 5.0/4*GHPLs2[0*4+1]*HPLs2[1*2+1]
          - 1.0/4*GHPLs4[2*4*4*4+1*4*4+0*4+1]
          + 1.0/4*GHPLs3[1*4*4+0*4+1]*HPLs1[0]
          + 1.0/4*GHPLs3[1*4*4+0*4+1]*HPLs1[1]
          + 7.0/4*GHPLs4[2*4*4*4+2*4*4+1*4+1]
          - 1.0/2*GHPLs3[2*4*4+1*4+1]*HPLs1[0]
          - 7.0/4*GHPLs3[2*4*4+1*4+1]*HPLs1[1]
          - 5.0/4*GHPLs4[0*4*4*4+2*4*4+1*4+1]
          + 3.0/4*GHPLs2[1*4+1]*zeta2
          + 5.0/4*GHPLs2[1*4+1]*HPLs2[1*2+0]
          + 1.0/2*GHPLs2[1*4+1]*HPLs2[0*2+1]
          + 7.0/4*GHPLs2[1*4+1]*HPLs2[1*2+1]
          - 5.0/4*GHPLs4[2*4*4*4+0*4*4+1*4+1]
          + 5.0/4*GHPLs3[0*4*4+1*4+1]*HPLs1[0]
          + 5.0/4*GHPLs3[0*4*4+1*4+1]*HPLs1[1]
          + 3.0/4*GHPLs4[2*4*4*4+1*4*4+1*4+1]
          - 3.0/4*GHPLs3[1*4*4+1*4+1]*HPLs1[0]
          - 3.0/4*GHPLs3[1*4*4+1*4+1]*HPLs1[1]
          )

       + (dN_c*dN_c-1)/(dN_c*dN_c)*pow(u,-2)*pow(v,3) * (
          - 1.0/8*GHPLs1[2]*zeta2
          + 1.0/8*GHPLs1[2]*HPLs1[0]
          - 1.0/8*GHPLs1[2]*HPLs2[0*2+0]
          + 1.0/8*GHPLs1[2]*HPLs2[1*2+0]
          + 1.0/8*GHPLs2[0*4+2]*HPLs1[0]
          + 1.0/8*GHPLs3[2*4*4+1*4+2]
          - 1.0/8*GHPLs2[1*4+2]*HPLs1[0]
          - 1.0/8*GHPLs2[1*4+2]*HPLs1[1]
          + 1.0/8*GHPLs2[2*4+3]*HPLs1[0]
          - 1.0/8*GHPLs3[0*4*4+2*4+3]
          - 1.0/8*GHPLs2[3*4+3]*HPLs1[0]
          + 1.0/8*GHPLs3[0*4*4+3*4+3]
          + 5.0/8*GHPLs1[3]*zeta2
          - 1.0/8*GHPLs1[3]*HPLs2[1*2+0]
          - 1.0/8*GHPLs1[3]*HPLs2[0*2+1]
          - 1.0/8*GHPLs3[2*4*4+0*4+3]
          + 1.0/8*GHPLs2[0*4+3]*HPLs1[1]
          + 1.0/8*GHPLs2[2*4+1]
          - 1.0/8*GHPLs1[1]*HPLs1[0]
          - 1.0/8*GHPLs1[1]*HPLs1[1]
          )

       + (dN_c*dN_c-1)/(dN_c*dN_c)*pow(u,-2)*pow(v,4) * (
          - 1.0/8*GHPLs1[2]*zeta2
          - 1.0/8*GHPLs1[2]*HPLs2[0*2+0]
          + 1.0/8*GHPLs1[2]*HPLs2[1*2+0]
          + 1.0/8*GHPLs2[0*4+2]*HPLs1[0]
          + 1.0/8*GHPLs3[2*4*4+1*4+2]
          - 1.0/8*GHPLs2[1*4+2]*HPLs1[0]
          - 1.0/8*GHPLs2[1*4+2]*HPLs1[1]
          + 1.0/8*GHPLs2[2*4+3]*HPLs1[0]
          - 1.0/8*GHPLs3[0*4*4+2*4+3]
          - 1.0/8*GHPLs2[3*4+3]*HPLs1[0]
          + 1.0/8*GHPLs3[0*4*4+3*4+3]
          + 5.0/8*GHPLs1[3]*zeta2
          - 1.0/8*GHPLs1[3]*HPLs2[1*2+0]
          - 1.0/8*GHPLs1[3]*HPLs2[0*2+1]
          - 1.0/8*GHPLs3[2*4*4+0*4+3]
          + 1.0/8*GHPLs2[0*4+3]*HPLs1[1]
          )

       + (dN_c*dN_c-1)/(dN_c*dN_c)*pow(u,-1)*pow(1-u-v,-1) * (
          - 1.0/8*zeta2
          + 1.0/8*GHPLs2[2*4+3]*HPLs1[0]
          - 1.0/8*GHPLs3[0*4*4+2*4+3]
          + 1.0/8*GHPLs2[3*4+3]*HPLs1[0]
          - 1.0/8*GHPLs3[0*4*4+3*4+3]
          + 7.0/8*GHPLs1[3]*zeta2
          + 1.0/8*GHPLs1[3]*HPLs1[0]
          - 1.0/8*GHPLs1[3]*HPLs2[1*2+0]
          - 1.0/8*GHPLs1[3]*HPLs2[0*2+1]
          - 1.0/8*GHPLs3[2*4*4+0*4+3]
          - 1.0/8*GHPLs2[0*4+3]
          + 1.0/8*GHPLs2[0*4+3]*HPLs1[1]
          - 1.0/8*GHPLs1[0]*HPLs1[0]
          - 1.0/8*GHPLs3[0*4*4+2*4+1]
          + GHPLs1[1]*zeta2
          - 1.0/8*GHPLs1[1]*HPLs2[0*2+0]
          - 1.0/8*GHPLs1[1]*HPLs2[1*2+0]
          - 1.0/8*GHPLs3[2*4*4+0*4+1]
          + 1.0/8*GHPLs2[0*4+1]*HPLs1[0]
          + 1.0/8*GHPLs2[0*4+1]*HPLs1[1]
          - 1.0/8*GHPLs3[2*4*4+1*4+1]
          + 1.0/8*GHPLs2[1*4+1]*HPLs1[0]
          + 1.0/8*GHPLs2[1*4+1]*HPLs1[1]
          + 1.0/8*HPLs2[0*2+0]
          - 1.0/8*HPLs2[0*2+1]
          )

       + (dN_c*dN_c-1)/(dN_c*dN_c)*pow(u,-1) * (
          + 1.0/8*zeta2
          - 1.0/4*GHPLs1[2]*HPLs1[0]
          - 1.0/8*GHPLs1[3]*HPLs1[0]
          + 1.0/8*GHPLs2[0*4+3]
          + 1.0/8*GHPLs1[0]*HPLs1[0]
          - 1.0/4*GHPLs2[2*4+1]
          + 1.0/4*GHPLs1[1]*HPLs1[0]
          + 1.0/4*GHPLs1[1]*HPLs1[1]
          - 1.0/8*HPLs2[0*2+0]
          + 1.0/8*HPLs2[0*2+1]
          )

       + (dN_c*dN_c-1)/(dN_c*dN_c)*pow(u,-1)*v * (
          - 1.0/2
          + 47.0/8*zeta2
          + 7.0/4*zeta3
          - 7.0/4*GHPLs3[3*4*4+2*4+2]*HPLs1[0]
          + 7.0/4*GHPLs4[0*4*4*4+3*4*4+2*4+2]
          - 5.0/4*GHPLs2[2*4+2]
          + 7.0/4*GHPLs2[2*4+2]*zeta2
          - 3.0/2*GHPLs2[2*4+2]*HPLs1[0]
          - 5.0/4*GHPLs2[2*4+2]*HPLs2[0*2+0]
          - 5.0/4*GHPLs2[2*4+2]*HPLs2[1*2+0]
          + 1.0/2*GHPLs2[2*4+2]*HPLs2[0*2+1]
          + 5.0/4*GHPLs3[0*4*4+2*4+2]
          + 1.0/2*GHPLs3[0*4*4+2*4+2]*HPLs1[0]
          - 5.0/4*GHPLs4[2*4*4*4+1*4*4+2*4+2]
          + 5.0/4*GHPLs3[1*4*4+2*4+2]*HPLs1[0]
          + 5.0/4*GHPLs3[1*4*4+2*4+2]*HPLs1[1]
          - 1.0/2*GHPLs3[3*4*4+3*4+2]*HPLs1[0]
          + 1.0/2*GHPLs4[0*4*4*4+3*4*4+3*4+2]
          - 1.0/2*GHPLs2[3*4+2]*zeta2
          + 3*GHPLs2[3*4+2]*HPLs1[0]
          - 3*GHPLs3[0*4*4+3*4+2]
          + 23.0/16*GHPLs1[2]
          - 5*GHPLs1[2]*zeta2
          - 3.0/4*GHPLs1[2]*zeta3
          + 7.0/16*GHPLs1[2]*HPLs1[0]
          + 11.0/2*GHPLs1[2]*HPLs1[0]*zeta2
          + 21.0/8*GHPLs1[2]*HPLs2[0*2+0]
          - 7.0/4*GHPLs1[2]*HPLs3[0*2*2+0*2+0]
          - 1.0/2*GHPLs1[2]*HPLs3[1*2*2+0*2+0]
          + 3.0/8*GHPLs1[2]*HPLs2[1*2+0]
          - 5.0/4*GHPLs1[2]*HPLs3[0*2*2+1*2+0]
          + 5.0/4*GHPLs1[2]*HPLs1[1]
          - 5.0/4*GHPLs1[2]*HPLs1[1]*zeta2
          + 13.0/8*GHPLs1[2]*HPLs2[0*2+1]
          + 5.0/4*GHPLs1[2]*HPLs3[0*2*2+0*2+1]
          + 5.0/4*GHPLs1[2]*HPLs3[1*2*2+0*2+1]
          + 5.0/4*GHPLs3[2*4*4+0*4+2]
          + 7.0/4*GHPLs3[3*4*4+0*4+2]*HPLs1[0]
          - 7.0/4*GHPLs4[0*4*4*4+3*4*4+0*4+2]
          - 3.0/4*GHPLs2[0*4+2]
          - 5.0/4*GHPLs2[0*4+2]*zeta2
          - 3.0/2*GHPLs2[0*4+2]*HPLs1[0]
          + 5.0/4*GHPLs2[0*4+2]*HPLs2[0*2+0]
          + 5.0/4*GHPLs2[0*4+2]*HPLs2[1*2+0]
          - 5.0/4*GHPLs2[0*4+2]*HPLs1[1]
          + 5.0/4*GHPLs4[2*4*4*4+1*4*4+0*4+2]
          - 5.0/4*GHPLs3[1*4*4+0*4+2]*HPLs1[0]
          - 5.0/4*GHPLs3[1*4*4+0*4+2]*HPLs1[1]
          - 9.0/8*GHPLs3[2*4*4+1*4+2]
          + 1.0/4*GHPLs3[2*4*4+1*4+2]*HPLs1[0]
          - GHPLs2[1*4+2]*zeta2
          + 9.0/8*GHPLs2[1*4+2]*HPLs1[0]
          + 1.0/4*GHPLs2[1*4+2]*HPLs2[1*2+0]
          + 9.0/8*GHPLs2[1*4+2]*HPLs1[1]
          - 1.0/4*GHPLs2[1*4+2]*HPLs2[0*2+1]
          + 1.0/2*GHPLs4[2*4*4*4+1*4*4+1*4+2]
          - 1.0/2*GHPLs3[1*4*4+1*4+2]*HPLs1[0]
          - 1.0/2*GHPLs3[1*4*4+1*4+2]*HPLs1[1]
          + 1.0/8*GHPLs2[2*4+3]*HPLs1[0]
          - 1.0/8*GHPLs3[0*4*4+2*4+3]
          + 5.0/8*GHPLs2[3*4+3]*HPLs1[0]
          - 5.0/8*GHPLs3[0*4*4+3*4+3]
          + 11.0/8*GHPLs1[3]*zeta2
          - 1.0/8*GHPLs1[3]*HPLs1[0]
          - 1.0/8*GHPLs1[3]*HPLs2[1*2+0]
          - 1.0/8*GHPLs1[3]*HPLs2[0*2+1]
          - 1.0/8*GHPLs3[2*4*4+0*4+3]
          + 1.0/8*GHPLs2[0*4+3]
          + 1.0/8*GHPLs2[0*4+3]*HPLs1[1]
          + 5.0/4*GHPLs3[2*4*4+2*4+0]
          - 3.0/4*GHPLs2[2*4+0]
          - 1.0/2*GHPLs2[2*4+0]*HPLs1[0]
          - 5.0/4*GHPLs2[2*4+0]*HPLs1[1]
          - 1.0/2*GHPLs2[3*4+0]*HPLs1[0]
          + 1.0/2*GHPLs3[0*4*4+3*4+0]
          - 5.0/2*GHPLs1[0]*zeta2
          + 1.0/8*GHPLs1[0]*HPLs1[0]
          + 3.0/4*GHPLs1[0]*HPLs1[1]
          + 5.0/4*GHPLs1[0]*HPLs2[0*2+1]
          + 5.0/4*GHPLs1[0]*HPLs2[1*2+1]
          - 1.0/2*GHPLs3[2*4*4+1*4+0]
          + 1.0/2*GHPLs2[1*4+0]*HPLs1[0]
          + 1.0/2*GHPLs2[1*4+0]*HPLs1[1]
          - 3.0/2*GHPLs3[2*4*4+2*4+1]
          + 7.0/4*GHPLs3[2*4*4+2*4+1]*HPLs1[0]
          - 5.0/4*GHPLs4[0*4*4*4+2*4*4+2*4+1]
          - 5.0/4*GHPLs3[3*4*4+2*4+1]*HPLs1[0]
          + 5.0/4*GHPLs4[0*4*4*4+3*4*4+2*4+1]
          + 7.0/16*GHPLs2[2*4+1]
          + 5*GHPLs2[2*4+1]*zeta2
          + 1.0/4*GHPLs2[2*4+1]*HPLs1[0]
          - 7.0/4*GHPLs2[2*4+1]*HPLs2[0*2+0]
          - 1.0/4*GHPLs2[2*4+1]*HPLs2[1*2+0]
          + 3.0/2*GHPLs2[2*4+1]*HPLs1[1]
          - 3.0/2*GHPLs2[2*4+1]*HPLs2[0*2+1]
          - 5.0/4*GHPLs4[2*4*4*4+0*4*4+2*4+1]
          + 11.0/8*GHPLs3[0*4*4+2*4+1]
          + 5.0/4*GHPLs3[0*4*4+2*4+1]*HPLs1[0]
          + 5.0/4*GHPLs3[0*4*4+2*4+1]*HPLs1[1]
          + 3.0/2*GHPLs4[2*4*4*4+1*4*4+2*4+1]
          - 3.0/2*GHPLs3[1*4*4+2*4+1]*HPLs1[0]
          - 3.0/2*GHPLs3[1*4*4+2*4+1]*HPLs1[1]
          - 9.0/4*GHPLs1[1]*zeta2
          - GHPLs1[1]*zeta3
          - 7.0/16*GHPLs1[1]*HPLs1[0]
          - 6*GHPLs1[1]*HPLs1[0]*zeta2
          + 1.0/4*GHPLs1[1]*HPLs2[0*2+0]
          + 7.0/4*GHPLs1[1]*HPLs3[0*2*2+0*2+0]
          + 1.0/2*GHPLs1[1]*HPLs3[1*2*2+0*2+0]
          - GHPLs1[1]*HPLs2[1*2+0]
          + 5.0/4*GHPLs1[1]*HPLs3[0*2*2+1*2+0]
          - 7.0/16*GHPLs1[1]*HPLs1[1]
          - 5*GHPLs1[1]*HPLs1[1]*zeta2
          - 1.0/4*GHPLs1[1]*HPLs2[0*2+1]
          + 7.0/4*GHPLs1[1]*HPLs3[0*2*2+0*2+1]
          + 1.0/4*GHPLs1[1]*HPLs3[1*2*2+0*2+1]
          - 3.0/2*GHPLs1[1]*HPLs2[1*2+1]
          + 3.0/2*GHPLs1[1]*HPLs3[0*2*2+1*2+1]
          - 5.0/4*GHPLs4[2*4*4*4+2*4*4+0*4+1]
          + 11.0/8*GHPLs3[2*4*4+0*4+1]
          + GHPLs3[2*4*4+0*4+1]*HPLs1[0]
          + 5.0/4*GHPLs3[2*4*4+0*4+1]*HPLs1[1]
          - 5.0/4*GHPLs3[3*4*4+0*4+1]*HPLs1[0]
          + 5.0/4*GHPLs4[0*4*4*4+3*4*4+0*4+1]
          + 15.0/4*GHPLs2[0*4+1]*zeta2
          - 11.0/8*GHPLs2[0*4+1]*HPLs1[0]
          - 5.0/4*GHPLs2[0*4+1]*HPLs2[0*2+0]
          - 5.0/4*GHPLs2[0*4+1]*HPLs2[1*2+0]
          - 11.0/8*GHPLs2[0*4+1]*HPLs1[1]
          - 5.0/4*GHPLs2[0*4+1]*HPLs2[0*2+1]
          - 5.0/4*GHPLs2[0*4+1]*HPLs2[1*2+1]
          - 1.0/4*GHPLs4[2*4*4*4+1*4*4+0*4+1]
          + 1.0/4*GHPLs3[1*4*4+0*4+1]*HPLs1[0]
          + 1.0/4*GHPLs3[1*4*4+0*4+1]*HPLs1[1]
          + 7.0/4*GHPLs4[2*4*4*4+2*4*4+1*4+1]
          - 3.0/4*GHPLs3[2*4*4+1*4+1]
          - 1.0/2*GHPLs3[2*4*4+1*4+1]*HPLs1[0]
          - 7.0/4*GHPLs3[2*4*4+1*4+1]*HPLs1[1]
          - 5.0/4*GHPLs4[0*4*4*4+2*4*4+1*4+1]
          + 3.0/4*GHPLs2[1*4+1]*zeta2
          + 3.0/4*GHPLs2[1*4+1]*HPLs1[0]
          + 5.0/4*GHPLs2[1*4+1]*HPLs2[1*2+0]
          + 3.0/4*GHPLs2[1*4+1]*HPLs1[1]
          + 1.0/2*GHPLs2[1*4+1]*HPLs2[0*2+1]
          + 7.0/4*GHPLs2[1*4+1]*HPLs2[1*2+1]
          - 5.0/4*GHPLs4[2*4*4*4+0*4*4+1*4+1]
          + 5.0/4*GHPLs3[0*4*4+1*4+1]*HPLs1[0]
          + 5.0/4*GHPLs3[0*4*4+1*4+1]*HPLs1[1]
          + 3.0/4*GHPLs4[2*4*4*4+1*4*4+1*4+1]
          - 3.0/4*GHPLs3[1*4*4+1*4+1]*HPLs1[0]
          - 3.0/4*GHPLs3[1*4*4+1*4+1]*HPLs1[1]
          + 1.0/2*HPLs1[0]*zeta2
          - 1.0/8*HPLs2[0*2+0]
          - 23.0/16*HPLs1[1]
          + 25.0/4*HPLs1[1]*zeta2
          - 9.0/4*HPLs2[0*2+1]
          - 3*HPLs3[0*2*2+0*2+1]
          - 3.0/2*HPLs3[1*2*2+0*2+1]
          - 5.0/4*HPLs2[1*2+1]
          - 3.0/2*HPLs3[0*2*2+1*2+1]
          )

       + (dN_c*dN_c-1)/(dN_c*dN_c)*pow(u,-1)*pow(v,2) * (
          - 51.0/8*zeta2
          - zeta3
          + 5.0/4*GHPLs2[2*4+2]
          + 3.0/2*GHPLs2[2*4+2]*HPLs1[0]
          - 5.0/4*GHPLs3[0*4*4+2*4+2]
          - 5.0/4*GHPLs2[3*4+2]*HPLs1[0]
          + 5.0/4*GHPLs3[0*4*4+3*4+2]
          - 23.0/16*GHPLs1[2]
          + 5*GHPLs1[2]*zeta2
          - 3.0/4*GHPLs1[2]*HPLs1[0]
          - 7.0/4*GHPLs1[2]*HPLs2[0*2+0]
          + 1.0/4*GHPLs1[2]*HPLs2[1*2+0]
          - 5.0/4*GHPLs1[2]*HPLs1[1]
          - GHPLs1[2]*HPLs2[0*2+1]
          - 5.0/4*GHPLs3[2*4*4+0*4+2]
          + 1.0/2*GHPLs2[0*4+2]
          + 7.0/4*GHPLs2[0*4+2]*HPLs1[0]
          + 5.0/4*GHPLs2[0*4+2]*HPLs1[1]
          + 7.0/4*GHPLs3[2*4*4+1*4+2]
          - 7.0/4*GHPLs2[1*4+2]*HPLs1[0]
          - 7.0/4*GHPLs2[1*4+2]*HPLs1[1]
          + 1.0/4*GHPLs2[2*4+3]*HPLs1[0]
          - 1.0/4*GHPLs3[0*4*4+2*4+3]
          - 1.0/4*GHPLs2[3*4+3]*HPLs1[0]
          + 1.0/4*GHPLs3[0*4*4+3*4+3]
          + 5.0/4*GHPLs1[3]*zeta2
          + 11.0/8*GHPLs1[3]*HPLs1[0]
          - 1.0/4*GHPLs1[3]*HPLs2[1*2+0]
          - 1.0/4*GHPLs1[3]*HPLs2[0*2+1]
          - 1.0/4*GHPLs3[2*4*4+0*4+3]
          - 11.0/8*GHPLs2[0*4+3]
          + 1.0/4*GHPLs2[0*4+3]*HPLs1[1]
          - 5.0/4*GHPLs3[2*4*4+2*4+0]
          + 1.0/2*GHPLs2[2*4+0]
          + 3.0/4*GHPLs2[2*4+0]*HPLs1[0]
          + 5.0/4*GHPLs2[2*4+0]*HPLs1[1]
          - 5.0/4*GHPLs2[3*4+0]*HPLs1[0]
          + 5.0/4*GHPLs3[0*4*4+3*4+0]
          + 15.0/4*GHPLs1[0]*zeta2
          - 5.0/8*GHPLs1[0]*HPLs1[0]
          - 5.0/4*GHPLs1[0]*HPLs2[0*2+0]
          - 5.0/4*GHPLs1[0]*HPLs2[1*2+0]
          - 1.0/2*GHPLs1[0]*HPLs1[1]
          - 5.0/4*GHPLs1[0]*HPLs2[0*2+1]
          - 5.0/4*GHPLs1[0]*HPLs2[1*2+1]
          - 1.0/2*GHPLs3[2*4*4+1*4+0]
          + 1.0/2*GHPLs2[1*4+0]*HPLs1[0]
          + 1.0/2*GHPLs2[1*4+0]*HPLs1[1]
          + 3.0/2*GHPLs3[2*4*4+2*4+1]
          + 3.0/8*GHPLs2[2*4+1]
          - 1.0/4*GHPLs2[2*4+1]*HPLs1[0]
          - 3.0/2*GHPLs2[2*4+1]*HPLs1[1]
          - GHPLs3[0*4*4+2*4+1]
          - 3.0/8*GHPLs1[1]*HPLs1[0]
          - 1.0/4*GHPLs1[1]*HPLs2[0*2+0]
          + GHPLs1[1]*HPLs2[1*2+0]
          - 3.0/8*GHPLs1[1]*HPLs1[1]
          + 1.0/4*GHPLs1[1]*HPLs2[0*2+1]
          + 3.0/2*GHPLs1[1]*HPLs2[1*2+1]
          - GHPLs3[2*4*4+0*4+1]
          + GHPLs2[0*4+1]*HPLs1[0]
          + GHPLs2[0*4+1]*HPLs1[1]
          + 3.0/4*GHPLs3[2*4*4+1*4+1]
          - 3.0/4*GHPLs2[1*4+1]*HPLs1[0]
          - 3.0/4*GHPLs2[1*4+1]*HPLs1[1]
          + 23.0/16*HPLs1[0]
          - 6*HPLs1[0]*zeta2
          + 3.0/2*HPLs2[0*2+0]
          + 7.0/4*HPLs3[0*2*2+0*2+0]
          + 1.0/2*HPLs3[1*2*2+0*2+0]
          + 9.0/8*HPLs2[1*2+0]
          + 5.0/4*HPLs3[0*2*2+1*2+0]
          + 23.0/16*HPLs1[1]
          - 5*HPLs1[1]*zeta2
          + 11.0/8*HPLs2[0*2+1]
          + 7.0/4*HPLs3[0*2*2+0*2+1]
          + 1.0/4*HPLs3[1*2*2+0*2+1]
          + 5.0/4*HPLs2[1*2+1]
          + 3.0/2*HPLs3[0*2*2+1*2+1]
          )

       + (dN_c*dN_c-1)/(dN_c*dN_c)*pow(u,-1)*pow(v,3) * (
          - 1.0/2*zeta2
          - 3.0/8*GHPLs1[2]*zeta2
          - 1.0/8*GHPLs1[2]*HPLs1[0]
          - 3.0/8*GHPLs1[2]*HPLs2[0*2+0]
          + 3.0/8*GHPLs1[2]*HPLs2[1*2+0]
          + 1.0/8*GHPLs2[0*4+2]
          + 3.0/8*GHPLs2[0*4+2]*HPLs1[0]
          + 3.0/8*GHPLs3[2*4*4+1*4+2]
          - 3.0/8*GHPLs2[1*4+2]*HPLs1[0]
          - 3.0/8*GHPLs2[1*4+2]*HPLs1[1]
          + 3.0/8*GHPLs2[2*4+3]*HPLs1[0]
          - 3.0/8*GHPLs3[0*4*4+2*4+3]
          - 3.0/8*GHPLs2[3*4+3]*HPLs1[0]
          + 3.0/8*GHPLs3[0*4*4+3*4+3]
          + 15.0/8*GHPLs1[3]*zeta2
          + 1.0/8*GHPLs1[3]*HPLs1[0]
          - 3.0/8*GHPLs1[3]*HPLs2[1*2+0]
          - 3.0/8*GHPLs1[3]*HPLs2[0*2+1]
          - 3.0/8*GHPLs3[2*4*4+0*4+3]
          - 1.0/8*GHPLs2[0*4+3]
          + 3.0/8*GHPLs2[0*4+3]*HPLs1[1]
          + 1.0/8*GHPLs2[2*4+0]
          - 1.0/8*GHPLs1[0]*HPLs1[0]
          - 1.0/8*GHPLs1[0]*HPLs1[1]
          - 1.0/8*GHPLs2[2*4+1]
          + 1.0/8*GHPLs1[1]*HPLs1[0]
          + 1.0/8*GHPLs1[1]*HPLs1[1]
          + 1.0/8*HPLs2[0*2+0]
          + 1.0/8*HPLs2[0*2+1]
          )

       + (dN_c*dN_c-1)/(dN_c*dN_c)*pow(1-v,-1) * (
          + 15.0/16*zeta2
          - 3.0/8*zeta3
          - 7.0/8*GHPLs2[3*4+2]*HPLs1[0]
          + 7.0/8*GHPLs3[0*4*4+3*4+2]
          + 3.0/4*GHPLs1[2]*zeta2
          + 7.0/16*GHPLs1[2]*HPLs1[0]
          - 5.0/8*GHPLs1[2]*HPLs2[0*2+0]
          - 1.0/2*GHPLs1[2]*HPLs2[1*2+0]
          + 1.0/4*GHPLs1[2]*HPLs2[0*2+1]
          + 1.0/4*GHPLs2[0*4+2]*HPLs1[0]
          - 1.0/2*GHPLs3[2*4*4+1*4+2]
          + 1.0/2*GHPLs2[1*4+2]*HPLs1[0]
          + 1.0/2*GHPLs2[1*4+2]*HPLs1[1]
          - 1.0/2*GHPLs1[3]*HPLs1[0]
          + 1.0/2*GHPLs2[0*4+3]
          - 1.0/8*GHPLs2[2*4+0]*HPLs1[0]
          + 7.0/8*GHPLs2[3*4+0]*HPLs1[0]
          - 7.0/8*GHPLs3[0*4*4+3*4+0]
          - 5.0/8*GHPLs1[0]*zeta2
          + 3.0/8*GHPLs1[0]*HPLs1[0]
          + 5.0/8*GHPLs1[0]*HPLs2[0*2+0]
          + 5.0/8*GHPLs1[0]*HPLs2[1*2+0]
          + 1.0/2*GHPLs3[2*4*4+1*4+0]
          - 1.0/2*GHPLs2[1*4+0]*HPLs1[0]
          - 1.0/2*GHPLs2[1*4+0]*HPLs1[1]
          - 1.0/8*GHPLs2[2*4+1]
          + 1.0/8*GHPLs1[1]*HPLs1[0]
          + 1.0/8*GHPLs1[1]*HPLs1[1]
          - 19.0/32*HPLs1[0]
          + 11.0/4*HPLs1[0]*zeta2
          - 3.0/4*HPLs2[0*2+0]
          - 7.0/8*HPLs3[0*2*2+0*2+0]
          - 1.0/4*HPLs3[1*2*2+0*2+0]
          - 9.0/16*HPLs2[1*2+0]
          - 5.0/8*HPLs3[0*2*2+1*2+0]
          - 5.0/8*HPLs1[1]*zeta2
          + 3.0/8*HPLs2[0*2+1]
          + 5.0/8*HPLs3[0*2*2+0*2+1]
          + 5.0/8*HPLs3[1*2*2+0*2+1]
          )

       + (dN_c*dN_c-1)/(dN_c*dN_c) * (
          - 1.0/2
          - 13.0/16*zeta2
          + 3.0/8*zeta3
          + 7.0/8*GHPLs2[3*4+2]*HPLs1[0]
          - 7.0/8*GHPLs3[0*4*4+3*4+2]
          - 1.0/4*GHPLs1[2]
          - 3.0/4*GHPLs1[2]*zeta2
          + 1.0/16*GHPLs1[2]*HPLs1[0]
          + 5.0/8*GHPLs1[2]*HPLs2[0*2+0]
          + 1.0/2*GHPLs1[2]*HPLs2[1*2+0]
          - 1.0/4*GHPLs1[2]*HPLs2[0*2+1]
          - 1.0/4*GHPLs2[0*4+2]*HPLs1[0]
          + 1.0/2*GHPLs3[2*4*4+1*4+2]
          - 1.0/2*GHPLs2[1*4+2]*HPLs1[0]
          - 1.0/2*GHPLs2[1*4+2]*HPLs1[1]
          + 3.0/8*GHPLs1[3]*HPLs1[0]
          - 3.0/8*GHPLs2[0*4+3]
          + 1.0/8*GHPLs2[2*4+0]*HPLs1[0]
          - 7.0/8*GHPLs2[3*4+0]*HPLs1[0]
          + 7.0/8*GHPLs3[0*4*4+3*4+0]
          + 5.0/8*GHPLs1[0]*zeta2
          - 1.0/4*GHPLs1[0]*HPLs1[0]
          - 5.0/8*GHPLs1[0]*HPLs2[0*2+0]
          - 5.0/8*GHPLs1[0]*HPLs2[1*2+0]
          - 1.0/2*GHPLs3[2*4*4+1*4+0]
          + 1.0/2*GHPLs2[1*4+0]*HPLs1[0]
          + 1.0/2*GHPLs2[1*4+0]*HPLs1[1]
          + 5.0/8*GHPLs2[2*4+1]
          - 5.0/8*GHPLs1[1]*HPLs1[0]
          - 5.0/8*GHPLs1[1]*HPLs1[1]
          + 19.0/32*HPLs1[0]
          - 11.0/4*HPLs1[0]*zeta2
          + 5.0/8*HPLs2[0*2+0]
          + 7.0/8*HPLs3[0*2*2+0*2+0]
          + 1.0/4*HPLs3[1*2*2+0*2+0]
          + 9.0/16*HPLs2[1*2+0]
          + 5.0/8*HPLs3[0*2*2+1*2+0]
          + 1.0/4*HPLs1[1]
          + 5.0/8*HPLs1[1]*zeta2
          - 1.0/4*HPLs2[0*2+1]
          - 5.0/8*HPLs3[0*2*2+0*2+1]
          - 5.0/8*HPLs3[1*2*2+0*2+1]
          )

       + (dN_c*dN_c-1)/(dN_c*dN_c)*v*pow(1-u,-1) * (
          + 17.0/32
          + 21.0/16*zeta2
          + 5.0/16*GHPLs2[2*4+2]
          + 1.0/4*GHPLs2[2*4+2]*HPLs1[0]
          - 1.0/8*GHPLs3[0*4*4+2*4+2]
          - 1.0/8*GHPLs2[3*4+2]*HPLs1[0]
          + 1.0/8*GHPLs3[0*4*4+3*4+2]
          - 29.0/32*GHPLs1[2]
          + 5.0/8*GHPLs1[2]*zeta2
          - 1.0/4*GHPLs1[2]*HPLs1[0]
          - 1.0/4*GHPLs1[2]*HPLs2[0*2+0]
          - 5.0/16*GHPLs1[2]*HPLs1[1]
          - 1.0/8*GHPLs3[2*4*4+0*4+2]
          - 1.0/2*GHPLs2[0*4+2]
          + 1.0/4*GHPLs2[0*4+2]*HPLs1[0]
          + 1.0/8*GHPLs2[0*4+2]*HPLs1[1]
          + 1.0/4*GHPLs3[2*4*4+1*4+2]
          - 1.0/4*GHPLs2[1*4+2]*HPLs1[0]
          - 1.0/4*GHPLs2[1*4+2]*HPLs1[1]
          + 1.0/8*GHPLs1[3]*HPLs1[0]
          - 1.0/8*GHPLs2[0*4+3]
          - 1.0/8*GHPLs3[2*4*4+2*4+0]
          - 1.0/2*GHPLs2[2*4+0]
          + 1.0/8*GHPLs2[2*4+0]*HPLs1[1]
          - 1.0/8*GHPLs2[3*4+0]*HPLs1[0]
          + 1.0/8*GHPLs3[0*4*4+3*4+0]
          + 3.0/8*GHPLs1[0]
          + 1.0/8*GHPLs1[0]*zeta2
          + 3.0/8*GHPLs1[0]*HPLs1[0]
          - 1.0/4*GHPLs1[0]*HPLs2[0*2+0]
          - 1.0/8*GHPLs1[0]*HPLs2[1*2+0]
          + 1.0/2*GHPLs1[0]*HPLs1[1]
          - 1.0/4*GHPLs1[0]*HPLs2[0*2+1]
          - 1.0/8*GHPLs1[0]*HPLs2[1*2+1]
          - 1.0/8*GHPLs3[2*4*4+1*4+0]
          + 1.0/8*GHPLs2[1*4+0]*HPLs1[0]
          + 1.0/8*GHPLs2[1*4+0]*HPLs1[1]
          + 1.0/4*GHPLs3[2*4*4+2*4+1]
          + 3.0/16*GHPLs2[2*4+1]
          - 1.0/4*GHPLs2[2*4+1]*HPLs1[0]
          - 1.0/4*GHPLs2[2*4+1]*HPLs1[1]
          - 1.0/4*GHPLs1[1]*zeta2
          - 3.0/16*GHPLs1[1]*HPLs1[0]
          - 3.0/16*GHPLs1[1]*HPLs1[1]
          + 1.0/4*GHPLs1[1]*HPLs2[0*2+1]
          + 1.0/4*GHPLs1[1]*HPLs2[1*2+1]
          - 1.0/4*GHPLs3[2*4*4+1*4+1]
          + 1.0/4*GHPLs2[1*4+1]*HPLs1[0]
          + 1.0/4*GHPLs2[1*4+1]*HPLs1[1]
          + 23.0/32*HPLs1[0]
          - 9.0/8*HPLs1[0]*zeta2
          + 3.0/8*HPLs2[0*2+0]
          + 1.0/4*HPLs3[0*2*2+0*2+0]
          + 1.0/8*HPLs3[1*2*2+0*2+0]
          + 7.0/16*HPLs2[1*2+0]
          - 1.0/8*HPLs3[0*2*2+1*2+0]
          + 29.0/32*HPLs1[1]
          - 5.0/8*HPLs1[1]*zeta2
          + 1.0/4*HPLs3[0*2*2+0*2+1]
          + 5.0/16*HPLs2[1*2+1]
          )

       + (dN_c*dN_c-1)/(dN_c*dN_c)*v * (
          - 53.0/8*zeta2
          - 1.0/2*zeta3
          + 1.0/2*GHPLs2[2*4+2]*HPLs1[0]
          - 1.0/2*GHPLs3[0*4*4+2*4+2]
          - 1.0/2*GHPLs2[3*4+2]*HPLs1[0]
          + 1.0/2*GHPLs3[0*4*4+3*4+2]
          + 3.0/8*GHPLs1[2]
          + 15.0/8*GHPLs1[2]*zeta2
          - GHPLs1[2]*HPLs1[0]
          - 5.0/8*GHPLs1[2]*HPLs2[0*2+0]
          + 1.0/8*GHPLs1[2]*HPLs2[1*2+0]
          - 1.0/2*GHPLs1[2]*HPLs2[0*2+1]
          - 1.0/2*GHPLs3[2*4*4+0*4+2]
          + 13.0/8*GHPLs2[0*4+2]
          + 5.0/8*GHPLs2[0*4+2]*HPLs1[0]
          + 1.0/2*GHPLs2[0*4+2]*HPLs1[1]
          + 5.0/8*GHPLs3[2*4*4+1*4+2]
          - 5.0/8*GHPLs2[1*4+2]*HPLs1[0]
          - 5.0/8*GHPLs2[1*4+2]*HPLs1[1]
          + 1.0/8*GHPLs2[2*4+3]*HPLs1[0]
          - 1.0/8*GHPLs3[0*4*4+2*4+3]
          - 1.0/8*GHPLs2[3*4+3]*HPLs1[0]
          + 1.0/8*GHPLs3[0*4*4+3*4+3]
          + 5.0/8*GHPLs1[3]*zeta2
          + 13.0/8*GHPLs1[3]*HPLs1[0]
          - 1.0/8*GHPLs1[3]*HPLs2[1*2+0]
          - 1.0/8*GHPLs1[3]*HPLs2[0*2+1]
          - 1.0/8*GHPLs3[2*4*4+0*4+3]
          - 13.0/8*GHPLs2[0*4+3]
          + 1.0/8*GHPLs2[0*4+3]*HPLs1[1]
          - 1.0/2*GHPLs3[2*4*4+2*4+0]
          + 13.0/8*GHPLs2[2*4+0]
          + 3.0/8*GHPLs2[2*4+0]*HPLs1[0]
          + 1.0/2*GHPLs2[2*4+0]*HPLs1[1]
          - 1.0/2*GHPLs2[3*4+0]*HPLs1[0]
          + 1.0/2*GHPLs3[0*4*4+3*4+0]
          + 7.0/4*GHPLs1[0]*zeta2
          - 2*GHPLs1[0]*HPLs1[0]
          - 3.0/8*GHPLs1[0]*HPLs2[0*2+0]
          - 1.0/2*GHPLs1[0]*HPLs2[1*2+0]
          - 13.0/8*GHPLs1[0]*HPLs1[1]
          - 3.0/8*GHPLs1[0]*HPLs2[0*2+1]
          - 1.0/2*GHPLs1[0]*HPLs2[1*2+1]
          - 1.0/8*GHPLs3[2*4*4+1*4+0]
          + 1.0/8*GHPLs2[1*4+0]*HPLs1[0]
          + 1.0/8*GHPLs2[1*4+0]*HPLs1[1]
          + 1.0/2*GHPLs3[2*4*4+2*4+1]
          - 11.0/8*GHPLs2[2*4+1]
          + 1.0/8*GHPLs2[2*4+1]*HPLs1[0]
          - 1.0/2*GHPLs2[2*4+1]*HPLs1[1]
          - 1.0/2*GHPLs3[0*4*4+2*4+1]
          + 1.0/4*GHPLs1[1]*zeta2
          + 11.0/8*GHPLs1[1]*HPLs1[0]
          - 1.0/8*GHPLs1[1]*HPLs2[0*2+0]
          + 1.0/2*GHPLs1[1]*HPLs2[1*2+0]
          + 11.0/8*GHPLs1[1]*HPLs1[1]
          - 1.0/8*GHPLs1[1]*HPLs2[0*2+1]
          + 1.0/2*GHPLs1[1]*HPLs2[1*2+1]
          - 1.0/2*GHPLs3[2*4*4+0*4+1]
          + 1.0/2*GHPLs2[0*4+1]*HPLs1[0]
          + 1.0/2*GHPLs2[0*4+1]*HPLs1[1]
          + 5.0/8*GHPLs3[2*4*4+1*4+1]
          - 5.0/8*GHPLs2[1*4+1]*HPLs1[0]
          - 5.0/8*GHPLs2[1*4+1]*HPLs1[1]
          - 3.0/8*HPLs1[0]
          - 15.0/8*HPLs1[0]*zeta2
          + 13.0/8*HPLs2[0*2+0]
          + 5.0/8*HPLs3[0*2*2+0*2+0]
          + 1.0/8*HPLs3[1*2*2+0*2+0]
          - 3.0/8*HPLs2[1*2+0]
          + 3.0/4*HPLs3[0*2*2+1*2+0]
          - 3.0/8*HPLs1[1]
          - 15.0/8*HPLs1[1]*zeta2
          + 5.0/4*HPLs2[0*2+1]
          + 5.0/8*HPLs3[0*2*2+0*2+1]
          + 1.0/8*HPLs3[1*2*2+0*2+1]
          + 3.0/4*HPLs3[0*2*2+1*2+1]
          )

       + (dN_c*dN_c-1)/(dN_c*dN_c)*pow(v,2)*pow(1-u,-2) * (
          - 7.0/16*zeta2
          - 5.0/16*GHPLs2[2*4+2]
          - 1.0/4*GHPLs2[2*4+2]*HPLs1[0]
          + 1.0/8*GHPLs3[0*4*4+2*4+2]
          + 1.0/8*GHPLs2[3*4+2]*HPLs1[0]
          - 1.0/8*GHPLs3[0*4*4+3*4+2]
          + 23.0/32*GHPLs1[2]
          - 5.0/8*GHPLs1[2]*zeta2
          + 1.0/8*GHPLs1[2]*HPLs1[0]
          + 1.0/4*GHPLs1[2]*HPLs2[0*2+0]
          + 5.0/16*GHPLs1[2]*HPLs1[1]
          + 1.0/8*GHPLs3[2*4*4+0*4+2]
          + 3.0/8*GHPLs2[0*4+2]
          - 1.0/4*GHPLs2[0*4+2]*HPLs1[0]
          - 1.0/8*GHPLs2[0*4+2]*HPLs1[1]
          - 1.0/4*GHPLs3[2*4*4+1*4+2]
          + 1.0/4*GHPLs2[1*4+2]*HPLs1[0]
          + 1.0/4*GHPLs2[1*4+2]*HPLs1[1]
          + 1.0/8*GHPLs3[2*4*4+2*4+0]
          + 3.0/8*GHPLs2[2*4+0]
          - 1.0/8*GHPLs2[2*4+0]*HPLs1[1]
          + 1.0/8*GHPLs2[3*4+0]*HPLs1[0]
          - 1.0/8*GHPLs3[0*4*4+3*4+0]
          - 1.0/8*GHPLs1[0]*zeta2
          - 3.0/8*GHPLs1[0]*HPLs1[0]
          + 1.0/4*GHPLs1[0]*HPLs2[0*2+0]
          + 1.0/8*GHPLs1[0]*HPLs2[1*2+0]
          - 3.0/8*GHPLs1[0]*HPLs1[1]
          + 1.0/4*GHPLs1[0]*HPLs2[0*2+1]
          + 1.0/8*GHPLs1[0]*HPLs2[1*2+1]
          + 1.0/8*GHPLs3[2*4*4+1*4+0]
          - 1.0/8*GHPLs2[1*4+0]*HPLs1[0]
          - 1.0/8*GHPLs2[1*4+0]*HPLs1[1]
          - 1.0/4*GHPLs3[2*4*4+2*4+1]
          - 7.0/16*GHPLs2[2*4+1]
          + 1.0/4*GHPLs2[2*4+1]*HPLs1[0]
          + 1.0/4*GHPLs2[2*4+1]*HPLs1[1]
          + 1.0/4*GHPLs1[1]*zeta2
          + 7.0/16*GHPLs1[1]*HPLs1[0]
          + 7.0/16*GHPLs1[1]*HPLs1[1]
          - 1.0/4*GHPLs1[1]*HPLs2[0*2+1]
          - 1.0/4*GHPLs1[1]*HPLs2[1*2+1]
          + 1.0/4*GHPLs3[2*4*4+1*4+1]
          - 1.0/4*GHPLs2[1*4+1]*HPLs1[0]
          - 1.0/4*GHPLs2[1*4+1]*HPLs1[1]
          - 23.0/32*HPLs1[0]
          + 9.0/8*HPLs1[0]*zeta2
          - 3.0/8*HPLs2[0*2+0]
          - 1.0/4*HPLs3[0*2*2+0*2+0]
          - 1.0/8*HPLs3[1*2*2+0*2+0]
          - 9.0/16*HPLs2[1*2+0]
          + 1.0/8*HPLs3[0*2*2+1*2+0]
          - 23.0/32*HPLs1[1]
          + 5.0/8*HPLs1[1]*zeta2
          - 1.0/8*HPLs2[0*2+1]
          - 1.0/4*HPLs3[0*2*2+0*2+1]
          - 5.0/16*HPLs2[1*2+1]
          )

       + (dN_c*dN_c-1)/(dN_c*dN_c)*pow(v,2)*pow(1-u,-1) * (
          - 5.0/4*zeta2
          - 1.0/2*zeta3
          + 5.0/4*GHPLs2[2*4+2]
          + GHPLs2[2*4+2]*HPLs1[0]
          - 3.0/4*GHPLs3[0*4*4+2*4+2]
          - 3.0/4*GHPLs2[3*4+2]*HPLs1[0]
          + 3.0/4*GHPLs3[0*4*4+3*4+2]
          - 23.0/16*GHPLs1[2]
          + 13.0/4*GHPLs1[2]*zeta2
          - GHPLs1[2]*HPLs2[0*2+0]
          - 5.0/4*GHPLs1[2]*HPLs1[1]
          - 1.0/2*GHPLs1[2]*HPLs2[0*2+1]
          - 3.0/4*GHPLs3[2*4*4+0*4+2]
          - 3.0/4*GHPLs2[0*4+2]
          + GHPLs2[0*4+2]*HPLs1[0]
          + 3.0/4*GHPLs2[0*4+2]*HPLs1[1]
          + GHPLs3[2*4*4+1*4+2]
          - GHPLs2[1*4+2]*HPLs1[0]
          - GHPLs2[1*4+2]*HPLs1[1]
          + 1.0/8*GHPLs1[3]*HPLs1[0]
          - 1.0/8*GHPLs2[0*4+3]
          - 3.0/4*GHPLs3[2*4*4+2*4+0]
          - 3.0/4*GHPLs2[2*4+0]
          + 1.0/2*GHPLs2[2*4+0]*HPLs1[0]
          + 3.0/4*GHPLs2[2*4+0]*HPLs1[1]
          - 3.0/4*GHPLs2[3*4+0]*HPLs1[0]
          + 3.0/4*GHPLs3[0*4*4+3*4+0]
          + 7.0/4*GHPLs1[0]*zeta2
          + 3.0/4*GHPLs1[0]*HPLs1[0]
          - GHPLs1[0]*HPLs2[0*2+0]
          - 3.0/4*GHPLs1[0]*HPLs2[1*2+0]
          + 3.0/4*GHPLs1[0]*HPLs1[1]
          - GHPLs1[0]*HPLs2[0*2+1]
          - 3.0/4*GHPLs1[0]*HPLs2[1*2+1]
          - 1.0/4*GHPLs3[2*4*4+1*4+0]
          + 1.0/4*GHPLs2[1*4+0]*HPLs1[0]
          + 1.0/4*GHPLs2[1*4+0]*HPLs1[1]
          + GHPLs3[2*4*4+2*4+1]
          + 5.0/4*GHPLs2[2*4+1]
          - 1.0/2*GHPLs2[2*4+1]*HPLs1[0]
          - GHPLs2[2*4+1]*HPLs1[1]
          - 1.0/2*GHPLs3[0*4*4+2*4+1]
          - 5.0/4*GHPLs1[1]*HPLs1[0]
          + 1.0/2*GHPLs1[1]*HPLs2[1*2+0]
          - 5.0/4*GHPLs1[1]*HPLs1[1]
          + 1.0/2*GHPLs1[1]*HPLs2[0*2+1]
          + GHPLs1[1]*HPLs2[1*2+1]
          - 1.0/2*GHPLs3[2*4*4+0*4+1]
          + 1.0/2*GHPLs2[0*4+1]*HPLs1[0]
          + 1.0/2*GHPLs2[0*4+1]*HPLs1[1]
          + 23.0/16*HPLs1[0]
          - 17.0/4*HPLs1[0]*zeta2
          + 1.0/4*HPLs2[0*2+0]
          + HPLs3[0*2*2+0*2+0]
          + 1.0/4*HPLs3[1*2*2+0*2+0]
          + 5.0/4*HPLs2[1*2+0]
          + 1.0/4*HPLs3[0*2*2+1*2+0]
          + 23.0/16*HPLs1[1]
          - 13.0/4*HPLs1[1]*zeta2
          + 1.0/4*HPLs2[0*2+1]
          + HPLs3[0*2*2+0*2+1]
          + 5.0/4*HPLs2[1*2+1]
          + 1.0/2*HPLs3[0*2*2+1*2+1]
          )

       + (dN_c*dN_c-1)/(dN_c*dN_c)*pow(v,2) * (
          - 2*zeta2
          - 3.0/8*GHPLs1[2]*zeta2
          - 1.0/2*GHPLs1[2]*HPLs1[0]
          - 3.0/8*GHPLs1[2]*HPLs2[0*2+0]
          + 3.0/8*GHPLs1[2]*HPLs2[1*2+0]
          + 1.0/2*GHPLs2[0*4+2]
          + 3.0/8*GHPLs2[0*4+2]*HPLs1[0]
          + 3.0/8*GHPLs3[2*4*4+1*4+2]
          - 3.0/8*GHPLs2[1*4+2]*HPLs1[0]
          - 3.0/8*GHPLs2[1*4+2]*HPLs1[1]
          + 3.0/8*GHPLs2[2*4+3]*HPLs1[0]
          - 3.0/8*GHPLs3[0*4*4+2*4+3]
          - 3.0/8*GHPLs2[3*4+3]*HPLs1[0]
          + 3.0/8*GHPLs3[0*4*4+3*4+3]
          + 15.0/8*GHPLs1[3]*zeta2
          + 1.0/2*GHPLs1[3]*HPLs1[0]
          - 3.0/8*GHPLs1[3]*HPLs2[1*2+0]
          - 3.0/8*GHPLs1[3]*HPLs2[0*2+1]
          - 3.0/8*GHPLs3[2*4*4+0*4+3]
          - 1.0/2*GHPLs2[0*4+3]
          + 3.0/8*GHPLs2[0*4+3]*HPLs1[1]
          + 1.0/2*GHPLs2[2*4+0]
          - 1.0/8*GHPLs2[2*4+0]*HPLs1[0]
          + 1.0/4*GHPLs1[0]*zeta2
          - 1.0/2*GHPLs1[0]*HPLs1[0]
          + 1.0/8*GHPLs1[0]*HPLs2[0*2+0]
          - 1.0/2*GHPLs1[0]*HPLs1[1]
          + 1.0/8*GHPLs1[0]*HPLs2[0*2+1]
          - 1.0/8*GHPLs3[2*4*4+1*4+0]
          + 1.0/8*GHPLs2[1*4+0]*HPLs1[0]
          + 1.0/8*GHPLs2[1*4+0]*HPLs1[1]
          - 1.0/2*GHPLs2[2*4+1]
          + 1.0/8*GHPLs2[2*4+1]*HPLs1[0]
          - 1.0/4*GHPLs1[1]*zeta2
          + 1.0/2*GHPLs1[1]*HPLs1[0]
          - 1.0/8*GHPLs1[1]*HPLs2[0*2+0]
          + 1.0/2*GHPLs1[1]*HPLs1[1]
          - 1.0/8*GHPLs1[1]*HPLs2[0*2+1]
          + 1.0/8*GHPLs3[2*4*4+1*4+1]
          - 1.0/8*GHPLs2[1*4+1]*HPLs1[0]
          - 1.0/8*GHPLs2[1*4+1]*HPLs1[1]
          + 1.0/8*HPLs1[0]*zeta2
          + 1.0/2*HPLs2[0*2+0]
          + 1.0/8*HPLs3[0*2*2+0*2+0]
          + 1.0/8*HPLs3[1*2*2+0*2+0]
          + 1.0/4*HPLs3[0*2*2+1*2+0]
          + 1.0/8*HPLs1[1]*zeta2
          + 1.0/2*HPLs2[0*2+1]
          + 1.0/8*HPLs3[0*2*2+0*2+1]
          + 1.0/8*HPLs3[1*2*2+0*2+1]
          + 1.0/4*HPLs3[0*2*2+1*2+1]
          )

       + (dN_c*dN_c-1)/(dN_c*dN_c)*u*pow(1-v,-2) * (
          - 15.0/16*zeta2
          - 3.0/8*zeta3
          - 7.0/8*GHPLs2[3*4+2]*HPLs1[0]
          + 7.0/8*GHPLs3[0*4*4+3*4+2]
          + 3.0/4*GHPLs1[2]*zeta2
          - 7.0/16*GHPLs1[2]*HPLs1[0]
          - 5.0/8*GHPLs1[2]*HPLs2[0*2+0]
          - 1.0/2*GHPLs1[2]*HPLs2[1*2+0]
          + 1.0/4*GHPLs1[2]*HPLs2[0*2+1]
          + 1.0/4*GHPLs2[0*4+2]*HPLs1[0]
          - 1.0/2*GHPLs3[2*4*4+1*4+2]
          + 1.0/2*GHPLs2[1*4+2]*HPLs1[0]
          + 1.0/2*GHPLs2[1*4+2]*HPLs1[1]
          + 9.0/8*GHPLs1[3]*HPLs1[0]
          - 9.0/8*GHPLs2[0*4+3]
          - 1.0/8*GHPLs2[2*4+0]*HPLs1[0]
          + 7.0/8*GHPLs2[3*4+0]*HPLs1[0]
          - 7.0/8*GHPLs3[0*4*4+3*4+0]
          - 5.0/8*GHPLs1[0]*zeta2
          + 5.0/8*GHPLs1[0]*HPLs1[0]
          + 5.0/8*GHPLs1[0]*HPLs2[0*2+0]
          + 5.0/8*GHPLs1[0]*HPLs2[1*2+0]
          + 1.0/2*GHPLs3[2*4*4+1*4+0]
          - 1.0/2*GHPLs2[1*4+0]*HPLs1[0]
          - 1.0/2*GHPLs2[1*4+0]*HPLs1[1]
          + 9.0/8*GHPLs2[2*4+1]
          - 9.0/8*GHPLs1[1]*HPLs1[0]
          - 9.0/8*GHPLs1[1]*HPLs1[1]
          - 27.0/32*HPLs1[0]
          + 11.0/4*HPLs1[0]*zeta2
          + 9.0/8*HPLs2[0*2+0]
          - 7.0/8*HPLs3[0*2*2+0*2+0]
          - 1.0/4*HPLs3[1*2*2+0*2+0]
          + 25.0/16*HPLs2[1*2+0]
          - 5.0/8*HPLs3[0*2*2+1*2+0]
          - 5.0/8*HPLs1[1]*zeta2
          + 5.0/8*HPLs2[0*2+1]
          + 5.0/8*HPLs3[0*2*2+0*2+1]
          + 5.0/8*HPLs3[1*2*2+0*2+1]
          )

       + (dN_c*dN_c-1)/(dN_c*dN_c)*u*pow(1-v,-1) * (
          - 17.0/32
          + 59.0/16*zeta2
          + 3.0/8*zeta3
          + 7.0/8*GHPLs2[3*4+2]*HPLs1[0]
          - 7.0/8*GHPLs3[0*4*4+3*4+2]
          - 17.0/16*GHPLs1[2]
          - 3.0/4*GHPLs1[2]*zeta2
          + 11.0/16*GHPLs1[2]*HPLs1[0]
          + 5.0/8*GHPLs1[2]*HPLs2[0*2+0]
          + 1.0/2*GHPLs1[2]*HPLs2[1*2+0]
          - 1.0/4*GHPLs1[2]*HPLs2[0*2+1]
          - 5.0/8*GHPLs2[0*4+2]
          - 1.0/4*GHPLs2[0*4+2]*HPLs1[0]
          + 1.0/2*GHPLs3[2*4*4+1*4+2]
          - 1.0/2*GHPLs2[1*4+2]*HPLs1[0]
          - 1.0/2*GHPLs2[1*4+2]*HPLs1[1]
          - 2*GHPLs1[3]*HPLs1[0]
          + 2*GHPLs2[0*4+3]
          - 5.0/8*GHPLs2[2*4+0]
          + 1.0/8*GHPLs2[2*4+0]*HPLs1[0]
          - 7.0/8*GHPLs2[3*4+0]*HPLs1[0]
          + 7.0/8*GHPLs3[0*4*4+3*4+0]
          + 3.0/4*GHPLs1[0]
          + 5.0/8*GHPLs1[0]*zeta2
          + 1.0/2*GHPLs1[0]*HPLs1[0]
          - 5.0/8*GHPLs1[0]*HPLs2[0*2+0]
          - 5.0/8*GHPLs1[0]*HPLs2[1*2+0]
          + 5.0/8*GHPLs1[0]*HPLs1[1]
          - 1.0/2*GHPLs3[2*4*4+1*4+0]
          + 1.0/2*GHPLs2[1*4+0]*HPLs1[0]
          + 1.0/2*GHPLs2[1*4+0]*HPLs1[1]
          - 5.0/8*GHPLs2[2*4+1]
          + 5.0/8*GHPLs1[1]*HPLs1[0]
          + 5.0/8*GHPLs1[1]*HPLs1[1]
          + 39.0/32*HPLs1[0]
          - 11.0/4*HPLs1[0]*zeta2
          - 2*HPLs2[0*2+0]
          + 7.0/8*HPLs3[0*2*2+0*2+0]
          + 1.0/4*HPLs3[1*2*2+0*2+0]
          - 21.0/16*HPLs2[1*2+0]
          + 5.0/8*HPLs3[0*2*2+1*2+0]
          + 17.0/16*HPLs1[1]
          + 5.0/8*HPLs1[1]*zeta2
          - 3.0/4*HPLs2[0*2+1]
          - 5.0/8*HPLs3[0*2*2+0*2+1]
          - 5.0/8*HPLs3[1*2*2+0*2+1]
          )

       + (dN_c*dN_c-1)/(dN_c*dN_c)*u * (
          - 3*zeta2
          + 3.0/4*GHPLs1[2]
          - 1.0/2*GHPLs1[2]*HPLs1[0]
          + 3.0/4*GHPLs2[0*4+2]
          + 3.0/4*GHPLs1[3]*HPLs1[0]
          - 3.0/4*GHPLs2[0*4+3]
          + 3.0/4*GHPLs2[2*4+0]
          - 3.0/8*GHPLs1[0]
          - GHPLs1[0]*HPLs1[0]
          - 3.0/4*GHPLs1[0]*HPLs1[1]
          - 3.0/4*GHPLs2[2*4+1]
          + 3.0/4*GHPLs1[1]*HPLs1[0]
          + 3.0/4*GHPLs1[1]*HPLs1[1]
          - 3.0/8*HPLs1[0]
          + 3.0/4*HPLs2[0*2+0]
          - 1.0/4*HPLs2[1*2+0]
          - 3.0/4*HPLs1[1]
          + 1.0/2*HPLs2[0*2+1]
          )

       + (dN_c*dN_c-1)/(dN_c*dN_c)*u*v * (
          - zeta2
          - 1.0/8*GHPLs1[2]*zeta2
          - 1.0/4*GHPLs1[2]*HPLs1[0]
          - 1.0/8*GHPLs1[2]*HPLs2[0*2+0]
          + 1.0/8*GHPLs1[2]*HPLs2[1*2+0]
          + 1.0/4*GHPLs2[0*4+2]
          + 1.0/8*GHPLs2[0*4+2]*HPLs1[0]
          + 1.0/8*GHPLs3[2*4*4+1*4+2]
          - 1.0/8*GHPLs2[1*4+2]*HPLs1[0]
          - 1.0/8*GHPLs2[1*4+2]*HPLs1[1]
          + 1.0/8*GHPLs2[2*4+3]*HPLs1[0]
          - 1.0/8*GHPLs3[0*4*4+2*4+3]
          - 1.0/8*GHPLs2[3*4+3]*HPLs1[0]
          + 1.0/8*GHPLs3[0*4*4+3*4+3]
          + 5.0/8*GHPLs1[3]*zeta2
          + 1.0/4*GHPLs1[3]*HPLs1[0]
          - 1.0/8*GHPLs1[3]*HPLs2[1*2+0]
          - 1.0/8*GHPLs1[3]*HPLs2[0*2+1]
          - 1.0/8*GHPLs3[2*4*4+0*4+3]
          - 1.0/4*GHPLs2[0*4+3]
          + 1.0/8*GHPLs2[0*4+3]*HPLs1[1]
          + 1.0/4*GHPLs2[2*4+0]
          - 1.0/8*GHPLs2[2*4+0]*HPLs1[0]
          + 1.0/4*GHPLs1[0]*zeta2
          - 1.0/4*GHPLs1[0]*HPLs1[0]
          + 1.0/8*GHPLs1[0]*HPLs2[0*2+0]
          - 1.0/4*GHPLs1[0]*HPLs1[1]
          + 1.0/8*GHPLs1[0]*HPLs2[0*2+1]
          - 1.0/8*GHPLs3[2*4*4+1*4+0]
          + 1.0/8*GHPLs2[1*4+0]*HPLs1[0]
          + 1.0/8*GHPLs2[1*4+0]*HPLs1[1]
          - 1.0/4*GHPLs2[2*4+1]
          + 1.0/8*GHPLs2[2*4+1]*HPLs1[0]
          - 1.0/4*GHPLs1[1]*zeta2
          + 1.0/4*GHPLs1[1]*HPLs1[0]
          - 1.0/8*GHPLs1[1]*HPLs2[0*2+0]
          + 1.0/4*GHPLs1[1]*HPLs1[1]
          - 1.0/8*GHPLs1[1]*HPLs2[0*2+1]
          + 1.0/8*GHPLs3[2*4*4+1*4+1]
          - 1.0/8*GHPLs2[1*4+1]*HPLs1[0]
          - 1.0/8*GHPLs2[1*4+1]*HPLs1[1]
          + 1.0/8*HPLs1[0]*zeta2
          + 1.0/4*HPLs2[0*2+0]
          + 1.0/8*HPLs3[0*2*2+0*2+0]
          + 1.0/8*HPLs3[1*2*2+0*2+0]
          + 1.0/4*HPLs3[0*2*2+1*2+0]
          + 1.0/8*HPLs1[1]*zeta2
          + 1.0/4*HPLs2[0*2+1]
          + 1.0/8*HPLs3[0*2*2+0*2+1]
          + 1.0/8*HPLs3[1*2*2+0*2+1]
          + 1.0/4*HPLs3[0*2*2+1*2+1]
          )

       + (dN_c*dN_c-1)/(dN_c*dN_c)*pow(u,2)*pow(1-v,-3) * (
          + 9.0/4*zeta2
          + 9.0/4*zeta3
          + 9.0/4*GHPLs2[3*4+2]*HPLs1[0]
          - 9.0/4*GHPLs3[0*4*4+3*4+2]
          - 9.0/4*GHPLs1[2]*zeta2
          + 9.0/4*GHPLs1[2]*HPLs2[0*2+0]
          + 9.0/4*GHPLs1[2]*HPLs2[1*2+0]
          + 9.0/4*GHPLs3[2*4*4+1*4+2]
          - 9.0/4*GHPLs2[1*4+2]*HPLs1[0]
          - 9.0/4*GHPLs2[1*4+2]*HPLs1[1]
          - 9.0/4*GHPLs1[3]*HPLs1[0]
          + 9.0/4*GHPLs2[0*4+3]
          - 9.0/4*GHPLs2[3*4+0]*HPLs1[0]
          + 9.0/4*GHPLs3[0*4*4+3*4+0]
          + 9.0/4*GHPLs1[0]*zeta2
          - 9.0/4*GHPLs1[0]*HPLs2[0*2+0]
          - 9.0/4*GHPLs1[0]*HPLs2[1*2+0]
          - 9.0/4*GHPLs3[2*4*4+1*4+0]
          + 9.0/4*GHPLs2[1*4+0]*HPLs1[0]
          + 9.0/4*GHPLs2[1*4+0]*HPLs1[1]
          - 9.0/4*GHPLs2[2*4+1]
          + 9.0/4*GHPLs1[1]*HPLs1[0]
          + 9.0/4*GHPLs1[1]*HPLs1[1]
          - 9*HPLs1[0]*zeta2
          - 9.0/4*HPLs2[0*2+0]
          + 9.0/4*HPLs3[0*2*2+0*2+0]
          - 9.0/4*HPLs2[1*2+0]
          + 9.0/4*HPLs3[0*2*2+1*2+0]
          + 9.0/4*HPLs1[1]*zeta2
          - 9.0/4*HPLs3[0*2*2+0*2+1]
          - 9.0/4*HPLs3[1*2*2+0*2+1]
          )

       + (dN_c*dN_c-1)/(dN_c*dN_c)*pow(u,2)*pow(1-v,-2) * (
          - 45.0/4*zeta2
          - 9.0/4*zeta3
          - 9.0/4*GHPLs2[3*4+2]*HPLs1[0]
          + 9.0/4*GHPLs3[0*4*4+3*4+2]
          + 9.0/8*GHPLs1[2]
          + 9.0/4*GHPLs1[2]*zeta2
          - 9.0/4*GHPLs1[2]*HPLs1[0]
          - 9.0/4*GHPLs1[2]*HPLs2[0*2+0]
          - 9.0/4*GHPLs1[2]*HPLs2[1*2+0]
          + 9.0/4*GHPLs2[0*4+2]
          - 9.0/4*GHPLs3[2*4*4+1*4+2]
          + 9.0/4*GHPLs2[1*4+2]*HPLs1[0]
          + 9.0/4*GHPLs2[1*4+2]*HPLs1[1]
          + 9.0/2*GHPLs1[3]*HPLs1[0]
          - 9.0/2*GHPLs2[0*4+3]
          + 9.0/4*GHPLs2[2*4+0]
          + 9.0/4*GHPLs2[3*4+0]*HPLs1[0]
          - 9.0/4*GHPLs3[0*4*4+3*4+0]
          - 9.0/8*GHPLs1[0]
          - 9.0/4*GHPLs1[0]*zeta2
          - 9.0/4*GHPLs1[0]*HPLs1[0]
          + 9.0/4*GHPLs1[0]*HPLs2[0*2+0]
          + 9.0/4*GHPLs1[0]*HPLs2[1*2+0]
          - 9.0/4*GHPLs1[0]*HPLs1[1]
          + 9.0/4*GHPLs3[2*4*4+1*4+0]
          - 9.0/4*GHPLs2[1*4+0]*HPLs1[0]
          - 9.0/4*GHPLs2[1*4+0]*HPLs1[1]
          + 9*HPLs1[0]*zeta2
          + 9.0/2*HPLs2[0*2+0]
          - 9.0/4*HPLs3[0*2*2+0*2+0]
          + 9.0/4*HPLs2[1*2+0]
          - 9.0/4*HPLs3[0*2*2+1*2+0]
          - 9.0/8*HPLs1[1]
          - 9.0/4*HPLs1[1]*zeta2
          + 9.0/4*HPLs2[0*2+1]
          + 9.0/4*HPLs3[0*2*2+0*2+1]
          + 9.0/4*HPLs3[1*2*2+0*2+1]
          )

       + (dN_c*dN_c-1)/(dN_c*dN_c)*pow(u,2)*pow(1-v,-1) * (
          + 9.0/2*zeta2
          - 3.0/8*GHPLs1[2]
          + 9.0/8*GHPLs1[2]*HPLs1[0]
          - 9.0/8*GHPLs2[0*4+2]
          - 9.0/8*GHPLs1[3]*HPLs1[0]
          + 9.0/8*GHPLs2[0*4+3]
          - 9.0/8*GHPLs2[2*4+0]
          + 3.0/8*GHPLs1[0]
          + 9.0/8*GHPLs1[0]*HPLs1[0]
          + 9.0/8*GHPLs1[0]*HPLs1[1]
          + 9.0/8*GHPLs2[2*4+1]
          - 9.0/8*GHPLs1[1]*HPLs1[0]
          - 9.0/8*GHPLs1[1]*HPLs1[1]
          - 9.0/8*HPLs2[0*2+0]
          + 3.0/8*HPLs1[1]
          - 9.0/8*HPLs2[0*2+1]
          )

       + (dN_c*dN_c-1)/(dN_c*dN_c)*pow(u,2) * (
          + 2*zeta2
          + 1.0/2*GHPLs1[2]*HPLs1[0]
          - 1.0/2*GHPLs2[0*4+2]
          - 1.0/2*GHPLs1[3]*HPLs1[0]
          + 1.0/2*GHPLs2[0*4+3]
          - 1.0/2*GHPLs2[2*4+0]
          + 1.0/2*GHPLs1[0]*HPLs1[0]
          + 1.0/2*GHPLs1[0]*HPLs1[1]
          + 1.0/2*GHPLs2[2*4+1]
          - 1.0/2*GHPLs1[1]*HPLs1[0]
          - 1.0/2*GHPLs1[1]*HPLs1[1]
          - 1.0/2*HPLs2[0*2+0]
          - 1.0/2*HPLs2[0*2+1]
          )

       + (dN_c*dN_c-1)/(dN_c*dN_c)*pow(u,3)*pow(1-v,-4) * (
          - 9.0/4*zeta3
          - 9.0/4*GHPLs2[3*4+2]*HPLs1[0]
          + 9.0/4*GHPLs3[0*4*4+3*4+2]
          + 9.0/4*GHPLs1[2]*zeta2
          - 9.0/4*GHPLs1[2]*HPLs2[0*2+0]
          - 9.0/4*GHPLs1[2]*HPLs2[1*2+0]
          - 9.0/4*GHPLs3[2*4*4+1*4+2]
          + 9.0/4*GHPLs2[1*4+2]*HPLs1[0]
          + 9.0/4*GHPLs2[1*4+2]*HPLs1[1]
          + 9.0/4*GHPLs2[3*4+0]*HPLs1[0]
          - 9.0/4*GHPLs3[0*4*4+3*4+0]
          - 9.0/4*GHPLs1[0]*zeta2
          + 9.0/4*GHPLs1[0]*HPLs2[0*2+0]
          + 9.0/4*GHPLs1[0]*HPLs2[1*2+0]
          + 9.0/4*GHPLs3[2*4*4+1*4+0]
          - 9.0/4*GHPLs2[1*4+0]*HPLs1[0]
          - 9.0/4*GHPLs2[1*4+0]*HPLs1[1]
          + 9*HPLs1[0]*zeta2
          - 9.0/4*HPLs3[0*2*2+0*2+0]
          - 9.0/4*HPLs3[0*2*2+1*2+0]
          - 9.0/4*HPLs1[1]*zeta2
          + 9.0/4*HPLs3[0*2*2+0*2+1]
          + 9.0/4*HPLs3[1*2*2+0*2+1]
          )

       + (dN_c*dN_c-1)/(dN_c*dN_c)*pow(u,3)*pow(1-v,-3) * (
          + 9*zeta2
          + 9.0/4*zeta3
          + 9.0/4*GHPLs2[3*4+2]*HPLs1[0]
          - 9.0/4*GHPLs3[0*4*4+3*4+2]
          - 9.0/4*GHPLs1[2]*zeta2
          + 9.0/4*GHPLs1[2]*HPLs1[0]
          + 9.0/4*GHPLs1[2]*HPLs2[0*2+0]
          + 9.0/4*GHPLs1[2]*HPLs2[1*2+0]
          - 9.0/4*GHPLs2[0*4+2]
          + 9.0/4*GHPLs3[2*4*4+1*4+2]
          - 9.0/4*GHPLs2[1*4+2]*HPLs1[0]
          - 9.0/4*GHPLs2[1*4+2]*HPLs1[1]
          - 9.0/4*GHPLs1[3]*HPLs1[0]
          + 9.0/4*GHPLs2[0*4+3]
          - 9.0/4*GHPLs2[2*4+0]
          - 9.0/4*GHPLs2[3*4+0]*HPLs1[0]
          + 9.0/4*GHPLs3[0*4*4+3*4+0]
          + 9.0/4*GHPLs1[0]*zeta2
          + 9.0/4*GHPLs1[0]*HPLs1[0]
          - 9.0/4*GHPLs1[0]*HPLs2[0*2+0]
          - 9.0/4*GHPLs1[0]*HPLs2[1*2+0]
          + 9.0/4*GHPLs1[0]*HPLs1[1]
          - 9.0/4*GHPLs3[2*4*4+1*4+0]
          + 9.0/4*GHPLs2[1*4+0]*HPLs1[0]
          + 9.0/4*GHPLs2[1*4+0]*HPLs1[1]
          + 9.0/4*GHPLs2[2*4+1]
          - 9.0/4*GHPLs1[1]*HPLs1[0]
          - 9.0/4*GHPLs1[1]*HPLs1[1]
          - 9*HPLs1[0]*zeta2
          - 9.0/4*HPLs2[0*2+0]
          + 9.0/4*HPLs3[0*2*2+0*2+0]
          + 9.0/4*HPLs3[0*2*2+1*2+0]
          + 9.0/4*HPLs1[1]*zeta2
          - 9.0/4*HPLs2[0*2+1]
          - 9.0/4*HPLs3[0*2*2+0*2+1]
          - 9.0/4*HPLs3[1*2*2+0*2+1]
          )

       + (dN_c*dN_c-1)/(dN_c*dN_c)*pow(u,3)*pow(1-v,-2) * (
          - 9.0/2*zeta2
          - 9.0/8*GHPLs1[2]*HPLs1[0]
          + 9.0/8*GHPLs2[0*4+2]
          + 9.0/8*GHPLs1[3]*HPLs1[0]
          - 9.0/8*GHPLs2[0*4+3]
          + 9.0/8*GHPLs2[2*4+0]
          - 9.0/8*GHPLs1[0]*HPLs1[0]
          - 9.0/8*GHPLs1[0]*HPLs1[1]
          - 9.0/8*GHPLs2[2*4+1]
          + 9.0/8*GHPLs1[1]*HPLs1[0]
          + 9.0/8*GHPLs1[1]*HPLs1[1]
          + 9.0/8*HPLs2[0*2+0]
          + 9.0/8*HPLs2[0*2+1]
          )

       + (dN_c*dN_c-1)/(dN_c*dN_c)*pow(u,3)*pow(1-v,-1) * (
          - 3.0/2*zeta2
          - 3.0/8*GHPLs1[2]*HPLs1[0]
          + 3.0/8*GHPLs2[0*4+2]
          + 3.0/8*GHPLs1[3]*HPLs1[0]
          - 3.0/8*GHPLs2[0*4+3]
          + 3.0/8*GHPLs2[2*4+0]
          - 3.0/8*GHPLs1[0]*HPLs1[0]
          - 3.0/8*GHPLs1[0]*HPLs1[1]
          - 3.0/8*GHPLs2[2*4+1]
          + 3.0/8*GHPLs1[1]*HPLs1[0]
          + 3.0/8*GHPLs1[1]*HPLs1[1]
          + 3.0/8*HPLs2[0*2+0]
          + 3.0/8*HPLs2[0*2+1]
          )

       + (dN_c*dN_c-1)/(dN_c*dN_c)*double_complex(0,1)*M_PI*pow(u,-2)*pow(1-u-v,-1) * (
          + 1.0/8*GHPLs2[2*4+3]
          + 1.0/8*GHPLs2[3*4+3]
          - 1.0/8*GHPLs1[3]*HPLs1[0]
          - 1.0/8*GHPLs1[3]*HPLs1[1]
          + 1.0/8*GHPLs2[0*4+3]
          + 1.0/8*GHPLs2[2*4+1]
          - 1.0/4*GHPLs1[1]*HPLs1[0]
          - 1.0/8*GHPLs1[1]*HPLs1[1]
          + 1.0/8*GHPLs2[0*4+1]
          + 1.0/8*GHPLs2[1*4+1]
          )

       + (dN_c*dN_c-1)/(dN_c*dN_c)*double_complex(0,1)*M_PI*pow(u,-2) * (
          - 1.0/8*GHPLs2[2*4+3]
          - 1.0/8*GHPLs2[3*4+3]
          + 1.0/8*GHPLs1[3]*HPLs1[0]
          + 1.0/8*GHPLs1[3]*HPLs1[1]
          - 1.0/8*GHPLs2[0*4+3]
          - 1.0/8*GHPLs2[2*4+1]
          + 1.0/4*GHPLs1[1]*HPLs1[0]
          + 1.0/8*GHPLs1[1]*HPLs1[1]
          - 1.0/8*GHPLs2[0*4+1]
          - 1.0/8*GHPLs2[1*4+1]
          )

       + (dN_c*dN_c-1)/(dN_c*dN_c)*double_complex(0,1)*M_PI*pow(u,-2)*v * (
          - 7.0/4*GHPLs3[3*4*4+2*4+2]
          - 7.0/4*GHPLs2[2*4+2]*HPLs1[0]
          + 5.0/4*GHPLs3[1*4*4+2*4+2]
          - 1.0/2*GHPLs3[3*4*4+3*4+2]
          + 5.0/2*GHPLs1[2]*zeta2
          - 9.0/8*GHPLs1[2]*HPLs1[0]
          - 7.0/4*GHPLs1[2]*HPLs2[0*2+0]
          - 5.0/4*GHPLs1[2]*HPLs2[1*2+0]
          + 5.0/4*GHPLs1[2]*HPLs2[0*2+1]
          + 7.0/4*GHPLs3[3*4*4+0*4+2]
          + 5.0/4*GHPLs2[0*4+2]*HPLs1[0]
          - 5.0/4*GHPLs3[1*4*4+0*4+2]
          + 3.0/8*GHPLs2[1*4+2]
          + 1.0/4*GHPLs2[1*4+2]*HPLs1[0]
          - 1.0/2*GHPLs3[1*4*4+1*4+2]
          - 1.0/8*GHPLs2[2*4+3]
          - 1.0/8*GHPLs2[3*4+3]
          + 1.0/8*GHPLs1[3]*HPLs1[0]
          + 1.0/8*GHPLs1[3]*HPLs1[1]
          - 1.0/8*GHPLs2[0*4+3]
          + 5.0/4*GHPLs3[2*4*4+2*4+1]
          - 5.0/4*GHPLs3[3*4*4+2*4+1]
          - 7.0/8*GHPLs2[2*4+1]
          - 3.0/2*GHPLs2[2*4+1]*HPLs1[0]
          - 5.0/4*GHPLs2[2*4+1]*HPLs1[1]
          + 5.0/4*GHPLs3[0*4*4+2*4+1]
          - 3.0/2*GHPLs3[1*4*4+2*4+1]
          + 11.0/16*GHPLs1[1]
          - 9.0/4*GHPLs1[1]*zeta2
          + 11.0/8*GHPLs1[1]*HPLs1[0]
          + 7.0/4*GHPLs1[1]*HPLs2[0*2+0]
          + 5.0/4*GHPLs1[1]*HPLs2[1*2+0]
          + 7.0/8*GHPLs1[1]*HPLs1[1]
          + 3.0/2*GHPLs1[1]*HPLs2[0*2+1]
          + 5.0/4*GHPLs1[1]*HPLs2[1*2+1]
          + 5.0/4*GHPLs3[2*4*4+0*4+1]
          - 5.0/4*GHPLs3[3*4*4+0*4+1]
          - 7.0/8*GHPLs2[0*4+1]
          - 5.0/4*GHPLs2[0*4+1]*HPLs1[0]
          - 5.0/4*GHPLs2[0*4+1]*HPLs1[1]
          + 1.0/4*GHPLs3[1*4*4+0*4+1]
          - 1.0/2*GHPLs3[2*4*4+1*4+1]
          - 1.0/2*GHPLs2[1*4+1]
          + 1.0/2*GHPLs2[1*4+1]*HPLs1[1]
          + 5.0/4*GHPLs3[0*4*4+1*4+1]
          - 3.0/4*GHPLs3[1*4*4+1*4+1]
          )

       + (dN_c*dN_c-1)/(dN_c*dN_c)*double_complex(0,1)*M_PI*pow(u,-2)*pow(v,2) * (
          + 7.0/4*GHPLs3[3*4*4+2*4+2]
          + 7.0/4*GHPLs2[2*4+2]*HPLs1[0]
          - 5.0/4*GHPLs3[1*4*4+2*4+2]
          + 1.0/2*GHPLs3[3*4*4+3*4+2]
          - 5.0/2*GHPLs1[2]*zeta2
          + 9.0/8*GHPLs1[2]*HPLs1[0]
          + 7.0/4*GHPLs1[2]*HPLs2[0*2+0]
          + 5.0/4*GHPLs1[2]*HPLs2[1*2+0]
          - 5.0/4*GHPLs1[2]*HPLs2[0*2+1]
          - 7.0/4*GHPLs3[3*4*4+0*4+2]
          - 5.0/4*GHPLs2[0*4+2]*HPLs1[0]
          + 5.0/4*GHPLs3[1*4*4+0*4+2]
          - 5.0/8*GHPLs2[1*4+2]
          - 1.0/4*GHPLs2[1*4+2]*HPLs1[0]
          + 1.0/2*GHPLs3[1*4*4+1*4+2]
          - 1.0/8*GHPLs2[2*4+3]
          - 5.0/8*GHPLs2[3*4+3]
          + 1.0/8*GHPLs1[3]*HPLs1[0]
          + 1.0/8*GHPLs1[3]*HPLs1[1]
          - 1.0/8*GHPLs2[0*4+3]
          - 5.0/4*GHPLs3[2*4*4+2*4+1]
          + 5.0/4*GHPLs3[3*4*4+2*4+1]
          + 3.0/8*GHPLs2[2*4+1]
          + 3.0/2*GHPLs2[2*4+1]*HPLs1[0]
          + 5.0/4*GHPLs2[2*4+1]*HPLs1[1]
          - 5.0/4*GHPLs3[0*4*4+2*4+1]
          + 3.0/2*GHPLs3[1*4*4+2*4+1]
          - 15.0/16*GHPLs1[1]
          + 9.0/4*GHPLs1[1]*zeta2
          - 3.0/8*GHPLs1[1]*HPLs1[0]
          - 7.0/4*GHPLs1[1]*HPLs2[0*2+0]
          - 5.0/4*GHPLs1[1]*HPLs2[1*2+0]
          - 3.0/8*GHPLs1[1]*HPLs1[1]
          - 3.0/2*GHPLs1[1]*HPLs2[0*2+1]
          - 5.0/4*GHPLs1[1]*HPLs2[1*2+1]
          - 5.0/4*GHPLs3[2*4*4+0*4+1]
          + 5.0/4*GHPLs3[3*4*4+0*4+1]
          + 3.0/8*GHPLs2[0*4+1]
          + 5.0/4*GHPLs2[0*4+1]*HPLs1[0]
          + 5.0/4*GHPLs2[0*4+1]*HPLs1[1]
          - 1.0/4*GHPLs3[1*4*4+0*4+1]
          + 1.0/2*GHPLs3[2*4*4+1*4+1]
          - 1.0/2*GHPLs2[1*4+1]*HPLs1[1]
          - 5.0/4*GHPLs3[0*4*4+1*4+1]
          + 3.0/4*GHPLs3[1*4*4+1*4+1]
          )

       + (dN_c*dN_c-1)/(dN_c*dN_c)*double_complex(0,1)*M_PI*pow(u,-2)*pow(v,3) * (
          + 1.0/8*GHPLs2[1*4+2]
          - 1.0/8*GHPLs2[2*4+3]
          + 1.0/8*GHPLs2[3*4+3]
          + 1.0/8*GHPLs1[3]*HPLs1[0]
          + 1.0/8*GHPLs1[3]*HPLs1[1]
          - 1.0/8*GHPLs2[0*4+3]
          + 1.0/8*GHPLs1[1]
          )

       + (dN_c*dN_c-1)/(dN_c*dN_c)*double_complex(0,1)*M_PI*pow(u,-2)*pow(v,4) * (
          + 1.0/8*GHPLs2[1*4+2]
          - 1.0/8*GHPLs2[2*4+3]
          + 1.0/8*GHPLs2[3*4+3]
          + 1.0/8*GHPLs1[3]*HPLs1[0]
          + 1.0/8*GHPLs1[3]*HPLs1[1]
          - 1.0/8*GHPLs2[0*4+3]
          )

       + (dN_c*dN_c-1)/(dN_c*dN_c)*double_complex(0,1)*M_PI*pow(u,-1)*pow(1-u-v,-1) * (
          - 1.0/8*GHPLs2[2*4+3]
          - 1.0/8*GHPLs2[3*4+3]
          - 1.0/8*GHPLs1[3]
          + 1.0/8*GHPLs1[3]*HPLs1[0]
          + 1.0/8*GHPLs1[3]*HPLs1[1]
          - 1.0/8*GHPLs2[0*4+3]
          - 1.0/8*GHPLs2[2*4+1]
          + 1.0/4*GHPLs1[1]*HPLs1[0]
          + 1.0/8*GHPLs1[1]*HPLs1[1]
          - 1.0/8*GHPLs2[0*4+1]
          - 1.0/8*GHPLs2[1*4+1]
          - 1.0/8*HPLs1[0]
          )

       + (dN_c*dN_c-1)/(dN_c*dN_c)*double_complex(0,1)*M_PI*pow(u,-1) * (
          + 1.0/8*GHPLs1[3]
          - 1.0/4*GHPLs1[1]
          + 1.0/8*HPLs1[0]
          )

       + (dN_c*dN_c-1)/(dN_c*dN_c)*double_complex(0,1)*M_PI*pow(u,-1)*v * (
          + 23.0/16
          + 1.0/4*zeta2
          + 7.0/4*GHPLs3[3*4*4+2*4+2]
          + 5.0/4*GHPLs2[2*4+2]
          + 7.0/4*GHPLs2[2*4+2]*HPLs1[0]
          - 5.0/4*GHPLs3[1*4*4+2*4+2]
          + 1.0/2*GHPLs3[3*4*4+3*4+2]
          - 3*GHPLs2[3*4+2]
          - 2*GHPLs1[2]
          - 5.0/2*GHPLs1[2]*zeta2
          - 15.0/8*GHPLs1[2]*HPLs1[0]
          + 7.0/4*GHPLs1[2]*HPLs2[0*2+0]
          + 5.0/4*GHPLs1[2]*HPLs2[1*2+0]
          - 5.0/4*GHPLs1[2]*HPLs1[1]
          - 5.0/4*GHPLs1[2]*HPLs2[0*2+1]
          - 7.0/4*GHPLs3[3*4*4+0*4+2]
          + 5.0/4*GHPLs2[0*4+2]
          - 5.0/4*GHPLs2[0*4+2]*HPLs1[0]
          + 5.0/4*GHPLs3[1*4*4+0*4+2]
          - 9.0/8*GHPLs2[1*4+2]
          - 1.0/4*GHPLs2[1*4+2]*HPLs1[0]
          + 1.0/2*GHPLs3[1*4*4+1*4+2]
          - 1.0/8*GHPLs2[2*4+3]
          - 5.0/8*GHPLs2[3*4+3]
          + 1.0/8*GHPLs1[3]
          + 1.0/8*GHPLs1[3]*HPLs1[0]
          + 1.0/8*GHPLs1[3]*HPLs1[1]
          - 1.0/8*GHPLs2[0*4+3]
          + 5.0/4*GHPLs2[2*4+0]
          + 1.0/2*GHPLs2[3*4+0]
          - 3.0/4*GHPLs1[0]
          - 5.0/4*GHPLs1[0]*HPLs1[1]
          - 1.0/2*GHPLs2[1*4+0]
          - 5.0/4*GHPLs3[2*4*4+2*4+1]
          + 5.0/4*GHPLs3[3*4*4+2*4+1]
          - 1.0/8*GHPLs2[2*4+1]
          + 3.0/2*GHPLs2[2*4+1]*HPLs1[0]
          + 5.0/4*GHPLs2[2*4+1]*HPLs1[1]
          - 5.0/4*GHPLs3[0*4*4+2*4+1]
          + 3.0/2*GHPLs3[1*4*4+2*4+1]
          + 7.0/16*GHPLs1[1]
          + 9.0/4*GHPLs1[1]*zeta2
          - 3.0/8*GHPLs1[1]*HPLs1[0]
          - 7.0/4*GHPLs1[1]*HPLs2[0*2+0]
          - 5.0/4*GHPLs1[1]*HPLs2[1*2+0]
          + 1.0/8*GHPLs1[1]*HPLs1[1]
          - 3.0/2*GHPLs1[1]*HPLs2[0*2+1]
          - 5.0/4*GHPLs1[1]*HPLs2[1*2+1]
          - 5.0/4*GHPLs3[2*4*4+0*4+1]
          + 5.0/4*GHPLs3[3*4*4+0*4+1]
          + 11.0/8*GHPLs2[0*4+1]
          + 5.0/4*GHPLs2[0*4+1]*HPLs1[0]
          + 5.0/4*GHPLs2[0*4+1]*HPLs1[1]
          - 1.0/4*GHPLs3[1*4*4+0*4+1]
          + 1.0/2*GHPLs3[2*4*4+1*4+1]
          - 3.0/4*GHPLs2[1*4+1]
          - 1.0/2*GHPLs2[1*4+1]*HPLs1[1]
          - 5.0/4*GHPLs3[0*4*4+1*4+1]
          + 3.0/4*GHPLs3[1*4*4+1*4+1]
          + 1.0/8*HPLs1[0]
          + 2*HPLs1[1]
          + 11.0/4*HPLs2[0*2+1]
          + 5.0/4*HPLs2[1*2+1]
          )

       + (dN_c*dN_c-1)/(dN_c*dN_c)*double_complex(0,1)*M_PI*pow(u,-1)*pow(v,2) * (
          - 23.0/16
          + 9.0/4*zeta2
          - 5.0/4*GHPLs2[2*4+2]
          + 5.0/4*GHPLs2[3*4+2]
          + 7.0/4*GHPLs1[2]
          + 3.0/2*GHPLs1[2]*HPLs1[0]
          + 5.0/4*GHPLs1[2]*HPLs1[1]
          - 5.0/4*GHPLs2[0*4+2]
          + 7.0/4*GHPLs2[1*4+2]
          - 1.0/4*GHPLs2[2*4+3]
          + 1.0/4*GHPLs2[3*4+3]
          - 11.0/8*GHPLs1[3]
          + 1.0/4*GHPLs1[3]*HPLs1[0]
          + 1.0/4*GHPLs1[3]*HPLs1[1]
          - 1.0/4*GHPLs2[0*4+3]
          - 5.0/4*GHPLs2[2*4+0]
          + 5.0/4*GHPLs2[3*4+0]
          + 1.0/2*GHPLs1[0]
          + 5.0/4*GHPLs1[0]*HPLs1[0]
          + 5.0/4*GHPLs1[0]*HPLs1[1]
          - 1.0/2*GHPLs2[1*4+0]
          + 1.0/2*GHPLs2[2*4+1]
          + 3.0/8*GHPLs1[1]
          - 1.0/2*GHPLs1[1]*HPLs1[1]
          - GHPLs2[0*4+1]
          + 3.0/4*GHPLs2[1*4+1]
          - 7.0/4*HPLs1[0]
          - 7.0/4*HPLs2[0*2+0]
          - 5.0/4*HPLs2[1*2+0]
          - 7.0/4*HPLs1[1]
          - 3.0/2*HPLs2[0*2+1]
          - 5.0/4*HPLs2[1*2+1]
          )

       + (dN_c*dN_c-1)/(dN_c*dN_c)*double_complex(0,1)*M_PI*pow(u,-1)*pow(v,3) * (
          + 1.0/8*GHPLs1[2]
          + 3.0/8*GHPLs2[1*4+2]
          - 3.0/8*GHPLs2[2*4+3]
          + 3.0/8*GHPLs2[3*4+3]
          - 1.0/8*GHPLs1[3]
          + 3.0/8*GHPLs1[3]*HPLs1[0]
          + 3.0/8*GHPLs1[3]*HPLs1[1]
          - 3.0/8*GHPLs2[0*4+3]
          + 1.0/8*GHPLs1[0]
          - 1.0/8*GHPLs1[1]
          - 1.0/8*HPLs1[0]
          - 1.0/8*HPLs1[1]
          )

       + (dN_c*dN_c-1)/(dN_c*dN_c)*double_complex(0,1)*M_PI*pow(1-v,-1) * (
          - 5.0/4*zeta2
          + 7.0/8*GHPLs2[3*4+2]
          + 3.0/4*GHPLs1[2]*HPLs1[0]
          - 1.0/2*GHPLs2[1*4+2]
          + 1.0/2*GHPLs1[3]
          - 7.0/8*GHPLs2[3*4+0]
          - 5.0/8*GHPLs1[0]*HPLs1[0]
          + 1.0/2*GHPLs2[1*4+0]
          - 1.0/8*GHPLs1[1]
          + 15.0/16*HPLs1[0]
          + 7.0/8*HPLs2[0*2+0]
          + 5.0/8*HPLs2[1*2+0]
          - 5.0/8*HPLs2[0*2+1]
          )

       + (dN_c*dN_c-1)/(dN_c*dN_c)*double_complex(0,1)*M_PI * (
          - 1.0/4
          + 5.0/4*zeta2
          - 7.0/8*GHPLs2[3*4+2]
          - 3.0/4*GHPLs1[2]*HPLs1[0]
          + 1.0/2*GHPLs2[1*4+2]
          - 3.0/8*GHPLs1[3]
          + 7.0/8*GHPLs2[3*4+0]
          + 5.0/8*GHPLs1[0]*HPLs1[0]
          - 1.0/2*GHPLs2[1*4+0]
          + 5.0/8*GHPLs1[1]
          - 13.0/16*HPLs1[0]
          - 7.0/8*HPLs2[0*2+0]
          - 5.0/8*HPLs2[1*2+0]
          + 5.0/8*HPLs2[0*2+1]
          )

       + (dN_c*dN_c-1)/(dN_c*dN_c)*double_complex(0,1)*M_PI*v*pow(1-u,-1) * (
          - 17.0/32
          - 1.0/8*GHPLs2[2*4+2]
          + 1.0/8*GHPLs2[3*4+2]
          - 3.0/16*GHPLs1[2]
          + 1.0/4*GHPLs1[2]*HPLs1[0]
          + 1.0/8*GHPLs1[2]*HPLs1[1]
          - 1.0/8*GHPLs2[0*4+2]
          + 1.0/4*GHPLs2[1*4+2]
          - 1.0/8*GHPLs1[3]
          - 1.0/8*GHPLs2[2*4+0]
          + 1.0/8*GHPLs2[3*4+0]
          - 1.0/2*GHPLs1[0]
          + 1.0/8*GHPLs1[0]*HPLs1[0]
          + 1.0/8*GHPLs1[0]*HPLs1[1]
          - 1.0/8*GHPLs2[1*4+0]
          + 1.0/4*GHPLs2[2*4+1]
          + 3.0/16*GHPLs1[1]
          - 1.0/4*GHPLs1[1]*HPLs1[1]
          - 1.0/4*GHPLs2[1*4+1]
          - 1.0/16*HPLs1[0]
          - 3.0/8*HPLs2[0*2+0]
          - 1.0/8*HPLs2[1*2+0]
          + 3.0/16*HPLs1[1]
          - 1.0/4*HPLs2[0*2+1]
          - 1.0/8*HPLs2[1*2+1]
          )

       + (dN_c*dN_c-1)/(dN_c*dN_c)*double_complex(0,1)*M_PI*v * (
          + 3.0/8
          + 9.0/8*zeta2
          - 1.0/2*GHPLs2[2*4+2]
          + 1.0/2*GHPLs2[3*4+2]
          + 13.0/8*GHPLs1[2]
          + 1.0/2*GHPLs1[2]*HPLs1[0]
          + 1.0/2*GHPLs1[2]*HPLs1[1]
          - 1.0/2*GHPLs2[0*4+2]
          + 5.0/8*GHPLs2[1*4+2]
          - 1.0/8*GHPLs2[2*4+3]
          + 1.0/8*GHPLs2[3*4+3]
          - 13.0/8*GHPLs1[3]
          + 1.0/8*GHPLs1[3]*HPLs1[0]
          + 1.0/8*GHPLs1[3]*HPLs1[1]
          - 1.0/8*GHPLs2[0*4+3]
          - 1.0/2*GHPLs2[2*4+0]
          + 1.0/2*GHPLs2[3*4+0]
          + 13.0/8*GHPLs1[0]
          + 1.0/2*GHPLs1[0]*HPLs1[0]
          + 1.0/2*GHPLs1[0]*HPLs1[1]
          - 1.0/8*GHPLs2[1*4+0]
          - 11.0/8*GHPLs1[1]
          - 1.0/2*GHPLs2[0*4+1]
          + 5.0/8*GHPLs2[1*4+1]
          - 13.0/8*HPLs1[0]
          - 1.0/2*HPLs2[0*2+0]
          - 1.0/2*HPLs2[1*2+0]
          - 13.0/8*HPLs1[1]
          - 1.0/2*HPLs2[0*2+1]
          - 1.0/2*HPLs2[1*2+1]
          )

       + (dN_c*dN_c-1)/(dN_c*dN_c)*double_complex(0,1)*M_PI*pow(v,2)*pow(1-u,-2) * (
          + 23.0/32
          + 1.0/8*GHPLs2[2*4+2]
          - 1.0/8*GHPLs2[3*4+2]
          + 1.0/16*GHPLs1[2]
          - 1.0/4*GHPLs1[2]*HPLs1[0]
          - 1.0/8*GHPLs1[2]*HPLs1[1]
          + 1.0/8*GHPLs2[0*4+2]
          - 1.0/4*GHPLs2[1*4+2]
          + 1.0/8*GHPLs2[2*4+0]
          - 1.0/8*GHPLs2[3*4+0]
          + 3.0/8*GHPLs1[0]
          - 1.0/8*GHPLs1[0]*HPLs1[0]
          - 1.0/8*GHPLs1[0]*HPLs1[1]
          + 1.0/8*GHPLs2[1*4+0]
          - 1.0/4*GHPLs2[2*4+1]
          - 7.0/16*GHPLs1[1]
          + 1.0/4*GHPLs1[1]*HPLs1[1]
          + 1.0/4*GHPLs2[1*4+1]
          + 3.0/16*HPLs1[0]
          + 3.0/8*HPLs2[0*2+0]
          + 1.0/8*HPLs2[1*2+0]
          - 1.0/16*HPLs1[1]
          + 1.0/4*HPLs2[0*2+1]
          + 1.0/8*HPLs2[1*2+1]
          )

       + (dN_c*dN_c-1)/(dN_c*dN_c)*double_complex(0,1)*M_PI*pow(v,2)*pow(1-u,-1) * (
          - 23.0/16
          + zeta2
          - 3.0/4*GHPLs2[2*4+2]
          + 3.0/4*GHPLs2[3*4+2]
          + 1.0/2*GHPLs1[2]
          + GHPLs1[2]*HPLs1[0]
          + 3.0/4*GHPLs1[2]*HPLs1[1]
          - 3.0/4*GHPLs2[0*4+2]
          + GHPLs2[1*4+2]
          - 1.0/8*GHPLs1[3]
          - 3.0/4*GHPLs2[2*4+0]
          + 3.0/4*GHPLs2[3*4+0]
          - 3.0/4*GHPLs1[0]
          + 3.0/4*GHPLs1[0]*HPLs1[0]
          + 3.0/4*GHPLs1[0]*HPLs1[1]
          - 1.0/4*GHPLs2[1*4+0]
          + 1.0/2*GHPLs2[2*4+1]
          + 5.0/4*GHPLs1[1]
          - 1.0/2*GHPLs1[1]*HPLs1[1]
          - 1.0/2*GHPLs2[0*4+1]
          - 1.0/2*HPLs1[0]
          - 5.0/4*HPLs2[0*2+0]
          - 3.0/4*HPLs2[1*2+0]
          - 1.0/2*HPLs1[1]
          - HPLs2[0*2+1]
          - 3.0/4*HPLs2[1*2+1]
          )

       + (dN_c*dN_c-1)/(dN_c*dN_c)*double_complex(0,1)*M_PI*pow(v,2) * (
          + 1.0/8*zeta2
          + 1.0/2*GHPLs1[2]
          + 3.0/8*GHPLs2[1*4+2]
          - 3.0/8*GHPLs2[2*4+3]
          + 3.0/8*GHPLs2[3*4+3]
          - 1.0/2*GHPLs1[3]
          + 3.0/8*GHPLs1[3]*HPLs1[0]
          + 3.0/8*GHPLs1[3]*HPLs1[1]
          - 3.0/8*GHPLs2[0*4+3]
          + 1.0/2*GHPLs1[0]
          - 1.0/8*GHPLs2[1*4+0]
          - 1.0/2*GHPLs1[1]
          + 1.0/8*GHPLs2[1*4+1]
          - 1.0/2*HPLs1[0]
          - 1.0/2*HPLs1[1]
          )

       + (dN_c*dN_c-1)/(dN_c*dN_c)*double_complex(0,1)*M_PI*u*pow(1-v,-2) * (
          - 5.0/4*zeta2
          + 7.0/8*GHPLs2[3*4+2]
          + 3.0/4*GHPLs1[2]*HPLs1[0]
          - 1.0/2*GHPLs2[1*4+2]
          - 9.0/8*GHPLs1[3]
          - 7.0/8*GHPLs2[3*4+0]
          - 5.0/8*GHPLs1[0]*HPLs1[0]
          + 1.0/2*GHPLs2[1*4+0]
          + 9.0/8*GHPLs1[1]
          - 15.0/16*HPLs1[0]
          + 7.0/8*HPLs2[0*2+0]
          + 5.0/8*HPLs2[1*2+0]
          - 5.0/8*HPLs2[0*2+1]
          )

       + (dN_c*dN_c-1)/(dN_c*dN_c)*double_complex(0,1)*M_PI*u*pow(1-v,-1) * (
          - 5.0/16
          + 5.0/4*zeta2
          - 7.0/8*GHPLs2[3*4+2]
          - 5.0/8*GHPLs1[2]
          - 3.0/4*GHPLs1[2]*HPLs1[0]
          + 1.0/2*GHPLs2[1*4+2]
          + 2*GHPLs1[3]
          + 7.0/8*GHPLs2[3*4+0]
          - 5.0/8*GHPLs1[0]
          + 5.0/8*GHPLs1[0]*HPLs1[0]
          - 1.0/2*GHPLs2[1*4+0]
          - 5.0/8*GHPLs1[1]
          + 29.0/16*HPLs1[0]
          - 7.0/8*HPLs2[0*2+0]
          - 5.0/8*HPLs2[1*2+0]
          + 5.0/8*HPLs1[1]
          + 5.0/8*HPLs2[0*2+1]
          )

       + (dN_c*dN_c-1)/(dN_c*dN_c)*double_complex(0,1)*M_PI*u * (
          + 3.0/8
          + 3.0/4*GHPLs1[2]
          - 3.0/4*GHPLs1[3]
          + 3.0/4*GHPLs1[0]
          - 3.0/4*GHPLs1[1]
          - 3.0/4*HPLs1[0]
          - 3.0/4*HPLs1[1]
          )

       + (dN_c*dN_c-1)/(dN_c*dN_c)*double_complex(0,1)*M_PI*u*v * (
          + 1.0/8*zeta2
          + 1.0/4*GHPLs1[2]
          + 1.0/8*GHPLs2[1*4+2]
          - 1.0/8*GHPLs2[2*4+3]
          + 1.0/8*GHPLs2[3*4+3]
          - 1.0/4*GHPLs1[3]
          + 1.0/8*GHPLs1[3]*HPLs1[0]
          + 1.0/8*GHPLs1[3]*HPLs1[1]
          - 1.0/8*GHPLs2[0*4+3]
          + 1.0/4*GHPLs1[0]
          - 1.0/8*GHPLs2[1*4+0]
          - 1.0/4*GHPLs1[1]
          + 1.0/8*GHPLs2[1*4+1]
          - 1.0/4*HPLs1[0]
          - 1.0/4*HPLs1[1]
          )

       + (dN_c*dN_c-1)/(dN_c*dN_c)*double_complex(0,1)*M_PI*pow(u,2)*pow(1-v,-3) * (
          + 9.0/2*zeta2
          - 9.0/4*GHPLs2[3*4+2]
          - 9.0/4*GHPLs1[2]*HPLs1[0]
          + 9.0/4*GHPLs2[1*4+2]
          + 9.0/4*GHPLs1[3]
          + 9.0/4*GHPLs2[3*4+0]
          + 9.0/4*GHPLs1[0]*HPLs1[0]
          - 9.0/4*GHPLs2[1*4+0]
          - 9.0/4*GHPLs1[1]
          + 9.0/4*HPLs1[0]
          - 9.0/4*HPLs2[0*2+0]
          - 9.0/4*HPLs2[1*2+0]
          + 9.0/4*HPLs2[0*2+1]
          )

       + (dN_c*dN_c-1)/(dN_c*dN_c)*double_complex(0,1)*M_PI*pow(u,2)*pow(1-v,-2) * (
          - 9.0/2*zeta2
          + 9.0/4*GHPLs2[3*4+2]
          + 9.0/4*GHPLs1[2]
          + 9.0/4*GHPLs1[2]*HPLs1[0]
          - 9.0/4*GHPLs2[1*4+2]
          - 9.0/2*GHPLs1[3]
          - 9.0/4*GHPLs2[3*4+0]
          + 9.0/4*GHPLs1[0]
          - 9.0/4*GHPLs1[0]*HPLs1[0]
          + 9.0/4*GHPLs2[1*4+0]
          - 9.0/2*HPLs1[0]
          + 9.0/4*HPLs2[0*2+0]
          + 9.0/4*HPLs2[1*2+0]
          - 9.0/4*HPLs1[1]
          - 9.0/4*HPLs2[0*2+1]
          )

       + (dN_c*dN_c-1)/(dN_c*dN_c)*double_complex(0,1)*M_PI*pow(u,2)*pow(1-v,-1) * (
          - 9.0/8*GHPLs1[2]
          + 9.0/8*GHPLs1[3]
          - 9.0/8*GHPLs1[0]
          + 9.0/8*GHPLs1[1]
          + 9.0/8*HPLs1[0]
          + 9.0/8*HPLs1[1]
          )

       + (dN_c*dN_c-1)/(dN_c*dN_c)*double_complex(0,1)*M_PI*pow(u,2) * (
          - 1.0/2*GHPLs1[2]
          + 1.0/2*GHPLs1[3]
          - 1.0/2*GHPLs1[0]
          + 1.0/2*GHPLs1[1]
          + 1.0/2*HPLs1[0]
          + 1.0/2*HPLs1[1]
          )

       + (dN_c*dN_c-1)/(dN_c*dN_c)*double_complex(0,1)*M_PI*pow(u,3)*pow(1-v,-4) * (
          - 9.0/2*zeta2
          + 9.0/4*GHPLs2[3*4+2]
          + 9.0/4*GHPLs1[2]*HPLs1[0]
          - 9.0/4*GHPLs2[1*4+2]
          - 9.0/4*GHPLs2[3*4+0]
          - 9.0/4*GHPLs1[0]*HPLs1[0]
          + 9.0/4*GHPLs2[1*4+0]
          + 9.0/4*HPLs2[0*2+0]
          + 9.0/4*HPLs2[1*2+0]
          - 9.0/4*HPLs2[0*2+1]
          )

       + (dN_c*dN_c-1)/(dN_c*dN_c)*double_complex(0,1)*M_PI*pow(u,3)*pow(1-v,-3) * (
          + 9.0/2*zeta2
          - 9.0/4*GHPLs2[3*4+2]
          - 9.0/4*GHPLs1[2]
          - 9.0/4*GHPLs1[2]*HPLs1[0]
          + 9.0/4*GHPLs2[1*4+2]
          + 9.0/4*GHPLs1[3]
          + 9.0/4*GHPLs2[3*4+0]
          - 9.0/4*GHPLs1[0]
          + 9.0/4*GHPLs1[0]*HPLs1[0]
          - 9.0/4*GHPLs2[1*4+0]
          + 9.0/4*GHPLs1[1]
          + 9.0/4*HPLs1[0]
          - 9.0/4*HPLs2[0*2+0]
          - 9.0/4*HPLs2[1*2+0]
          + 9.0/4*HPLs1[1]
          + 9.0/4*HPLs2[0*2+1]
          )

       + (dN_c*dN_c-1)/(dN_c*dN_c)*double_complex(0,1)*M_PI*pow(u,3)*pow(1-v,-2) * (
          + 9.0/8*GHPLs1[2]
          - 9.0/8*GHPLs1[3]
          + 9.0/8*GHPLs1[0]
          - 9.0/8*GHPLs1[1]
          - 9.0/8*HPLs1[0]
          - 9.0/8*HPLs1[1]
          )

       + (dN_c*dN_c-1)/(dN_c*dN_c)*double_complex(0,1)*M_PI*pow(u,3)*pow(1-v,-1) * (
          + 3.0/8*GHPLs1[2]
          - 3.0/8*GHPLs1[3]
          + 3.0/8*GHPLs1[0]
          - 3.0/8*GHPLs1[1]
          - 3.0/8*HPLs1[0]
          - 3.0/8*HPLs1[1]
          )

       + C_F*NF*pow(u,-2)*v * (
          + 1.0/3*GHPLs2[2*4+2]*HPLs1[0]
          + 1.0/3*GHPLs1[2]*zeta2
          - 19.0/18*GHPLs1[2]*HPLs1[0]
          - 2.0/3*GHPLs1[2]*HPLs2[0*2+0]
          - 1.0/3*GHPLs1[2]*HPLs2[1*2+0]
          + 1.0/3*GHPLs3[2*4*4+2*4+1]
          - 19.0/18*GHPLs2[2*4+1]
          - 1.0/3*GHPLs2[2*4+1]*HPLs1[0]
          - 1.0/3*GHPLs2[2*4+1]*HPLs1[1]
          + 1.0/3*GHPLs1[1]*zeta2
          + 19.0/18*GHPLs1[1]*HPLs1[0]
          + 2.0/3*GHPLs1[1]*HPLs2[0*2+0]
          + 2.0/3*GHPLs1[1]*HPLs2[1*2+0]
          + 19.0/18*GHPLs1[1]*HPLs1[1]
          + 1.0/3*GHPLs1[1]*HPLs2[0*2+1]
          + 1.0/3*GHPLs1[1]*HPLs2[1*2+1]
          + 1.0/3*GHPLs3[2*4*4+1*4+1]
          - 1.0/3*GHPLs2[1*4+1]*HPLs1[0]
          - 1.0/3*GHPLs2[1*4+1]*HPLs1[1]
          )

       + C_F*NF*pow(u,-2)*pow(v,2) * (
          - 1.0/3*GHPLs2[2*4+2]*HPLs1[0]
          - 1.0/3*GHPLs1[2]*zeta2
          + 19.0/18*GHPLs1[2]*HPLs1[0]
          + 2.0/3*GHPLs1[2]*HPLs2[0*2+0]
          + 1.0/3*GHPLs1[2]*HPLs2[1*2+0]
          - 1.0/3*GHPLs3[2*4*4+2*4+1]
          + 19.0/18*GHPLs2[2*4+1]
          + 1.0/3*GHPLs2[2*4+1]*HPLs1[0]
          + 1.0/3*GHPLs2[2*4+1]*HPLs1[1]
          - 1.0/3*GHPLs1[1]*zeta2
          - 19.0/18*GHPLs1[1]*HPLs1[0]
          - 2.0/3*GHPLs1[1]*HPLs2[0*2+0]
          - 2.0/3*GHPLs1[1]*HPLs2[1*2+0]
          - 19.0/18*GHPLs1[1]*HPLs1[1]
          - 1.0/3*GHPLs1[1]*HPLs2[0*2+1]
          - 1.0/3*GHPLs1[1]*HPLs2[1*2+1]
          - 1.0/3*GHPLs3[2*4*4+1*4+1]
          + 1.0/3*GHPLs2[1*4+1]*HPLs1[0]
          + 1.0/3*GHPLs2[1*4+1]*HPLs1[1]
          )

       + C_F*NF*pow(u,-1)*v * (
          + 2.0/3*zeta2
          + 1.0/3*GHPLs2[2*4+2]
          - 1.0/3*GHPLs2[2*4+2]*HPLs1[0]
          - 19.0/18*GHPLs1[2]
          - 1.0/3*GHPLs1[2]*zeta2
          + 19.0/18*GHPLs1[2]*HPLs1[0]
          + 2.0/3*GHPLs1[2]*HPLs2[0*2+0]
          + 1.0/3*GHPLs1[2]*HPLs2[1*2+0]
          - 1.0/3*GHPLs1[2]*HPLs1[1]
          - 1.0/3*GHPLs3[2*4*4+2*4+1]
          + 25.0/18*GHPLs2[2*4+1]
          + 1.0/3*GHPLs2[2*4+1]*HPLs1[0]
          + 1.0/3*GHPLs2[2*4+1]*HPLs1[1]
          - 1.0/3*GHPLs1[1]*zeta2
          - 25.0/18*GHPLs1[1]*HPLs1[0]
          - 2.0/3*GHPLs1[1]*HPLs2[0*2+0]
          - 2.0/3*GHPLs1[1]*HPLs2[1*2+0]
          - 25.0/18*GHPLs1[1]*HPLs1[1]
          - 1.0/3*GHPLs1[1]*HPLs2[0*2+1]
          - 1.0/3*GHPLs1[1]*HPLs2[1*2+1]
          - 1.0/3*GHPLs3[2*4*4+1*4+1]
          + 1.0/3*GHPLs2[1*4+1]*HPLs1[0]
          + 1.0/3*GHPLs2[1*4+1]*HPLs1[1]
          + 1.0/3*HPLs2[1*2+0]
          + 19.0/18*HPLs1[1]
          + 1.0/3*HPLs2[0*2+1]
          + 1.0/3*HPLs2[1*2+1]
          )

       + C_F*NF*pow(u,-1)*pow(v,2) * (
          - 1.0/3*zeta2
          - 1.0/3*GHPLs2[2*4+2]
          + 19.0/18*GHPLs1[2]
          + 1.0/3*GHPLs1[2]*HPLs1[0]
          + 1.0/3*GHPLs1[2]*HPLs1[1]
          - 1.0/3*GHPLs2[2*4+1]
          + 1.0/3*GHPLs1[1]*HPLs1[0]
          + 1.0/3*GHPLs1[1]*HPLs1[1]
          - 19.0/18*HPLs1[0]
          - 2.0/3*HPLs2[0*2+0]
          - 2.0/3*HPLs2[1*2+0]
          - 19.0/18*HPLs1[1]
          - 1.0/3*HPLs2[0*2+1]
          - 1.0/3*HPLs2[1*2+1]
          )

       + C_F*NF*pow(1-v,-1) * (
          - 1.0/6*zeta2
          - 1.0/6*GHPLs1[2]*HPLs1[0]
          + 25.0/36*HPLs1[0]
          + 1.0/3*HPLs2[0*2+0]
          + 1.0/6*HPLs2[1*2+0]
          )

       + C_F*NF * (
          + 1.0/6*zeta2
          + 1.0/6*GHPLs1[2]*HPLs1[0]
          - 25.0/36*HPLs1[0]
          - 1.0/3*HPLs2[0*2+0]
          - 1.0/6*HPLs2[1*2+0]
          )

       + C_F*NF*v*pow(1-u,-1) * (
          - 19.0/36
          - 1.0/6*zeta2
          - 1.0/6*GHPLs2[2*4+2]
          + 31.0/36*GHPLs1[2]
          + 1.0/6*GHPLs1[2]*HPLs1[0]
          + 1.0/6*GHPLs1[2]*HPLs1[1]
          - 1.0/6*GHPLs2[2*4+1]
          + 1.0/6*GHPLs1[1]*HPLs1[0]
          + 1.0/6*GHPLs1[1]*HPLs1[1]
          - 31.0/36*HPLs1[0]
          - 1.0/3*HPLs2[0*2+0]
          - 1.0/3*HPLs2[1*2+0]
          - 31.0/36*HPLs1[1]
          - 1.0/6*HPLs2[0*2+1]
          - 1.0/6*HPLs2[1*2+1]
          )

       + C_F*NF*pow(v,2)*pow(1-u,-2) * (
          + 1.0/6*zeta2
          + 1.0/6*GHPLs2[2*4+2]
          - 25.0/36*GHPLs1[2]
          - 1.0/6*GHPLs1[2]*HPLs1[0]
          - 1.0/6*GHPLs1[2]*HPLs1[1]
          + 1.0/6*GHPLs2[2*4+1]
          - 1.0/6*GHPLs1[1]*HPLs1[0]
          - 1.0/6*GHPLs1[1]*HPLs1[1]
          + 25.0/36*HPLs1[0]
          + 1.0/3*HPLs2[0*2+0]
          + 1.0/3*HPLs2[1*2+0]
          + 25.0/36*HPLs1[1]
          + 1.0/6*HPLs2[0*2+1]
          + 1.0/6*HPLs2[1*2+1]
          )

       + C_F*NF*pow(v,2)*pow(1-u,-1) * (
          - 1.0/3*zeta2
          - 1.0/3*GHPLs2[2*4+2]
          + 19.0/18*GHPLs1[2]
          + 1.0/3*GHPLs1[2]*HPLs1[0]
          + 1.0/3*GHPLs1[2]*HPLs1[1]
          - 1.0/3*GHPLs2[2*4+1]
          + 1.0/3*GHPLs1[1]*HPLs1[0]
          + 1.0/3*GHPLs1[1]*HPLs1[1]
          - 19.0/18*HPLs1[0]
          - 2.0/3*HPLs2[0*2+0]
          - 2.0/3*HPLs2[1*2+0]
          - 19.0/18*HPLs1[1]
          - 1.0/3*HPLs2[0*2+1]
          - 1.0/3*HPLs2[1*2+1]
          )

       + C_F*NF*u*pow(1-v,-2) * (
          - 1.0/6*zeta2
          - 1.0/6*GHPLs1[2]*HPLs1[0]
          + 13.0/36*HPLs1[0]
          + 1.0/3*HPLs2[0*2+0]
          + 1.0/6*HPLs2[1*2+0]
          )

       + C_F*NF*u*pow(1-v,-1) * (
          + 19.0/36
          + 1.0/6*zeta2
          - 1.0/6*GHPLs1[2]
          + 1.0/6*GHPLs1[2]*HPLs1[0]
          - 7.0/36*HPLs1[0]
          - 1.0/3*HPLs2[0*2+0]
          - 1.0/6*HPLs2[1*2+0]
          + 1.0/6*HPLs1[1]
          )

       + C_F*NF*double_complex(0,1)*M_PI*pow(u,-2)*v * (
          - 19.0/18*GHPLs1[1]
          - 1.0/3*GHPLs1[1]*HPLs1[0]
          + 1.0/3*GHPLs2[1*4+1]
          )

       + C_F*NF*double_complex(0,1)*M_PI*pow(u,-2)*pow(v,2) * (
          + 19.0/18*GHPLs1[1]
          + 1.0/3*GHPLs1[1]*HPLs1[0]
          - 1.0/3*GHPLs2[1*4+1]
          )

       + C_F*NF*double_complex(0,1)*M_PI*pow(u,-1)*v * (
          - 19.0/18
          + 25.0/18*GHPLs1[1]
          + 1.0/3*GHPLs1[1]*HPLs1[0]
          - 1.0/3*GHPLs2[1*4+1]
          - 1.0/3*HPLs1[0]
          )

       + C_F*NF*double_complex(0,1)*M_PI*pow(u,-1)*pow(v,2) * (
          + 19.0/18
          - 1.0/3*GHPLs1[1]
          + 1.0/3*HPLs1[0]
          )

       + C_F*NF*double_complex(0,1)*M_PI*v*pow(1-u,-1) * (
          + 25.0/36
          - 1.0/6*GHPLs1[1]
          + 1.0/6*HPLs1[0]
          )

       + C_F*NF*double_complex(0,1)*M_PI*pow(v,2)*pow(1-u,-2) * (
          - 25.0/36
          + 1.0/6*GHPLs1[1]
          - 1.0/6*HPLs1[0]
          )

       + C_F*NF*double_complex(0,1)*M_PI*pow(v,2)*pow(1-u,-1) * (
          + 19.0/18
          - 1.0/3*GHPLs1[1]
          + 1.0/3*HPLs1[0]
          );
}

void gamma_2_3(double u, double v, int n_f, double *GHPLs1, double *GHPLs2, double *GHPLs3, double *GHPLs4, double *HPLs1, double *HPLs2, double *HPLs3, double *HPLs4, double_complex &gamma) {
  gamma = 0;
}

void gamma_2_4(double u, double v, int n_f, double *GHPLs1, double *GHPLs2, double *GHPLs3, double *GHPLs4, double *HPLs1, double *HPLs2, double *HPLs3, double *HPLs4, double_complex &gamma) {
  //  const double zeta2 = M_PI*M_PI/6;
  //  const double zeta3 = 1.20205690315959429;
  //  const double zeta4 = pow(M_PI,4)/90;
  //  const double dN_c=3;
  //  const double C_F=(dN_c*dN_c-1)/(2*dN_c);
  double NF=(double)n_f;

  gamma =
    C_F*pow(u,-2)*v * (
          + 4*GHPLs3[3*4*4+2*4+2]*HPLs1[0]
          - 4*GHPLs4[0*4*4*4+3*4*4+2*4+2]
          - 4*GHPLs2[2*4+2]*zeta2
          + 4*GHPLs2[2*4+2]*HPLs2[0*2+0]
          - 4*GHPLs2[2*4+2]*HPLs2[0*2+1]
          - 4*GHPLs3[0*4*4+2*4+2]*HPLs1[0]
          + 2.0/3*GHPLs1[2]*zeta2
          - 4*GHPLs1[2]*zeta3
          + GHPLs1[2]*HPLs1[0]
          - 4*GHPLs1[2]*HPLs1[0]*zeta2
          - 2.0/3*GHPLs1[2]*HPLs2[0*2+0]
          + 4*GHPLs1[2]*HPLs3[0*2*2+0*2+0]
          - 2.0/3*GHPLs1[2]*HPLs2[1*2+0]
          - 4*GHPLs1[2]*HPLs3[0*2*2+1*2+0]
          - 4*GHPLs1[2]*HPLs3[0*2*2+0*2+1]
          - 4*GHPLs3[3*4*4+0*4+2]*HPLs1[0]
          + 4*GHPLs4[0*4*4*4+3*4*4+0*4+2]
          - 2.0/3*GHPLs2[0*4+2]*HPLs1[0]
          - 4*GHPLs2[0*4+2]*HPLs2[0*2+0]
          - 2.0/3*GHPLs3[2*4*4+1*4+2]
          + 2.0/3*GHPLs2[1*4+2]*HPLs1[0]
          + 2.0/3*GHPLs2[1*4+2]*HPLs1[1]
          + 4*GHPLs3[3*4*4+2*4+1]*HPLs1[0]
          - 4*GHPLs4[0*4*4*4+3*4*4+2*4+1]
          + GHPLs2[2*4+1]
          - 4*GHPLs2[2*4+1]*zeta2
          + 4*GHPLs2[2*4+1]*HPLs2[0*2+0]
          - 4*GHPLs2[2*4+1]*HPLs2[0*2+1]
          - 2.0/3*GHPLs3[0*4*4+2*4+1]
          - 4*GHPLs3[0*4*4+2*4+1]*HPLs1[0]
          + 8.0/3*GHPLs1[1]*zeta2
          - 4*GHPLs1[1]*zeta3
          - GHPLs1[1]*HPLs1[0]
          + 4*GHPLs1[1]*HPLs1[0]*zeta2
          + 2.0/3*GHPLs1[1]*HPLs2[0*2+0]
          - 4*GHPLs1[1]*HPLs3[0*2*2+0*2+0]
          + 2.0/3*GHPLs1[1]*HPLs2[1*2+0]
          + 4*GHPLs1[1]*HPLs3[0*2*2+1*2+0]
          - GHPLs1[1]*HPLs1[1]
          + 4*GHPLs1[1]*HPLs1[1]*zeta2
          - 4*GHPLs1[1]*HPLs3[0*2*2+0*2+1]
          + 4*GHPLs1[1]*HPLs3[0*2*2+1*2+1]
          - 2.0/3*GHPLs3[2*4*4+0*4+1]
          + 4*GHPLs3[3*4*4+0*4+1]*HPLs1[0]
          - 4*GHPLs4[0*4*4*4+3*4*4+0*4+1]
          + 8*GHPLs2[0*4+1]*zeta2
          + 2.0/3*GHPLs2[0*4+1]*HPLs1[0]
          + 4*GHPLs2[0*4+1]*HPLs2[0*2+0]
          + 2.0/3*GHPLs2[0*4+1]*HPLs1[1]
          + 4*GHPLs2[0*4+1]*HPLs2[0*2+1]
          + 2.0/3*GHPLs3[2*4*4+1*4+1]
          - 2.0/3*GHPLs2[1*4+1]*HPLs1[0]
          - 2.0/3*GHPLs2[1*4+1]*HPLs1[1]
          )

       + C_F*pow(u,-2)*pow(v,2) * (
          - 4*GHPLs3[3*4*4+2*4+2]*HPLs1[0]
          + 4*GHPLs4[0*4*4*4+3*4*4+2*4+2]
          + 4*GHPLs2[2*4+2]*zeta2
          - 4*GHPLs2[2*4+2]*HPLs2[0*2+0]
          + 4*GHPLs2[2*4+2]*HPLs2[0*2+1]
          + 4*GHPLs3[0*4*4+2*4+2]*HPLs1[0]
          - 2.0/3*GHPLs1[2]*zeta2
          + 4*GHPLs1[2]*zeta3
          - 2.0/3*GHPLs1[2]*HPLs1[0]
          + 4*GHPLs1[2]*HPLs1[0]*zeta2
          + 2.0/3*GHPLs1[2]*HPLs2[0*2+0]
          - 4*GHPLs1[2]*HPLs3[0*2*2+0*2+0]
          + 2.0/3*GHPLs1[2]*HPLs2[1*2+0]
          + 4*GHPLs1[2]*HPLs3[0*2*2+1*2+0]
          + 4*GHPLs1[2]*HPLs3[0*2*2+0*2+1]
          + 4*GHPLs3[3*4*4+0*4+2]*HPLs1[0]
          - 4*GHPLs4[0*4*4*4+3*4*4+0*4+2]
          + 2.0/3*GHPLs2[0*4+2]*HPLs1[0]
          + 4*GHPLs2[0*4+2]*HPLs2[0*2+0]
          + 2.0/3*GHPLs3[2*4*4+1*4+2]
          - 2.0/3*GHPLs2[1*4+2]*HPLs1[0]
          - 2.0/3*GHPLs2[1*4+2]*HPLs1[1]
          - 4*GHPLs3[3*4*4+2*4+1]*HPLs1[0]
          + 4*GHPLs4[0*4*4*4+3*4*4+2*4+1]
          - 2.0/3*GHPLs2[2*4+1]
          + 4*GHPLs2[2*4+1]*zeta2
          - 4*GHPLs2[2*4+1]*HPLs2[0*2+0]
          + 4*GHPLs2[2*4+1]*HPLs2[0*2+1]
          + 2.0/3*GHPLs3[0*4*4+2*4+1]
          + 4*GHPLs3[0*4*4+2*4+1]*HPLs1[0]
          - 8.0/3*GHPLs1[1]*zeta2
          + 4*GHPLs1[1]*zeta3
          + 2.0/3*GHPLs1[1]*HPLs1[0]
          - 4*GHPLs1[1]*HPLs1[0]*zeta2
          - 2.0/3*GHPLs1[1]*HPLs2[0*2+0]
          + 4*GHPLs1[1]*HPLs3[0*2*2+0*2+0]
          - 2.0/3*GHPLs1[1]*HPLs2[1*2+0]
          - 4*GHPLs1[1]*HPLs3[0*2*2+1*2+0]
          + 2.0/3*GHPLs1[1]*HPLs1[1]
          - 4*GHPLs1[1]*HPLs1[1]*zeta2
          + 4*GHPLs1[1]*HPLs3[0*2*2+0*2+1]
          - 4*GHPLs1[1]*HPLs3[0*2*2+1*2+1]
          + 2.0/3*GHPLs3[2*4*4+0*4+1]
          - 4*GHPLs3[3*4*4+0*4+1]*HPLs1[0]
          + 4*GHPLs4[0*4*4*4+3*4*4+0*4+1]
          - 8*GHPLs2[0*4+1]*zeta2
          - 2.0/3*GHPLs2[0*4+1]*HPLs1[0]
          - 4*GHPLs2[0*4+1]*HPLs2[0*2+0]
          - 2.0/3*GHPLs2[0*4+1]*HPLs1[1]
          - 4*GHPLs2[0*4+1]*HPLs2[0*2+1]
          - 2.0/3*GHPLs3[2*4*4+1*4+1]
          + 2.0/3*GHPLs2[1*4+1]*HPLs1[0]
          + 2.0/3*GHPLs2[1*4+1]*HPLs1[1]
          )

       + C_F*pow(u,-2)*pow(v,3) * (
          + 1.0/3*GHPLs1[2]*HPLs1[0]
          + 1.0/3*GHPLs2[2*4+1]
          - 1.0/3*GHPLs1[1]*HPLs1[0]
          - 1.0/3*GHPLs1[1]*HPLs1[1]
          )

       + C_F*pow(u,-2)*pow(v,4) * (
          - 2.0/3*GHPLs1[2]*zeta2
          - 2.0/3*GHPLs1[2]*HPLs1[0]
          - 2.0/3*GHPLs1[2]*HPLs2[0*2+0]
          + 2.0/3*GHPLs1[2]*HPLs2[1*2+0]
          + 2.0/3*GHPLs2[0*4+2]*HPLs1[0]
          + 2.0/3*GHPLs3[2*4*4+1*4+2]
          - 2.0/3*GHPLs2[1*4+2]*HPLs1[0]
          - 2.0/3*GHPLs2[1*4+2]*HPLs1[1]
          + 2.0/3*GHPLs2[2*4+3]*HPLs1[0]
          - 2.0/3*GHPLs3[0*4*4+2*4+3]
          - 2.0/3*GHPLs2[3*4+3]*HPLs1[0]
          + 2.0/3*GHPLs3[0*4*4+3*4+3]
          + 10.0/3*GHPLs1[3]*zeta2
          - 2.0/3*GHPLs1[3]*HPLs2[1*2+0]
          - 2.0/3*GHPLs1[3]*HPLs2[0*2+1]
          - 2.0/3*GHPLs3[2*4*4+0*4+3]
          + 2.0/3*GHPLs2[0*4+3]*HPLs1[1]
          - 2.0/3*GHPLs2[2*4+1]
          + 2.0/3*GHPLs1[1]*HPLs1[0]
          + 2.0/3*GHPLs1[1]*HPLs1[1]
          )

       + C_F*pow(u,-2)*pow(v,5) * (
          + 2.0/3*GHPLs1[2]*zeta2
          + 2.0/3*GHPLs1[2]*HPLs2[0*2+0]
          - 2.0/3*GHPLs1[2]*HPLs2[1*2+0]
          - 2.0/3*GHPLs2[0*4+2]*HPLs1[0]
          - 2.0/3*GHPLs3[2*4*4+1*4+2]
          + 2.0/3*GHPLs2[1*4+2]*HPLs1[0]
          + 2.0/3*GHPLs2[1*4+2]*HPLs1[1]
          - 2.0/3*GHPLs2[2*4+3]*HPLs1[0]
          + 2.0/3*GHPLs3[0*4*4+2*4+3]
          + 2.0/3*GHPLs2[3*4+3]*HPLs1[0]
          - 2.0/3*GHPLs3[0*4*4+3*4+3]
          - 10.0/3*GHPLs1[3]*zeta2
          + 2.0/3*GHPLs1[3]*HPLs2[1*2+0]
          + 2.0/3*GHPLs1[3]*HPLs2[0*2+1]
          + 2.0/3*GHPLs3[2*4*4+0*4+3]
          - 2.0/3*GHPLs2[0*4+3]*HPLs1[1]
          )

       + C_F*pow(u,-1) * (
          + 3.0/2*GHPLs1[2]*HPLs1[0]
          + 3.0/2*GHPLs2[2*4+1]
          - 3.0/2*GHPLs1[1]*HPLs1[0]
          - 3.0/2*GHPLs1[1]*HPLs1[1]
          )

       + C_F*pow(u,-1)*v * (
          - 14.0/3*zeta2
          - 8*zeta3
          - 4*GHPLs3[3*4*4+2*4+2]*HPLs1[0]
          + 4*GHPLs4[0*4*4*4+3*4*4+2*4+2]
          + 4*GHPLs2[2*4+2]*zeta2
          - 4*GHPLs2[2*4+2]*HPLs2[0*2+0]
          + 4*GHPLs2[2*4+2]*HPLs2[0*2+1]
          + 4*GHPLs3[0*4*4+2*4+2]*HPLs1[0]
          + 8*GHPLs2[3*4+2]*HPLs1[0]
          - 8*GHPLs3[0*4*4+3*4+2]
          + 5.0/3*GHPLs1[2]
          - 23.0/3*GHPLs1[2]*zeta2
          + 4*GHPLs1[2]*zeta3
          + 4*GHPLs1[2]*HPLs1[0]*zeta2
          + 26.0/3*GHPLs1[2]*HPLs2[0*2+0]
          - 4*GHPLs1[2]*HPLs3[0*2*2+0*2+0]
          - 1.0/3*GHPLs1[2]*HPLs2[1*2+0]
          + 4*GHPLs1[2]*HPLs3[0*2*2+1*2+0]
          - 8*GHPLs1[2]*HPLs2[0*2+1]
          + 4*GHPLs1[2]*HPLs3[0*2*2+0*2+1]
          + 4*GHPLs3[3*4*4+0*4+2]*HPLs1[0]
          - 4*GHPLs4[0*4*4*4+3*4*4+0*4+2]
          - 2.0/3*GHPLs2[0*4+2]
          - 22.0/3*GHPLs2[0*4+2]*HPLs1[0]
          + 4*GHPLs2[0*4+2]*HPLs2[0*2+0]
          - 1.0/3*GHPLs3[2*4*4+1*4+2]
          + 1.0/3*GHPLs2[1*4+2]*HPLs1[0]
          + 1.0/3*GHPLs2[1*4+2]*HPLs1[1]
          - 2.0/3*GHPLs2[2*4+0]
          + GHPLs2[2*4+0]*HPLs1[0]
          + 8*GHPLs1[0]*zeta2
          + 2.0/3*GHPLs1[0]*HPLs1[1]
          + 4*GHPLs1[0]*HPLs2[0*2+1]
          + GHPLs3[2*4*4+1*4+0]
          - GHPLs2[1*4+0]*HPLs1[0]
          - GHPLs2[1*4+0]*HPLs1[1]
          - 4*GHPLs3[3*4*4+2*4+1]*HPLs1[0]
          + 4*GHPLs4[0*4*4*4+3*4*4+2*4+1]
          + 4*GHPLs2[2*4+1]*zeta2
          - 4*GHPLs2[2*4+1]*HPLs2[0*2+0]
          + 4*GHPLs2[2*4+1]*HPLs2[0*2+1]
          + 2.0/3*GHPLs3[0*4*4+2*4+1]
          + 4*GHPLs3[0*4*4+2*4+1]*HPLs1[0]
          - 8.0/3*GHPLs1[1]*zeta2
          + 4*GHPLs1[1]*zeta3
          - 4*GHPLs1[1]*HPLs1[0]*zeta2
          - 2.0/3*GHPLs1[1]*HPLs2[0*2+0]
          + 4*GHPLs1[1]*HPLs3[0*2*2+0*2+0]
          - 2.0/3*GHPLs1[1]*HPLs2[1*2+0]
          - 4*GHPLs1[1]*HPLs3[0*2*2+1*2+0]
          - 4*GHPLs1[1]*HPLs1[1]*zeta2
          + 4*GHPLs1[1]*HPLs3[0*2*2+0*2+1]
          - 4*GHPLs1[1]*HPLs3[0*2*2+1*2+1]
          + 2.0/3*GHPLs3[2*4*4+0*4+1]
          - 4*GHPLs3[3*4*4+0*4+1]*HPLs1[0]
          + 4*GHPLs4[0*4*4*4+3*4*4+0*4+1]
          - 8*GHPLs2[0*4+1]*zeta2
          - 2.0/3*GHPLs2[0*4+1]*HPLs1[0]
          - 4*GHPLs2[0*4+1]*HPLs2[0*2+0]
          - 2.0/3*GHPLs2[0*4+1]*HPLs1[1]
          - 4*GHPLs2[0*4+1]*HPLs2[0*2+1]
          - 2.0/3*GHPLs3[2*4*4+1*4+1]
          + 2.0/3*GHPLs2[1*4+1]*HPLs1[0]
          + 2.0/3*GHPLs2[1*4+1]*HPLs1[1]
          - 5.0/3*HPLs1[1]
          + 4*HPLs1[1]*zeta2
          - 4*HPLs2[0*2+1]
          - 8*HPLs3[0*2*2+0*2+1]
          + 4*HPLs3[0*2*2+1*2+1]
          )

       + C_F*pow(u,-1)*pow(v,2) * (
          + 16.0/3*zeta2
          + 4*zeta3
          - 4*GHPLs2[3*4+2]*HPLs1[0]
          + 4*GHPLs3[0*4*4+3*4+2]
          - 4.0/3*GHPLs1[2]
          + 4*GHPLs1[2]*zeta2
          + 1.0/6*GHPLs1[2]*HPLs1[0]
          - 4*GHPLs1[2]*HPLs2[0*2+0]
          + 4*GHPLs1[2]*HPLs2[0*2+1]
          + 2.0/3*GHPLs2[0*4+2]
          + 4*GHPLs2[0*4+2]*HPLs1[0]
          + 4*GHPLs1[3]*HPLs1[0]
          - 4*GHPLs2[0*4+3]
          + 2.0/3*GHPLs2[2*4+0]
          - 4*GHPLs2[3*4+0]*HPLs1[0]
          + 4*GHPLs3[0*4*4+3*4+0]
          - 8*GHPLs1[0]*zeta2
          - 2.0/3*GHPLs1[0]*HPLs1[0]
          - 4*GHPLs1[0]*HPLs2[0*2+0]
          - 2.0/3*GHPLs1[0]*HPLs1[1]
          - 4*GHPLs1[0]*HPLs2[0*2+1]
          - 1.0/2*GHPLs2[2*4+1]
          + 1.0/2*GHPLs1[1]*HPLs1[0]
          + 1.0/2*GHPLs1[1]*HPLs1[1]
          + 5.0/3*HPLs1[0]
          - 4*HPLs1[0]*zeta2
          + 10.0/3*HPLs2[0*2+0]
          + 4*HPLs3[0*2*2+0*2+0]
          - 2.0/3*HPLs2[1*2+0]
          - 4*HPLs3[0*2*2+1*2+0]
          + 4.0/3*HPLs1[1]
          - 4*HPLs1[1]*zeta2
          + 4*HPLs2[0*2+1]
          + 4*HPLs3[0*2*2+0*2+1]
          - 4*HPLs3[0*2*2+1*2+1]
          )

       + C_F*pow(u,-1)*pow(v,3) * (
          - 10.0/3*zeta2
          - 1.0/3*GHPLs1[2]
          - 2*GHPLs1[2]*zeta2
          - 10.0/3*GHPLs1[2]*HPLs1[0]
          - 2*GHPLs1[2]*HPLs2[0*2+0]
          + 2*GHPLs1[2]*HPLs2[1*2+0]
          + 2.0/3*GHPLs2[0*4+2]
          + 2*GHPLs2[0*4+2]*HPLs1[0]
          + 2*GHPLs3[2*4*4+1*4+2]
          - 2*GHPLs2[1*4+2]*HPLs1[0]
          - 2*GHPLs2[1*4+2]*HPLs1[1]
          + 2*GHPLs2[2*4+3]*HPLs1[0]
          - 2*GHPLs3[0*4*4+2*4+3]
          - 2*GHPLs2[3*4+3]*HPLs1[0]
          + 2*GHPLs3[0*4*4+3*4+3]
          + 10*GHPLs1[3]*zeta2
          + 2.0/3*GHPLs1[3]*HPLs1[0]
          - 2*GHPLs1[3]*HPLs2[1*2+0]
          - 2*GHPLs1[3]*HPLs2[0*2+1]
          - 2*GHPLs3[2*4*4+0*4+3]
          - 2.0/3*GHPLs2[0*4+3]
          + 2*GHPLs2[0*4+3]*HPLs1[1]
          + 2.0/3*GHPLs2[2*4+0]
          - 2.0/3*GHPLs1[0]*HPLs1[1]
          - 8.0/3*GHPLs2[2*4+1]
          + 8.0/3*GHPLs1[1]*HPLs1[0]
          + 8.0/3*GHPLs1[1]*HPLs1[1]
          + 1.0/3*HPLs1[0]
          + 2.0/3*HPLs2[1*2+0]
          + 1.0/3*HPLs1[1]
          + 2.0/3*HPLs2[0*2+1]
          )

       + C_F*pow(u,-1)*pow(v,4) * (
          + 8.0/3*zeta2
          + 8.0/3*GHPLs1[2]*zeta2
          + 2.0/3*GHPLs1[2]*HPLs1[0]
          + 8.0/3*GHPLs1[2]*HPLs2[0*2+0]
          - 8.0/3*GHPLs1[2]*HPLs2[1*2+0]
          - 2.0/3*GHPLs2[0*4+2]
          - 8.0/3*GHPLs2[0*4+2]*HPLs1[0]
          - 8.0/3*GHPLs3[2*4*4+1*4+2]
          + 8.0/3*GHPLs2[1*4+2]*HPLs1[0]
          + 8.0/3*GHPLs2[1*4+2]*HPLs1[1]
          - 8.0/3*GHPLs2[2*4+3]*HPLs1[0]
          + 8.0/3*GHPLs3[0*4*4+2*4+3]
          + 8.0/3*GHPLs2[3*4+3]*HPLs1[0]
          - 8.0/3*GHPLs3[0*4*4+3*4+3]
          - 40.0/3*GHPLs1[3]*zeta2
          - 2.0/3*GHPLs1[3]*HPLs1[0]
          + 8.0/3*GHPLs1[3]*HPLs2[1*2+0]
          + 8.0/3*GHPLs1[3]*HPLs2[0*2+1]
          + 8.0/3*GHPLs3[2*4*4+0*4+3]
          + 2.0/3*GHPLs2[0*4+3]
          - 8.0/3*GHPLs2[0*4+3]*HPLs1[1]
          - 2.0/3*GHPLs2[2*4+0]
          + 2.0/3*GHPLs1[0]*HPLs1[0]
          + 2.0/3*GHPLs1[0]*HPLs1[1]
          + 2.0/3*GHPLs2[2*4+1]
          - 2.0/3*GHPLs1[1]*HPLs1[0]
          - 2.0/3*GHPLs1[1]*HPLs1[1]
          - 2.0/3*HPLs2[0*2+0]
          - 2.0/3*HPLs2[0*2+1]
          )

       + C_F*pow(1-u,-1) * (
          - 3.0/2*zeta2
          + 3.0/2*GHPLs1[3]*HPLs1[0]
          - 3.0/2*GHPLs2[0*4+3]
          - 3.0/2*GHPLs1[0]*HPLs1[0]
          + 3.0/2*HPLs2[0*2+0]
          - 3.0/2*HPLs2[0*2+1]
          )

       + C_F*pow(1-v,-1) * (
          - zeta2
          + 2*zeta3
          - 2*GHPLs2[3*4+2]*HPLs1[0]
          + 2*GHPLs3[0*4*4+3*4+2]
          - 2*GHPLs1[2]*HPLs2[0*2+0]
          + 2*GHPLs1[2]*HPLs2[1*2+0]
          + 2*GHPLs1[2]*HPLs2[0*2+1]
          + 2*GHPLs2[0*4+2]*HPLs1[0]
          + 2*GHPLs3[2*4*4+1*4+2]
          - 2*GHPLs2[1*4+2]*HPLs1[0]
          - 2*GHPLs2[1*4+2]*HPLs1[1]
          - GHPLs1[3]*HPLs1[0]
          + GHPLs2[0*4+3]
          - 2*GHPLs2[2*4+0]*HPLs1[0]
          + 2*GHPLs2[3*4+0]*HPLs1[0]
          - 2*GHPLs3[0*4*4+3*4+0]
          - 2*GHPLs1[0]*HPLs1[0]
          + 2*GHPLs1[0]*HPLs2[0*2+0]
          - 2*GHPLs3[2*4*4+1*4+0]
          + 2*GHPLs2[1*4+0]*HPLs1[0]
          + 2*GHPLs2[1*4+0]*HPLs1[1]
          - GHPLs2[2*4+1]
          + GHPLs1[1]*HPLs1[0]
          + GHPLs1[1]*HPLs1[1]
          + 2*HPLs1[0]
          + 2*HPLs1[0]*zeta2
          - 1.0/3*HPLs2[0*2+0]
          - 2*HPLs3[0*2*2+0*2+0]
          - HPLs2[1*2+0]
          + 2*HPLs3[0*2*2+1*2+0]
          - 2*HPLs2[0*2+1]
          + 2*HPLs3[0*2*2+0*2+1]
          )

       + C_F * (
          + 5.0/2*zeta2
          - 2*zeta3
          + 2*GHPLs2[3*4+2]*HPLs1[0]
          - 2*GHPLs3[0*4*4+3*4+2]
          + 3.0/2*GHPLs1[2]
          - 5.0/2*GHPLs1[2]*HPLs1[0]
          + 2*GHPLs1[2]*HPLs2[0*2+0]
          - 2*GHPLs1[2]*HPLs2[1*2+0]
          - 2*GHPLs1[2]*HPLs2[0*2+1]
          - 2*GHPLs2[0*4+2]*HPLs1[0]
          - 2*GHPLs3[2*4*4+1*4+2]
          + 2*GHPLs2[1*4+2]*HPLs1[0]
          + 2*GHPLs2[1*4+2]*HPLs1[1]
          - 1.0/2*GHPLs1[3]*HPLs1[0]
          + 1.0/2*GHPLs2[0*4+3]
          + 2*GHPLs2[2*4+0]*HPLs1[0]
          - 2*GHPLs2[3*4+0]*HPLs1[0]
          + 2*GHPLs3[0*4*4+3*4+0]
          + 7.0/2*GHPLs1[0]*HPLs1[0]
          - 2*GHPLs1[0]*HPLs2[0*2+0]
          + 2*GHPLs3[2*4*4+1*4+0]
          - 2*GHPLs2[1*4+0]*HPLs1[0]
          - 2*GHPLs2[1*4+0]*HPLs1[1]
          - 3.0/2*GHPLs2[2*4+1]
          + 3.0/2*GHPLs1[1]*HPLs1[0]
          + 3.0/2*GHPLs1[1]*HPLs1[1]
          - 2*HPLs1[0]
          - 2*HPLs1[0]*zeta2
          - 7.0/6*HPLs2[0*2+0]
          + 2*HPLs3[0*2*2+0*2+0]
          + HPLs2[1*2+0]
          - 2*HPLs3[0*2*2+1*2+0]
          - 3.0/2*HPLs1[1]
          + 7.0/2*HPLs2[0*2+1]
          - 2*HPLs3[0*2*2+0*2+1]
          )

       + C_F*v*pow(1-u,-2) * (
          + 3*zeta2
          - 3*zeta3
          + 3*GHPLs2[3*4+2]*HPLs1[0]
          - 3*GHPLs3[0*4*4+3*4+2]
          - 3*GHPLs1[2]*zeta2
          + 3*GHPLs1[2]*HPLs2[0*2+0]
          - 3*GHPLs1[2]*HPLs2[0*2+1]
          - 3*GHPLs2[0*4+2]*HPLs1[0]
          - 3*GHPLs1[3]*HPLs1[0]
          + 3*GHPLs2[0*4+3]
          + 3*GHPLs2[3*4+0]*HPLs1[0]
          - 3*GHPLs3[0*4*4+3*4+0]
          + 6*GHPLs1[0]*zeta2
          + 3*GHPLs1[0]*HPLs1[0]
          + 3*GHPLs1[0]*HPLs2[0*2+0]
          + 3*GHPLs1[0]*HPLs2[0*2+1]
          + 3*HPLs1[0]*zeta2
          - 3*HPLs2[0*2+0]
          - 3*HPLs3[0*2*2+0*2+0]
          + 3*HPLs3[0*2*2+1*2+0]
          + 3*HPLs1[1]*zeta2
          + 3*HPLs2[0*2+1]
          - 3*HPLs3[0*2*2+0*2+1]
          + 3*HPLs3[0*2*2+1*2+1]
          )

       + C_F*v*pow(1-u,-1) * (
          + zeta2
          + 5*zeta3
          - 5*GHPLs2[3*4+2]*HPLs1[0]
          + 5*GHPLs3[0*4*4+3*4+2]
          + 5*GHPLs1[2]*zeta2
          - 5*GHPLs1[2]*HPLs2[0*2+0]
          + 5*GHPLs1[2]*HPLs2[0*2+1]
          + 5*GHPLs2[0*4+2]*HPLs1[0]
          + 8*GHPLs1[3]*HPLs1[0]
          - 8*GHPLs2[0*4+3]
          - 5*GHPLs2[3*4+0]*HPLs1[0]
          + 5*GHPLs3[0*4*4+3*4+0]
          + 3.0/2*GHPLs1[0]
          - 10*GHPLs1[0]*zeta2
          - 5*GHPLs1[0]*HPLs1[0]
          - 5*GHPLs1[0]*HPLs2[0*2+0]
          - 5*GHPLs1[0]*HPLs2[0*2+1]
          - 5*HPLs1[0]*zeta2
          + 8*HPLs2[0*2+0]
          + 5*HPLs3[0*2*2+0*2+0]
          - 5*HPLs3[0*2*2+1*2+0]
          - 5*HPLs1[1]*zeta2
          - 2*HPLs2[0*2+1]
          + 5*HPLs3[0*2*2+0*2+1]
          - 5*HPLs3[0*2*2+1*2+1]
          )

       + C_F*v * (
          - 5.0/3*zeta2
          + GHPLs1[2]
          + 1.0/3*GHPLs2[0*4+2]
          + 1.0/3*GHPLs2[2*4+0]
          + 1.0/6*GHPLs1[0]
          - 1.0/3*GHPLs1[0]*HPLs1[1]
          - 1.0/2*HPLs1[0]
          - 2.0/3*HPLs2[0*2+0]
          - HPLs1[1]
          )

       + C_F*pow(v,2)*pow(1-u,-3) * (
          + 3*zeta3
          - 3*GHPLs2[3*4+2]*HPLs1[0]
          + 3*GHPLs3[0*4*4+3*4+2]
          + 3*GHPLs1[2]*zeta2
          - 3*GHPLs1[2]*HPLs2[0*2+0]
          + 3*GHPLs1[2]*HPLs2[0*2+1]
          + 3*GHPLs2[0*4+2]*HPLs1[0]
          - 3*GHPLs2[3*4+0]*HPLs1[0]
          + 3*GHPLs3[0*4*4+3*4+0]
          - 6*GHPLs1[0]*zeta2
          - 3*GHPLs1[0]*HPLs2[0*2+0]
          - 3*GHPLs1[0]*HPLs2[0*2+1]
          - 3*HPLs1[0]*zeta2
          + 3*HPLs3[0*2*2+0*2+0]
          - 3*HPLs3[0*2*2+1*2+0]
          - 3*HPLs1[1]*zeta2
          + 3*HPLs3[0*2*2+0*2+1]
          - 3*HPLs3[0*2*2+1*2+1]
          )

       + C_F*pow(v,2)*pow(1-u,-2) * (
          - 6*zeta2
          - 5*zeta3
          + 5*GHPLs2[3*4+2]*HPLs1[0]
          - 5*GHPLs3[0*4*4+3*4+2]
          - 5*GHPLs1[2]*zeta2
          + 5*GHPLs1[2]*HPLs2[0*2+0]
          - 5*GHPLs1[2]*HPLs2[0*2+1]
          - 5*GHPLs2[0*4+2]*HPLs1[0]
          - 3*GHPLs1[3]*HPLs1[0]
          + 3*GHPLs2[0*4+3]
          + 5*GHPLs2[3*4+0]*HPLs1[0]
          - 5*GHPLs3[0*4*4+3*4+0]
          + 10*GHPLs1[0]*zeta2
          + 5*GHPLs1[0]*HPLs2[0*2+0]
          + 5*GHPLs1[0]*HPLs2[0*2+1]
          + 5*HPLs1[0]*zeta2
          - 3*HPLs2[0*2+0]
          - 5*HPLs3[0*2*2+0*2+0]
          + 5*HPLs3[0*2*2+1*2+0]
          + 5*HPLs1[1]*zeta2
          - 3*HPLs2[0*2+1]
          - 5*HPLs3[0*2*2+0*2+1]
          + 5*HPLs3[0*2*2+1*2+1]
          )

       + C_F*pow(v,2)*pow(1-u,-1) * (
          + 6*zeta2
          + 4*zeta3
          - 4*GHPLs2[3*4+2]*HPLs1[0]
          + 4*GHPLs3[0*4*4+3*4+2]
          - 3.0/2*GHPLs1[2]
          + 4*GHPLs1[2]*zeta2
          - 4*GHPLs1[2]*HPLs2[0*2+0]
          + 4*GHPLs1[2]*HPLs2[0*2+1]
          + 1.0/2*GHPLs2[0*4+2]
          + 4*GHPLs2[0*4+2]*HPLs1[0]
          + 7.0/2*GHPLs1[3]*HPLs1[0]
          - 7.0/2*GHPLs2[0*4+3]
          + 1.0/2*GHPLs2[2*4+0]
          - 4*GHPLs2[3*4+0]*HPLs1[0]
          + 4*GHPLs3[0*4*4+3*4+0]
          - 8*GHPLs1[0]*zeta2
          - 1.0/2*GHPLs1[0]*HPLs1[0]
          - 4*GHPLs1[0]*HPLs2[0*2+0]
          - 1.0/2*GHPLs1[0]*HPLs1[1]
          - 4*GHPLs1[0]*HPLs2[0*2+1]
          - GHPLs2[2*4+1]
          + GHPLs1[1]*HPLs1[0]
          + GHPLs1[1]*HPLs1[1]
          + 3.0/2*HPLs1[0]
          - 4*HPLs1[0]*zeta2
          + 5.0/2*HPLs2[0*2+0]
          + 4*HPLs3[0*2*2+0*2+0]
          - HPLs2[1*2+0]
          - 4*HPLs3[0*2*2+1*2+0]
          + 3.0/2*HPLs1[1]
          - 4*HPLs1[1]*zeta2
          + 7.0/2*HPLs2[0*2+1]
          + 4*HPLs3[0*2*2+0*2+1]
          - 4*HPLs3[0*2*2+1*2+1]
          )

       + C_F*pow(v,2) * (
          - 8*zeta2
          - GHPLs1[2]
          - 2*GHPLs1[2]*zeta2
          - 37.0/6*GHPLs1[2]*HPLs1[0]
          - 2*GHPLs1[2]*HPLs2[0*2+0]
          + 2*GHPLs1[2]*HPLs2[1*2+0]
          + 3.0/2*GHPLs2[0*4+2]
          + 2*GHPLs2[0*4+2]*HPLs1[0]
          + 2*GHPLs3[2*4*4+1*4+2]
          - 2*GHPLs2[1*4+2]*HPLs1[0]
          - 2*GHPLs2[1*4+2]*HPLs1[1]
          + 2*GHPLs2[2*4+3]*HPLs1[0]
          - 2*GHPLs3[0*4*4+2*4+3]
          - 2*GHPLs2[3*4+3]*HPLs1[0]
          + 2*GHPLs3[0*4*4+3*4+3]
          + 10*GHPLs1[3]*zeta2
          + 13.0/6*GHPLs1[3]*HPLs1[0]
          - 2*GHPLs1[3]*HPLs2[1*2+0]
          - 2*GHPLs1[3]*HPLs2[0*2+1]
          - 2*GHPLs3[2*4*4+0*4+3]
          - 13.0/6*GHPLs2[0*4+3]
          + 2*GHPLs2[0*4+3]*HPLs1[1]
          + 3.0/2*GHPLs2[2*4+0]
          + 1.0/3*GHPLs1[0]
          + 1.0/2*GHPLs1[0]*HPLs1[0]
          - 3.0/2*GHPLs1[0]*HPLs1[1]
          - 7.0/2*GHPLs2[2*4+1]
          + 7.0/2*GHPLs1[1]*HPLs1[0]
          + 7.0/2*GHPLs1[1]*HPLs1[1]
          + 2.0/3*HPLs1[0]
          + 5.0/6*HPLs2[0*2+0]
          + 8.0/3*HPLs2[1*2+0]
          + HPLs1[1]
          + 13.0/6*HPLs2[0*2+1]
          )

       + C_F*pow(v,3) * (
          + 28.0/3*zeta2
          + 4*GHPLs1[2]*zeta2
          + 7.0/3*GHPLs1[2]*HPLs1[0]
          + 4*GHPLs1[2]*HPLs2[0*2+0]
          - 4*GHPLs1[2]*HPLs2[1*2+0]
          - 7.0/3*GHPLs2[0*4+2]
          - 4*GHPLs2[0*4+2]*HPLs1[0]
          - 4*GHPLs3[2*4*4+1*4+2]
          + 4*GHPLs2[1*4+2]*HPLs1[0]
          + 4*GHPLs2[1*4+2]*HPLs1[1]
          - 4*GHPLs2[2*4+3]*HPLs1[0]
          + 4*GHPLs3[0*4*4+2*4+3]
          + 4*GHPLs2[3*4+3]*HPLs1[0]
          - 4*GHPLs3[0*4*4+3*4+3]
          - 20*GHPLs1[3]*zeta2
          - 7.0/3*GHPLs1[3]*HPLs1[0]
          + 4*GHPLs1[3]*HPLs2[1*2+0]
          + 4*GHPLs1[3]*HPLs2[0*2+1]
          + 4*GHPLs3[2*4*4+0*4+3]
          + 7.0/3*GHPLs2[0*4+3]
          - 4*GHPLs2[0*4+3]*HPLs1[1]
          - 7.0/3*GHPLs2[2*4+0]
          + 7.0/3*GHPLs1[0]*HPLs1[0]
          + 7.0/3*GHPLs1[0]*HPLs1[1]
          + 7.0/3*GHPLs2[2*4+1]
          - 7.0/3*GHPLs1[1]*HPLs1[0]
          - 7.0/3*GHPLs1[1]*HPLs1[1]
          - 7.0/3*HPLs2[0*2+0]
          - 7.0/3*HPLs2[0*2+1]
          )

       + C_F*u*pow(1-v,-2) * (
          - 2*zeta2
          + zeta3
          - GHPLs2[3*4+2]*HPLs1[0]
          + GHPLs3[0*4*4+3*4+2]
          + 2*GHPLs1[2]*zeta2
          - 5*GHPLs1[2]*HPLs1[0]
          + 1.0/3*GHPLs1[2]*HPLs2[0*2+0]
          - GHPLs1[2]*HPLs2[1*2+0]
          + GHPLs1[2]*HPLs2[0*2+1]
          + GHPLs2[0*4+2]*HPLs1[0]
          - GHPLs3[2*4*4+1*4+2]
          + GHPLs2[1*4+2]*HPLs1[0]
          + GHPLs2[1*4+2]*HPLs1[1]
          + GHPLs2[2*4+0]*HPLs1[0]
          + GHPLs2[3*4+0]*HPLs1[0]
          - GHPLs3[0*4*4+3*4+0]
          + 3*GHPLs1[0]*HPLs1[0]
          - 1.0/3*GHPLs1[0]*HPLs2[0*2+0]
          + GHPLs3[2*4*4+1*4+0]
          - GHPLs2[1*4+0]*HPLs1[0]
          - GHPLs2[1*4+0]*HPLs1[1]
          - 4*HPLs1[0]
          + HPLs1[0]*zeta2
          + 2.0/3*HPLs2[0*2+0]
          - HPLs3[0*2*2+0*2+0]
          - 4.0/3*HPLs3[1*2*2+0*2+0]
          + 5*HPLs2[1*2+0]
          - 1.0/3*HPLs3[0*2*2+1*2+0]
          + 3*HPLs2[0*2+1]
          - 1.0/3*HPLs3[0*2*2+0*2+1]
          )

       + C_F*u*pow(1-v,-1) * (
          + 4*zeta2
          - zeta3
          + GHPLs2[3*4+2]*HPLs1[0]
          - GHPLs3[0*4*4+3*4+2]
          - 6*GHPLs1[2]
          - 2*GHPLs1[2]*zeta2
          + 19.0/3*GHPLs1[2]*HPLs1[0]
          - 1.0/3*GHPLs1[2]*HPLs2[0*2+0]
          + GHPLs1[2]*HPLs2[1*2+0]
          - GHPLs1[2]*HPLs2[0*2+1]
          - GHPLs2[0*4+2]*HPLs1[0]
          + GHPLs3[2*4*4+1*4+2]
          - GHPLs2[1*4+2]*HPLs1[0]
          - GHPLs2[1*4+2]*HPLs1[1]
          - GHPLs1[3]*HPLs1[0]
          + GHPLs2[0*4+3]
          - GHPLs2[2*4+0]*HPLs1[0]
          - GHPLs2[3*4+0]*HPLs1[0]
          + GHPLs3[0*4*4+3*4+0]
          + 2*GHPLs1[0]
          - 7.0/3*GHPLs1[0]*HPLs1[0]
          + 1.0/3*GHPLs1[0]*HPLs2[0*2+0]
          - GHPLs3[2*4*4+1*4+0]
          + GHPLs2[1*4+0]*HPLs1[0]
          + GHPLs2[1*4+0]*HPLs1[1]
          + GHPLs2[2*4+1]
          - GHPLs1[1]*HPLs1[0]
          - GHPLs1[1]*HPLs1[1]
          + 14.0/3*HPLs1[0]
          - HPLs1[0]*zeta2
          - 2.0/3*HPLs2[0*2+0]
          + HPLs3[0*2*2+0*2+0]
          + 4.0/3*HPLs3[1*2*2+0*2+0]
          - 16.0/3*HPLs2[1*2+0]
          + 1.0/3*HPLs3[0*2*2+1*2+0]
          + 6*HPLs1[1]
          - 4.0/3*HPLs2[0*2+1]
          + 1.0/3*HPLs3[0*2*2+0*2+1]
          )

       + C_F*u * (
          + zeta2
          + 3.0/2*GHPLs1[2]
          + 1.0/6*GHPLs1[2]*HPLs1[0]
          - 1.0/2*GHPLs2[0*4+2]
          - 1.0/2*GHPLs1[3]*HPLs1[0]
          + 1.0/2*GHPLs2[0*4+3]
          - 1.0/2*GHPLs2[2*4+0]
          - 1.0/2*GHPLs1[0]
          + 5.0/6*GHPLs1[0]*HPLs1[0]
          + 1.0/2*GHPLs1[0]*HPLs1[1]
          + 1.0/2*GHPLs2[2*4+1]
          - 1.0/2*GHPLs1[1]*HPLs1[0]
          - 1.0/2*GHPLs1[1]*HPLs1[1]
          - 2.0/3*HPLs1[0]
          - 3.0/2*HPLs2[0*2+0]
          + 1.0/3*HPLs2[1*2+0]
          - 3.0/2*HPLs1[1]
          - 7.0/6*HPLs2[0*2+1]
          )

       + C_F*u*v * (
          - 32.0/3*zeta2
          - GHPLs1[2]
          - 2.0/3*GHPLs1[2]*zeta2
          - 19.0/3*GHPLs1[2]*HPLs1[0]
          - 2.0/3*GHPLs1[2]*HPLs2[0*2+0]
          + 2.0/3*GHPLs1[2]*HPLs2[1*2+0]
          + 7.0/3*GHPLs2[0*4+2]
          + 2.0/3*GHPLs2[0*4+2]*HPLs1[0]
          + 2.0/3*GHPLs3[2*4*4+1*4+2]
          - 2.0/3*GHPLs2[1*4+2]*HPLs1[0]
          - 2.0/3*GHPLs2[1*4+2]*HPLs1[1]
          + 2.0/3*GHPLs2[2*4+3]*HPLs1[0]
          - 2.0/3*GHPLs3[0*4*4+2*4+3]
          - 2.0/3*GHPLs2[3*4+3]*HPLs1[0]
          + 2.0/3*GHPLs3[0*4*4+3*4+3]
          + 10.0/3*GHPLs1[3]*zeta2
          + 3*GHPLs1[3]*HPLs1[0]
          - 2.0/3*GHPLs1[3]*HPLs2[1*2+0]
          - 2.0/3*GHPLs1[3]*HPLs2[0*2+1]
          - 2.0/3*GHPLs3[2*4*4+0*4+3]
          - 3*GHPLs2[0*4+3]
          + 2.0/3*GHPLs2[0*4+3]*HPLs1[1]
          + 7.0/3*GHPLs2[2*4+0]
          - 2.0/3*GHPLs2[2*4+0]*HPLs1[0]
          + 2.0/3*GHPLs2[3*4+0]*HPLs1[0]
          - 2.0/3*GHPLs3[0*4*4+3*4+0]
          + 2.0/3*GHPLs1[0]
          + 1.0/3*GHPLs1[0]*HPLs1[0]
          + 4.0/3*GHPLs1[0]*HPLs2[0*2+0]
          + 2.0/3*GHPLs1[0]*HPLs2[1*2+0]
          - 7.0/3*GHPLs1[0]*HPLs1[1]
          + 2.0/3*GHPLs1[0]*HPLs2[0*2+1]
          - 3*GHPLs2[2*4+1]
          + 2.0/3*GHPLs3[0*4*4+2*4+1]
          - 8.0/3*GHPLs1[1]*zeta2
          + 3*GHPLs1[1]*HPLs1[0]
          - 2.0/3*GHPLs1[1]*HPLs2[0*2+0]
          - 2.0/3*GHPLs1[1]*HPLs2[1*2+0]
          + 3*GHPLs1[1]*HPLs1[1]
          + 2.0/3*GHPLs3[2*4*4+0*4+1]
          - 2.0/3*GHPLs2[0*4+1]*HPLs1[0]
          - 2.0/3*GHPLs2[0*4+1]*HPLs1[1]
          - 2.0/3*GHPLs3[2*4*4+1*4+1]
          + 2.0/3*GHPLs2[1*4+1]*HPLs1[0]
          + 2.0/3*GHPLs2[1*4+1]*HPLs1[1]
          + 1.0/3*HPLs1[0]
          + 10.0/3*HPLs1[0]*zeta2
          + 7.0/3*HPLs2[0*2+0]
          + 2.0/3*HPLs3[1*2*2+0*2+0]
          + 10.0/3*HPLs2[1*2+0]
          + 2.0/3*HPLs3[0*2*2+1*2+0]
          + HPLs1[1]
          + 2.0/3*HPLs1[1]*zeta2
          + 13.0/3*HPLs2[0*2+1]
          + 2.0/3*HPLs3[0*2*2+0*2+1]
          + 2.0/3*HPLs3[1*2*2+0*2+1]
          + 4.0/3*HPLs3[0*2*2+1*2+1]
          )

       + C_F*u*pow(v,2) * (
          + 44.0/3*zeta2
          + 8.0/3*GHPLs1[2]*zeta2
          + 11.0/3*GHPLs1[2]*HPLs1[0]
          + 8.0/3*GHPLs1[2]*HPLs2[0*2+0]
          - 8.0/3*GHPLs1[2]*HPLs2[1*2+0]
          - 11.0/3*GHPLs2[0*4+2]
          - 8.0/3*GHPLs2[0*4+2]*HPLs1[0]
          - 8.0/3*GHPLs3[2*4*4+1*4+2]
          + 8.0/3*GHPLs2[1*4+2]*HPLs1[0]
          + 8.0/3*GHPLs2[1*4+2]*HPLs1[1]
          - 8.0/3*GHPLs2[2*4+3]*HPLs1[0]
          + 8.0/3*GHPLs3[0*4*4+2*4+3]
          + 8.0/3*GHPLs2[3*4+3]*HPLs1[0]
          - 8.0/3*GHPLs3[0*4*4+3*4+3]
          - 40.0/3*GHPLs1[3]*zeta2
          - 11.0/3*GHPLs1[3]*HPLs1[0]
          + 8.0/3*GHPLs1[3]*HPLs2[1*2+0]
          + 8.0/3*GHPLs1[3]*HPLs2[0*2+1]
          + 8.0/3*GHPLs3[2*4*4+0*4+3]
          + 11.0/3*GHPLs2[0*4+3]
          - 8.0/3*GHPLs2[0*4+3]*HPLs1[1]
          - 11.0/3*GHPLs2[2*4+0]
          + 2.0/3*GHPLs2[2*4+0]*HPLs1[0]
          - 2.0/3*GHPLs2[3*4+0]*HPLs1[0]
          + 2.0/3*GHPLs3[0*4*4+3*4+0]
          + 11.0/3*GHPLs1[0]*HPLs1[0]
          - 4.0/3*GHPLs1[0]*HPLs2[0*2+0]
          - 2.0/3*GHPLs1[0]*HPLs2[1*2+0]
          + 11.0/3*GHPLs1[0]*HPLs1[1]
          - 2.0/3*GHPLs1[0]*HPLs2[0*2+1]
          + 11.0/3*GHPLs2[2*4+1]
          - 2.0/3*GHPLs3[0*4*4+2*4+1]
          + 8.0/3*GHPLs1[1]*zeta2
          - 11.0/3*GHPLs1[1]*HPLs1[0]
          + 2.0/3*GHPLs1[1]*HPLs2[0*2+0]
          + 2.0/3*GHPLs1[1]*HPLs2[1*2+0]
          - 11.0/3*GHPLs1[1]*HPLs1[1]
          - 2.0/3*GHPLs3[2*4*4+0*4+1]
          + 2.0/3*GHPLs2[0*4+1]*HPLs1[0]
          + 2.0/3*GHPLs2[0*4+1]*HPLs1[1]
          + 2.0/3*GHPLs3[2*4*4+1*4+1]
          - 2.0/3*GHPLs2[1*4+1]*HPLs1[0]
          - 2.0/3*GHPLs2[1*4+1]*HPLs1[1]
          - 10.0/3*HPLs1[0]*zeta2
          - 11.0/3*HPLs2[0*2+0]
          - 2.0/3*HPLs3[1*2*2+0*2+0]
          - 2.0/3*HPLs3[0*2*2+1*2+0]
          - 2.0/3*HPLs1[1]*zeta2
          - 11.0/3*HPLs2[0*2+1]
          - 2.0/3*HPLs3[0*2*2+0*2+1]
          - 2.0/3*HPLs3[1*2*2+0*2+1]
          - 4.0/3*HPLs3[0*2*2+1*2+1]
          )

       + C_F*pow(u,2)*pow(1-v,-3) * (
          + 4*GHPLs1[2]*HPLs1[0]
          - 4.0/3*GHPLs1[2]*HPLs2[0*2+0]
          - 4*GHPLs1[0]*HPLs1[0]
          + 4.0/3*GHPLs1[0]*HPLs2[0*2+0]
          + 4.0/3*HPLs3[1*2*2+0*2+0]
          - 4*HPLs2[1*2+0]
          + 4.0/3*HPLs3[0*2*2+1*2+0]
          - 4*HPLs2[0*2+1]
          + 4.0/3*HPLs3[0*2*2+0*2+1]
          )

       + C_F*pow(u,2)*pow(1-v,-2) * (
          + 4*GHPLs1[2]
          - 10.0/3*GHPLs1[2]*HPLs1[0]
          + 4.0/3*GHPLs1[2]*HPLs2[0*2+0]
          - 4*GHPLs1[0]
          + 10.0/3*GHPLs1[0]*HPLs1[0]
          - 4.0/3*GHPLs1[0]*HPLs2[0*2+0]
          - 4.0/3*HPLs3[1*2*2+0*2+0]
          + 10.0/3*HPLs2[1*2+0]
          - 4.0/3*HPLs3[0*2*2+1*2+0]
          - 4*HPLs1[1]
          + 10.0/3*HPLs2[0*2+1]
          - 4.0/3*HPLs3[0*2*2+0*2+1]
          )

       + C_F*pow(u,2)*pow(1-v,-1) * (
          - 2.0/3*GHPLs1[2]
          + 2.0/3*GHPLs1[2]*HPLs1[0]
          + 2.0/3*GHPLs1[0]
          - 2.0/3*GHPLs1[0]*HPLs1[0]
          - 2.0/3*HPLs2[1*2+0]
          + 2.0/3*HPLs1[1]
          - 2.0/3*HPLs2[0*2+1]
          )

       + C_F*pow(u,2) * (
          - 6*zeta2
          - 1.0/3*GHPLs1[2]
          - 17.0/6*GHPLs1[2]*HPLs1[0]
          + 3.0/2*GHPLs2[0*4+2]
          + 3.0/2*GHPLs1[3]*HPLs1[0]
          - 3.0/2*GHPLs2[0*4+3]
          + 3.0/2*GHPLs2[2*4+0]
          + 1.0/3*GHPLs1[0]
          - 1.0/6*GHPLs1[0]*HPLs1[0]
          - 3.0/2*GHPLs1[0]*HPLs1[1]
          - 3.0/2*GHPLs2[2*4+1]
          + 3.0/2*GHPLs1[1]*HPLs1[0]
          + 3.0/2*GHPLs1[1]*HPLs1[1]
          + 3.0/2*HPLs2[0*2+0]
          + 4.0/3*HPLs2[1*2+0]
          + 1.0/3*HPLs1[1]
          + 17.0/6*HPLs2[0*2+1]
          )

       + C_F*pow(u,2)*v * (
          + 12*zeta2
          + 2.0/3*GHPLs1[2]*zeta2
          + 3*GHPLs1[2]*HPLs1[0]
          + 2.0/3*GHPLs1[2]*HPLs2[0*2+0]
          - 2.0/3*GHPLs1[2]*HPLs2[1*2+0]
          - 3*GHPLs2[0*4+2]
          - 2.0/3*GHPLs2[0*4+2]*HPLs1[0]
          - 2.0/3*GHPLs3[2*4*4+1*4+2]
          + 2.0/3*GHPLs2[1*4+2]*HPLs1[0]
          + 2.0/3*GHPLs2[1*4+2]*HPLs1[1]
          - 2.0/3*GHPLs2[2*4+3]*HPLs1[0]
          + 2.0/3*GHPLs3[0*4*4+2*4+3]
          + 2.0/3*GHPLs2[3*4+3]*HPLs1[0]
          - 2.0/3*GHPLs3[0*4*4+3*4+3]
          - 10.0/3*GHPLs1[3]*zeta2
          - 3*GHPLs1[3]*HPLs1[0]
          + 2.0/3*GHPLs1[3]*HPLs2[1*2+0]
          + 2.0/3*GHPLs1[3]*HPLs2[0*2+1]
          + 2.0/3*GHPLs3[2*4*4+0*4+3]
          + 3*GHPLs2[0*4+3]
          - 2.0/3*GHPLs2[0*4+3]*HPLs1[1]
          - 3*GHPLs2[2*4+0]
          + 2.0/3*GHPLs2[2*4+0]*HPLs1[0]
          - 2.0/3*GHPLs2[3*4+0]*HPLs1[0]
          + 2.0/3*GHPLs3[0*4*4+3*4+0]
          + 3*GHPLs1[0]*HPLs1[0]
          - 4.0/3*GHPLs1[0]*HPLs2[0*2+0]
          - 2.0/3*GHPLs1[0]*HPLs2[1*2+0]
          + 3*GHPLs1[0]*HPLs1[1]
          - 2.0/3*GHPLs1[0]*HPLs2[0*2+1]
          + 3*GHPLs2[2*4+1]
          - 2.0/3*GHPLs3[0*4*4+2*4+1]
          + 8.0/3*GHPLs1[1]*zeta2
          - 3*GHPLs1[1]*HPLs1[0]
          + 2.0/3*GHPLs1[1]*HPLs2[0*2+0]
          + 2.0/3*GHPLs1[1]*HPLs2[1*2+0]
          - 3*GHPLs1[1]*HPLs1[1]
          - 2.0/3*GHPLs3[2*4*4+0*4+1]
          + 2.0/3*GHPLs2[0*4+1]*HPLs1[0]
          + 2.0/3*GHPLs2[0*4+1]*HPLs1[1]
          + 2.0/3*GHPLs3[2*4*4+1*4+1]
          - 2.0/3*GHPLs2[1*4+1]*HPLs1[0]
          - 2.0/3*GHPLs2[1*4+1]*HPLs1[1]
          - 10.0/3*HPLs1[0]*zeta2
          - 3*HPLs2[0*2+0]
          - 2.0/3*HPLs3[1*2*2+0*2+0]
          - 2.0/3*HPLs3[0*2*2+1*2+0]
          - 2.0/3*HPLs1[1]*zeta2
          - 3*HPLs2[0*2+1]
          - 2.0/3*HPLs3[0*2*2+0*2+1]
          - 2.0/3*HPLs3[1*2*2+0*2+1]
          - 4.0/3*HPLs3[0*2*2+1*2+1]
          )

       + C_F*pow(u,3) * (
          + 4*zeta2
          + GHPLs1[2]*HPLs1[0]
          - GHPLs2[0*4+2]
          - GHPLs1[3]*HPLs1[0]
          + GHPLs2[0*4+3]
          - GHPLs2[2*4+0]
          + GHPLs1[0]*HPLs1[0]
          + GHPLs1[0]*HPLs1[1]
          + GHPLs2[2*4+1]
          - GHPLs1[1]*HPLs1[0]
          - GHPLs1[1]*HPLs1[1]
          - HPLs2[0*2+0]
          - HPLs2[0*2+1]
          )

       + C_F*double_complex(0,1)*M_PI*pow(u,-2)*v * (
          - 4*GHPLs3[3*4*4+2*4+2]
          - 4*GHPLs2[2*4+2]*HPLs1[0]
          - 4*GHPLs1[2]*HPLs2[0*2+0]
          + 4*GHPLs3[3*4*4+0*4+2]
          - 2.0/3*GHPLs2[1*4+2]
          - 4*GHPLs3[3*4*4+2*4+1]
          - 2.0/3*GHPLs2[2*4+1]
          - 4*GHPLs2[2*4+1]*HPLs1[0]
          + GHPLs1[1]
          + 8*GHPLs1[1]*zeta2
          + 4*GHPLs1[1]*HPLs2[0*2+0]
          + 2.0/3*GHPLs1[1]*HPLs1[1]
          + 4*GHPLs1[1]*HPLs2[0*2+1]
          - 4*GHPLs3[3*4*4+0*4+1]
          - 2.0/3*GHPLs2[0*4+1]
          + 2.0/3*GHPLs2[1*4+1]
          )

       + C_F*double_complex(0,1)*M_PI*pow(u,-2)*pow(v,2) * (
          + 4*GHPLs3[3*4*4+2*4+2]
          + 4*GHPLs2[2*4+2]*HPLs1[0]
          + 4*GHPLs1[2]*HPLs2[0*2+0]
          - 4*GHPLs3[3*4*4+0*4+2]
          + 2.0/3*GHPLs2[1*4+2]
          + 4*GHPLs3[3*4*4+2*4+1]
          + 2.0/3*GHPLs2[2*4+1]
          + 4*GHPLs2[2*4+1]*HPLs1[0]
          - 2.0/3*GHPLs1[1]
          - 8*GHPLs1[1]*zeta2
          - 4*GHPLs1[1]*HPLs2[0*2+0]
          - 2.0/3*GHPLs1[1]*HPLs1[1]
          - 4*GHPLs1[1]*HPLs2[0*2+1]
          + 4*GHPLs3[3*4*4+0*4+1]
          + 2.0/3*GHPLs2[0*4+1]
          - 2.0/3*GHPLs2[1*4+1]
          )

       + C_F*double_complex(0,1)*M_PI*pow(u,-2)*pow(v,3) * (
          + 1.0/3*GHPLs1[1]
          )

       + C_F*double_complex(0,1)*M_PI*pow(u,-2)*pow(v,4) * (
          + 2.0/3*GHPLs2[1*4+2]
          - 2.0/3*GHPLs2[2*4+3]
          + 2.0/3*GHPLs2[3*4+3]
          + 2.0/3*GHPLs1[3]*HPLs1[0]
          + 2.0/3*GHPLs1[3]*HPLs1[1]
          - 2.0/3*GHPLs2[0*4+3]
          - 2.0/3*GHPLs1[1]
          )

       + C_F*double_complex(0,1)*M_PI*pow(u,-2)*pow(v,5) * (
          - 2.0/3*GHPLs2[1*4+2]
          + 2.0/3*GHPLs2[2*4+3]
          - 2.0/3*GHPLs2[3*4+3]
          - 2.0/3*GHPLs1[3]*HPLs1[0]
          - 2.0/3*GHPLs1[3]*HPLs1[1]
          + 2.0/3*GHPLs2[0*4+3]
          )

       + C_F*double_complex(0,1)*M_PI*pow(u,-1) * (
          + 3.0/2*GHPLs1[1]
          )

       + C_F*double_complex(0,1)*M_PI*pow(u,-1)*v * (
          + 5.0/3
          + 8*zeta2
          + 4*GHPLs3[3*4*4+2*4+2]
          + 4*GHPLs2[2*4+2]*HPLs1[0]
          - 8*GHPLs2[3*4+2]
          - 2.0/3*GHPLs1[2]
          - 7*GHPLs1[2]*HPLs1[0]
          + 4*GHPLs1[2]*HPLs2[0*2+0]
          - 4*GHPLs3[3*4*4+0*4+2]
          - 1.0/3*GHPLs2[1*4+2]
          - 2.0/3*GHPLs1[0]
          + GHPLs2[1*4+0]
          + 4*GHPLs3[3*4*4+2*4+1]
          + 2.0/3*GHPLs2[2*4+1]
          + 4*GHPLs2[2*4+1]*HPLs1[0]
          - 8*GHPLs1[1]*zeta2
          - 4*GHPLs1[1]*HPLs2[0*2+0]
          - 2.0/3*GHPLs1[1]*HPLs1[1]
          - 4*GHPLs1[1]*HPLs2[0*2+1]
          + 4*GHPLs3[3*4*4+0*4+1]
          + 2.0/3*GHPLs2[0*4+1]
          - 2.0/3*GHPLs2[1*4+1]
          + 2.0/3*HPLs1[1]
          + 4*HPLs2[0*2+1]
          )

       + C_F*double_complex(0,1)*M_PI*pow(u,-1)*pow(v,2) * (
          - 4.0/3
          - 8*zeta2
          + 4*GHPLs2[3*4+2]
          + 2.0/3*GHPLs1[2]
          + 4*GHPLs1[2]*HPLs1[0]
          - 4*GHPLs1[3]
          + 4*GHPLs2[3*4+0]
          + 2.0/3*GHPLs1[0]
          - 1.0/2*GHPLs1[1]
          - 4*HPLs2[0*2+0]
          - 2.0/3*HPLs1[1]
          - 4*HPLs2[0*2+1]
          )

       + C_F*double_complex(0,1)*M_PI*pow(u,-1)*pow(v,3) * (
          - 1.0/3
          + 2.0/3*GHPLs1[2]
          + 2*GHPLs2[1*4+2]
          - 2*GHPLs2[2*4+3]
          + 2*GHPLs2[3*4+3]
          - 2.0/3*GHPLs1[3]
          + 2*GHPLs1[3]*HPLs1[0]
          + 2*GHPLs1[3]*HPLs1[1]
          - 2*GHPLs2[0*4+3]
          + 2.0/3*GHPLs1[0]
          - 8.0/3*GHPLs1[1]
          - 2.0/3*HPLs1[0]
          - 2.0/3*HPLs1[1]
          )

       + C_F*double_complex(0,1)*M_PI*pow(u,-1)*pow(v,4) * (
          - 2.0/3*GHPLs1[2]
          - 8.0/3*GHPLs2[1*4+2]
          + 8.0/3*GHPLs2[2*4+3]
          - 8.0/3*GHPLs2[3*4+3]
          + 2.0/3*GHPLs1[3]
          - 8.0/3*GHPLs1[3]*HPLs1[0]
          - 8.0/3*GHPLs1[3]*HPLs1[1]
          + 8.0/3*GHPLs2[0*4+3]
          - 2.0/3*GHPLs1[0]
          + 2.0/3*GHPLs1[1]
          + 2.0/3*HPLs1[0]
          + 2.0/3*HPLs1[1]
          )

       + C_F*double_complex(0,1)*M_PI*pow(1-u,-1) * (
          - 3.0/2*GHPLs1[3]
          - 3.0/2*HPLs1[0]
          )

       + C_F*double_complex(0,1)*M_PI*pow(1-v,-1) * (
          + 2*GHPLs2[3*4+2]
          + 2*GHPLs2[1*4+2]
          + GHPLs1[3]
          - 2*GHPLs2[3*4+0]
          - 2*GHPLs2[1*4+0]
          - GHPLs1[1]
          - HPLs1[0]
          + 2*HPLs2[0*2+0]
          )

       + C_F*double_complex(0,1)*M_PI * (
          + 3.0/2
          - 2*GHPLs2[3*4+2]
          - 2*GHPLs2[1*4+2]
          + 1.0/2*GHPLs1[3]
          + 2*GHPLs2[3*4+0]
          + 2*GHPLs2[1*4+0]
          - 3.0/2*GHPLs1[1]
          + 5.0/2*HPLs1[0]
          - 2*HPLs2[0*2+0]
          )

       + C_F*double_complex(0,1)*M_PI*v*pow(1-u,-2) * (
          + 6*zeta2
          - 3*GHPLs2[3*4+2]
          - 3*GHPLs1[2]*HPLs1[0]
          + 3*GHPLs1[3]
          - 3*GHPLs2[3*4+0]
          + 3*HPLs1[0]
          + 3*HPLs2[0*2+0]
          + 3*HPLs2[0*2+1]
          )

       + C_F*double_complex(0,1)*M_PI*v*pow(1-u,-1) * (
          + 3.0/2
          - 10*zeta2
          + 5*GHPLs2[3*4+2]
          + 5*GHPLs1[2]*HPLs1[0]
          - 8*GHPLs1[3]
          + 5*GHPLs2[3*4+0]
          - 5*HPLs1[0]
          - 5*HPLs2[0*2+0]
          - 5*HPLs2[0*2+1]
          )

       + C_F*double_complex(0,1)*M_PI*v * (
          + 7.0/6
          + 1.0/3*GHPLs1[2]
          + 1.0/3*GHPLs1[0]
          - 1.0/3*HPLs1[1]
          )

       + C_F*double_complex(0,1)*M_PI*pow(v,2)*pow(1-u,-3) * (
          - 6*zeta2
          + 3*GHPLs2[3*4+2]
          + 3*GHPLs1[2]*HPLs1[0]
          + 3*GHPLs2[3*4+0]
          - 3*HPLs2[0*2+0]
          - 3*HPLs2[0*2+1]
          )

       + C_F*double_complex(0,1)*M_PI*pow(v,2)*pow(1-u,-2) * (
          + 10*zeta2
          - 5*GHPLs2[3*4+2]
          - 5*GHPLs1[2]*HPLs1[0]
          + 3*GHPLs1[3]
          - 5*GHPLs2[3*4+0]
          + 5*HPLs2[0*2+0]
          + 5*HPLs2[0*2+1]
          )

       + C_F*double_complex(0,1)*M_PI*pow(v,2)*pow(1-u,-1) * (
          - 3.0/2
          - 8*zeta2
          + 4*GHPLs2[3*4+2]
          + 1.0/2*GHPLs1[2]
          + 4*GHPLs1[2]*HPLs1[0]
          - 7.0/2*GHPLs1[3]
          + 4*GHPLs2[3*4+0]
          + 1.0/2*GHPLs1[0]
          - GHPLs1[1]
          + 1.0/2*HPLs1[0]
          - 4*HPLs2[0*2+0]
          - 1.0/2*HPLs1[1]
          - 4*HPLs2[0*2+1]
          )

       + C_F*double_complex(0,1)*M_PI*pow(v,2) * (
          - 2.0/3
          + 3.0/2*GHPLs1[2]
          + 2*GHPLs2[1*4+2]
          - 2*GHPLs2[2*4+3]
          + 2*GHPLs2[3*4+3]
          - 13.0/6*GHPLs1[3]
          + 2*GHPLs1[3]*HPLs1[0]
          + 2*GHPLs1[3]*HPLs1[1]
          - 2*GHPLs2[0*4+3]
          + 3.0/2*GHPLs1[0]
          - 7.0/2*GHPLs1[1]
          - 13.0/6*HPLs1[0]
          - 3.0/2*HPLs1[1]
          )

       + C_F*double_complex(0,1)*M_PI*pow(v,3) * (
          - 7.0/3*GHPLs1[2]
          - 4*GHPLs2[1*4+2]
          + 4*GHPLs2[2*4+3]
          - 4*GHPLs2[3*4+3]
          + 7.0/3*GHPLs1[3]
          - 4*GHPLs1[3]*HPLs1[0]
          - 4*GHPLs1[3]*HPLs1[1]
          + 4*GHPLs2[0*4+3]
          - 7.0/3*GHPLs1[0]
          + 7.0/3*GHPLs1[1]
          + 7.0/3*HPLs1[0]
          + 7.0/3*HPLs1[1]
          )

       + C_F*double_complex(0,1)*M_PI*u*pow(1-v,-2) * (
          + GHPLs2[3*4+2]
          + 2*GHPLs1[2]*HPLs1[0]
          - GHPLs2[1*4+2]
          - GHPLs2[3*4+0]
          + GHPLs2[1*4+0]
          - 2*HPLs1[0]
          + HPLs2[0*2+0]
          )

       + C_F*double_complex(0,1)*M_PI*u*pow(1-v,-1) * (
          - 4
          - GHPLs2[3*4+2]
          - 2*GHPLs1[2]*HPLs1[0]
          + GHPLs2[1*4+2]
          + GHPLs1[3]
          + GHPLs2[3*4+0]
          - GHPLs2[1*4+0]
          + GHPLs1[1]
          + 3*HPLs1[0]
          - HPLs2[0*2+0]
          )

       + C_F*double_complex(0,1)*M_PI*u * (
          + 1
          - 1.0/2*GHPLs1[2]
          + 1.0/2*GHPLs1[3]
          - 1.0/2*GHPLs1[0]
          + 1.0/2*GHPLs1[1]
          + 1.0/2*HPLs1[0]
          + 1.0/2*HPLs1[1]
          )

       + C_F*double_complex(0,1)*M_PI*u*v * (
          - 1.0/3
          - 2.0/3*zeta2
          + 7.0/3*GHPLs1[2]
          + 2.0/3*GHPLs2[1*4+2]
          - 2.0/3*GHPLs2[2*4+3]
          + 2.0/3*GHPLs2[3*4+3]
          - 3*GHPLs1[3]
          + 2.0/3*GHPLs1[3]*HPLs1[0]
          + 2.0/3*GHPLs1[3]*HPLs1[1]
          - 2.0/3*GHPLs2[0*4+3]
          - 2.0/3*GHPLs2[3*4+0]
          + 7.0/3*GHPLs1[0]
          - 2.0/3*GHPLs1[0]*HPLs1[0]
          + 2.0/3*GHPLs2[2*4+1]
          - 3*GHPLs1[1]
          - 2.0/3*GHPLs1[1]*HPLs1[1]
          + 2.0/3*GHPLs2[0*4+1]
          - 2.0/3*GHPLs2[1*4+1]
          - 3*HPLs1[0]
          + 2.0/3*HPLs2[0*2+0]
          + 2.0/3*HPLs2[1*2+0]
          - 7.0/3*HPLs1[1]
          )

       + C_F*double_complex(0,1)*M_PI*u*pow(v,2) * (
          + 2.0/3*zeta2
          - 11.0/3*GHPLs1[2]
          - 8.0/3*GHPLs2[1*4+2]
          + 8.0/3*GHPLs2[2*4+3]
          - 8.0/3*GHPLs2[3*4+3]
          + 11.0/3*GHPLs1[3]
          - 8.0/3*GHPLs1[3]*HPLs1[0]
          - 8.0/3*GHPLs1[3]*HPLs1[1]
          + 8.0/3*GHPLs2[0*4+3]
          + 2.0/3*GHPLs2[3*4+0]
          - 11.0/3*GHPLs1[0]
          + 2.0/3*GHPLs1[0]*HPLs1[0]
          - 2.0/3*GHPLs2[2*4+1]
          + 11.0/3*GHPLs1[1]
          + 2.0/3*GHPLs1[1]*HPLs1[1]
          - 2.0/3*GHPLs2[0*4+1]
          + 2.0/3*GHPLs2[1*4+1]
          + 11.0/3*HPLs1[0]
          - 2.0/3*HPLs2[0*2+0]
          - 2.0/3*HPLs2[1*2+0]
          + 11.0/3*HPLs1[1]
          )

       + C_F*double_complex(0,1)*M_PI*pow(u,2) * (
          + 3.0/2*GHPLs1[2]
          - 3.0/2*GHPLs1[3]
          + 3.0/2*GHPLs1[0]
          - 3.0/2*GHPLs1[1]
          - 3.0/2*HPLs1[0]
          - 3.0/2*HPLs1[1]
          )

       + C_F*double_complex(0,1)*M_PI*pow(u,2)*v * (
          + 2.0/3*zeta2
          - 3*GHPLs1[2]
          - 2.0/3*GHPLs2[1*4+2]
          + 2.0/3*GHPLs2[2*4+3]
          - 2.0/3*GHPLs2[3*4+3]
          + 3*GHPLs1[3]
          - 2.0/3*GHPLs1[3]*HPLs1[0]
          - 2.0/3*GHPLs1[3]*HPLs1[1]
          + 2.0/3*GHPLs2[0*4+3]
          + 2.0/3*GHPLs2[3*4+0]
          - 3*GHPLs1[0]
          + 2.0/3*GHPLs1[0]*HPLs1[0]
          - 2.0/3*GHPLs2[2*4+1]
          + 3*GHPLs1[1]
          + 2.0/3*GHPLs1[1]*HPLs1[1]
          - 2.0/3*GHPLs2[0*4+1]
          + 2.0/3*GHPLs2[1*4+1]
          + 3*HPLs1[0]
          - 2.0/3*HPLs2[0*2+0]
          - 2.0/3*HPLs2[1*2+0]
          + 3*HPLs1[1]
          )

       + C_F*double_complex(0,1)*M_PI*pow(u,3) * (
          - GHPLs1[2]
          + GHPLs1[3]
          - GHPLs1[0]
          + GHPLs1[1]
          + HPLs1[0]
          + HPLs1[1]
          );
}

void Omega_2_W(double u, double v, double e_q, double e_qprime, double *GHPLs1, double *GHPLs2, double *GHPLs3, double *GHPLs4, double *HPLs1, double *HPLs2, double *HPLs3, double *HPLs4, double_complex &alpha_W, double_complex &beta_W, double_complex &gamma_W) {
  double_complex Omega1, Omega2, Omega3;
  int n_f = 5;

  alpha_2_1(u, v, n_f, GHPLs1, GHPLs2, GHPLs3, GHPLs4, HPLs1, HPLs2, HPLs3, HPLs4, Omega1);
  alpha_2_2(u, v, n_f, GHPLs1, GHPLs2, GHPLs3, GHPLs4, HPLs1, HPLs2, HPLs3, HPLs4, Omega2);
  alpha_2_3(u, v, n_f, GHPLs1, GHPLs2, GHPLs3, GHPLs4, HPLs1, HPLs2, HPLs3, HPLs4, Omega3);
//  cout << "alpha: " << Omega1 << ", " << Omega2 << ", " << Omega4 << endl;
  alpha_W = e_qprime * Omega1 + e_q * Omega2 + Omega3;

  beta_2_1(u, v, n_f, GHPLs1, GHPLs2, GHPLs3, GHPLs4, HPLs1, HPLs2, HPLs3, HPLs4, Omega1);
  beta_2_2(u, v, n_f, GHPLs1, GHPLs2, GHPLs3, GHPLs4, HPLs1, HPLs2, HPLs3, HPLs4, Omega2);
  beta_2_3(u, v, n_f, GHPLs1, GHPLs2, GHPLs3, GHPLs4, HPLs1, HPLs2, HPLs3, HPLs4, Omega3);
//  cout << "alpha: " << Omega1 << ", " << Omega2 << ", " << Omega4 << endl;
  beta_W = e_qprime * Omega1 + e_q * Omega2 + Omega3;

  gamma_2_1(u, v, n_f, GHPLs1, GHPLs2, GHPLs3, GHPLs4, HPLs1, HPLs2, HPLs3, HPLs4, Omega1);
  gamma_2_2(u, v, n_f, GHPLs1, GHPLs2, GHPLs3, GHPLs4, HPLs1, HPLs2, HPLs3, HPLs4, Omega2);
  gamma_2_3(u, v, n_f, GHPLs1, GHPLs2, GHPLs3, GHPLs4, HPLs1, HPLs2, HPLs3, HPLs4, Omega3);
//  cout << "alpha: " << Omega1 << ", " << Omega2 << ", " << Omega4 << endl;
  gamma_W = e_qprime * Omega1 + e_q * Omega2 + Omega3;

//  cout << "alpha: " << alpha_ZR << ", " << alpha_ZL << ", " << alpha_P << endl;
}

void Omega_2_ZP(double u, double v, double e_q, double_complex sin_W, double *GHPLs1, double *GHPLs2, double *GHPLs3, double *GHPLs4, double *HPLs1, double *HPLs2, double *HPLs3, double *HPLs4, double_complex &alpha_ZR, double_complex &beta_ZR, double_complex &gamma_ZR, double_complex &alpha_ZL, double_complex &beta_ZL, double_complex &gamma_ZL, double_complex &alpha_P, double_complex &beta_P, double_complex &gamma_P) {
  double_complex Omega1, Omega2, Omega4;
  int n_f = 5;

  double I3_q;
  if (e_q > 0) {
    I3_q = 0.5;
  } else {
    I3_q = -0.5;
  }

  double_complex cos_W = sqrt(1.0 - sin_W * sin_W);

  double_complex RZ_q1q2 = -sin_W * e_q / cos_W;
  double_complex LZ_q1q2 = (I3_q - sin_W * sin_W * e_q) / (sin_W * cos_W);

  double_complex N_FZR = (-1.0 / 3.0 * 3.0 * ((-0.5 + sin_W * sin_W / 3.0) / sin_W / cos_W + 1.0 / 3.0 * sin_W / cos_W) + 2.0 / 3.0 * 2.0 * ((0.5 - sin_W * sin_W * 2.0 / 3.0) / sin_W / cos_W - 2.0 / 3.0 * sin_W / cos_W)) / (2.0 * RZ_q1q2); // TODO: check!
  double_complex N_FZL = (-1.0 / 3.0 * 3.0 * ((-0.5 + sin_W * sin_W / 3.0) / sin_W / cos_W + 1.0 / 3.0 * sin_W / cos_W) + 2.0 / 3.0 * 2.0 * ((0.5 - sin_W * sin_W * 2.0 / 3.0) / sin_W / cos_W - 2.0 / 3.0 * sin_W / cos_W)) / (2.0 * LZ_q1q2); // TODO: check!
  double N_FP = 11.0 / 9 / e_q; // TODO: check!

//  cout << N_FZR << ", " << N_FZL << ", " << N_FP << endl;

  alpha_2_1(u, v, n_f, GHPLs1, GHPLs2, GHPLs3, GHPLs4, HPLs1, HPLs2, HPLs3, HPLs4, Omega1);
  alpha_2_2(u, v, n_f, GHPLs1, GHPLs2, GHPLs3, GHPLs4, HPLs1, HPLs2, HPLs3, HPLs4, Omega2);
  alpha_2_4(u, v, n_f, GHPLs1, GHPLs2, GHPLs3, GHPLs4, HPLs1, HPLs2, HPLs3, HPLs4, Omega4);
//  cout << "alpha: " << Omega1 << ", " << Omega2 << ", " << Omega4 << endl;
  alpha_ZR = e_q * (Omega1 + Omega2) + N_FZR * Omega4;
  alpha_ZL = e_q * (Omega1 + Omega2) + N_FZL * Omega4;
  alpha_P = e_q * (Omega1 + Omega2) + N_FP * Omega4;

//  cout << "alpha: " << alpha_ZR << ", " << alpha_ZL << ", " << alpha_P << endl;

  beta_2_1(u, v, n_f, GHPLs1, GHPLs2, GHPLs3, GHPLs4, HPLs1, HPLs2, HPLs3, HPLs4, Omega1);
  beta_2_2(u, v, n_f, GHPLs1, GHPLs2, GHPLs3, GHPLs4, HPLs1, HPLs2, HPLs3, HPLs4, Omega2);
  beta_2_4(u, v, n_f, GHPLs1, GHPLs2, GHPLs3, GHPLs4, HPLs1, HPLs2, HPLs3, HPLs4, Omega4);
//  cout << "beta: " << Omega1 << ", " << Omega2 << ", " << Omega4 << endl;
  beta_ZR = e_q * (Omega1 + Omega2) + N_FZR * Omega4;
  beta_ZL = e_q * (Omega1 + Omega2) + N_FZL * Omega4;
  beta_P = e_q * (Omega1 + Omega2) + N_FP * Omega4;

//  cout << "beta: " << beta_ZR << ", " << beta_ZL << ", " << beta_P << endl;

  gamma_2_1(u, v, n_f, GHPLs1, GHPLs2, GHPLs3, GHPLs4, HPLs1, HPLs2, HPLs3, HPLs4, Omega1);
  gamma_2_2(u, v, n_f, GHPLs1, GHPLs2, GHPLs3, GHPLs4, HPLs1, HPLs2, HPLs3, HPLs4, Omega2);
  gamma_2_4(u, v, n_f, GHPLs1, GHPLs2, GHPLs3, GHPLs4, HPLs1, HPLs2, HPLs3, HPLs4, Omega4);
//  cout << "gamma: " << Omega1 << ", " << Omega2 << ", " << Omega4 << endl;
  gamma_ZR = e_q * (Omega1 + Omega2) + N_FZR * Omega4;
  gamma_ZL = e_q * (Omega1 + Omega2) + N_FZL * Omega4;
  gamma_P = e_q * (Omega1 + Omega2) + N_FP * Omega4;

//  cout << "gamma: " << gamma_ZR << ", " << gamma_ZL << ", " << gamma_P << endl;
}
