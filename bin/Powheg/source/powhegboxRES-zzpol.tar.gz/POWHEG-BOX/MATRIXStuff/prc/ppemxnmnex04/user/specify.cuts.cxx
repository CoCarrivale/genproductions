{
  static int switch_optimize_sqrts_min = USERSWITCH("optimize_sqrts_min");
  static double cut_optimize_sqrts_min = USERCUT("optimize_sqrts_min");

  static int switch_cut_pT_lep_1st = USERSWITCH("pT_lep_1st");
  static double cut_min_pT_lep_1st = USERCUT("min_pT_lep_1st");

  static int switch_cut_M_4lep = USERSWITCH("M_leplepnunu");
  static double cut_min_M_4lep = USERCUT("min_M_leplepnunu");
  static double cut_min_M2_4lep = pow(cut_min_M_4lep, 2);
  static double cut_max_M_4lep = USERCUT("max_M_leplepnunu");
  static double cut_max_M2_4lep = pow(cut_max_M_4lep, 2);
  static double cut_min_deltaZ_M_4lep = USERCUT("min_delta_M_leplepnunu");
  static double cut_max_deltaZ_M_4lep = USERCUT("max_delta_M_leplepnunu");

  static int switch_cut_M_leplep = USERSWITCH("M_leplep");
  static double cut_min_M_leplep = USERCUT("min_M_leplep");
  static double cut_min_M2_leplep = pow(cut_min_M_leplep, 2);
  static double cut_max_M_leplep = USERCUT("max_M_leplep");
  static double cut_max_M2_leplep = pow(cut_max_M_leplep, 2);

  static int switch_cut_R_leplep = USERSWITCH("R_leplep");
  static double cut_min_R_leplep = USERCUT("min_R_leplep");
  static double cut_min_R2_leplep = pow(cut_min_R_leplep, 2);
  
  static int switch_cut_R_rapidity_leplep = USERSWITCH("R_rapidity_leplep");
  static double cut_min_R_rapidity_leplep = USERCUT("min_R_rapidity_leplep");
  static double cut_min_R2_rapidity_leplep = pow(cut_min_R_rapidity_leplep, 2);

  static int switch_cut_R_eta_leplep = USERSWITCH("R_eta_leplep");
  static double cut_min_R_eta_leplep = USERCUT("min_R_eta_leplep");
  static double cut_min_R2_eta_leplep = pow(cut_min_R_eta_leplep, 2);

  static int switch_cut_gap_eta_e = USERSWITCH("gap_eta_e");
  static double cut_gap_min_eta_e = USERCUT("gap_min_eta_e");
  static double cut_gap_max_eta_e = USERCUT("gap_max_eta_e");

  static int switch_cut_R_ejet = USERSWITCH("R_ejet");
  static double cut_min_R_ejet = USERCUT("min_R_ejet");
  static double cut_min_R2_ejet = pow(cut_min_R_ejet, 2);
  
  static int switch_cut_R_mujet = USERSWITCH("R_mujet");
  static double cut_min_R_mujet = USERCUT("min_R_mujet");
  static double cut_min_R2_mujet = pow(cut_min_R_mujet, 2);
  
  static int switch_n_jet_modified = USERSWITCH("n_jet_modified");
  static int cut_n_jet_min_modified = USERINT("n_jet_min_modified");
  static int cut_n_jet_max_modified = USERINT("n_jet_max_modified");

  static int switch_cut_phi_leplep = USERSWITCH("phi_leplep");
  static double cut_min_phi_leplep = USERCUT("min_phi_leplep");
  static double cut_max_phi_leplep = USERCUT("max_phi_leplep");

  static int switch_cut_phi_leplep_nunu = USERSWITCH("phi_leplep_nunu");
  static double cut_min_phi_leplep_nunu = USERCUT("min_phi_leplep_nunu");

  static int switch_cut_pT_leplep = USERSWITCH("pT_leplep");
  static double cut_min_pT_leplep = USERCUT("min_pT_leplep");

  static int switch_cut_rel_pT_miss = USERSWITCH("rel_pT_miss");
  static double cut_min_rel_pT_miss = USERCUT("min_rel_pT_miss");

  static int switch_cut_pT_W = USERSWITCH("pT_W");
  static double cut_min_pT_W = USERCUT("min_pT_W");
  static double cut_max_pT_W = USERCUT("max_pT_W");

  static int switch_axial_ETmiss = USERSWITCH("axial_ETmiss");
  static double cut_min_axial_ETmiss = USERCUT("min_axial_ETmiss");

  static int switch_pT_balance_Zs = USERSWITCH("pT_balance_Zs");
  static double cut_max_pT_balance_Zs = USERCUT("max_pT_balance_Zs");

  // not correctly working !!! not correctly mirrored when filling distribution !!
  static int switch_cut_dy_WpWm = USERSWITCH("dy_WpWm");
  static double cut_min_dy_WpWm = USERCUT("min_dy_WpWm");
  static double cut_max_dy_WpWm = USERCUT("max_dy_WpWm");


  if (switch_optimize_sqrts_min){
    fourvector total_momentum;
    for (int i_l = 0; i_l < NUMBER("lep"); i_l++){total_momentum = total_momentum + PARTICLE("lep")[i_l].momentum;}
    for (int i_j = 0; i_j < NUMBER("jet"); i_j++){total_momentum = total_momentum + PARTICLE("jet")[i_j].momentum;}
    for (int i_n = 0; i_n < NUMBER("nua"); i_n++){total_momentum = total_momentum + PARTICLE("nua")[i_n].momentum;}
    if (total_momentum.m() < cut_optimize_sqrts_min ){osi_cut_ps[i_a] = -1; return;}
  }


  // lepton--lepton pseudo-rapidity--azimuthal-angle-plane (dR) isolation cut
  if (osi_switch_output_cutinfo){info_cut << "[" << setw(2) << i_a << "]" << "   switch_cut_R_leplep = " << switch_cut_R_leplep << endl; }
  if (switch_cut_R_leplep){
    double R2_eta_leplep = R2_eta(PARTICLE("lep")[0], PARTICLE("lep")[1]);
    if (osi_switch_output_cutinfo){info_cut << "[" << setw(2) << i_a << "]   PARTICLE(lep)[0] = " << PARTICLE("lep")[0].momentum << endl;}
    if (osi_switch_output_cutinfo){info_cut << "[" << setw(2) << i_a << "]   PARTICLE(lep)[1] = " << PARTICLE("lep")[1].momentum << endl;}
    if (osi_switch_output_cutinfo){info_cut << "[" << setw(2) << i_a << "]   R2_eta_leplep = " << R2_eta_leplep << " > " << cut_min_R2_leplep << endl;}
    if (R2_eta_leplep < cut_min_R2_leplep){
      osi_cut_ps[i_a] = -1; 
      if (osi_switch_output_cutinfo){
	info_cut << "[" << setw(2) << i_a << "]" << "   individual cut after cut_R_leplep" << endl; 
	logger << LOG_DEBUG << endl << info_cut.str(); 
      }
      logger << LOG_DEBUG_VERBOSE << "switch_cut_R_leplep cut applied" << endl; 
      return;
    }
  }

  if (switch_cut_R_rapidity_leplep) {
    for (int i_l1 = 0; i_l1 < PARTICLE("lep").size(); i_l1++) {
      for (int i_l2 = i_l1 + 1; i_l2 < PARTICLE("lep").size(); i_l2++) {
        double R2_rapidity_leplep = R2_rapidity(PARTICLE("lep")[i_l1], PARTICLE("lep")[i_l2]);
	if (osi_switch_output_cutinfo){info_cut << "[" << setw(2) << i_a << "]   R2_lep[" << i_l1 << "]lep[" << i_l2 << "] = " << R2_rapidity_leplep << " > " << cut_min_R2_rapidity_leplep << endl;}
        if (R2_rapidity_leplep < cut_min_R2_rapidity_leplep) {
          osi_cut_ps[i_a] = -1;
	  if (osi_switch_output_cutinfo){
	    info_cut << "[" << setw(2) << i_a << "]" << "   process-specific cut after cut_R_rapidity_leplep" << endl;
	    logger << LOG_DEBUG << endl << info_cut.str();
	  }
          return;
        }
      }
    }
  }


  // lepton lepton R-separation (pseudo-rapidity-based) cut (to be applied to *any* two leptons)
  if (switch_cut_R_eta_leplep) {
    for (int i_l1 = 0; i_l1 < PARTICLE("lep").size(); i_l1++) {
      for (int i_l2 = i_l1 + 1; i_l2 < PARTICLE("lep").size(); i_l2++) {
        double R2_eta_leplep = R2_eta(PARTICLE("lep")[i_l1], PARTICLE("lep")[i_l2]);
	if (osi_switch_output_cutinfo){info_cut << "[" << setw(2) << i_a << "]   R2_lep[" << i_l1 << "]lep[" << i_l2 << "] = " << R2_eta_leplep << " > " << cut_min_R2_eta_leplep << endl;}
        if (R2_eta_leplep < cut_min_R2_eta_leplep) {
          osi_cut_ps[i_a] = -1;
	  if (osi_switch_output_cutinfo){
	    info_cut << "[" << setw(2) << i_a << "]" << "   process-specific cut after cut_R_eta_leplep" << endl;
	    logger << LOG_DEBUG << endl << info_cut.str();
	  }
          return;
        }
      }
    }
  }

  
  // lepton--lepton invariant-mass cut
  if (osi_switch_output_cutinfo){info_cut << "[" << setw(2) << i_a << "]" << "   switch_cut_M_leplep = " << switch_cut_M_leplep << endl;}
  if (switch_cut_M_leplep == 1){
    double M2_leplep = (PARTICLE("lep")[0].momentum + PARTICLE("lep")[1].momentum).m2();
    if (osi_switch_output_cutinfo){info_cut << "[" << setw(2) << i_a << "]   PARTICLE(lep)[0] = " << PARTICLE("lep")[0].momentum << endl;}
    if (osi_switch_output_cutinfo){info_cut << "[" << setw(2) << i_a << "]   PARTICLE(lep)[1] = " << PARTICLE("lep")[1].momentum << endl;}
    if (cut_min_M2_leplep != 0.){
      if (osi_switch_output_cutinfo){info_cut << "[" << setw(2) << i_a << "]   M2_leplep = " << M2_leplep << " > " << cut_min_M2_leplep << endl;}

      if (M2_leplep < cut_min_M2_leplep){
	osi_cut_ps[i_a] = -1; 
	if (osi_switch_output_cutinfo){
	  info_cut << "[" << setw(2) << i_a << "]" << "   individual cut after cut_min_M_leplep" << endl;
	  logger << LOG_DEBUG << endl << info_cut.str();
	}
	logger << LOG_DEBUG_VERBOSE << "switch_cut_M_leplep min cut applied" << endl; 
	return;
      }
    }
    
    if (cut_max_M2_leplep != 0.){
      if (osi_switch_output_cutinfo){info_cut << "[" << setw(2) << i_a << "]   M2_leplep = " << M2_leplep << " < " << cut_max_M2_leplep << endl;}
      if (M2_leplep > cut_max_M2_leplep){
	osi_cut_ps[i_a] = -1; 
	if (osi_switch_output_cutinfo){
	  info_cut << "[" << setw(2) << i_a << "]" << "   individual cut after cut_max_M_leplep" << endl; 
	  logger << LOG_DEBUG << endl << info_cut.str(); 
	}
	logger << LOG_DEBUG_VERBOSE << "switch_cut_M_leplep max cut applied" << endl; 
	return;
      }
    }
  }



  // lepton + neutrino invariant-mass cut
  if (osi_switch_output_cutinfo){info_cut << "[" << setw(2) << i_a << "]" << "   switch_cut_M_4lep = " << switch_cut_M_4lep << endl;}
  if (switch_cut_M_4lep){
    double M2_4lep = (PARTICLE("lep")[0].momentum + PARTICLE("lep")[1].momentum + PARTICLE("nua")[0].momentum + PARTICLE("nua")[1].momentum).m2();
    if (osi_switch_output_cutinfo){info_cut << "[" << setw(2) << i_a << "]   PARTICLE(lep)[0] = " << PARTICLE("lep")[0].momentum << endl;}
    if (osi_switch_output_cutinfo){info_cut << "[" << setw(2) << i_a << "]   PARTICLE(lep)[1] = " << PARTICLE("lep")[1].momentum << endl;}
    if (osi_switch_output_cutinfo){info_cut << "[" << setw(2) << i_a << "]   PARTICLE(nua)[0] = " << PARTICLE("nua")[0].momentum << endl;}
    if (osi_switch_output_cutinfo){info_cut << "[" << setw(2) << i_a << "]   PARTICLE(nua)[1] = " << PARTICLE("nua")[1].momentum << endl;}
    if (osi_switch_output_cutinfo){if (cut_min_M_4lep != 0.){info_cut << "[" << setw(2) << i_a << "]   M2_4lep = " << M2_4lep << " > " << cut_min_M2_4lep << endl;}}
    if (osi_switch_output_cutinfo){if (cut_max_M_4lep != 0.){info_cut << "[" << setw(2) << i_a << "]   M2_4lep = " << M2_4lep << " < " << cut_max_M2_4lep << endl;}}
    if (osi_switch_output_cutinfo){if (cut_min_deltaZ_M_4lep != 0.){info_cut << "[" << setw(2) << i_a << "]   |M_4lep - M_Z| = " << abs(sqrt(M2_4lep) - osi_msi.M_Z) << " > " << cut_min_deltaZ_M_4lep << endl;}}
    if (osi_switch_output_cutinfo){if (cut_max_deltaZ_M_4lep != 0.){info_cut << "[" << setw(2) << i_a << "]   |M_4lep - M_Z| = " << abs(sqrt(M2_4lep) - osi_msi.M_Z) << " < " << cut_max_deltaZ_M_4lep << endl;}}

    if (cut_min_M2_4lep != 0 && M2_4lep < cut_min_M2_4lep){
      osi_cut_ps[i_a] = -1; 
      if (osi_switch_output_cutinfo){
	info_cut << "[" << setw(2) << i_a << "]" << "   individual cut after cut_min_M_4lep" << endl; 
	logger << LOG_DEBUG << endl << info_cut.str(); 
      }
      logger << LOG_DEBUG_VERBOSE << "cut_M_leplep min cut applied" << endl; 
      return;
    }

    if (cut_max_M2_4lep != 0 && M2_4lep > cut_max_M2_4lep){
      osi_cut_ps[i_a] = -1; 
      if (osi_switch_output_cutinfo){
	info_cut << "[" << setw(2) << i_a << "]" << "   individual cut after cut_max_M_4lep" << endl; 
	logger << LOG_DEBUG << endl << info_cut.str(); 
      }
      logger << LOG_DEBUG_VERBOSE << "cut_M_leplep max cut applied" << endl; 
      return;
    }

    if (cut_min_deltaZ_M_4lep != 0.){
      if (abs(sqrt(M2_4lep) - osi_msi.M_Z) < cut_min_deltaZ_M_4lep){
	osi_cut_ps[i_a] = -1; 
	if (osi_switch_output_cutinfo){
	  info_cut << "[" << setw(2) << i_a << "]" << "   ppemxnmnex04-cut after cut_min_deltaZ_M_4lep" << endl; 
	  logger << LOG_DEBUG << endl << info_cut.str(); 
	}
	logger << LOG_DEBUG_VERBOSE << "cut_M_leplep delta cut applied" << endl; 
	return;
      }
    }

    if (cut_max_deltaZ_M_4lep != 0.){
      if (abs(sqrt(M2_4lep) - osi_msi.M_Z) > cut_max_deltaZ_M_4lep){
	osi_cut_ps[i_a] = -1; 
	if (osi_switch_output_cutinfo){
	  info_cut << "[" << setw(2) << i_a << "]" << "   ppemxnmnex04-cut after cut_max_deltaZ_M_4lep" << endl; 
	  logger << LOG_DEBUG << endl << info_cut.str(); 
	}
	logger << LOG_DEBUG_VERBOSE << "cut_M_leplep delta cut applied" << endl; 
	return;
      }
    }
  }



  // pT-cut on highest-pT lepton
  if (osi_switch_output_cutinfo){info_cut << "[" << setw(2) << i_a << "]" << "   switch_cut_pT_lep_1st = " << switch_cut_pT_lep_1st << endl;}
  if (switch_cut_pT_lep_1st){
    double temp_pT_lep_1st = PARTICLE("lep")[0].pT;
    if (osi_switch_output_cutinfo){info_cut << "[" << setw(2) << i_a << "]   PARTICLE(lep)[" << 0 << "] = " << PARTICLE("lep")[0].momentum << endl;}
    if (osi_switch_output_cutinfo){info_cut << "[" << setw(2) << i_a << "]   pT_lep_1st = " << temp_pT_lep_1st << " > " << cut_min_pT_lep_1st << endl;}
    if (temp_pT_lep_1st < cut_min_pT_lep_1st){
      osi_cut_ps[i_a] = -1; 
      if (osi_switch_output_cutinfo){
	info_cut << "[" << setw(2) << i_a << "]" << "   individual cut after cut_min_pT_lep_1st" << endl; 
	logger << LOG_DEBUG << endl << info_cut.str(); 
      }
     
      logger << LOG_DEBUG_VERBOSE << "Event at ps = " << i_a << " discarded due to " << temp_pT_lep_1st << " < cut_min_pT_lep_1st = " << cut_min_pT_lep_1st << endl;
      return;
    }
  }



  // (detector-geometry-motivated) gap in the electron-pseudo-rapidity acceptance (eta_e < gap_min_eta_e or eta_e > gap_max_e)
  if (osi_switch_output_cutinfo){info_cut << "[" << setw(2) << i_a << "]" << "   switch_cut_gap_eta_e = " << switch_cut_gap_eta_e << endl;}
  if (switch_cut_gap_eta_e){
    for (int i_l = 0; i_l < PARTICLE("e").size(); i_l++){
      double abs_eta_e = abs(PARTICLE("e")[i_l].eta);
      if (osi_switch_output_cutinfo){info_cut << "[" << setw(2) << i_a << "]   PARTICLE(e)[" << i_l << "] = " << PARTICLE("e")[i_l].momentum << endl;}
      if (osi_switch_output_cutinfo){info_cut << "[" << setw(2) << i_a << "]   |eta_e| = " << abs_eta_e << " < " << cut_gap_min_eta_e << "   or   |eta_e| = " << abs_eta_e << " > " << cut_gap_max_eta_e << endl;}
      if (abs_eta_e > cut_gap_min_eta_e && abs_eta_e < cut_gap_max_eta_e){
	osi_cut_ps[i_a] = -1; 
	if (osi_switch_output_cutinfo){
	  info_cut << "[" << setw(2) << i_a << "]" << "   individual cut after switch_cut_gap_eta_e   i_l = " << i_l << endl; 
	  logger << LOG_DEBUG << endl << info_cut.str(); 
	}
	logger << LOG_DEBUG_VERBOSE << "switch_cut_gap_eta_e cut applied" << endl; 
	return;
      }
    }
  }



  // cut on relative missing pT
  if (osi_switch_output_cutinfo){info_cut << "[" << setw(2) << i_a << "]" << "   switch_cut_rel_pT_miss = " << switch_cut_rel_pT_miss << endl;}
  if (switch_cut_rel_pT_miss){
    double min_sin_dphi_miss = 1.;
    for (int i_l = 0; i_l < PARTICLE("lep").size(); i_l++){
      double temp_dphi = abs(PARTICLE("lep")[i_l].phi - PARTICLE("missing")[0].phi);
      if (temp_dphi > pi){temp_dphi = f2pi - temp_dphi;}
      if (osi_switch_output_cutinfo){info_cut << "[" << setw(2) << i_a << "]   PARTICLE(lep)[" << i_l << "] = " << PARTICLE("lep")[i_l].momentum << "   phi(miss, lep " << i_l << ") = " << temp_dphi << endl;}
      if (temp_dphi < pi / 2){
	double sin_temp_dphi = sin(temp_dphi);
	if (sin_temp_dphi < min_sin_dphi_miss){min_sin_dphi_miss = sin_temp_dphi;}
      }
    }
    // no jets included in definition by ATLAS -> switch_cut_rel_pT_miss = 1
    if (switch_cut_rel_pT_miss == 2){
      for (int i_j = 0; i_j < NUMBER("jet"); i_j++){
	double temp_dphi = abs(PARTICLE("jet")[i_j].phi - PARTICLE("missing")[0].phi);
	if (temp_dphi > pi){temp_dphi = f2pi - temp_dphi;}
	if (osi_switch_output_cutinfo){info_cut << "[" << setw(2) << i_a << "]   PARTICLE(jet)[" << i_j << "] = " << PARTICLE("jet")[i_j].momentum <<  "   phi(miss, jet " << i_j << ") = " << temp_dphi << endl;}
	if (temp_dphi < pi / 2){
	  double sin_temp_dphi = sin(temp_dphi);
	  if (sin_temp_dphi < min_sin_dphi_miss){min_sin_dphi_miss = sin_temp_dphi;}
	}
      }
    }

    if (osi_switch_output_cutinfo){info_cut << "[" << setw(2) << i_a << "]   min_sin_dphi_miss * pTmiss = " << min_sin_dphi_miss << " * " << PARTICLE("missing")[0].pT << " = " << min_sin_dphi_miss * PARTICLE("missing")[0].pT << " > " << cut_min_rel_pT_miss << endl;}

    if (min_sin_dphi_miss * PARTICLE("missing")[0].pT < cut_min_rel_pT_miss){
      osi_cut_ps[i_a] = -1;
      if (osi_switch_output_cutinfo){
	info_cut << "[" << setw(2) << i_a << "]" << "   individual cut after cut_rel_pT_miss" << endl; 
	logger << LOG_DEBUG << endl << info_cut.str(); 
      }
      logger << LOG_DEBUG_VERBOSE << "switch_cut_rel_pT_miss cut applied" << endl; 
      return;
    }
  }


  // cut on pT of the two leptons (vectorial sum)
  if (switch_cut_pT_leplep){
    double temp_pT = (PARTICLE("lep")[0] + PARTICLE("lep")[1]).pT;
    if (temp_pT < cut_min_pT_leplep) {
      osi_cut_ps[i_a] = -1;
      return;
    }
  }



  // cut on maximal azimuthal separation between the two leptons
  if (switch_cut_phi_leplep){
    double temp_dphi = abs(PARTICLE("lep")[0].phi - PARTICLE("lep")[1].phi);
    if (temp_dphi > pi){temp_dphi = f2pi - temp_dphi;}
    if (temp_dphi<cut_min_phi_leplep) {
      osi_cut_ps[i_a] = -1;
      return;
    }
    if (temp_dphi>cut_max_phi_leplep) {
      osi_cut_ps[i_a] = -1;
      return;
    }
  }


  // cut on minimal azimuthal separation between the two-lepton-system and the missing energy
  if (switch_cut_phi_leplep_nunu){
    double temp_dphi = abs((PARTICLE("lep")[0] + PARTICLE("lep")[1]).phi - (PARTICLE("missing")[0]).phi);
    if (temp_dphi > pi){temp_dphi = f2pi - temp_dphi;}
    if (temp_dphi < cut_min_phi_leplep_nunu) {
      osi_cut_ps[i_a] = -1;
      return;
    }
  }
   


  // electron--jet isolation cut
  // removes jets which are too close to electrons (and reduced jet number); the electrons are not affected.
  if (osi_switch_output_cutinfo){info_cut << "[" << setw(2) << i_a << "]" << "   switch_cut_R_ejet = " << switch_cut_R_ejet << endl;}
  if (switch_cut_R_ejet){
    for (int i_j = 0; i_j < NUMBER("jet"); i_j++){
    //  for (int i_j = 0; i_j < PARTICLE("jet").size(); i_j++){ // separation wrt. jets below pT/ET-threshold included
      if (osi_switch_output_cutinfo){info_cut << "[" << setw(2) << i_a << "]" << "   switch_cut_R_ejet = " << switch_cut_R_ejet << "   i_j = " << i_j << endl;}
      // lepton--jet pseudo-rapidity isolation cuts
      for (int i_l = 0; i_l < PARTICLE("e").size(); i_l++){
	double R2_eta_ejet = R2_eta(PARTICLE("e")[i_l], PARTICLE("jet")[i_j]);
	if (osi_switch_output_cutinfo){info_cut << "[" << setw(2) << i_a << "]   PARTICLE(e)[" << i_l << "] = " << PARTICLE("e")[i_l].momentum << endl;}
	if (osi_switch_output_cutinfo){info_cut << "[" << setw(2) << i_a << "]   PARTICLE(jet)[" << i_j << "] = " << PARTICLE("jet")[i_j].momentum << endl;}
	if (osi_switch_output_cutinfo){info_cut << "[" << setw(2) << i_a << "]   R2_eta_ejet = " << R2_eta_ejet << " > " << cut_min_R2_ejet << endl;}
	if (R2_eta_ejet < cut_min_R2_ejet){
	  // R2_eta_ejet should only "unidentify" jets, cut not cut events !!!
	  if (osi_switch_output_cutinfo){info_cut << "[" << setw(2) << i_a << "]   PARTICLE(jet)[" << i_j << "] = " << PARTICLE("jet")[i_j].momentum << " is removed due to R2_eta_ejet = " << R2_eta_ejet << " > " << cut_min_R2_ejet << endl;}
	  for (int j_j = 0; j_j < NUMBER("jet"); j_j++){
	    if (osi_switch_output_cutinfo){info_cut << "[" << setw(2) << i_a << "]   before removal:  PARTICLE(jet)[" << j_j << "] = " << PARTICLE("jet")[j_j].momentum << endl;}
	  }
	  if (osi_switch_output_cutinfo){info_cut << "[" << setw(2) << i_a << "]   before removal:  NUMBER(jet) = " << NUMBER("jet") << endl;}
	  PARTICLE("jet").erase(PARTICLE("jet").begin() + i_j);
	  NUMBER("jet")--;
	  i_j--;
	  for (int j_j = 0; j_j < NUMBER("jet"); j_j++){
	    if (osi_switch_output_cutinfo){info_cut << "[" << setw(2) << i_a << "]   after removal:   PARTICLE(jet)[" << j_j << "] = " << PARTICLE("jet")[j_j].momentum << endl;}
	  }
	  if (osi_switch_output_cutinfo){info_cut << "[" << setw(2) << i_a << "]   after removal:   NUMBER(jet) = " << NUMBER("jet") << endl;}
	  break;
	}
      }
    }
  }

  // muon--jet isolation cut
  // removes jets which are too close to muons (and reduced jet number); the muons are not affected.
  if (osi_switch_output_cutinfo){info_cut << "[" << setw(2) << i_a << "]" << "   switch_cut_R_mujet = " << switch_cut_R_mujet << endl;}
  if (switch_cut_R_mujet){
    for (int i_j = 0; i_j < NUMBER("jet"); i_j++){
    //  for (int i_j = 0; i_j < PARTICLE("jet").size(); i_j++){ // separation wrt. jets below pT/ET-threshold included
      if (osi_switch_output_cutinfo){info_cut << "[" << setw(2) << i_a << "]" << "   switch_cut_R_mujet = " << switch_cut_R_mujet << "   i_j = " << i_j << endl;}
      // lepton--jet pseudo-rapidity isolation cuts
      for (int i_l = 0; i_l < PARTICLE("mu").size(); i_l++){
	double R2_eta_mujet = R2_eta(PARTICLE("mu")[i_l], PARTICLE("jet")[i_j]);
	if (osi_switch_output_cutinfo){info_cut << "[" << setw(2) << i_a << "]   PARTICLE(e)[" << i_l << "] = " << PARTICLE("mu")[i_l].momentum << endl;}
	if (osi_switch_output_cutinfo){info_cut << "[" << setw(2) << i_a << "]   PARTICLE(jet)[" << i_j << "] = " << PARTICLE("jet")[i_j].momentum << endl;}
	if (osi_switch_output_cutinfo){info_cut << "[" << setw(2) << i_a << "]   R2_eta_mujet = " << R2_eta_mujet << " > " << cut_min_R2_mujet << endl;}
	if (R2_eta_mujet < cut_min_R2_mujet){
	  // R2_eta_mujet should only "unidentify" jets, cut not cut events !!!
	  if (osi_switch_output_cutinfo){info_cut << "[" << setw(2) << i_a << "]   PARTICLE(jet)[" << i_j << "] = " << PARTICLE("jet")[i_j].momentum << " is removed due to R2_eta_mujet = " << R2_eta_mujet << " > " << cut_min_R2_mujet << endl;}
	  for (int j_j = 0; j_j < NUMBER("jet"); j_j++){
	    if (osi_switch_output_cutinfo){info_cut << "[" << setw(2) << i_a << "]   before removal:  PARTICLE(jet)[" << j_j << "] = " << PARTICLE("jet")[j_j].momentum << endl;}
	  }
	  if (osi_switch_output_cutinfo){info_cut << "[" << setw(2) << i_a << "]   before removal:  NUMBER(jet) = " << NUMBER("jet") << endl;}
	  PARTICLE("jet").erase(PARTICLE("jet").begin() + i_j);
	  NUMBER("jet")--;
	  i_j--;
	  for (int j_j = 0; j_j < NUMBER("jet"); j_j++){
	    if (osi_switch_output_cutinfo){info_cut << "[" << setw(2) << i_a << "]   after removal:   PARTICLE(jet)[" << j_j << "] = " << PARTICLE("jet")[j_j].momentum << endl;}
	  }
	  if (osi_switch_output_cutinfo){info_cut << "[" << setw(2) << i_a << "]   after removal:   NUMBER(jet) = " << NUMBER("jet") << endl;}
	  break;
	}
      }
    }
  }



  // cut on the modified number of jets (must be after modifying jet content, ie, after R_ejet/R_mujet cut!)
  if (osi_switch_output_cutinfo){info_cut << "[" << setw(2) << i_a << "]" << "   switch_n_jet_modified = " << switch_n_jet_modified << endl;}
  if (switch_n_jet_modified){
    //    if (osi_switch_output_cutinfo){info_cut << "[" << setw(2) << i_a << "]   NUMBER(jet) = " << NUMBER("jet") << endl;}
    if (osi_switch_output_cutinfo){info_cut << "[" << setw(2) << i_a << "]   " << cut_n_jet_min_modified << " <= n_jet_modified = " << NUMBER("jet") << " <= " << cut_n_jet_max_modified << endl;}
    if (NUMBER("jet") < cut_n_jet_min_modified || NUMBER("jet") > cut_n_jet_max_modified){
      osi_cut_ps[i_a] = -1;
      if (osi_switch_output_cutinfo){
	info_cut << "[" << setw(2) << i_a << "]" << "   individual cut after n_jet_modified" << endl; 
	logger << LOG_DEBUG << endl << info_cut.str(); 
      }
      logger << LOG_DEBUG_VERBOSE << " cut applied" << endl; 
      return;
    }
  }



  // technical cut on pT_W - should not be necessary !!!
  if (osi_switch_output_cutinfo){info_cut << "[" << setw(2) << i_a << "]" << "   switch_cut_pT_W = " << switch_cut_pT_W << endl;}
  if (switch_cut_pT_W){
    particle wplus = PARTICLE("lp")[0] + PARTICLE("nu")[0];
    particle wminus = PARTICLE("lm")[0] + PARTICLE("nux")[0];
    if (switch_cut_pT_W == 1 ||
	(switch_cut_pT_W == 2 && (osi_type_contribution == "RVA" || 
				  osi_type_contribution == "RRA" || 
				  osi_type_contribution == "RCA" || 
				  osi_type_contribution == "VT2" || 
				  osi_type_contribution == "CT2"))){
      if (wminus.pT < cut_min_pT_W){
	osi_cut_ps[i_a] = -1;
	if (osi_switch_output_cutinfo){
	  info_cut << "[" << setw(2) << i_a << "]" << "   individual cut after technical cut on W- pT." << endl;
	  logger << LOG_DEBUG << endl << info_cut.str();
	}
	return;
      }
      if (wplus.pT < cut_min_pT_W){
	osi_cut_ps[i_a] = -1;
	if (osi_switch_output_cutinfo){
	  info_cut << "[" << setw(2) << i_a << "]" << "   individual cut after technical cut on W+ pT." << endl;
	  logger << LOG_DEBUG << endl << info_cut.str();
	}
	return;
      }
      if (wminus.pT > cut_max_pT_W){
	osi_cut_ps[i_a] = -1;
	if (osi_switch_output_cutinfo){
	  info_cut << "[" << setw(2) << i_a << "]" << "   individual cut after technical cut on W- pT." << endl;
	  logger << LOG_DEBUG << endl << info_cut.str();
	}
	return;
      }
      if (wplus.pT > cut_max_pT_W){
	osi_cut_ps[i_a] = -1;
	if (osi_switch_output_cutinfo){
	  info_cut << "[" << setw(2) << i_a << "]" << "   individual cut after technical cut on W+ pT." << endl;
	  logger << LOG_DEBUG << endl << info_cut.str();
	}
	return;
      }
    }
  }


  // cut on axial ETmiss
  if (switch_axial_ETmiss == 1){
    
    double ET_miss = PARTICLE("missing")[0].pT;
    double phi_miss = PARTICLE("missing")[0].phi;
    double phi_Z    = (PARTICLE("lep")[0].momentum+PARTICLE("lep")[1].momentum).phi();
    double temp_dphi = abs(phi_miss - phi_Z);
    if (temp_dphi > pi){temp_dphi = f2pi - temp_dphi;}
    double axial_ETmiss = - ET_miss * cos(temp_dphi);
    if (axial_ETmiss < cut_min_axial_ETmiss){
      osi_cut_ps[i_a] = -1; 
    }
  }

  // cut on pT balance betwen Z bosons
  if (switch_pT_balance_Zs == 1){
    double pT_miss = PARTICLE("missing")[0].pT;
    double pT_Z    = (PARTICLE("lep")[0].momentum+PARTICLE("lep")[1].momentum).pT();
    double pT_balance_Zs = abs(pT_miss-pT_Z)/pT_Z;
    if (pT_balance_Zs > cut_max_pT_balance_Zs){
      osi_cut_ps[i_a] = -1; 
    }
  }

  if (switch_cut_dy_WpWm){
    particle wplus = PARTICLE("lp")[0] + PARTICLE("nu")[0];
    particle wminus = PARTICLE("lm")[0] + PARTICLE("nux")[0];
    double dy_WpWm = wplus.rapidity - wminus.rapidity;
    if (dy_WpWm < cut_min_dy_WpWm){
      osi_cut_ps[i_a] = -1;
      return;
    }
    if (dy_WpWm > cut_max_dy_WpWm){
      osi_cut_ps[i_a] = -1;
      return;
    }
  }

  if (osi_switch_output_cutinfo){info_cut << "[" << setw(2) << i_a << "]   individual event selection passed" << endl;}
  if (osi_switch_output_cutinfo){logger << LOG_DEBUG << endl << info_cut.str();}

}
