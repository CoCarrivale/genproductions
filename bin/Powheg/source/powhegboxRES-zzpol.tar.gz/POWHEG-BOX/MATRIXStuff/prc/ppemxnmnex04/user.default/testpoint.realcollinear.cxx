{
  osi_z_coll[1] =                       1.;
  osi_z_coll[2] =                       1.;
  osi_x_pdf[0] =                       0.;
  osi_x_pdf[1] =                       0.;
  osi_x_pdf[2] =                       0.;

  osi_p_parton[0][0] = fourvector(                      0.,                      0.,                      0.,                     0.);
  osi_p_parton[0][1] = fourvector(                      0.,                      0.,                      0.,                     0.);
  osi_p_parton[0][2] = fourvector(                      0.,                      0.,                      0.,                     0.);
  osi_p_parton[0][3] = fourvector(                      0.,                      0.,                      0.,                     0.);
  osi_p_parton[0][4] = fourvector(                      0.,                      0.,                      0.,                     0.);
  osi_p_parton[0][5] = fourvector(                      0.,                      0.,                      0.,                     0.);
  osi_p_parton[0][6] = fourvector(                      0.,                      0.,                      0.,                     0.);
  osi_p_parton[0][7] = fourvector(                      0.,                      0.,                      0.,                     0.);
}
