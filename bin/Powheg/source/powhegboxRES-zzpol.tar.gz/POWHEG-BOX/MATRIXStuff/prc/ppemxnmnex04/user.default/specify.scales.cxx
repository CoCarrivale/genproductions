if (sd == 1){
  fourvector Q;
  for (int i_p = 3; i_p < 7; i_p++){Q = Q + osi_p_parton[i_a][i_p];}
  temp_mu_central = Q.m();
}
