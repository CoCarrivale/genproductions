{
  osi_p_parton[0][0] = fourvector(                      0.,                      0.,                      0.,                     0.);
  osi_p_parton[0][1] = fourvector(                      0.,                      0.,                      0.,                     0.);
  osi_p_parton[0][2] = fourvector(                      0.,                      0.,                      0.,                     0.);
  osi_p_parton[0][3] = fourvector(                      0.,                      0.,                      0.,                     0.);
  osi_p_parton[0][4] = fourvector(                      0.,                      0.,                      0.,                     0.);
  osi_p_parton[0][5] = fourvector(                      0.,                      0.,                      0.,                     0.);
  osi_p_parton[0][6] = fourvector(                      0.,                      0.,                      0.,                     0.);
}
