if (osi_cut_ps[i_a] != -1){
  //  cuts ...
  //  if (){osi_cut_ps[i_a] = -1;}
}
