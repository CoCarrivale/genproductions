logger << LOG_DEBUG_VERBOSE << "user/specify.particles.cxx started" << endl;
{
  //  particles ...
  //  vector<vector<particle> > 'user_particle' with all user-defined particle candidates is filled:
  //  user_particle[oset.user.particle_map["<particle_name>"]].push_back(<particle>);
}
logger << LOG_DEBUG_VERBOSE << "user/specify.particles.cxx ended" << endl;
