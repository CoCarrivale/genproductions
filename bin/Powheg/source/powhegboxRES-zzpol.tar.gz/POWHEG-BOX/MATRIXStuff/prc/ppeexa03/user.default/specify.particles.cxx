logger << LOG_DEBUG_VERBOSE << "specify.particles.cxx started" << endl;
{
  //  particles ...
  //  vector<vector<particle> > 'user_particle' with all user-defined particle candidates is filled:
  //  USERPARTICLE("<particle_name>").push_back(<particle>);
}
logger << LOG_DEBUG_VERBOSE << "specify.particles.cxx ended" << endl;
