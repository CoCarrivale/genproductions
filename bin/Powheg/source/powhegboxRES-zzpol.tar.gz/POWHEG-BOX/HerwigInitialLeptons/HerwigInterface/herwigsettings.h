      integer eventCounter
      real * 8 scalupfac,ub_btilde_corr,ub_remn_corr, ub_corr
      common/herwigSettings/ scalupfac,ub_btilde_corr,
     2     ub_remn_corr,eventCounter
